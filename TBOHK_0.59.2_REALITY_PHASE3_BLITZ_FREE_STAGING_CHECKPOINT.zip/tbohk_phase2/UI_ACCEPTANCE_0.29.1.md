# TBOHK UI Acceptance — 0.29.1

## Verified in this build

- View/navigation parity: Home, Ask, Research, Knowledge, Investigate, Review, Assurance, Plans, Account.
- Every inline click handler has a defined JavaScript function.
- UI API paths map to server routes, including dynamic review routes.
- Account controls: subscription refresh, session listing, revoke-all, password-reset request, billing portal entry, permanent deletion flow.
- Research: plan and bounded research actions.
- Knowledge: search, gaps, conflicts.
- Investigation: candidate hypothesis generation.
- Assurance: core audit, release audit, self-care, migrations, invariants.
- Pricing: Free, Pro, Unlimited only.
- Answer external links are restricted to HTTP(S) and opened with `noopener noreferrer`.
- Sidebar navigation is event-bound and keyboard-operable as native buttons.
- Responsive layout is explicitly tested at mobile width for horizontal overflow.
- Reduced-motion CSS remains enabled for users who request it.

## Automated acceptance

- Full regression suite: 584 passed.
- Production-code coverage: 6,854 / 6,854 statements, 100%.
- Python compileall: PASS.
- Frontend JavaScript `node --check`: PASS.
- HTTP smoke: PASS for UI shell, health, pricing, account, stats, knowledge, review, release audit, assurance endpoints, billing entitlements, research planning, hypothesis generation, gaps and conflicts.
- Independent database verifier: 13 checks, 0 findings.

## Known execution-environment limitation

The local browser runner in this build environment blocks direct navigation to localhost/file/data origins with `ERR_BLOCKED_BY_ADMINISTRATOR`. Therefore pixel-level browser rendering was not claimed as verified here. DOM/event/static acceptance, JavaScript syntax, responsive CSS structure, and live HTTP API behavior were verified instead.

## Browser rendering acceptance update

A real Chromium binary (`/usr/bin/chromium`) with Playwright is available in the build environment. Direct browser navigation to `http://127.0.0.1`, `http://localhost`, and `file://` remains blocked by the sandbox policy with `ERR_BLOCKED_BY_ADMINISTRATOR`; this is an execution-environment restriction, not an application response.

To remove the practical rendering blind spot, `scripts_browser_acceptance.py` renders the exact `tbohk/ui.html` through Chromium using Playwright `set_content()` (with only the startup `boot()` call removed so network/session initialization is isolated from layout testing). It exercises all 9 production views and checks horizontal overflow at 320, 360, 390, 412, 768, and 1440 px widths.

Result: **PASS — 10 views × 6 viewport widths, zero horizontal overflow.**

The browser pass also exposed and fixed a real mobile defect: at 390 px, the header flex row previously produced 422 px document width. The mobile breakpoint now stacks the header and wraps top actions; all tested views remain within the viewport from 320 through 768 px.

The acceptance boundary is now:
- Chromium DOM/CSS/rendering/viewport acceptance: executable and passing via `scripts_browser_acceptance.py`.
- Live HTTP/API acceptance: executable and passing via the existing HTTP smoke checks.
- Full browser navigation against a local server: still blocked by the sandbox's browser navigation policy and therefore not claimed as verified.


## Commercial foundation continuation — 2026-09-26
- Transactional email adapter: SMTP verification/reset delivery with failure-safe behavior.
- Public legal/support routes: `/legal/privacy`, `/legal/terms`, `/support`.
- UI footer links to all three public surfaces.
- Full regression: 587 passed.
- Production coverage: 6,921 statements, 0 missed, 100%.
- Chromium acceptance: 10 views × 6 viewport widths, no horizontal overflow.


## Learning canary

The Learning Lab exposes isolated adapter experiments and a controlled canary check. Canary evidence records continue/rollback decisions and does not deploy candidates.
