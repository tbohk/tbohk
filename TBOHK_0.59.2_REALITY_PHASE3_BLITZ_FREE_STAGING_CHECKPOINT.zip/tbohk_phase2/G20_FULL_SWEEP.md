# TBOHK Full Architectural Sweep — G20

## Areas already hardened
1. Persistent graph substrate and revisions
2. Research/evidence/claim chain
3. Independence and contradiction handling
4. Reasoning and structured semantics
5. Decisions, plans, governance and authority
6. Recovery with independent validation
7. Evaluation-isolated learning
8. Bounded autonomy
9. Adversarial validation
10. Reality correspondence and post-action verification
11. Release aggregation
12. Tamper-evident graph/checkpoint integrity
13. Provenance and authenticated release identity
14. Public release attestation
15. Independent system validation
16. Long-horizon integrity
17. Dependency-aware lifecycle invalidation
18. Epistemic contamination and quarantine
19. Recovery provenance and clean reconstitution

## Remaining gaps found by the sweep

### A. Checkpoint semantics
Current checkpoints identify graph hashes but are not intrinsically self-contained backup packages. G20 adds an explicit recovery snapshot mechanism, but the checkpoint format should eventually bind the actual snapshot artifact, schema migration version, event/revision manifests, and cryptographic identity into one portable release object.

### B. Event-log immutability
Events and revisions are auditable records but are not yet an append-only hash chain with external anchoring. A privileged database writer could alter historical rows unless an external checkpoint detects the change.

### C. Key lifecycle
Public attestation exists, but production-grade key rotation, revocation, expiration, threshold/multisignature policy, and compromise recovery need explicit modeling.

### D. Source lineage / common-origin detection
Independence analysis exists, but copied-source detection and upstream-origin equivalence are still limited. Two apparently separate providers can still reproduce one upstream source.

### E. Temporal epistemics
Temporal source validity exists, but claim-level valid intervals, event-time vs processing-time semantics, timezone normalization policy, and temporal conflict reconciliation need further hardening.

### F. Uncertainty
The architecture records epistemic states and assessments, but uncertainty is not yet a fully multidimensional first-class object covering measurement error, model uncertainty, source reliability, sampling uncertainty, and interval/distribution representations.

### G. Research completeness
Research records capture strategy and stopping conditions, but a formal completeness/coverage model is still needed for large open-world questions.

### H. Conflict reconciliation
Conflict sets exist, but there is not yet a complete policy-driven reconciliation engine that can preserve incompatible hypotheses, scope them temporally, and prevent premature collapse.

### I. Security isolation
Prompt-injection/untrusted-input boundaries exist at the logical layer. Full tool/process isolation, network egress policy, credential compartmentalization, document sandboxing, and supply-chain verification remain future hardening work.

### J. Concurrency and transactional correctness
SQLite transactions are used, but multi-writer concurrency, locking behavior, crash recovery, idempotency, and exactly-once/at-least-once semantics for external actions require dedicated stress testing.

### K. Resource exhaustion
Reasoning budgets exist, but graph traversal, contamination closure, recovery export, research result volume, metadata size, and adversarial input amplification need comprehensive resource limits.

### L. Privacy/data governance
The prototype is provenance-heavy but lacks a complete data classification, retention, redaction, deletion, access-control, and privacy-preserving provenance model.

### M. Schema evolution
The graph has schema/invariant version fields, but automated migration compatibility, downgrade prevention, migration provenance, and cross-version replay tests need to be added.

### N. Deterministic replay
Core operations are largely deterministic, but full replay still needs explicit control of time, randomness, external observations, provider versions, and dependency artifacts.

### O. External action durability
The action ledger is strong structurally, but production integration still needs idempotency keys, external transaction reconciliation, timeout handling, partial-failure semantics, and compensating-action verification.

### P. Independent implementation diversity
G16 provides an independent validation path, but it is implemented in the same codebase. A stronger assurance tier would use a separately maintained verifier or independently generated conformance suite.

### Q. Formal policy specification
Many invariants are implemented as code. A future policy layer should make authority, verification, release, recovery, and escalation rules declarative, versioned, reviewable, and testable independently of their enforcement implementation.

## Priority next sequence
G21 — Immutable Event/Revision Ledger
G22 — Portable Self-Contained Checkpoint + Migration Proof
G23 — Cryptographic Key Lifecycle & Trust Recovery
G24 — Deterministic Replay & Crash/Concurrency Validation
G25 — Tool Isolation / Supply-Chain / Credential Boundary
G26 — Uncertainty + Temporal Conflict Engine
G27 — Research Completeness & Open-World Coverage
G28 — Independent Verifier / Cross-Implementation Conformance
G29 — Production Action Durability & Compensation
G30 — Final Full-System Red Team

The sweep deliberately does not treat these as failures of the current gates. They are the next assurance layers required before claiming production-grade autonomous operation.
