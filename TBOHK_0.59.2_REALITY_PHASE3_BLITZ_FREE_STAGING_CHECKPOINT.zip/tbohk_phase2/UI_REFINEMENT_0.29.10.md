# TBOHK 0.29.10 — Continuity & Question Framing Pass

## Focus
Improve the first-use and return-user experience without changing backend contracts, billing, or store integrations.

## Changes
- Added a Home **Recent investigations** panel backed by the existing local Library data.
- Added one-click **Continue** actions so saved investigations are reachable immediately from Home.
- Added Home **question patterns** for understanding a topic, verifying a claim, and comparing a decision.
- Added matching question-template controls to Ask; templates place the cursor on the bracketed placeholder for quick editing.
- Preserved the existing server-authoritative knowledge/evidence model and local-device Library disclosure.
- Preserved all existing navigation, authentication, research, review, assurance, billing, and account contracts.

## Verification
- Python compilation: PASS
- JavaScript syntax check: PASS
- Full regression suite: 677 passed
- UI acceptance suite: 16 passed
