from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable
import json

@dataclass(frozen=True)
class KindSpec:
    kind: str
    required_metadata: tuple[str, ...] = ()
    allowed_statuses: tuple[str, ...] = ()
    description: str = ""

class DomainKernel:
    """Small deterministic domain contract layer over the authoritative graph.

    It validates shape and invariants but deliberately does not decide truth.
    """
    def __init__(self, graph):
        self.g = graph
        self._specs: dict[str, KindSpec] = {}

    def register(self, spec: KindSpec) -> None:
        if not spec.kind.strip(): raise ValueError("kind required")
        self._specs[spec.kind] = spec

    def register_defaults(self) -> None:
        defaults = [
            KindSpec("Claim", ("subject",), description="Atomic knowledge assertion."),
            KindSpec("Evidence", (), description="Auditable supporting source record."),
            KindSpec("Unknown", ("scope", "basis"), description="Explicitly unresolved knowledge boundary."),
            KindSpec("Decision", ("question",), description="Decision record without automatic recommendation."),
            KindSpec("Action", ("authority",), description="Authorized or proposed operational action."),
            KindSpec("MaintenanceTask", ("task_kind", "reversible"), description="Bounded maintenance work item."),
            KindSpec("Hypothesis", ("question",), description="Falsifiable candidate explanation."),
        ]
        for spec in defaults: self.register(spec)

    def validate(self, kind: str, metadata: dict[str, Any], status: str) -> list[str]:
        spec = self._specs.get(kind)
        if not spec: return []
        errors=[]
        for key in spec.required_metadata:
            if key not in metadata or metadata[key] in (None, ""):
                errors.append(f"{kind} requires metadata.{key}")
        if spec.allowed_statuses and status not in spec.allowed_statuses:
            errors.append(f"{kind} does not allow status {status}")
        if kind == "MaintenanceTask" and metadata.get("reversible") is not True:
            errors.append("MaintenanceTask must be reversible")
        return errors

    def inspect(self, node_id: str) -> dict[str, Any]:
        n=self.g.get(node_id)
        if not n: raise KeyError(node_id)
        errors=self.validate(n.kind,n.metadata,n.status)
        return {"id":n.id,"kind":n.kind,"status":n.status,"valid":not errors,"errors":errors,"metadata_keys":sorted(n.metadata)}

    def graph_invariants(self, limit=500) -> dict[str, Any]:
        rows=self.g.db.execute("SELECT id,kind,status,metadata FROM nodes ORDER BY rowid DESC LIMIT ?",(max(1,min(int(limit),2000)),)).fetchall()
        invalid=[]
        for r in rows:
            m=json.loads(r[3]); errors=self.validate(r[1],m,r[2])
            if errors: invalid.append({"id":r[0],"kind":r[1],"errors":errors})
        return {"checked":len(rows),"invalid":invalid,"valid":not invalid}
