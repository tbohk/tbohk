from __future__ import annotations
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

from .provider_readiness import readiness
from .observability import metrics
from .worker import DurableWorkQueue

@dataclass(frozen=True)
class RuntimeCheck:
    name: str
    ok: bool
    detail: str

class ProductionRuntime:
    """Small production boundary: readiness, metrics export, and bounded worker execution."""
    def __init__(self, graph, *, artifact_root: str | None = None):
        self.g = graph
        self.queue = DurableWorkQueue(graph)
        self.artifact_root = artifact_root or os.environ.get("TBOHK_ARTIFACT_ROOT", "./artifacts")
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._worker_id = os.environ.get("TBOHK_WORKER_ID", "worker-local")

    def register(self, kind: str, handler: Callable[[dict[str, Any]], Any]) -> None:
        if not kind.strip() or not callable(handler):
            raise ValueError("kind and callable handler are required")
        self._handlers[kind] = handler

    def readiness(self) -> dict[str, Any]:
        checks = [
            RuntimeCheck("database", self.g.db is not None, "graph database available"),
            RuntimeCheck("worker_handlers", True, f"{len(self._handlers)} handler(s) registered"),
            RuntimeCheck("artifact_root", bool(self.artifact_root.strip()), self.artifact_root),
        ]
        provider = readiness()
        configured = [name for name, row in provider.items() if row["configured"]]
        return {
            "ok": all(c.ok for c in checks),
            "checks": [c.__dict__ for c in checks],
            "providers": provider,
            "configured_provider_count": len(configured),
            "mode": os.environ.get("TBOHK_ENV", "development"),
        }

    def metrics_prometheus(self) -> str:
        snap = metrics.snapshot()
        lines = [
            "# HELP tbohk_requests_total Total HTTP requests observed.",
            "# TYPE tbohk_requests_total counter",
            f"tbohk_requests_total {snap['requests']}",
            "# HELP tbohk_server_errors_total Total HTTP 5xx responses by route.",
            "# TYPE tbohk_server_errors_total counter",
        ]
        for route, count in sorted(snap["server_errors"].items()):
            lines.append(f'tbohk_server_errors_total{{route="{route}"}} {count}')
        for quantile, value in snap["latency_ms"].items():
            lines.append(f'tbohk_request_latency_ms{{quantile="{quantile}"}} {value:.3f}')
        return "\n".join(lines) + "\n"

    def run_once(self, *, limit: int = 1, lease_seconds: int = 60) -> dict[str, Any]:
        items = self.queue.lease(self._worker_id, lease_seconds=lease_seconds, limit=limit)
        completed = failed = 0
        for item in items:
            handler = self._handlers.get(item.kind)
            if handler is None:
                self.queue.fail(item.id, "no registered production handler")
                failed += 1
                continue
            try:
                handler(dict(item.payload))
                self.queue.complete(item.id)
                completed += 1
            except Exception as exc:
                self.queue.fail(item.id, f"handler failure: {type(exc).__name__}")
                failed += 1
        return {"leased": len(items), "completed": completed, "failed": failed}

    def start(self, *, interval_seconds: float = 1.0, limit: int = 1) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        def loop():
            while not self._stop.is_set():
                self.run_once(limit=limit)
                self._stop.wait(max(0.05, interval_seconds))
        self._thread = threading.Thread(target=loop, name="tbohk-worker", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        self._thread = None
