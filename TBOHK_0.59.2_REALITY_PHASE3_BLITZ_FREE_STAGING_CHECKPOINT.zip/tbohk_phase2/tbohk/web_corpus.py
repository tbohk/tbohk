from __future__ import annotations

"""Bounded, auditable ingestion of large public web corpora.

This is deliberately a *corpus learner*, not an autonomous truth engine.  It
imports source observations, provenance and retrieval metadata; it never marks
claims verified merely because a page was found.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import re
import urllib.parse
import urllib.request
from typing import Any, Iterable

from bs4 import BeautifulSoup

from .research import SourceDocument, ResearchChain, validate_source_document
from .intelligence import KnowledgeIntelligence
from .epistemic import EpistemicEngine
from . import __version__


@dataclass(frozen=True)
class CorpusBatch:
    crawl_id: str
    query: str
    batch_id: str
    cursor: str | None
    next_cursor: str | None
    candidates: int
    imported: int
    duplicates: int
    failures: int
    source_ids: tuple[str, ...]


class CommonCrawlProvider:
    """Read a bounded set of records from a Common Crawl URL index.

    Common Crawl is used as a public, timestamped corpus rather than trying to
    crawl the live Internet from the application.  A batch is intentionally
    small and resumable; the application can process billions of pages over
    many jobs without pretending that one HTTP request has "read the Internet".
    """
    provider_id = "common-crawl"
    INDEX_BASE = "https://index.commoncrawl.org"
    DATA_BASE = "https://data.commoncrawl.org/"
    DEFAULT_CRAWL = "CC-MAIN-2026-39"

    def __init__(self, crawl_id: str = DEFAULT_CRAWL, *, max_results: int = 8,
                 timeout: float = 20.0, max_bytes: int = 1_500_000):
        if not re.fullmatch(r"CC-MAIN-\d{4}-\d{2}", crawl_id):
            raise ValueError("invalid Common Crawl crawl id")
        if not 1 <= max_results <= 100:
            raise ValueError("max_results must be 1..100")
        if not 1 <= max_bytes <= 5_000_000:
            raise ValueError("max_bytes must be 1..5000000")
        self.crawl_id, self.max_results, self.timeout, self.max_bytes = crawl_id, max_results, timeout, max_bytes

    @staticmethod
    def _request(url: str, *, headers: dict[str, str] | None = None, timeout: float = 20.0) -> bytes:
        p = urllib.parse.urlparse(url)
        if p.scheme != "https" or p.hostname not in {"index.commoncrawl.org", "data.commoncrawl.org"}:
            raise ValueError("Common Crawl requests must target the approved HTTPS hosts")
        req = urllib.request.Request(url, headers={"User-Agent": f"TBOHK/{__version__} corpus-learner", **(headers or {})})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()

    def _index(self, query: str, cursor: str | None = None) -> list[dict[str, Any]]:
        terms = [re.sub(r"[^a-zA-Z0-9.-]", "", x) for x in query.split()]
        terms = [x for x in terms if x]
        if not terms:
            raise ValueError("query must contain searchable terms")
        # URL-index search is a discovery mechanism, not a claim that every
        # matching page on the Internet was found.
        pattern = "*" + "*".join(terms[:4]) + "*"
        params = {"url": pattern, "output": "json", "filter": "status:200", "collapse": "urlkey"}
        if cursor:
            params["page"] = cursor
        url = f"{self.INDEX_BASE}/{self.crawl_id}-index?{urllib.parse.urlencode(params)}"
        raw = self._request(url, timeout=self.timeout).decode("utf-8", errors="replace")
        rows = []
        for line in raw.splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get("filename") and row.get("offset") is not None and row.get("length") is not None:
                rows.append(row)
            if len(rows) >= self.max_results:
                break
        return rows

    def _record(self, row: dict[str, Any]) -> SourceDocument:
        filename = str(row["filename"]).lstrip("/")
        start = int(row["offset"]); length = int(row["length"])
        if length <= 0 or length > self.max_bytes * 2:
            raise ValueError("Common Crawl record exceeds configured compressed size limit")
        url = urllib.parse.urljoin(self.DATA_BASE, filename)
        raw = self._request(url, headers={"Range": f"bytes={start}-{start + length - 1}"}, timeout=self.timeout)
        raw = raw[:length]
        record = gzip.decompress(raw)
        header_end = record.find(b"\r\n\r\n")
        if header_end < 0:
            header_end = record.find(b"\n\n")
        if header_end < 0:
            raise ValueError("invalid WARC record")
        header = record[:header_end].decode("utf-8", errors="replace")
        body = record[header_end + (4 if b"\r\n\r\n" in record[:header_end + 4] else 2):]
        target = row.get("url") or ""
        content_type = "text/html"
        for line in header.splitlines():
            if line.lower().startswith("content-type:"):
                content_type = line.split(":", 1)[1].strip().lower()
        if len(body) > self.max_bytes:
            body = body[:self.max_bytes]
        text = body.decode("utf-8", errors="replace")
        media: list[dict[str, Any]] = []
        title = target or "Common Crawl page"
        if "html" in content_type or "<html" in text.lower():
            soup = BeautifulSoup(text, "html.parser")
            title = soup.title.get_text(" ", strip=True) if soup.title else title
            text = soup.get_text(" ", strip=True)
            # Media is metadata only; never fetch media during corpus ingestion.
            media = [{"type": "image", "url": urllib.parse.urljoin(target, t.get("src")), "alt": t.get("alt", "")}
                     for t in soup.find_all("img") if t.get("src")][:20]
        if not text.strip():
            raise ValueError("Common Crawl record has no extractable text")
        timestamp = row.get("timestamp")
        retrieved = datetime.now(timezone.utc).isoformat()
        published = None
        return SourceDocument(
            source_id="cc:" + hashlib.sha256((target + "|" + str(timestamp) + "|" + str(row.get("digest"))).encode()).hexdigest(),
            title=title[:500], uri=target, text=text[:self.max_bytes], provider_id=self.provider_id,
            retrieved_at=retrieved, origin_id=urllib.parse.urlparse(target).netloc.casefold(),
            published_at=published, media=tuple(media),
        )

    def search(self, query: str, cursor: str | None = None) -> list[SourceDocument]:
        docs: list[SourceDocument] = []
        for row in self._index(query, cursor):
            try:
                doc = self._record(row)
                validate_source_document(doc)
                docs.append(doc)
            except Exception:
                continue
        return docs


class CorpusLearningEngine:
    """Turn public-web observations into auditable research records.

    The learner stores evidence and candidate observations.  Verification and
    knowledge promotion remain governed by TBOHK's existing epistemic policies.
    """
    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _normalize_claim(text: str) -> str:
        text = re.sub(r"[^a-z0-9\s]", " ", text.casefold())
        return re.sub(r"\s+", " ", text).strip()

    def verification_triage(self, limit: int = 50) -> dict[str, Any]:
        """Return a bounded, auditable verification queue ordered by structural need.

        This is prioritization only. It never estimates truth probability or changes claim status.
        """
        limit=max(1,min(int(limit),100))
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='VerificationTask' AND status='proposed'").fetchall()
        items=[]
        for row in rows:
            task=self.g.get(row['id'])
            if not task: continue
            md=dict(task.metadata or {})
            claim=self.g.get(md.get('claim_id'))
            if not claim: continue
            evidence_ids=list(md.get('evidence_ids') or [])
            origins={str(x) for x in (md.get('independent_origins') or []) if x}
            conflict_count=0
            for edge in self.g.edges(claim.id,'in','contradicts')+self.g.edges(claim.id,'out','contradicts'):
                conflict_count += 1
            dependency_count=0
            try:
                dependency_count=len((claim.metadata or {}).get('dependency_profile',{}).get('prerequisite_ids',[]))
            except Exception: pass
            freshness_gap=0
            for eid in evidence_ids:
                e=self.g.get(eid)
                if e and not e.metadata.get('retrieved_at'): freshness_gap+=1
            # Transparent triage components; not a confidence score.
            priority=(4 if conflict_count else 0)+(3 if len(origins)<2 else 0)+(2 if not evidence_ids else 0)+(min(dependency_count,5)*0.5)+(min(freshness_gap,3)*0.25)
            items.append({"task_id":task.id,"claim_id":claim.id,"claim":claim.content,"priority":priority,
                          "evidence_count":len(evidence_ids),"independent_origin_count":len(origins),
                          "conflict_count":conflict_count,"dependency_count":dependency_count,
                          "reasons":(["open_conflict"] if conflict_count else [])+(["insufficient_source_independence"] if len(origins)<2 else [])+(["missing_evidence"] if not evidence_ids else [])})
        items.sort(key=lambda x:(-x['priority'],x['claim_id']))
        return {"items":items[:limit],"total_open_tasks":len(items),"ordering":"structural_need_only","not_a_truth_score":True}

    def _record_verification_feedback_base(self, task_id: str, *, outcome: str, evidence_pattern: str = "", notes: str = "") -> dict[str, Any]:
        task=self.g.get(task_id)
        if not task or task.kind!='VerificationTask': raise ValueError("unknown verification task")
        if outcome not in {"verified","rejected","inconclusive","superseded"}: raise ValueError("invalid verification outcome")
        md=dict(task.metadata or {})
        history=list(md.get('verification_feedback') or [])
        history.append({"outcome":outcome,"evidence_pattern":evidence_pattern[:300],"notes":notes[:1000],"recorded_at":datetime.now(timezone.utc).isoformat()})
        md['verification_feedback']=history[-20:]
        md['last_outcome']=outcome
        md['resolved']=outcome in {"verified","rejected","superseded"}
        self.g.update_metadata(task.id,md,reason="verification feedback recorded")
        return {"task_id":task.id,"outcome":outcome,"feedback_count":len(md['verification_feedback']),"resolved":md['resolved']}

    def research_tactic_history(self, *, limit: int = 50) -> dict[str, Any]:
        limit=max(1,min(int(limit),100))
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='VerificationFeedbackProfile' ORDER BY rowid DESC LIMIT 200").fetchall()
        profiles=[]
        for row in rows:
            n=self.g.get(row['id'])
            if n:
                profiles.append(dict(n.metadata or {}, profile_id=n.id))
        profiles.sort(key=lambda x:(-float(x.get('resolved_count',0)), -float(x.get('success_rate',0))))
        return {"profiles":profiles[:limit],"bounded":True,"basis":"verification outcomes only"}

    def recommend_research_tactics(self, claim_id: str, *, limit: int = 5) -> dict[str, Any]:
        claim=self.g.get(claim_id)
        if not claim or claim.kind!='Claim': raise ValueError("unknown claim")
        md=dict(claim.metadata or {})
        evidence_ids=list(md.get('evidence_ids') or [])
        origins=set()
        for eid in evidence_ids:
            e=self.g.get(eid)
            if e and e.metadata.get('origin_id'): origins.add(str(e.metadata['origin_id']))
        tactics=[]
        if len(origins)<2: tactics.append(("independent_source","Add evidence from an independent origin",3.0))
        if not evidence_ids: tactics.append(("coverage_search","Gather initial evidence",3.0))
        if any(not (self.g.get(eid) and self.g.get(eid).metadata.get('retrieved_at')) for eid in evidence_ids): tactics.append(("provenance_recheck","Strengthen provenance and retrieval metadata",2.0))
        if (md.get('dependency_profile') or {}).get('prerequisite_ids'): tactics.append(("dependency_recheck","Inspect foundational prerequisites before accepting downstream support",1.5))
        if self.g.db.execute("SELECT 1 FROM edges WHERE relation='contradicts' AND (source_id=? OR target_id=?) LIMIT 1",(claim.id,claim.id)).fetchone(): tactics.append(("conflict_resolution","Resolve conflicting evidence or claims",3.5))
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='VerificationFeedbackProfile'").fetchall()
        learned=[]
        for row in rows:
            n=self.g.get(row['id']); m=dict(n.metadata or {}) if n else {}
            if m.get('tactic') and m.get('success_rate') is not None:
                learned.append((m['tactic'],float(m.get('success_rate',0)),int(m.get('resolved_count',0))))
        for key,rate,count in learned:
            for i,(t,label,score) in enumerate(tactics):
                if t==key: tactics[i]=(t,label,score + min(1.5,rate*1.5) if count else score)
        seen=set(); out=[]
        for t,label,score in sorted(tactics,key=lambda x:(-x[2],x[0])):
            if t not in seen: out.append({"tactic":t,"label":label,"structural_basis":round(score,2),"history_used":any(x[0]==t for x in learned)}); seen.add(t)
        return {"claim_id":claim.id,"recommendations":out[:max(1,min(int(limit),10))],"selection_policy":"bounded structural needs plus historical verification outcomes; not a truth score"}

    def record_verification_feedback(self, task_id: str, *, outcome: str, evidence_pattern: str = "", notes: str = "") -> dict[str, Any]:
        result=self._record_verification_feedback_base(task_id, outcome=outcome, evidence_pattern=evidence_pattern, notes=notes)
        task=self.g.get(task_id); md=dict(task.metadata or {}) if task else {}
        tactic=str(md.get('recommended_tactic') or evidence_pattern or 'unspecified')[:120]
        key=hashlib.sha256((tactic+'|'+str(evidence_pattern)).encode()).hexdigest()[:24]
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='VerificationFeedbackProfile'").fetchall()
        profile=None
        for row in rows:
            n=self.g.get(row['id'])
            if n and (n.metadata or {}).get('profile_key')==key: profile=n; break
        if not profile:
            profile=self.g.add_node('VerificationFeedbackProfile',tactic,'supported',{'profile_key':key,'tactic':tactic,'evidence_pattern':evidence_pattern[:300],'resolved_count':0,'attempt_count':0,'success_count':0,'success_rate':0.0})
        pm=dict(profile.metadata or {}); pm['attempt_count']=int(pm.get('attempt_count',0))+1
        if outcome in {'verified','rejected','superseded'}:
            pm['resolved_count']=int(pm.get('resolved_count',0))+1
            if outcome=='verified': pm['success_count']=int(pm.get('success_count',0))+1
        pm['success_rate']=round(pm['success_count']/max(1,pm['resolved_count']),4)
        pm['last_outcome']=outcome; pm['updated_at']=datetime.now(timezone.utc).isoformat()
        self.g.update_metadata(profile.id,pm,reason='verification outcome learned as bounded research-pattern feedback')
        result['feedback_profile_id']=profile.id; result['tactic']=tactic; result['success_rate']=pm['success_rate']
        return result

    def learn_batch(self, query: str, *, crawl_id: str = CommonCrawlProvider.DEFAULT_CRAWL,
                    max_results: int = 8, cursor: str | None = None, max_claims: int = 30) -> dict[str, Any]:
        """Run one bounded web-learning cycle.

        Ingestion, candidate extraction, deduplication, independence analysis,
        contradiction detection, and verification-task generation happen in one
        auditable cycle. Candidate claims never become verified knowledge here.
        """
        batch = self.ingest_batch(query, crawl_id=crawl_id, max_results=max_results, cursor=cursor)
        evidence_ids = [x["evidence"] for x in batch.get("results", [])]
        intelligence = KnowledgeIntelligence(self.g)
        # Extract conservatively, then collapse exact normalized duplicates so
        # repeated reporting becomes multiple evidence links to one candidate.
        raw_ids = intelligence.extract_claim_candidates(evidence_ids, max_claims=max_claims * 2)
        raw_ids += intelligence.extract_structured_claim_candidates(evidence_ids, max_claims=max_claims * 2)
        groups: dict[str, list[str]] = {}
        for cid in raw_ids:
            c = self.g.get(cid)
            if c:
                groups.setdefault(self._normalize_claim(c.content), []).append(cid)
        candidate_ids=[]
        verification_tasks=[]
        for norm, ids in list(groups.items())[:max_claims]:
            first=self.g.get(ids[0])
            if not first: continue
            evidence=set(first.metadata.get("evidence_ids", []))
            for cid in ids[1:]:
                c=self.g.get(cid)
                if c: evidence.update(c.metadata.get("evidence_ids", []))
            if len(ids)>1:
                first_meta=dict(first.metadata)
                for other_id in ids[1:]:
                    other=self.g.get(other_id)
                    if other and other.metadata.get("structured") and not first_meta.get("structured"):
                        first_meta["structured"]=other.metadata["structured"]
                        first_meta["candidate_origin"]=other.metadata.get("candidate_origin", first_meta.get("candidate_origin"))
                first_meta.update({"merged_candidate_ids":ids,"evidence_ids":sorted(evidence),"candidate_group_size":len(ids)})
                self.g.update_metadata(first.id, first_meta, reason="web learning candidate deduplication")
                for cid in ids[1:]:
                    try: self.g.set_status(cid, "superseded", f"merged into candidate {first.id}")
                    except Exception: pass
                    self.g.link(cid, "same_as", first.id)
            origins=set()
            for eid in evidence:
                e=self.g.get(eid)
                if e and e.metadata.get("origin_id"): origins.add(e.metadata["origin_id"])
            candidate_ids.append(first.id)
            task_status="ready_for_independent_verification" if len(origins)>=2 else "needs_independent_evidence"
            task=self.g.add_node("VerificationTask", first.content, "proposed", {
                "claim_id":first.id,"query":query,"evidence_ids":sorted(evidence),
                "independent_origins":sorted(origins),"independent_origin_count":len(origins),
                "status":task_status,"automatic_verification":False,
                "recommended_tactic":("independent_source" if len(origins)<2 else "conflict_resolution" if self.g.db.execute("SELECT 1 FROM edges WHERE relation='contradicts' AND (source_id=? OR target_id=?) LIMIT 1",(first.id,first.id)).fetchone() else "coverage_search"),
                "reason":"candidate extracted from public corpus; promotion requires governed verification"
            })
            self.g.link(task.id,"evaluates",first.id)
            verification_tasks.append(task.id)
        # Detect structured disagreements among candidates in this cycle.
        structured=[]
        for cid in candidate_ids:
            c=self.g.get(cid); st=(c.metadata or {}).get("structured") if c else None
            if st and st.get("subject") and st.get("predicate"):
                structured.append((cid,st))
        conflicts=[]
        for i,(a,sa) in enumerate(structured):
            for b,sb in structured[i+1:]:
                if (sa.get("subject","").casefold()==sb.get("subject","").casefold() and
                    sa.get("predicate","").casefold()==sb.get("predicate","").casefold() and
                    sa.get("object","").casefold()!=sb.get("object","").casefold()):
                    exists=self.g.db.execute("SELECT 1 FROM edges WHERE relation='contradicts' AND ((source_id=? AND target_id=?) OR (source_id=? AND target_id=?))",(a,b,b,a)).fetchone()
                    if not exists:
                        conflict=EpistemicEngine(self.g).contradict(a,b,"same subject/predicate with differing extracted objects from web corpus")
                        conflicts.append(conflict.id)
        cycle=self.g.add_node("WebLearningCycle", query, "supported", {
            "batch_id":batch["batch"]["batch_id"],"query":query,"crawl_id":crawl_id,
            "candidate_claim_ids":candidate_ids,"verification_task_ids":verification_tasks,
            "conflict_ids":conflicts,"evidence_ids":evidence_ids,
            "next_cursor":batch["batch"].get("next_cursor"),
            "authority_boundary":"candidate_learning_only; no automatic truth promotion"
        })
        return {"cycle_id":cycle.id,"batch":batch["batch"],"candidate_claim_ids":candidate_ids,
                "verification_task_ids":verification_tasks,"conflict_ids":conflicts,
                "evidence_count":len(evidence_ids),
                "next_cursor":batch["batch"].get("next_cursor"),
                "learning_boundary":"candidate extraction and verification planning only"}

    def ingest_batch(self, query: str, *, crawl_id: str = CommonCrawlProvider.DEFAULT_CRAWL,
                     max_results: int = 8, cursor: str | None = None) -> dict[str, Any]:
        provider = CommonCrawlProvider(crawl_id, max_results=max_results)
        activity = self.g.add_node("CorpusIngestion", query, "proposed", {
            "query": query, "crawl_id": crawl_id, "bounded_batch": max_results,
            "cursor": cursor, "learning_policy": "observations_only_until_verification",
        })
        docs = provider.search(query, cursor)
        # Reuse the audited research ingestion path.  It records origins,
        # snapshots, evidence, duplicate suppression and prompt-injection boundaries.
        out = ResearchChain(self.g, [StaticDocumentsProvider("common-crawl", docs)]).run(
            query, stopping_condition=f"bounded Common Crawl batch <= {max_results}"
        )
        imported = len(out["results"])
        for _, evidence in out["results"]:
            self.g.link(activity.id, "uses", evidence.id)
        next_cursor = str(int(cursor or 0) + 1) if len(docs) >= max_results else None
        batch = CorpusBatch(crawl_id, query, activity.id, cursor, next_cursor,
                            len(docs), imported, 0, len(docs) - imported,
                            tuple(e.id for _, e in out["results"]))
        self.g.update_metadata(activity.id, {"result": asdict(batch), "status": "completed"}, reason="corpus batch completed")
        return {"batch": asdict(batch), "research_record": out["research_record"],
                "results": [{"snapshot": s.id, "evidence": e.id} for s, e in out["results"]]}


class StaticDocumentsProvider:
    def __init__(self, provider_id: str, documents: Iterable[SourceDocument]):
        self.provider_id = provider_id
        self.documents = list(documents)

    def search(self, query: str):
        return self.documents
