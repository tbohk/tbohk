from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from .core import TBOHK

@dataclass(frozen=True)
class InvestigationState:
    question: str
    hypotheses: tuple[str, ...]
    supporting_evidence: tuple[str, ...]
    contradicting_evidence: tuple[str, ...]
    independent_origins: tuple[str, ...]
    dependent_origins: tuple[str, ...]
    unresolved_conflicts: tuple[str, ...]
    stale_evidence: tuple[str, ...]
    unresolved_targets: tuple[str, ...]
    cycle_count: int
    stopping_reason: str
    state_revision: int = 1
    previous_state_id: str | None = None
    changed_fields: tuple[str, ...] = ()
    as_of: str | None = None

@dataclass(frozen=True)
class InvestigationStateDelta:
    """Structural difference between two immutable investigation states.

    Drivers are explicitly framed as candidate structural drivers, not causal
    proof, truth probabilities, or explanations of why evidence exists.
    """
    run_id: str
    from_state_id: str | None
    to_state_id: str
    from_revision: int
    to_revision: int
    changed_fields: tuple[str, ...]
    added: dict[str, tuple[str, ...]]
    removed: dict[str, tuple[str, ...]]
    candidate_drivers: tuple[str, ...]
    new_evidence_ids: tuple[str, ...]
    temporal_horizon_changed: bool


class InvestigationStateEngine:
    """Builds a deterministic, auditable state from an adaptive research run.

    Counts evidence structurally; it never converts counts into truth probabilities
    and never changes hypothesis/claim status as a side effect.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _cycles(self, run_id):
        out=[]
        for e in self.g.edges(run_id, direction='out', relation='contains'):
            n=self.g.get(e['target_id'])
            if n and n.kind == 'AdaptiveResearchCycle': out.append(n)
        return sorted(out, key=lambda n: int(n.metadata.get('cycle', 0)))

    def build(self, run_id: str, hypothesis_ids: list[str] | None = None, *, through_cycle: int | None = None, as_of: str | datetime | None = None) -> InvestigationState:
        run=self.g.get(run_id)
        if not run or run.kind != 'AdaptiveResearchRun':
            raise ValueError('invalid adaptive research run')
        cycles=self._cycles(run_id)
        if through_cycle is not None:
            if through_cycle < 0:
                raise ValueError('through_cycle must be non-negative')
            cycles=[c for c in cycles if int(c.metadata.get('cycle', 0)) <= through_cycle]
        if isinstance(as_of, str):
            as_of_dt=self.g._parse_time(as_of)
            if as_of_dt is None: raise ValueError('invalid as_of timestamp')
        elif as_of is not None:
            as_of_dt=as_of
        elif cycles:
            as_of_dt=self.g._parse_time(cycles[-1].created_at) or datetime.now(timezone.utc)
        else:
            as_of_dt=self.g._parse_time(run.created_at) or datetime.now(timezone.utc)
        as_of_text=as_of_dt.isoformat()
        hids=tuple(hypothesis_ids or run.metadata.get('hypothesis_ids', []))
        evidence=[]
        for c in cycles:
            for eid in c.metadata.get('evidence_ids', []):
                n=self.g.get(eid)
                if n and n.kind == 'Evidence': evidence.append(n)
        evidence_by_id={e.id:e for e in evidence}
        # Evidence without a valid origin is retained for audit/history but cannot
        # influence epistemic reconciliation.
        valid_evidence={e.id:e for e in evidence if e.metadata.get('origin_id') and self.g.get(e.metadata.get('origin_id'))}
        origins={e.metadata.get('origin_id') for e in valid_evidence.values() if e.metadata.get('origin_id')}
        # A source is treated as dependent only when the graph explicitly records
        # a dependency/derivation relation; absence of independence evidence is
        # not silently promoted to independence.
        dependent=set()
        for oid in origins:
            if any(r for r in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='depends_on' AND (source_id=? OR target_id=?)", (oid,oid))):
                dependent.add(oid)
        independent=origins-dependent
        supporting=set(); contradicting=set()
        for h in hids:
            for e in self.g.edges(h, direction='out', relation='evidence_for'):
                if e['target_id'] in valid_evidence: supporting.add(e['target_id'])
            for e in self.g.edges(h, direction='in', relation='contradicts'):
                if e['source_id'] in valid_evidence: contradicting.add(e['source_id'])
        # Evidence content may have been returned by research but not yet attached
        # to a hypothesis; it remains unresolved rather than being counted as support.
        # Conflicts are scoped to claims/hypotheses participating in this run.
        # A conflict elsewhere in the graph must never contaminate this investigation.
        relevant_claims=set(hids)
        for h in hids:
            for edge in self.g.edges(h, direction='out', relation='derives') + self.g.edges(h, direction='out', relation='produces'):
                relevant_claims.add(edge['target_id'])
        conflicts=[]
        for row in self.g.db.execute("SELECT id FROM nodes WHERE kind='ConflictSet'"):
            n=self.g.get(row['id'])
            if not n or n.status in {'resolved','superseded','rejected'}:
                continue
            members={e['target_id'] for e in self.g.edges(n.id, direction='out', relation='contains')}
            if members & relevant_claims:
                conflicts.append(n.id)
        stale=[]
        for ev in evidence:
            snaps=[self.g._snapshot_for_evidence(ev.id)]
            snaps=[s for s in snaps if s is not None]
            if snaps and all(not self.g._temporal_valid(s, as_of_dt) for s in snaps):
                stale.append(ev.id)
        targets=[]
        for c in cycles:
            tid=c.metadata.get('target_prediction_id')
            if tid: targets.append(tid)
        learning=[]
        for c in cycles:
            learning.extend(self.g.get(r['target_id']) for r in self.g.edges(c.id,direction='out',relation='evaluates') if self.g.get(r['target_id']) and self.g.get(r['target_id']).kind=='AdaptiveLearningState')
        last=learning[-1] if learning else None
        stop=last.metadata.get('rationale',['run still unresolved'])[0] if last else 'no learning state recorded'
        return InvestigationState(run.metadata.get('question',run.content),hids,tuple(sorted(supporting)),tuple(sorted(contradicting)),tuple(sorted(independent)),tuple(sorted(dependent)),tuple(sorted(conflicts)),tuple(sorted(stale)),tuple(sorted(set(targets))),len(cycles),stop, as_of=as_of_text)

    def history(self, run_id: str) -> tuple[dict, ...]:
        run=self.g.get(run_id)
        if not run or run.kind != 'AdaptiveResearchRun':
            raise ValueError('invalid adaptive research run')
        rows=self.g.db.execute(
            "SELECT id FROM nodes WHERE kind='InvestigationState' AND json_extract(metadata, '$.run_id')=? ORDER BY CAST(json_extract(metadata, '$.state_revision') AS INTEGER), rowid",
            (run_id,),
        ).fetchall()
        return tuple(self.g.get(r['id']).metadata | {'id': r['id']} for r in rows if self.g.get(r['id']))

    @staticmethod
    def _state_data(meta: dict) -> dict:
        fields = (
            "hypotheses", "supporting_evidence", "contradicting_evidence",
            "independent_origins", "dependent_origins", "unresolved_conflicts",
            "stale_evidence", "unresolved_targets", "cycle_count",
            "stopping_reason", "as_of",
        )
        return {k: meta.get(k, []) if k != "cycle_count" and k != "stopping_reason" and k != "as_of" else meta.get(k) for k in fields}

    def delta(self, run_id: str, from_state_id: str | None, to_state_id: str) -> InvestigationStateDelta:
        run = self.g.get(run_id)
        to_state = self.g.get(to_state_id)
        if not run or run.kind != "AdaptiveResearchRun":
            raise ValueError("invalid adaptive research run")
        if not to_state or to_state.kind != "InvestigationState" or to_state.metadata.get("run_id") != run_id:
            raise ValueError("to_state_id must reference a state from the same run")
        from_state = self.g.get(from_state_id) if from_state_id else None
        if from_state_id and (not from_state or from_state.kind != "InvestigationState" or from_state.metadata.get("run_id") != run_id):
            raise ValueError("from_state_id must reference a state from the same run")
        before = self._state_data(from_state.metadata) if from_state else {k: ([] if k not in {"cycle_count", "stopping_reason", "as_of"} else None) for k in self._state_data(to_state.metadata)}
        after = self._state_data(to_state.metadata)
        added = {}; removed = {}; changed = []
        list_fields = {"hypotheses", "supporting_evidence", "contradicting_evidence", "independent_origins", "dependent_origins", "unresolved_conflicts", "stale_evidence", "unresolved_targets"}
        for field in after:
            if field in list_fields:
                a=set(before.get(field) or []); b=set(after.get(field) or [])
                if a != b:
                    changed.append(field); added[field]=tuple(sorted(b-a)); removed[field]=tuple(sorted(a-b))
            elif before.get(field) != after.get(field):
                changed.append(field)
        new_evidence=set(added.get("supporting_evidence",())) | set(added.get("contradicting_evidence",())) | set(added.get("stale_evidence",()))
        prior_all=set(before.get("supporting_evidence") or ()) | set(before.get("contradicting_evidence") or ()) | set(before.get("stale_evidence") or ())
        current_all=set(after.get("supporting_evidence") or ()) | set(after.get("contradicting_evidence") or ()) | set(after.get("stale_evidence") or ())
        if from_state:
            new_evidence |= current_all - prior_all
        else:
            new_evidence = current_all
        drivers=[]
        if new_evidence: drivers.append("new_or_newly_relevant_evidence")
        if before.get("as_of") != after.get("as_of"): drivers.append("temporal_horizon_changed")
        if before.get("hypotheses") != after.get("hypotheses"): drivers.append("hypothesis_set_changed")
        if before.get("unresolved_conflicts") != after.get("unresolved_conflicts"): drivers.append("conflict_membership_changed")
        if before.get("stale_evidence") != after.get("stale_evidence"): drivers.append("evidence_freshness_reconciled")
        if not drivers and changed: drivers.append("structural_reconciliation_changed")
        return InvestigationStateDelta(
            run_id, from_state_id, to_state_id,
            int(from_state.metadata.get("state_revision", 0)) if from_state else 0,
            int(to_state.metadata.get("state_revision", 0)),
            tuple(sorted(changed)), added, removed, tuple(drivers), tuple(sorted(new_evidence)),
            before.get("as_of") != after.get("as_of"),
        )

    def record_delta(self, run_id: str, delta: InvestigationStateDelta) -> str:
        state = self.g.get(delta.to_state_id)
        if not state or state.kind != "InvestigationState" or state.metadata.get("run_id") != run_id:
            raise ValueError("delta target must reference a state from the same run")
        n = self.g.add_node("InvestigationStateDelta", f"state delta {delta.from_revision}->{delta.to_revision} for {run_id}", "supported", {
            "run_id": run_id, "from_state_id": delta.from_state_id, "to_state_id": delta.to_state_id,
            "from_revision": delta.from_revision, "to_revision": delta.to_revision,
            "changed_fields": list(delta.changed_fields),
            "added": {k:list(v) for k,v in delta.added.items()},
            "removed": {k:list(v) for k,v in delta.removed.items()},
            "candidate_drivers": list(delta.candidate_drivers),
            "new_evidence_ids": list(delta.new_evidence_ids),
            "temporal_horizon_changed": delta.temporal_horizon_changed,
            "causal_boundary": "candidate structural drivers only; not causal proof, truth probability, or explanation of evidence generation",
        })
        self.g.link(state.id, "records", n.id)
        return n.id

    def record(self, run_id: str, state: InvestigationState, *, previous_state_id: str | None = None) -> str:
        previous=self.g.get(previous_state_id) if previous_state_id else None
        if previous_state_id and (not previous or previous.kind != 'InvestigationState' or previous.metadata.get('run_id') != run_id):
            raise ValueError('previous_state_id must reference a state from the same run')
        revision=(int(previous.metadata.get('state_revision', 0))+1) if previous else 1
        previous_data=previous.metadata if previous else {}
        current_data={
            'hypotheses':list(state.hypotheses),
            'supporting_evidence':list(state.supporting_evidence),
            'contradicting_evidence':list(state.contradicting_evidence),
            'independent_origins':list(state.independent_origins),
            'dependent_origins':list(state.dependent_origins),
            'unresolved_conflicts':list(state.unresolved_conflicts),
            'stale_evidence':list(state.stale_evidence),
            'unresolved_targets':list(state.unresolved_targets),
            'cycle_count':state.cycle_count,
            'stopping_reason':state.stopping_reason,
            'as_of':state.as_of,
        }
        changed=tuple(sorted(k for k,v in current_data.items() if previous_data.get(k) != v))
        n=self.g.add_node('InvestigationState', f'investigation state for {run_id} cycle {state.cycle_count}', 'supported', {
            'run_id':run_id, 'question':state.question, 'hypotheses':list(state.hypotheses),
            'supporting_evidence':list(state.supporting_evidence), 'contradicting_evidence':list(state.contradicting_evidence),
            'independent_origins':list(state.independent_origins), 'dependent_origins':list(state.dependent_origins),
            'unresolved_conflicts':list(state.unresolved_conflicts), 'stale_evidence':list(state.stale_evidence),
            'unresolved_targets':list(state.unresolved_targets), 'cycle_count':state.cycle_count,
            'stopping_reason':state.stopping_reason,
            'as_of':state.as_of,
            'state_revision':revision,
            'previous_state_id':previous_state_id,
            'changed_fields':list(changed),
            'truth_boundary':'structural investigation state; not a truth score or probability and does not alter hypothesis status',
        })
        self.g.link(run_id,'evaluates',n.id)
        if previous_state_id:
            self.g.link(n.id,'supersedes',previous_state_id)
        return n.id
