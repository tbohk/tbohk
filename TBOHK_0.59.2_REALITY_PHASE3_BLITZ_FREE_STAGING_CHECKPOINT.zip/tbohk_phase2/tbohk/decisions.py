from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone

@dataclass(frozen=True)
class DecisionResult:
    decision_id:str
    option_ids:tuple[str,...]

class DecisionEngine:
    def __init__(self,graph): self.g=graph
    def propose(self,title,options,*,criteria=None,evidence_ids=None,authority='analyst'):
        if not options: raise ValueError('decision needs options')
        d=self.g.add_node('Decision',title,'proposed',{'options':list(options),'criteria':criteria or [],'evidence_ids':evidence_ids or [],'authority':authority,'created_at':datetime.now(timezone.utc).isoformat()})
        for oid in evidence_ids or []: self.g.link(d.id,'based_on',oid)
        for i,opt in enumerate(options):
            o=self.g.add_node('DecisionOption',str(opt),'proposed',{'decision_id':d.id,'position':i})
            self.g.link(d.id,'contains',o.id)
        return DecisionResult(d.id,tuple(x['target_id'] for x in self.g.edges(d.id,'out','contains')))
    def approve(self,decision_id,*,authority_grant_id,reason=''):
        grant=self.g.get(authority_grant_id)
        if not grant or grant.kind!='AuthorityGrant' or grant.status!='verified': raise PermissionError('verified authority grant required')
        d=self.g.get(decision_id)
        if not d or d.kind!='Decision': raise ValueError('invalid decision')
        self.g.set_status(decision_id,'verified',reason)
        self.g.link(decision_id,'approved_by',authority_grant_id)
        return self.g.get(decision_id)
