from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Callable, Iterable

@dataclass(frozen=True)
class Invariant:
    id: str
    title: str
    statement: str
    severity: str
    detection: str
    remediation: str
    release_blocking: bool = True

INVARIANTS: tuple[Invariant, ...] = (
    Invariant("I1","Graph identity","Node and edge identity must remain structurally valid; self-links are forbidden.","critical","core audit / independent validator","quarantine and restore from a verified checkpoint"),
    Invariant("I2","Epistemic support","Verified claims, decisions and knowledge require explicit supporting or verification lineage.","critical","core audit","re-evaluate through the governing workflow"),
    Invariant("I3","Provenance attribution","Generated artifacts and activities retain attributable provenance.","critical","provenance audit","quarantine the affected lineage"),
    Invariant("I4","Temporal coherence","Time fields and validity intervals must be parseable and non-inverted.","high","core temporal audit","invalidate or repair through an audited proposal"),
    Invariant("I5","Authority boundary","Capability never implies authority; executable actions require a valid scoped authority grant.","critical","independent validator","revoke/quarantine and require independent authorization"),
    Invariant("I6","No self-authorization","Autonomous or evaluation components cannot grant themselves authority.","critical","independent validator","quarantine proposal and require external assessment"),
    Invariant("I7","Action durability","Consequential actions require durable records and post-action verification/compensation information.","critical","independent validator","stop execution and reconcile with reality"),
    Invariant("I8","Untrusted input isolation","External content cannot cross into authority, execution or policy channels merely by being ingested.","critical","boundary/red-team audit","quarantine the contaminated path"),
    Invariant("I9","Checkpoint integrity","A checkpoint manifest and its recorded digest must agree with the observed state.","critical","checkpoint verifier","restore from an independently verified checkpoint"),
    Invariant("I10","Ledger continuity","Event and revision chains must remain continuous and consistent with their anchors.","critical","ledger auditor","freeze writes and investigate forensic discrepancy"),
    Invariant("I11","Canonical representation","Security-sensitive serialized objects use a versioned canonical representation.","high","serialization verifier","migrate through the registered schema version"),
    Invariant("I12","Migration monotonicity","Schema migrations are ordered, recorded, idempotent and never silently skipped.","critical","migration manager","restore and replay migrations from a known version"),
    Invariant("I13","Independent verification","At least one release path must validate critical state without invoking the primary release auditor implementation.","critical","independent verifier","block release until independent verification succeeds"),
    Invariant("I14","External trust anchoring","Release/checkpoint identity must be exportable to a trust domain outside the live database.","critical","anchor verifier","create and independently retain a new signed anchor"),
    Invariant("I15","Recovery separation","Recovery cannot certify its own repair; validation must be independent of the proposal/applier.","critical","recovery lifecycle audit","rollback and require independent validation"),
    Invariant("I16","Mutation attribution","Every durable mutation has an attributable event/revision trail.","critical","ledger audit","freeze and reconstruct from checkpoint"),
    Invariant("I17","No silent repair","Observation and audit operations must not rewrite trusted knowledge or erase evidence of damage.","critical","forensic hardening tests","preserve damaged state and use explicit recovery"),
    Invariant("I18","Resource bounds","Parsing, retrieval, reasoning and recovery operations must have explicit resource limits.","high","resource/security audits","abort bounded operation and retain failure record"),
    Invariant("I19","Reproducible release","A release records code/schema/invariant/dependency/test identity sufficient to reproduce its checkpoint context.","high","checkpoint manifest","rebuild and re-attest"),
    Invariant("I20","Fail-closed degradation","Unexpected verifier/auditor failures are reported as failed checks, never as clean state.","critical","self-care/release tests","stop release and surface the exception"),
)

INVARIANT_BY_ID = {i.id: i for i in INVARIANTS}

@dataclass(frozen=True)
class TransitionRule:
    source: str
    target: str
    allowed: bool
    requires_workflow: bool = False
    rationale: str = ""

# Broad enough for legacy fixtures, but explicit enough to make sensitive transitions governed.
_ALLOWED = {
    "unknown": {"proposed","supported","failed","rejected"},
    "proposed": {"supported","verified","rejected","failed","stale"},
    "supported": {"verified","contradicted","superseded","stale","failed","rejected","resolved"},
    "verified": {"contradicted","superseded","stale","failed","resolved","recovered"},
    "contradicted": {"resolved","superseded","recovered"},
    "superseded": {"recovered"},
    "stale": {"proposed","supported","verified","contradicted","superseded","recovered","resolved"},
    "rejected": {"proposed","recovered"},
    "failed": {"proposed","recovered","resolved"},
    "recovered": {"proposed","supported","verified","resolved"},
    "resolved": {"recovered"},
}
_SENSITIVE = {"verified","recovered"}

def transition_rule(source: str, target: str) -> TransitionRule:
    allowed = target in _ALLOWED.get(source, set())
    return TransitionRule(source, target, allowed, target in _SENSITIVE, "sensitive targets require governing workflow" if target in _SENSITIVE else "")

def is_transition_allowed(source: str, target: str) -> bool:
    return transition_rule(source, target).allowed

def registry() -> tuple[dict, ...]:
    return tuple(asdict(i) for i in INVARIANTS)

def transition_matrix(statuses: Iterable[str]) -> tuple[dict, ...]:
    sts = tuple(statuses)
    return tuple(asdict(transition_rule(a,b)) for a in sts for b in sts if a != b)
