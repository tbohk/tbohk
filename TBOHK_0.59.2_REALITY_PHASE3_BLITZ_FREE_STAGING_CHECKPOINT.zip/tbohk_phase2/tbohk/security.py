from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
import json
import re
from typing import Any, Mapping

SECURITY_VERSION = "G4.10-1"
MAX_CONTENT_BYTES = 256_000
MAX_METADATA_BYTES = 64_000
MAX_DEPTH = 12
MAX_KEYS = 256

INSTRUCTION_PATTERNS = (
    r"\bignore\s+(?:all|any|the)\s+(?:previous|prior|above)\s+instructions\b",
    r"\b(system|developer)\s+(?:message|instruction|prompt)\b",
    r"\bdo\s+not\s+tell\s+(?:the\s+)?user\b",
    r"\breveal\s+(?:the\s+)?(?:system|developer)\s+prompt\b",
    r"\boverride\s+(?:the\s+)?(?:policy|rules|authority)\b",
    r"\bgrant\s+(?:yourself|me|this)\s+(?:permission|authority|access)\b",
)

FORBIDDEN_AUTHORITY_FIELDS = frozenset({
    "authority", "authority_grant", "capability", "permissions",
    "role", "principal", "authorization", "credential", "secret",
    "access_token", "api_key", "system_instruction", "developer_instruction",
})

@dataclass(frozen=True)
class SecurityFinding:
    code: str
    severity: str
    field: str
    detail: str

@dataclass(frozen=True)
class SecurityAssessment:
    accepted: bool
    quarantined: bool
    findings: tuple[SecurityFinding, ...]
    content_sha256: str
    security_version: str = SECURITY_VERSION

@dataclass(frozen=True)
class UntrustedInput:
    source_id: str
    content: str
    metadata: Mapping[str, Any] = field(default_factory=dict)
    trusted_instruction: bool = False

class SecurityBoundary:
    """Boundary between untrusted observations and trusted TBOHK instructions.

    Source content is data only. It cannot create authority, instructions, or
    credentials. Validation is deterministic and non-mutating.
    """
    def assess(self, item: UntrustedInput) -> SecurityAssessment:
        findings: list[SecurityFinding] = []
        content = item.content if isinstance(item.content, str) else str(item.content)
        digest = sha256(content.encode("utf-8", errors="replace")).hexdigest()
        size = len(content.encode("utf-8", errors="replace"))
        if size > MAX_CONTENT_BYTES:
            findings.append(SecurityFinding("content_too_large", "high", "content", str(size)))
        for pat in INSTRUCTION_PATTERNS:
            if re.search(pat, content, re.IGNORECASE):
                findings.append(SecurityFinding("instruction_like_source_text", "high", "content", pat))
        md = item.metadata
        if not isinstance(md, Mapping):
            findings.append(SecurityFinding("metadata_not_mapping", "high", "metadata", type(md).__name__))
            md = {}
        raw = json.dumps(md, sort_keys=True, default=str)
        if len(raw.encode("utf-8")) > MAX_METADATA_BYTES:
            findings.append(SecurityFinding("metadata_too_large", "high", "metadata", str(len(raw))))
        keys = list(md.keys())
        if len(keys) > MAX_KEYS:
            findings.append(SecurityFinding("metadata_key_limit_exceeded", "high", "metadata", str(len(keys))))
        for key in keys:
            if str(key).lower() in FORBIDDEN_AUTHORITY_FIELDS:
                findings.append(SecurityFinding("untrusted_authority_field", "critical", f"metadata.{key}", "authority-bearing field is not accepted from untrusted input"))
        depth = self._depth(md)
        if depth > MAX_DEPTH:
            findings.append(SecurityFinding("metadata_depth_exceeded", "high", "metadata", str(depth)))
        if item.trusted_instruction:
            findings.append(SecurityFinding("untrusted_item_marked_instruction", "critical", "trusted_instruction", "untrusted input cannot elevate itself"))
        quarantine = any(f.severity in {"critical", "high"} for f in findings)
        return SecurityAssessment(not quarantine, quarantine, tuple(findings), digest)

    def ingest_observation(self, item: UntrustedInput) -> tuple[UntrustedInput, SecurityAssessment]:
        """Return a data-only observation and its assessment; never returns authority."""
        assessment = self.assess(item)
        safe_metadata = {str(k): v for k, v in item.metadata.items() if str(k).lower() not in FORBIDDEN_AUTHORITY_FIELDS}
        safe = UntrustedInput(item.source_id, item.content, safe_metadata, trusted_instruction=False)
        return safe, assessment

    @staticmethod
    def _depth(value: Any, current: int = 0) -> int:
        if isinstance(value, Mapping):
            return max([current] + [SecurityBoundary._depth(v, current + 1) for v in value.values()])
        if isinstance(value, (list, tuple)):
            return max([current] + [SecurityBoundary._depth(v, current + 1) for v in value])
        return current
