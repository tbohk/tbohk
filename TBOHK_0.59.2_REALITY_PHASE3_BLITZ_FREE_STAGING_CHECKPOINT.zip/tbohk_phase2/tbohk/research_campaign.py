from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from typing import Any


@dataclass(frozen=True)
class CampaignTask:
    task_id: str
    kind: str
    question: str
    priority: int
    claim_ids: tuple[str, ...] = ()
    status: str = "planned"


class BoundedResearchCampaign:
    """Plan and execute a finite research campaign without changing truth state.

    Execution delegates explicit source acquisition to the existing research service.
    No web content is promoted automatically; every acquired observation remains
    subject to the existing evidence/verification workflow.
    """
    KINDS = {"coverage", "independence", "source_family", "scope", "time", "verification", "semantics", "counterevidence", "alternative_explanation", "primary_source", "recheck"}

    def __init__(self, graph, research_service=None, research_agent=None):
        self.g = graph
        self.service = research_service
        self.agent = research_agent

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _campaign_id(question: str) -> str:
        return "campaign_" + hashlib.sha256(question.strip().encode()).hexdigest()[:24]

    def create(self, question: str, *, claim_ids: list[str] | None = None, max_tasks: int = 8, max_sources: int = 8) -> dict[str, Any]:
        question = str(question or "").strip()
        if not question:
            raise ValueError("research question required")
        max_tasks = max(1, min(int(max_tasks), 50))
        max_sources = max(0, min(int(max_sources), 50))
        if self.agent is None:
            raise RuntimeError("research agent unavailable")
        diagnostics = self.agent.run_diagnostics(question, claim_ids=claim_ids)
        raw = diagnostics.get("plan", {}).get("steps", [])[:max_tasks]
        tasks = []
        for i, item in enumerate(raw, 1):
            kind = str(item.get("kind") or "recheck")
            if kind not in self.KINDS:
                kind = "recheck"
            q = str(item.get("action") or question).strip()
            tid = f"{self._campaign_id(question)}_task_{i:02d}"
            tasks.append(CampaignTask(tid, kind, q, int(item.get("priority") or 1), tuple(item.get("claim_ids") or ())))
        cid = self._campaign_id(question)
        node = self.g.add_node("ResearchCampaign", question, "proposed", {
            "question": question, "claim_ids": list(diagnostics.get("claim_ids", [])),
            "max_tasks": max_tasks, "max_sources": max_sources, "created_at": self._now(),
            "task_ids": [t.task_id for t in tasks], "status": "planned"
        })
        for t in tasks:
            n = self.g.add_node("ResearchTask", t.question, "proposed", {
                "campaign_id": node.id, "task_id": t.task_id, "kind": t.kind,
                "priority": t.priority, "claim_ids": list(t.claim_ids), "status": t.status
            })
            self.g.link(node.id, "contains", n.id)
        return {"campaign_id": node.id, "question": question, "tasks": [asdict(t) for t in tasks],
                "limits": {"max_tasks": max_tasks, "max_sources": max_sources},
                "stopping_rule": diagnostics.get("plan", {}).get("stopping_rule", "Stop at the configured task/source limits."),
                "truth_boundary": "Campaign execution gathers and records evidence; it does not verify or promote claims by itself."}

    def inspect(self, campaign_id: str) -> dict[str, Any]:
        c = self.g.get(campaign_id)
        if not c or c.kind != "ResearchCampaign":
            raise ValueError("invalid research campaign")
        tasks = []
        for r in self.g.edges(campaign_id, "out", "contains"):
            n = self.g.get(r["target_id"])
            if n and n.kind == "ResearchTask":
                tasks.append({"id": n.id, "task_id": (n.metadata or {}).get("task_id"), "kind": (n.metadata or {}).get("kind"),
                              "question": n.content, "priority": (n.metadata or {}).get("priority", 0),
                              "claim_ids": (n.metadata or {}).get("claim_ids", []), "status": (n.metadata or {}).get("status", n.status),
                              "metadata": n.metadata or {}})
        tasks.sort(key=lambda x: (x["priority"] * -1, x["task_id"] or ""))
        return {"campaign": {"id": c.id, "question": c.content, "status": c.status, "metadata": c.metadata or {}},
                "tasks": tasks, "truth_boundary": "Campaign state is operational metadata, not a truth or confidence score."}

    def execute(self, campaign_id: str, *, max_tasks: int | None = None) -> dict[str, Any]:
        c = self.g.get(campaign_id)
        if not c or c.kind != "ResearchCampaign":
            raise ValueError("invalid research campaign")
        meta = c.metadata or {}
        limit = int(max_tasks if max_tasks is not None else meta.get("max_tasks", 8))
        limit = max(1, min(limit, int(meta.get("max_tasks", 8))))
        task_nodes = []
        for r in self.g.edges(campaign_id, "out", "contains"):
            n = self.g.get(r["target_id"])
            if n and n.kind == "ResearchTask" and (n.metadata or {}).get("status", "proposed") in {"proposed", "planned"}:
                task_nodes.append(n)
        task_nodes.sort(key=lambda n: (-(n.metadata or {}).get("priority", 0), (n.metadata or {}).get("task_id", "")))
        selected = task_nodes[:limit]
        results = []
        for task in selected:
            tm = dict(task.metadata or {})
            tm["status"] = "executed"
            tm["executed_at"] = self._now()
            tm["execution"] = "planned_only"
            self.g.update_metadata(task.id, tm)
            # The campaign engine intentionally does not invent URLs or silently
            # perform unrestricted browsing. Explicit source acquisition remains
            # the responsibility of the existing research endpoint/provider.
            results.append({"task_id": tm.get("task_id"), "status": "executed", "kind": tm.get("kind"),
                            "action": task.content, "result": "research_action_recorded"})
        remaining = len(task_nodes) - len(selected)
        self.g.update_metadata(campaign_id, {**meta, "status": "completed" if remaining == 0 else "in_progress",
                                             "last_run_at": self._now(), "executed_task_count": len(selected)})
        return {"campaign_id": campaign_id, "executed": results, "remaining_tasks": max(0, remaining),
                "status": "completed" if remaining == 0 else "in_progress",
                "truth_boundary": "Execution records bounded research actions; it does not verify or promote claims. Evidence still requires the normal ingestion and verification pipeline."}
