from __future__ import annotations
from dataclasses import dataclass
from .gate_audit import GateAuditor
from .adversarial import AdversarialValidator
from .checkpoints import CheckpointManager
from .integrity import IntegrityAuditor
from .trust import TrustAuditor, ReleaseSigner
from .attestation import IndependentVerifier, PublicAttestation
from .independent_validation import IndependentSystemValidator
from .long_horizon import LongHorizonValidator
from .lifecycle import KnowledgeLifecycleAuditor
from .contamination import ContaminationValidator
from .reconstitution import RecoveryLifecycleAuditor
from .gates_21_30 import run_all

@dataclass(frozen=True)
class ReleaseFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    blocks_release: bool

@dataclass(frozen=True)
class ReleaseReport:
    passed: bool
    findings: tuple[ReleaseFinding, ...]

class ReleaseAuditor:
    """Final structural release gate: aggregate prior gates and verify checkpoint integrity."""
    def __init__(self, graph):
        self.g = graph

    def audit(self, *, checkpoint_id=None, signer: ReleaseSigner | None = None, trusted_public_keys=None):
        findings = []
        for f in GateAuditor(self.g).audit():
            findings.append(ReleaseFinding(f"{f.gate}:{f.code}", f.severity, f.affected, f.blocks_release))
        for f in AdversarialValidator(self.g).run():
            findings.append(ReleaseFinding(f"G10:{f.code}", f.severity, f.affected, f.blocks_release))
        for f in IndependentSystemValidator(self.g).run().findings:
            findings.append(ReleaseFinding(f"G16:{f.code}", f.severity, f.affected, f.blocks_release))
        for f in LongHorizonValidator(self.g).run(cycles=3).findings:
            findings.append(ReleaseFinding(f"G17:{f.code}", f.severity, f.affected, f.blocks_release))
        for f in KnowledgeLifecycleAuditor(self.g).audit().findings:
            findings.append(ReleaseFinding(f"G18:{f.code}", f.severity, f.affected, f.blocks_release))
        for f in RecoveryLifecycleAuditor(self.g).audit():
            findings.append(ReleaseFinding(f"G20:{f.code}", f.severity, f.affected, f.blocks_release))
        for report in run_all(self.g):
            for f in report.findings:
                findings.append(ReleaseFinding(f"{f.gate}:{f.code}", f.severity, f.affected, f.blocks_release))
        contamination_roots = tuple(r[0] for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='ContaminationRoot'").fetchall())
        for f in ContaminationValidator(self.g).audit(contamination_roots).findings:
            findings.append(ReleaseFinding(f"G19:{f.code}", f.severity, f.affected, f.blocks_release))
        core = self.g.audit()
        for node_id, code in core['problems']:
            findings.append(ReleaseFinding(f"CORE:{code}", "critical", (node_id,), True))
        try:
            from .state_machine import StateTransitionEngine
            for item in StateTransitionEngine(self.g).audit():
                findings.append(ReleaseFinding(f"STATE:{item['code']}", "critical", (item.get('node_id',''),), True))
        except Exception as exc:
            findings.append(ReleaseFinding("STATE:validator_exception", "critical", (), True))
        try:
            migration = self.g.migrations.verify()
            if not migration["ok"]:
                findings.append(ReleaseFinding("SCHEMA:migration_integrity", "critical", (), True))
        except Exception:
            findings.append(ReleaseFinding("SCHEMA:migration_validator_exception", "critical", (), True))
        if checkpoint_id is not None:
            if not CheckpointManager(self.g).verify(checkpoint_id):
                findings.append(ReleaseFinding("G12:checkpoint_integrity_failure", "critical", (checkpoint_id,), True))
            for f in IntegrityAuditor(self.g).audit_checkpoint(checkpoint_id).findings:
                findings.append(ReleaseFinding(f"G13:{f.code}", f.severity, (checkpoint_id,), True))
            if signer is not None:
                trust = TrustAuditor(self.g).verify_checkpoint(checkpoint_id, signer)
                for code in trust.findings:
                    findings.append(ReleaseFinding(f"G14:{code}", "critical", (checkpoint_id,), True))
            if trusted_public_keys is not None:
                row = self.g.db.execute("SELECT metadata FROM nodes WHERE id=?", (checkpoint_id,)).fetchone()
                try:
                    meta = __import__("json").loads(row["metadata"])
                    att = PublicAttestation(**meta["public_attestation"])
                    report = IndependentVerifier.verify(meta["manifest"], att, trusted_public_keys)
                except Exception:
                    report = type("R", (), {"passed":False,"findings":("public_attestation_missing_or_malformed",)})()
                for code in report.findings:
                    findings.append(ReleaseFinding(f"G15:{code}", "critical", (checkpoint_id,), True))
        return ReleaseReport(not any(f.blocks_release for f in findings), tuple(findings))
