from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Iterable
import hashlib, json

@dataclass(frozen=True)
class CompilationResult:
    observation_ids: tuple[str,...]
    claim_ids: tuple[str,...]
    unknown_ids: tuple[str,...]
    digest: str

class KnowledgeCompiler:
    """Deterministic compiler from observations into explicit knowledge artifacts.

    Compilation never promotes truth. Every output remains inspectable and retains
    source lineage; unresolved inputs become first-class Unknown objects.
    """
    def __init__(self, graph): self.g=graph
    def compile(self, observations: Iterable[dict[str,Any]], *, unknowns=()):
        obs_ids=[]; claim_ids=[]; unknown_ids=[]
        for o in observations:
            text=str(o.get('content','')).strip()
            if not text: continue
            n=self.g.add_node('Observation',text,'proposed',{'source_id':o.get('source_id'),'observed_at':o.get('observed_at'),'compiler':'deterministic-0.43'})
            obs_ids.append(n.id)
            subject=o.get('subject')
            if subject and o.get('predicate'):
                c=self.g.add_node('Claim',str(o.get('statement') or f"{subject} {o['predicate']} {o.get('object','')}"),'proposed',{'subject':subject,'predicate':o['predicate'],'object':o.get('object'),'origin':'knowledge_compiler','truth_boundary':'compiled candidate; requires verification'})
                self.g.link(c.id,'derived_from',n.id); claim_ids.append(c.id)
        for u in unknowns:
            scope=str(u.get('scope','')).strip(); basis=str(u.get('basis','')).strip()
            if scope and basis:
                n=self.g.add_node('Unknown',str(u.get('content') or f'Unknown within {scope}'),'proposed',{'scope':scope,'basis':basis,'compiler':'deterministic-0.43'})
                unknown_ids.append(n.id)
        payload={'observations':obs_ids,'claims':claim_ids,'unknowns':unknown_ids}
        digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return CompilationResult(tuple(obs_ids),tuple(claim_ids),tuple(unknown_ids),digest)
