from __future__ import annotations
from dataclasses import dataclass
import sqlite3
from datetime import datetime, timezone

CURRENT_SCHEMA_VERSION = 3

@dataclass(frozen=True)
class MigrationRecord:
    version: int
    name: str
    applied_at: str

class MigrationManager:
    """Small monotonic, recorded SQLite migration runner.

    The application schema may still be backward-compatible, but every structural
    version transition is explicit and recorded. Migrations are idempotent by version.
    """
    def __init__(self, db: sqlite3.Connection):
        self.db = db

    def _ensure_table(self):
        self.db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)")

    def current_version(self) -> int:
        self._ensure_table()
        row = self.db.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").fetchone()
        return int(row[0])

    def migrate(self) -> int:
        self._ensure_table()
        current = self.current_version()
        # A database created by 0.27 has all base tables but no migration ledger.
        if current == 0:
            self._record(1, "baseline-0.27-schema")
            current = 1
        migrations = {2: self._v2, 3: self._v3}
        for version in sorted(migrations):
            if version <= current:
                continue
            with self.db:
                migrations[version]()
                self._record(version, {2:"formalized-schema-metadata",3:"query-and-workflow-foundation"}[version])
            current = version
        return current

    def _record(self, version: int, name: str):
        self.db.execute("INSERT INTO schema_migrations(version,name,applied_at) VALUES (?,?,?)", (version,name,datetime.now(timezone.utc).isoformat()))

    def _v2(self):
        self.db.execute("CREATE TABLE IF NOT EXISTS schema_metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        self.db.execute("INSERT OR REPLACE INTO schema_metadata(key,value) VALUES ('schema_version','2')")
        self.db.execute("INSERT OR REPLACE INTO schema_metadata(key,value) VALUES ('serialization_version','1')")
        self.db.execute("INSERT OR REPLACE INTO schema_metadata(key,value) VALUES ('migration_contract','monotonic-recorded')")

    def history(self) -> list[MigrationRecord]:
        self._ensure_table()
        return [MigrationRecord(int(r[0]),r[1],r[2]) for r in self.db.execute("SELECT version,name,applied_at FROM schema_migrations ORDER BY version")]

    def verify(self) -> dict:
        history=self.history()
        versions=[r.version for r in history]
        contiguous=versions == list(range(1, len(versions)+1))
        return {"ok": contiguous and (not versions or versions[-1] == CURRENT_SCHEMA_VERSION), "current": versions[-1] if versions else 0, "expected": CURRENT_SCHEMA_VERSION, "history":[r.__dict__ for r in history]}

    def _v3(self):
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_nodes_kind_status ON nodes(kind,status)")
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_nodes_created ON nodes(created_at)")
        self.db.execute("CREATE TABLE IF NOT EXISTS read_model_state(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        self.db.execute("INSERT OR REPLACE INTO read_model_state(key,value) VALUES ('version','1')")

