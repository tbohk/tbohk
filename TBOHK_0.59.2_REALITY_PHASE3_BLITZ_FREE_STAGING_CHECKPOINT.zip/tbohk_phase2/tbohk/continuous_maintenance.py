from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json
from typing import Iterable

from .independence import IndependenceAnalyzer
from .evaluation_harness import EvaluationHarness


def _now(): return datetime.now(timezone.utc).isoformat()
def _parse(value):
    if not value: return None
    try: return datetime.fromisoformat(str(value).replace('Z','+00:00'))
    except Exception: return None

@dataclass(frozen=True)
class MaintenanceTask:
    task_id: str
    kind: str
    priority: str
    target_id: str | None
    reason: str
    action: str
    reversible: bool

@dataclass(frozen=True)
class MaintenancePlan:
    plan_id: str
    created_at: str
    fingerprint: str
    tasks: tuple[MaintenanceTask, ...]
    authority_boundary: str

class ContinuousMaintenanceEngine:
    """Convert existing diagnostics into bounded, inspectable maintenance work.

    This engine schedules work; it does not promote truth, execute external
    actions, or silently change epistemic status.
    """
    def __init__(self, graph): self.g = graph

    def _fingerprint(self, tasks):
        raw=json.dumps([asdict(t) for t in tasks],sort_keys=True,separators=(',',':'))
        return hashlib.sha256(raw.encode()).hexdigest()

    def _task(self, kind, priority, target, reason, action):
        return MaintenanceTask('',kind,priority,target,reason,action,True)

    def plan(self, *, max_tasks=100, include_clean=False):
        if not 1 <= max_tasks <= 500: raise ValueError('max_tasks must be 1..500')
        tasks=[]
        # Evaluation failures are explicit system-quality triggers.
        for r in self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='EvaluationRun' ORDER BY created_at DESC LIMIT 20"):
            meta=json.loads(r['metadata'])
            for action in meta.get('maintenance_actions',[]):
                if action.startswith('recheck:'):
                    suite=action.split(':',1)[1]
                    tasks.append(self._task('evaluation_recheck','high',r['id'],f'Evaluation suite {suite} requested recheck.',f'Re-run isolated {suite} evaluation.'))
            if meta.get('failed',0):
                tasks.append(self._task('evaluation_failure_review','high',r['id'],'Evaluation recorded failures.','Inspect failures before any release or truth change.'))
        # Re-evaluation queues are durable review triggers.
        for r in self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='ReEvaluationQueue' AND status IN ('proposed','supported') ORDER BY created_at DESC LIMIT 50"):
            m=json.loads(r['metadata']); total=m.get('source_counts',{}).get('total',0)
            tasks.append(self._task('knowledge_recheck','high',r['id'],f'Re-evaluation queue contains {total} impacted graph nodes.','Execute independent review items; do not auto-apply transitions.'))
        # Evidence gaps and temporal validity are first-class maintenance triggers.
        for r in self.g.db.execute("SELECT id,kind,status,metadata FROM nodes WHERE kind IN ('Claim','Knowledge','Decision') AND status IN ('verified','supported','stale') LIMIT 500"):
            m=json.loads(r['metadata'])
            if m.get('valid_until') and (_parse(m['valid_until']) or datetime.max.replace(tzinfo=timezone.utc)) <= datetime.now(timezone.utc):
                tasks.append(self._task('temporal_recheck','high',r['id'],'Declared validity interval has ended.','Re-evaluate current evidence for temporal validity.'))
            if r['kind']=='Claim':
                ev=self.g._supporting_evidence(r['id'])
                if not ev:
                    tasks.append(self._task('evidence_gap','high',r['id'],'No supporting evidence is linked.','Research and attach auditable evidence.'))
                elif len(ev)==1:
                    tasks.append(self._task('independence_recheck','normal',r['id'],'Only one evidence item supports the claim.','Seek an independent origin or document why independence is unavailable.'))
        # Living-knowledge triggers are already explicit and should become work.
        for r in self.g.db.execute("SELECT id,kind,status FROM nodes WHERE kind IN ('MaintenanceTrigger','KnowledgeMaintenanceTrigger') AND status IN ('proposed','supported') LIMIT 200"):
            tasks.append(self._task('living_knowledge_maintenance','normal',r['id'],'A living-knowledge maintenance trigger is open.','Inspect the trigger and perform the bounded maintenance action.'))
        if not tasks and include_clean:
            tasks.append(self._task('periodic_integrity_check','normal',None,'No immediate trigger is open.','Run a bounded integrity/evaluation sweep.'))
        # deterministic deduplication and priority ordering
        uniq={}
        for t in tasks:
            key=(t.kind,t.target_id,t.reason)
            uniq[key]=t
        ordered=sorted(uniq.values(), key=lambda x: ({'critical':0,'high':1,'normal':2,'low':3}[x.priority],x.kind,x.target_id or ''))[:max_tasks]
        fp=self._fingerprint(ordered)
        existing=self.g.db.execute("SELECT id FROM nodes WHERE kind='MaintenancePlan' AND metadata LIKE ? ORDER BY created_at DESC LIMIT 1",(f'%{fp}%',)).fetchone()
        if existing:
            return self.get(existing['id'])
        plan=self.g.add_node('MaintenancePlan',f'Maintenance plan {fp[:12]}','proposed',{'fingerprint':fp,'created_at':_now(),'task_count':len(ordered),'authority_boundary':'bounded maintenance planning only; no automatic truth/status promotion; no external execution'})
        final=[]
        for i,t in enumerate(ordered):
            task=self.g.add_node('MaintenanceTask',f'{t.kind}: {t.target_id or "system"}','proposed',{**asdict(t),'plan_id':plan.id,'position':i,'created_at':_now()})
            self.g.link(plan.id,'contains',task.id)
            if t.target_id:
                self.g.link(task.id,'about',t.target_id)
            final.append(MaintenanceTask(task.id,t.kind,t.priority,t.target_id,t.reason,t.action,t.reversible))
        return MaintenancePlan(plan.id,plan.created_at,fp,tuple(final),plan.metadata['authority_boundary'])

    def execute(self, task_id, *, executor="maintenance-engine"):
        task=self.g.get(task_id)
        if not task or task.kind!='MaintenanceTask': raise ValueError(f'invalid maintenance task: {task_id}')
        m=task.metadata
        if m.get('execution_id'):
            n=self.g.get(m['execution_id'])
            return n.metadata if n else {'state':'record_missing'}
        kind=m.get('kind')
        result={'state':'queued','task_id':task_id,'executor':executor,'executed_at':_now(),'truth_status_changed':False}
        if kind=='evaluation_recheck':
            report=EvaluationHarness(self.g).run(include_mutation=False,as_of=result['executed_at'])
            result.update({'state':'completed','total':report.total,'passed':report.passed,'failed':report.failed,'passed_all':report.passed_all,'maintenance_actions':list(report.maintenance_actions)})
        elif kind=='periodic_integrity_check':
            audit=self.g.audit(); result.update({'state':'completed','audit_problems':len(audit.get('problems',[])),'audit_ok':not audit.get('problems')})
        else:
            result['state']='queued_for_review'
        execution=self.g.add_node('MaintenanceExecution',f'Maintenance execution {task_id}','supported',result)
        self.g.link(execution.id,'records',task_id)
        self.g.update_metadata(task_id,{'execution_id':execution.id,'execution_state':result['state'],'last_executed_at':result['executed_at']},reason='maintenance execution recorded')
        return result | {'execution_id':execution.id}

    def get(self, plan_id):
        p=self.g.get(plan_id)
        if not p or p.kind!='MaintenancePlan': raise ValueError(f'invalid maintenance plan: {plan_id}')
        tasks=[]
        for e in self.g.edges(plan_id,direction='out',relation='contains'):
            n=self.g.get(e['target_id'])
            if n and n.kind=='MaintenanceTask':
                m=n.metadata; tasks.append(MaintenanceTask(n.id,m['kind'],m['priority'],m.get('target_id'),m['reason'],m['action'],bool(m.get('reversible',True))))
        return MaintenancePlan(p.id,p.created_at,p.metadata['fingerprint'],tuple(tasks),p.metadata['authority_boundary'])

@dataclass(frozen=True)
class EvidenceSpan:
    span_id: str
    evidence_id: str
    locator: str
    quote: str
    extraction_method: str
    start_offset: int | None
    end_offset: int | None

class EvidencePrecision:
    """Attach exact, auditable source spans to evidence without changing truth."""
    def __init__(self, graph): self.g=graph
    def add_span(self,evidence_id,locator,quote,*,extraction_method='manual',start_offset=None,end_offset=None):
        ev=self.g.get(evidence_id)
        if not ev or ev.kind!='Evidence': raise ValueError('invalid evidence')
        if not str(locator).strip() or not str(quote).strip(): raise ValueError('locator and quote are required')
        if start_offset is not None and end_offset is not None and (start_offset<0 or end_offset<start_offset): raise ValueError('invalid offsets')
        n=self.g.add_node('EvidenceSpan',quote,'supported',{'evidence_id':evidence_id,'locator':locator,'quote_sha256':hashlib.sha256(quote.encode()).hexdigest(),'extraction_method':extraction_method,'start_offset':start_offset,'end_offset':end_offset,'created_at':_now()})
        self.g.link(n.id,'documents',evidence_id)
        return EvidenceSpan(n.id,evidence_id,locator,quote,extraction_method,start_offset,end_offset)
    def spans(self,evidence_id):
        out=[]
        for e in self.g.edges(evidence_id,direction='in',relation='documents'):
            n=self.g.get(e['source_id'])
            if n and n.kind=='EvidenceSpan':
                m=n.metadata; out.append(EvidenceSpan(n.id,evidence_id,m['locator'],n.content,m['extraction_method'],m.get('start_offset'),m.get('end_offset')))
        return tuple(out)

class SourceIndependence:
    """Expose source-family diagnostics on top of origin lineage."""
    def __init__(self, graph): self.g=graph; self.base=IndependenceAnalyzer(graph)
    def analyze(self,evidence_ids: Iterable[str]):
        r=self.base.analyze_evidence(evidence_ids)
        families={}
        for eid in r.evidence_ids:
            ev=self.g.get(eid); m=ev.metadata
            family=m.get('source_family') or m.get('publisher') or m.get('domain') or m.get('origin_id') or 'unknown'
            families.setdefault(str(family),[]).append(eid)
        return {'evidence_ids':r.evidence_ids,'independent_groups':r.independent_groups,'shared_dependencies':r.shared_dependencies,'reasons':r.reasons,'source_families':{k:tuple(v) for k,v in sorted(families.items())},'independent_count':r.independent_count}

@dataclass(frozen=True)
class UnknownRecord:
    unknown_id: str
    subject_id: str | None
    question: str
    scope: str
    basis: str
    status: str

class NegativeKnowledge:
    """Represent bounded unknowns/absence-of-evidence explicitly; never infer falsehood."""
    def __init__(self,graph): self.g=graph
    def record(self,question,*,subject_id=None,scope='current investigation',basis='insufficient evidence'):
        if not str(question).strip(): raise ValueError('question is required')
        if subject_id and not self.g.get(subject_id): raise KeyError(subject_id)
        n=self.g.add_node('Unknown',question,'proposed',{'subject_id':subject_id,'scope':scope,'basis':basis,'created_at':_now(),'truth_boundary':'unknown is not false; absence of evidence is not evidence of absence'})
        if subject_id: self.g.link(n.id,'about',subject_id)
        return UnknownRecord(n.id,subject_id,question,scope,basis,n.status)
    def list(self,subject_id=None):
        rows=self.g.db.execute("SELECT id,content,status,metadata FROM nodes WHERE kind='Unknown' ORDER BY created_at DESC").fetchall()
        out=[]
        for r in rows:
            m=json.loads(r['metadata'])
            if subject_id and m.get('subject_id')!=subject_id: continue
            out.append(UnknownRecord(r['id'],m.get('subject_id'),r['content'],m.get('scope',''),m.get('basis',''),r['status']))
        return tuple(out)

@dataclass(frozen=True)
class ValidityAssessment:
    node_id: str
    valid: bool | None
    valid_from: str | None
    valid_until: str | None
    reason: str

class TemporalValidity:
    """Evaluate declared validity intervals without deciding truth."""
    def __init__(self,graph): self.g=graph
    def assess(self,node_id,*,as_of=None):
        n=self.g.get(node_id)
        if not n: raise KeyError(node_id)
        m=n.metadata; vf,vu=m.get('valid_from'),m.get('valid_until')
        if not vf and not vu: return ValidityAssessment(node_id,None,None,None,'no explicit validity interval')
        now=_parse(as_of) or datetime.now(timezone.utc); start,end=_parse(vf),_parse(vu)
        if vf and start is None: return ValidityAssessment(node_id,None,vf,vu,'invalid valid_from timestamp')
        if vu and end is None: return ValidityAssessment(node_id,None,vf,vu,'invalid valid_until timestamp')
        if start and end and start>end: return ValidityAssessment(node_id,None,vf,vu,'invalid interval: start after end')
        return ValidityAssessment(node_id, (start is None or now>=start) and (end is None or now<=end), vf,vu,'within declared validity interval' if (start is None or now>=start) and (end is None or now<=end) else 'outside declared validity interval')

@dataclass(frozen=True)
class VerificationPolicyResult:
    target_id: str
    required_evidence: int
    independent_sources: int
    required_spans: bool
    conflicts_open: int
    ready: bool
    blockers: tuple[str,...]

class VerificationPolicyEngine:
    """Explicit, inspectable verification requirements; no hidden confidence score."""
    def __init__(self,graph): self.g=graph
    def assess(self,target_id,*,required_evidence=1,minimum_independent=2,require_spans=False):
        n=self.g.get(target_id)
        if not n: raise KeyError(target_id)
        ev=self.g._supporting_evidence(target_id) if n.kind=='Claim' else []
        independence=SourceIndependence(self.g).analyze([e.id for e in ev]) if ev else {'independent_count':0}
        span_ok=all(EvidencePrecision(self.g).spans(e.id) for e in ev) if require_spans else True
        conflicts=sum(1 for e in self.g.edges(target_id,direction='in',relation='contradicts'))+sum(1 for e in self.g.edges(target_id,direction='out',relation='contradicts'))
        blockers=[]
        if len(ev)<required_evidence: blockers.append('insufficient_evidence')
        if independence['independent_count']<minimum_independent: blockers.append('insufficient_independence')
        if not span_ok: blockers.append('missing_evidence_spans')
        if conflicts: blockers.append('open_conflict')
        return VerificationPolicyResult(target_id,required_evidence,independence['independent_count'],require_spans,conflicts,not blockers,tuple(blockers))

@dataclass(frozen=True)
class AuditDigest:
    generated_at: str
    events_head: str
    revisions_head: str
    digest: str

class CryptographicAudit:
    """Produce a tamper-evident digest over the existing append-only ledger heads."""
    def __init__(self,graph): self.g=graph
    def digest(self):
        rows=self.g.db.execute("SELECT table_name,row_count,head_row_id,head_hash FROM ledger_anchor ORDER BY table_name").fetchall()
        payload=[dict(r) for r in rows]
        raw=json.dumps(payload,sort_keys=True,separators=(',',':'))
        digest=hashlib.sha256(raw.encode()).hexdigest()
        heads={r['table_name']:r['head_hash'] for r in rows}
        return AuditDigest(_now(),heads.get('events','GENESIS'),heads.get('revisions','GENESIS'),digest)
    def record(self):
        d=self.digest()
        n=self.g.add_node('AuditDigest',f'Ledger digest {d.digest[:16]}','supported',{'generated_at':d.generated_at,'events_head':d.events_head,'revisions_head':d.revisions_head,'digest':d.digest,'tamper_boundary':'digest detects changes to ledger anchors; it is not an external notarization'})
        return d,n
    def verify(self,digest): return self.digest().digest==digest


class DecisionActionBridge:
    """Connect a Decision to an explicit Action without selecting or authorizing it."""
    def __init__(self,graph): self.g=graph
    def propose(self,decision_id,action,target,expected_effect,*,rollback=None,authority_grant_id=None):
        from .actions import ActionLedger
        d=self.g.get(decision_id)
        if not d or d.kind!='Decision': raise ValueError('invalid decision')
        a=ActionLedger(self.g).propose('decision-workspace',action,target,expected_effect,authority_grant_id=authority_grant_id,rollback=rollback,idempotency_key=f'decision:{decision_id}:{action}:{target}')
        self.g.link(a.id,'proposes',decision_id)
        return a
    def context(self,decision_id):
        d=self.g.get(decision_id)
        if not d or d.kind!='Decision': raise ValueError('invalid decision')
        actions=[]
        for e in self.g.edges(decision_id,direction='in',relation='proposes'):
            n=self.g.get(e['source_id'])
            if n and n.kind=='Action': actions.append({'id':n.id,'status':n.status,'content':n.content,'metadata':n.metadata})
        return {'decision_id':decision_id,'decision_status':d.status,'actions':actions,'boundary':'Decision organization does not authorize or execute actions.'}
