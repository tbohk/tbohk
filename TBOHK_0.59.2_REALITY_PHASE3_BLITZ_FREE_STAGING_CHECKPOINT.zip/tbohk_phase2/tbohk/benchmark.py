from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib, json
from .core import TBOHK
from .research import ResearchChain, MockProvider, SourceDocument
from .epistemic import EpistemicEngine
from .reasoning import ReasoningEngine
from .semantics import SemanticReasoningEngine
from .inference import InferenceEvaluator
from .conflict_analysis import ConflictAnalyzer
from .explanation import ExplanationReconstructor
from .robustness import ReasoningStressTester

CORPUS_VERSION = "G4.7-1"

@dataclass(frozen=True)
class BenchmarkCase:
    case_id: str
    category: str
    purpose: str

@dataclass(frozen=True)
class BenchmarkResult:
    case_id: str
    passed: bool
    findings: tuple[str, ...]

@dataclass(frozen=True)
class BenchmarkReport:
    corpus_version: str
    corpus_sha256: str
    total: int
    passed: int
    failed: int
    results: tuple[BenchmarkResult, ...]
    assessed_at: str

CASES = (
    BenchmarkCase("G47-001", "provenance", "reasoning retains premises and derivation provenance"),
    BenchmarkCase("G47-002", "verification", "derived claims are not automatically verified"),
    BenchmarkCase("G47-003", "assumption", "assumption failure is explicitly exposed"),
    BenchmarkCase("G47-004", "defeater", "defeaters remain visible and do not erase history"),
    BenchmarkCase("G47-005", "counterfactual", "counterfactual reasoning remains isolated from reality"),
    BenchmarkCase("G47-006", "conflict", "conflicting claims remain unresolved without authorization"),
    BenchmarkCase("G47-007", "circularity", "self-supporting reasoning is rejected or exposed"),
    BenchmarkCase("G47-008", "scope", "explanations expose missing provenance rather than inventing it"),
    BenchmarkCase("G47-009", "robustness", "premise removal is detected without mutation"),
    BenchmarkCase("G47-010", "temporal", "temporal invalidation is detected"),
    BenchmarkCase("G47-011", "independence", "shared origin is not treated as independent corroboration"),
    BenchmarkCase("G47-012", "audit", "graph audit remains clean for a valid benchmark fixture"),
)


def corpus_manifest() -> str:
    payload = [{"case_id": c.case_id, "category": c.category, "purpose": c.purpose} for c in CASES]
    return json.dumps({"version": CORPUS_VERSION, "cases": payload}, sort_keys=True, separators=(",", ":"))


def corpus_sha256() -> str:
    return hashlib.sha256(corpus_manifest().encode()).hexdigest()


def _doc(source, provider, origin, text="Water freezes at 0 C."):
    now = "2026-01-01T00:00:00+00:00"
    return SourceDocument(source, source, f"https://example/{source}", text, provider, now, origin, now)


def _base(shared=False):
    a = MockProvider("p1", [_doc("s1", "p1", "origin-A")])
    b = MockProvider("p2", [_doc("s2", "p2", "origin-A" if shared else "origin-B")])
    g = TBOHK(); out = ResearchChain(g, [a, b]).run("freezes")
    return g, out


def _case(case_id):
    g, out = _base()
    e = EpistemicEngine(g)
    if case_id == "G47-001":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        rr = ReasoningEngine(g); rule = rr.add_rule("id", "identity", {"consequent": c.metadata["structured"]}); r = rr.derive(rule.id, [c.id])
        ok = g.edges(r.activity_id, "out", "derives") and g.edges(r.conclusion_id, "out", "derived_from")
        return ok, "derivation provenance present"
    if case_id == "G47-002":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        rr = ReasoningEngine(g); rule = rr.add_rule("id", "identity", {"consequent": c.metadata["structured"]}); r = rr.derive(rule.id, [c.id])
        return g.get(r.conclusion_id).status == "proposed", "derived claim remains proposed"
    if case_id == "G47-003":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        se = SemanticReasoningEngine(g); a = se.add_assumption("condition"); r = se.propose("defeasible", [c.id], conclusion="normally", assumption_ids=[a.id])
        report = ReasoningStressTester(g).test(r.activity_id, ["fail_assumption"])
        return report.cases[0].outcome == "conditionally_fragile", "assumption failure exposed"
    if case_id == "G47-004":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        se = SemanticReasoningEngine(g); d = se.add_defeater("exception"); r = se.propose("defeasible", [c.id], conclusion="normally", defeater_ids=[d.id])
        report = ReasoningStressTester(g).test(r.activity_id, ["activate_defeater"])
        return report.cases[0].outcome == "defeated_or_reassess", "defeater exposure preserved"
    if case_id == "G47-005":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        se = SemanticReasoningEngine(g); r = se.propose("counterfactual", [c.id], conclusion="would change", counterfactual={"intervention":"remove X"})
        branch = g.get(r.branch_id)
        return bool(branch and branch.kind == "CounterfactualBranch" and g.get(r.conclusion_id).metadata.get("counterfactual_branch_id") == r.branch_id), "counterfactual branch isolated"
    if case_id == "G47-006":
        a = e.propose_claim("A", [out["results"][0][1].id]); b = e.propose_claim("not A", [out["results"][1][1].id]); cset = e.contradict(a.id, b.id)
        return g.get(cset.id).status == "proposed", "conflict remains unresolved"
    if case_id == "G47-007":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        rr = ReasoningEngine(g); rule = rr.add_rule("id", "identity", {"consequent": c.metadata["structured"]})
        try:
            rr.derive(rule.id, [c.id, c.id])
        except ValueError:
            return True, "duplicate/self-supporting premise path rejected"
        return False, "self-supporting path was accepted"
    if case_id == "G47-008":
        c = g.add_node("Claim", "derived", metadata={"derived": True})
        t = ExplanationReconstructor(g).trace(c.id)
        return (not t.complete and any("derived claim" in x for x in t.missing_links)), "missing provenance reported"
    if case_id == "G47-009":
        c = e.propose_claim("fact", [out["results"][0][1].id]); g.set_status(c.id, "supported", "fixture")
        rr = ReasoningEngine(g); rule = rr.add_rule("id", "identity", {"consequent": c.metadata["structured"]}); r = rr.derive(rule.id, [c.id])
        before = g.get(r.conclusion_id).status
        report = ReasoningStressTester(g).test(r.activity_id, ["remove_premise"])
        return report.resilience == "fragile" and g.get(r.conclusion_id).status == before, "stress detected without mutation"
    if case_id == "G47-010":
        past="2026-01-01T00:00:00+00:00"; future="2026-02-01T00:00:00+00:00"; g2=TBOHK(); evs=[]
        for i,o in enumerate(("o1","o2")):
            s=g2.add_node("SourceSnapshot",f"x{i}","supported",{"source_id":f"s{i}","provider_id":f"p{i}","origin_id":o,"uri":f"https://x/{i}","retrieved_at":past,"valid_from":past,"valid_until":future})
            ev=g2.add_node("Evidence",f"x{i}","supported",{"source_id":f"s{i}","provider_id":f"p{i}","origin_id":o,"locator":{"type":"document","source_id":f"s{i}"},"extraction_method":"test","observation_time":past,"observation_basis":"test"})
            g2.link(ev.id,"derived_from",s.id); evs.append(ev.id)
        c2=EpistemicEngine(g2).propose_claim("x",evs); EpistemicEngine(g2).verify_claim(c2.id)
        audit=g2.audit("2026-03-01T00:00:00+00:00")
        return any(p[1]=="verified_claim_supported_only_by_temporally_invalid_evidence" for p in audit["problems"]), "temporal invalidity detected"
    if case_id == "G47-011":
        g2,out2=_base(shared=True); e2=EpistemicEngine(g2); c=e2.propose_claim("fact",[out2["results"][0][1].id,out2["results"][1][1].id])
        try: e2.verify_claim(c.id)
        except ValueError as exc: return "independent origin" in str(exc), "shared origin rejected as independence"
        return False, "shared origin incorrectly verified"
    if case_id == "G47-012":
        return g.audit()["ok"], "valid benchmark fixture audits cleanly"
    raise KeyError(case_id)


class ReasoningBenchmark:
    """Fixed, deterministic G4.7 regression corpus.

    The corpus is intentionally small and inspectable. It is a release barrier,
    not a claim of comprehensive reasoning competence.
    """
    def run(self, *, as_of=None):
        results=[]
        for c in CASES:
            try:
                passed, finding = _case(c.case_id)
            except Exception as exc:
                passed=False; finding=f"unexpected exception: {type(exc).__name__}: {exc}"
            results.append(BenchmarkResult(c.case_id, bool(passed), (finding,)))
        stamp = as_of or datetime.now(timezone.utc).isoformat()
        return BenchmarkReport(CORPUS_VERSION, corpus_sha256(), len(results), sum(x.passed for x in results), sum(not x.passed for x in results), tuple(results), stamp)

    def record(self, graph: TBOHK, *, assessor="independent-regression-suite", as_of=None):
        report=self.run(as_of=as_of)
        node=graph.add_node("BenchmarkRun", f"G4.7 reasoning regression {report.corpus_version}", "supported", {
            "corpus_version":report.corpus_version,"corpus_sha256":report.corpus_sha256,
            "assessor":assessor,"assessed_at":report.assessed_at,"total":report.total,
            "passed":report.passed,"failed":report.failed,
            "results":[{"case_id":r.case_id,"passed":r.passed,"findings":list(r.findings)} for r in report.results]
        })
        return report, node
