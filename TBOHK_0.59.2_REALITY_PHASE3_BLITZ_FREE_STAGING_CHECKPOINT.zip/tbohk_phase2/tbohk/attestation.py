from __future__ import annotations
from dataclasses import dataclass
import base64, hashlib, json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

@dataclass(frozen=True)
class PublicAttestation:
    algorithm: str
    key_id: str
    manifest_sha256: str
    public_key: str
    signature: str

@dataclass(frozen=True)
class AttestationReport:
    passed: bool
    findings: tuple[str, ...]

class ReleaseAttestor:
    """G15 public-key release attestation using Ed25519."""
    algorithm = "Ed25519"
    def __init__(self, private_key: Ed25519PrivateKey, key_id: str):
        if not key_id: raise ValueError("key_id is required")
        self.private_key = private_key
        self.key_id = key_id
    @staticmethod
    def canonical_manifest(manifest: dict) -> bytes:
        return json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    @classmethod
    def generate(cls, key_id: str):
        return cls(Ed25519PrivateKey.generate(), key_id)
    def attest(self, manifest: dict) -> PublicAttestation:
        raw = self.canonical_manifest(manifest)
        return PublicAttestation(self.algorithm, self.key_id,
            hashlib.sha256(raw).hexdigest(),
            base64.b64encode(self.private_key.public_key().public_bytes_raw()).decode(),
            base64.b64encode(self.private_key.sign(raw)).decode())

class IndependentVerifier:
    """Verifier intentionally requires only a public key and attestation."""
    @staticmethod
    def verify(manifest: dict, attestation: PublicAttestation, trusted_public_keys: dict[str, bytes]) -> AttestationReport:
        findings=[]
        if attestation.algorithm != "Ed25519": findings.append("unsupported_algorithm")
        pub = trusted_public_keys.get(attestation.key_id)
        if pub is None: findings.append("untrusted_key_id")
        try:
            raw = ReleaseAttestor.canonical_manifest(manifest)
            if hashlib.sha256(raw).hexdigest() != attestation.manifest_sha256: findings.append("manifest_digest_mismatch")
            key_bytes = base64.b64decode(attestation.public_key.encode())
            if pub is not None and key_bytes != pub: findings.append("public_key_mismatch")
            Ed25519PublicKey.from_public_bytes(key_bytes).verify(base64.b64decode(attestation.signature.encode()), raw)
        except Exception:
            findings.append("signature_invalid")
        return AttestationReport(not findings, tuple(findings))
