"""Architecture-to-regression coverage mapping without pretending it is code coverage."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class CoverageGap:
    surface: str
    reason: str
    severity: str

class CoverageIntelligence:
    def find_gaps(self, surfaces, covered) -> tuple[CoverageGap, ...]:
        covered_set = set(covered)
        return tuple(CoverageGap(s, "no mapped regression case", "maintenance") for s in surfaces if s not in covered_set)
