from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter
from datetime import datetime, timezone
from typing import Iterable

from .core import TBOHK
from .impact import DependencyImpactAnalyzer
from .independence import IndependenceAnalyzer
from .temporal_quantitative import TemporalQuantitativeAnalyzer
from .adversarial import AdversarialValidator
from .checkpoints import CheckpointManager

@dataclass(frozen=True)
class InvestigationHealth:
    roots: tuple[str, ...]
    coverage: dict
    counterfactuals: tuple[dict, ...]
    redundancy: dict
    temporal: tuple[dict, ...]
    contradiction_propagation: dict
    maintenance: tuple[dict, ...]
    decisions: tuple[dict, ...]
    checkpoint: dict
    adversarial: tuple[dict, ...]
    graph: dict
    boundary: str

class InvestigationHealthAnalyzer:
    """Compose TBOHK's bounded evidence/knowledge diagnostics into one view.

    This is read-only. It does not promote claims, resolve conflicts, rank
    decisions, assign truth probabilities, or authorize actions.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.impact = DependencyImpactAnalyzer(graph)

    def _claim_ids(self, roots: Iterable[str]) -> list[str]:
        seen=set(); out=[]
        queue=list(roots)
        while queue:
            nid=queue.pop(0)
            if nid in seen: continue
            seen.add(nid)
            n=self.g.get(nid)
            if not n: continue
            if n.kind in {"Claim","Conclusion","Hypothesis"}: out.append(nid)
            for e in self.g.edges(nid, "both"):
                if e["relation"] in {"evidence_for","derives","produces","derived_from","based_on","depends_on","contains","premise_of"}:
                    nxt=e["target_id"] if e["source_id"]==nid else e["source_id"]
                    if nxt not in seen and len(seen)<500: queue.append(nxt)
        return sorted(set(out))

    def _evidence_for(self, claim_id: str):
        return [self.g.get(e["source_id"]) for e in self.g.edges(claim_id, "in", "evidence_for") if self.g.get(e["source_id"]) and self.g.get(e["source_id"]).kind=="Evidence"]

    def _coverage(self, claims):
        rows=[]
        for cid in claims:
            n=self.g.get(cid); ev=self._evidence_for(cid)
            rows.append({"claim_id":cid,"claim":n.content,"status":n.status,"evidence_count":len(ev),"evidence_ids":[e.id for e in ev],"covered":bool(ev)})
        return {"claim_count":len(rows),"covered_claims":sum(r["covered"] for r in rows),"uncovered_claims":sum(not r["covered"] for r in rows),"items":rows}

    def _counterfactuals(self, evidence_ids):
        out=[]
        for eid in sorted(set(evidence_ids))[:20]:
            report=self.impact.analyze([eid], max_nodes=5000)
            affected=[asdict(i) for i in report.items]
            out.append({"evidence_id":eid,"affected_count":len(affected),"potentially_invalidated":sum(i["impact"]=="potentially_invalidated" for i in affected),"disproven":sum(i["impact"]=="disproven" for i in affected),"affected_ids":[i["node_id"] for i in affected[:50]]})
        return tuple(out)

    def _redundancy(self, evidence_ids):
        if not evidence_ids:
            return {"evidence_count":0,"independent_count":0,"groups":[],"shared_dependencies":[],"reasons":[]}
        a=IndependenceAnalyzer(self.g).analyze_evidence(evidence_ids)
        return {"evidence_count":len(a.evidence_ids),"independent_count":a.independent_count,"groups":[list(x) for x in a.independent_groups],"shared_dependencies":[list(x) for x in a.shared_dependencies],"reasons":list(a.reasons)}

    def _temporal(self, claims):
        rows=[]
        for i,a_id in enumerate(claims):
            a=self.g.get(a_id)
            for b_id in claims[i+1:]:
                b=self.g.get(b_id)
                same_subject=bool(a.metadata.get("subject") and a.metadata.get("subject")==b.metadata.get("subject"))
                same_predicate=bool(a.metadata.get("predicate") and a.metadata.get("predicate")==b.metadata.get("predicate"))
                if not (same_subject and same_predicate):
                    # Fall back conservatively to text identity only; never infer semantic sameness.
                    continue
                c=TemporalQuantitativeAnalyzer.analyze(a.content,b.content,same_subject=True,same_predicate=True)
                if c.relationship not in {"compatible_or_unresolved"}:
                    rows.append({"claim_a":a_id,"claim_b":b_id,"relationship":c.relationship,"reason":c.reason,"time_a":c.time_a,"time_b":c.time_b,"quantity_a":c.quantity_a,"quantity_b":c.quantity_b})
        return tuple(rows[:100])

    def _maintenance(self, claims, counterfactuals, redundancy):
        rows=[]
        for cid in claims:
            n=self.g.get(cid); ev=self._evidence_for(cid)
            if not ev: rows.append({"node_id":cid,"kind":n.kind,"priority":"high","reason":"claim has no directly linked evidence"})
            if n.status in {"stale","contradicted","rejected"}: rows.append({"node_id":cid,"kind":n.kind,"priority":"critical","reason":f"claim status is {n.status}"})
        for row in counterfactuals:
            if row["affected_count"]>=2: rows.append({"node_id":row["evidence_id"],"kind":"Evidence","priority":"high","reason":f"removing this evidence affects {row['affected_count']} downstream objects"})
        if redundancy.get("evidence_count")>=2 and redundancy.get("independent_count",0)<2:
            rows.append({"node_id":None,"kind":"EvidenceSet","priority":"high","reason":"multiple evidence items do not establish two independent provenance lineages"})
        return tuple(rows[:100])

    def _decisions(self, claims):
        ids=set(claims); out=[]
        for row in self.g.db.execute("SELECT id FROM nodes WHERE kind='Decision' ORDER BY rowid DESC LIMIT 100"):
            n=self.g.get(row[0]); deps=list(n.metadata.get("evidence_ids",[]))
            linked=[e["source_id"] for e in self.g.edges(n.id,"out","based_on")]
            deps=sorted(set(deps+linked)); related=bool(ids & set(deps))
            if related or not claims:
                options=[self.g.get(e["target_id"]).content for e in self.g.edges(n.id,"out","contains") if self.g.get(e["target_id"])]
                out.append({"decision_id":n.id,"title":n.content,"status":n.status,"options":options,"evidence_ids":deps,"related_to_roots":related})
        return tuple(out)

    def _checkpoint(self):
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='Checkpoint' ORDER BY rowid DESC LIMIT 1").fetchall()
        if not rows: return {"present":False,"verified":False}
        cid=rows[0][0]
        return {"present":True,"checkpoint_id":cid,"verified":CheckpointManager(self.g).verify(cid)}

    def _graph(self, roots, max_nodes=150):
        seen=set(); edges=[]; queue=list(roots)
        while queue and len(seen)<max_nodes:
            nid=queue.pop(0)
            if nid in seen: continue
            n=self.g.get(nid)
            if not n: continue
            seen.add(nid)
            for e in self.g.edges(nid,"both"):
                if e["relation"] not in {"evidence_for","derives","derived_from","based_on","depends_on","contains","produces","contradicts","invalidates","resolves"}: continue
                other=e["target_id"] if e["source_id"]==nid else e["source_id"]
                if self.g.get(other):
                    edges.append({"source":e["source_id"],"target":e["target_id"],"relation":e["relation"]})
                    if other not in seen and len(seen)+len(queue)<max_nodes: queue.append(other)
        nodes=[]
        for nid in sorted(seen):
            n=self.g.get(nid); nodes.append({"id":n.id,"kind":n.kind,"status":n.status,"content":n.content[:180]})
        return {"nodes":nodes,"edges":sorted({(e["source"],e["target"],e["relation"]) for e in edges}),"truncated":len(seen)>=max_nodes}

    def analyze(self, root_ids: Iterable[str], *, max_nodes=5000) -> InvestigationHealth:
        roots=tuple(sorted(set(root_ids)))
        if not roots: raise ValueError("at least one root_id is required")
        for rid in roots:
            if not self.g.get(rid): raise ValueError(f"root node does not exist: {rid}")
        claims=self._claim_ids(roots)
        evidence=[]
        for cid in claims: evidence.extend(e.id for e in self._evidence_for(cid))
        evidence=sorted(set(evidence))
        coverage=self._coverage(claims)
        counter=self._counterfactuals(evidence)
        redundancy=self._redundancy(evidence)
        temporal=self._temporal(claims)
        contradiction=self.impact.analyze(roots,max_nodes=max_nodes)
        adversarial=tuple(asdict(x) for x in AdversarialValidator(self.g).run())
        return InvestigationHealth(
            roots,coverage,counter,redundancy,temporal,
            {"affected":contradiction.counts.get("affected",0),"potentially_invalidated":contradiction.counts.get("potentially_invalidated",0),"disproven":contradiction.counts.get("disproven",0),"impacted_ids":[x.node_id for x in contradiction.items[:100]]},
            self._maintenance(claims,counter,redundancy),self._decisions(claims),self._checkpoint(),adversarial,self._graph(roots),
            "Composite diagnostic only: read-only evidence/knowledge maintenance analysis. It does not decide truth, rank choices, resolve conflicts, change status, or authorize action."
        )
