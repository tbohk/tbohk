"""Meta-evaluation of the mechanisms that evaluate and repair TBOHK itself.

The meta layer deliberately tests the test system rather than product truth. It
uses deterministic probes, contract checks, and controlled fault injection. It
never mutates authoritative knowledge and never edits source code automatically.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any

from .repair_plan import RepairPlanner
from .selftest import SelfTestEngine
from .repair_verification import RepairVerifier
from .fault_injection import FaultInjectionLab
from .coverage_intelligence import CoverageIntelligence
from .repair_lab import RepairLab
from .differential import DifferentialComparator
from .repair_lab import RepairLab
from .differential import DifferentialComparator


@dataclass(frozen=True)
class MetaCheck:
    check_id: str
    passed: bool
    detail: str = ""


@dataclass(frozen=True)
class MetaEvaluationReport:
    version: str
    checks: tuple[MetaCheck, ...]
    digest: str

    @property
    def total(self) -> int:
        return len(self.checks)

    @property
    def passed(self) -> int:
        return sum(c.passed for c in self.checks)

    @property
    def failed(self) -> int:
        return self.total - self.passed

    @property
    def passed_all(self) -> bool:
        return bool(self.checks) and self.failed == 0


class MetaEvaluationEngine:
    """Exercise self-test, repair planning, and determinism contracts."""

    VERSION = "M1.1-1"

    @staticmethod
    def _digest(checks: tuple[MetaCheck, ...]) -> str:
        payload = [c.__dict__ for c in checks]
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def run(self) -> MetaEvaluationReport:
        checks: list[MetaCheck] = []

        # 1. The evaluator must distinguish a healthy check from a broken one.
        healthy = SelfTestEngine()
        healthy.register("meta-healthy", "integrity", lambda: True)
        healthy_report = healthy.run()
        checks.append(MetaCheck("selftest-detects-pass", healthy_report.passed_all and healthy_report.failed == 0))

        broken = SelfTestEngine()
        broken.register("meta-broken", "integrity", lambda: False)
        broken_report = broken.run()
        checks.append(MetaCheck(
            "selftest-detects-failure",
            broken_report.failed == 1 and len(broken_report.repairs) == 1,
        ))

        # 2. Repair planning must remain bounded even when a signal requests an
        # unknown action. Unknown actions are reduced to safe recheck behavior.
        class Signal:
            check_id = "meta-hostile-action"
            action = "execute:arbitrary-code"

        plan = RepairPlanner().plan((Signal(),))
        checks.append(MetaCheck(
            "repair-plan-safety",
            len(plan) == 1 and plan[0].bounded and plan[0].reversible and plan[0].action == "recheck",
        ))

        # 3. A deterministic self-test must have a stable digest when timing is
        # ignored. This catches accidental inclusion of wall-clock measurements.
        left = SelfTestEngine(); left.register("same", "integrity", lambda: True)
        right = SelfTestEngine(); right.register("same", "integrity", lambda: True)
        checks.append(MetaCheck("selftest-digest-determinism", left.run().run_digest == right.run().run_digest))

        # 4. The evaluator itself must produce a deterministic digest for its
        # logical findings.
        first = self._run_core_checks()  # fresh instances, no shared mutable state
        second = self._run_core_checks()
        checks.append(MetaCheck("meta-digest-determinism", self._digest(first) == self._digest(second)))

        # 5. Closed-loop repair verification must accept only when the original
        # failure reproduces, the bounded candidate has an effect, and the
        # regression gate passes.
        verifier = RepairVerifier()
        good = verifier.verify("meta-repair", reproduce=lambda: True, apply_candidate=lambda: True, regression=lambda: True)
        bad = verifier.verify("meta-repair-bad", reproduce=lambda: True, apply_candidate=lambda: True, regression=lambda: False)
        checks.append(MetaCheck("repair-verification-acceptance", good.accepted and not good.failures))
        checks.append(MetaCheck("repair-verification-rejection", not bad.accepted and "regression-gate-failed" in bad.failures))

        # 6. Fault probes must remain allow-listed and reversible.
        lab = FaultInjectionLab()
        checks.append(MetaCheck("fault-probe-boundary", bool(lab.probes()) and all(p.reversible for p in lab.probes())))
        try:
            lab.run("unsupported", detect=lambda: True)
            fault_boundary = False
        except ValueError:
            fault_boundary = True
        checks.append(MetaCheck("fault-probe-rejection", fault_boundary))

        # 7. Coverage intelligence must expose, rather than hide, an uncovered
        # architectural surface.
        gaps = CoverageIntelligence().find_gaps(("kernel", "repair"), ("kernel",))
        checks.append(MetaCheck("coverage-gap-disclosure", len(gaps) == 1 and gaps[0].surface == "repair"))

        # 8. The repair laboratory must generate bounded hypotheses, minimize
        # reproducible evidence, and reject side effects.
        lab = RepairLab()
        hypotheses = lab.generate(target="meta", failure_type="stale_projection")
        minimized = lab.minimize(("a", "noise", "b"), lambda xs: "a" in xs and "b" in xs)
        outcome = lab.evaluate(hypotheses[0], reproduce=lambda: True, apply=lambda _: True, regression=lambda: True, side_effects=lambda: ("unexpected",))
        checks.append(MetaCheck("repair-lab-bounded", 1 <= len(hypotheses) <= 3 and minimized == ("a", "b")))
        checks.append(MetaCheck("repair-lab-side-effect-rejection", not outcome.accepted and "side-effects-detected" in outcome.reason))

        # 9. Differential comparison must expose exact divergent paths.
        diff = DifferentialComparator().compare({"x":[1,2]}, {"x":[1,3]})
        checks.append(MetaCheck("differential-mismatch-localization", not diff.equal and diff.mismatches[0].path == "/x/1"))

        # 8. The repair laboratory must generate bounded hypotheses, minimize
        # reproducible evidence, and reject side effects.
        lab = RepairLab()
        hypotheses = lab.generate(target="meta", failure_type="stale_projection")
        minimized = lab.minimize(("a", "noise", "b"), lambda xs: "a" in xs and "b" in xs)
        outcome = lab.evaluate(hypotheses[0], reproduce=lambda: True, apply=lambda _: True, regression=lambda: True, side_effects=lambda: ("unexpected",))
        checks.append(MetaCheck("repair-lab-bounded", 1 <= len(hypotheses) <= 3 and minimized == ("a", "b")))
        checks.append(MetaCheck("repair-lab-side-effect-rejection", not outcome.accepted and "side-effects-detected" in outcome.reason))

        # 9. Differential comparison must expose exact divergent paths.
        diff = DifferentialComparator().compare({"x":[1,2]}, {"x":[1,3]})
        checks.append(MetaCheck("differential-mismatch-localization", not diff.equal and diff.mismatches[0].path == "/x/1"))

        result = tuple(checks)
        return MetaEvaluationReport(self.VERSION, result, self._digest(result))

    def _run_core_checks(self) -> tuple[MetaCheck, ...]:
        engine = SelfTestEngine()
        engine.register("probe", "integrity", lambda: True)
        report = engine.run()
        return (MetaCheck("probe-contract", report.passed_all),)

    def record(self, graph: Any | None = None) -> MetaEvaluationReport:
        report = self.run()
        if graph is not None:
            graph.add_node(
                "MetaEvaluationRun",
                f"Meta-evaluation {report.version}",
                "supported" if report.passed_all else "failed",
                {
                    "version": report.version,
                    "total": report.total,
                    "passed": report.passed,
                    "failed": report.failed,
                    "digest": report.digest,
                    "checks": [c.__dict__ for c in report.checks],
                },
            )
        return report
