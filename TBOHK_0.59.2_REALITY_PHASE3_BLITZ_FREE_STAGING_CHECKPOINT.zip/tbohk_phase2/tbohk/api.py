from __future__ import annotations
import os
import threading
import contextlib
import smtplib
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from dataclasses import asdict
from pydantic import BaseModel, Field
from .core import TBOHK
from . import __version__
from .service import TBOHKService, DirectURLProvider
from .research import ResearchChain, SourceDocument
from .web_corpus import CorpusLearningEngine, CommonCrawlProvider
from .research_agent import ResearchAgent
from .release import ReleaseAuditor
from .intelligence import KnowledgeIntelligence
from .living_knowledge import LivingKnowledge
from .personal_graph import PersonalKnowledgeGraph
from .decision_workspace import DecisionWorkspace
from .research_campaign import BoundedResearchCampaign
from .hypothesis import HypothesisEngine
from .prediction import PredictiveReasoner
from .adaptive import AdaptiveResearchController
from .investigation_state import InvestigationStateEngine
from .ui import page
from .impact import DependencyImpactAnalyzer
from .projections import GraphProjection
from .reevaluation import ReEvaluationController, ReEvaluationWorkflow
from .investigation_health import InvestigationHealthAnalyzer
from .health_history import InvestigationHealthHistory
from .workspace import QuestionWorkspace
from .answer import AnswerPresenter
from .repair import SelfRepairController
from .assurance_pipeline import AssurancePipeline
from .pricing import catalog
from .accounts import AccountManager, AccountIdentity, QuotaExceeded, StripeBilling
from .billing import normalize_entitlement
from .store_billing import StorePurchaseVerifier, PurchaseVerificationError, deterministic_event_id, validate_event_timestamp
from .store_providers import AppleStoreServerVerifier, GooglePlayVerifier, GoogleRTDNVerifier
from .provider_readiness import readiness as provider_readiness
from .deployment import DeploymentManager, LocalSystemdAdapter, DeploymentError
from .evaluation_harness import EvaluationHarness
from .continuous_maintenance import ContinuousMaintenanceEngine, EvidencePrecision, SourceIndependence, NegativeKnowledge, TemporalValidity, VerificationPolicyEngine, CryptographicAudit
from .email import TransactionalEmail
from .learning_core import LearningCore
from .learning_experiments import LearningExperimentEngine
from .learning_canary import LearningCanaryEngine
from .release_control import ReleaseControlEngine
from .observability import metrics, request_timer, elapsed_ms
from .production_runtime import ProductionRuntime
from .staging import StagingOrchestrator
from .query_engine import QueryEngine
from .workflow_engine import WorkflowEngine
from .foundation import Capability, CapabilityRegistry
from .kernel import DomainKernel
from .execution import BoundedExecutor
from .temporal_query import TemporalQuery
from .research import citation_status

DB_PATH=os.getenv("TBOHK_DB", str(Path.home()/".tbohk"/"tbohk.sqlite"))
Path(DB_PATH).parent.mkdir(parents=True,exist_ok=True)
TOKEN=os.getenv("TBOHK_API_TOKEN")
ACCOUNTS_DB=os.getenv("TBOHK_ACCOUNTS_DB", str(Path(DB_PATH).with_name("accounts.sqlite")))
ACCOUNT_DATA_DIR=os.getenv("TBOHK_ACCOUNT_DATA_DIR", str(Path(DB_PATH).with_name("accounts")))
account_manager=AccountManager(ACCOUNTS_DB, ACCOUNT_DATA_DIR)
if TOKEN:  # pragma: no cover
    account_manager.ensure_bootstrap(TOKEN)
PUBLIC_BASE_URL=os.getenv("TBOHK_PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")
email_sender=TransactionalEmail()
apple_store_verifier=AppleStoreServerVerifier()
google_play_verifier=GooglePlayVerifier()
google_rtdn_verifier=GoogleRTDNVerifier()
deployment_manager=DeploymentManager({"systemd": LocalSystemdAdapter()})
store_verifier=StorePurchaseVerifier({
    "apple": apple_store_verifier.verify,
    "google": google_play_verifier.verify,
})
billing=StripeBilling(os.getenv("STRIPE_SECRET_KEY"), os.getenv("STRIPE_WEBHOOK_SECRET"), {
    "pro": os.getenv("STRIPE_PRICE_PRO", ""),
    "unlimited": os.getenv("STRIPE_PRICE_UNLIMITED", ""),
})
DB_LOCK=threading.RLock()
g=TBOHK(DB_PATH)
service=TBOHKService(g)
intelligence=KnowledgeIntelligence(g)
living=LivingKnowledge(g)
personal_graph=PersonalKnowledgeGraph(g)
decision_workspace=DecisionWorkspace(g)
research_campaign=BoundedResearchCampaign(g, service, ResearchAgent(g))
predictive=PredictiveReasoner(g)
adaptive=AdaptiveResearchController(g)
learning_core=LearningCore(g)
learning_experiments=LearningExperimentEngine(g)
learning_canary=LearningCanaryEngine(g)
def _ed25519_private_env(name: str):
    raw=os.getenv(name, "")
    if not raw: return None
    try:
        import base64
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        return Ed25519PrivateKey.from_private_bytes(base64.b64decode(raw))
    except Exception:
        return None
def _ed25519_public_env(name: str):
    raw=os.getenv(name, "")
    if not raw: return None
    try:
        import base64
        return base64.b64decode(raw)
    except Exception:
        return None
release_control=ReleaseControlEngine(g, _ed25519_private_env("TBOHK_RELEASE_SIGNING_KEY_B64"), _ed25519_public_env("TBOHK_DEPLOYMENT_AUTH_PUBLIC_KEY_B64"))
production_runtime=ProductionRuntime(g)
_runtime_cache: dict[str, tuple] = {}
app=FastAPI(title="TBOHK",version=__version__,description="The Book of Human Knowledge — auditable knowledge system")
query_engine=QueryEngine(g)
workflow_engine=WorkflowEngine(g)
capabilities=CapabilityRegistry()
kernel=DomainKernel(g); kernel.register_defaults()
executor=BoundedExecutor(g)
for _cap in (
    Capability("ask","Ask","core","Turn a question into a grounded knowledge workspace","/answer"),
    Capability("research","Research","knowledge","Acquire bounded external evidence","/research"),
    Capability("challenge","Challenge","reasoning","Stress-test claims and assumptions","/intelligence/claim/{claim_id}/challenge"),
    Capability("maintenance","Maintenance","system","Plan bounded rechecks and repairs","/maintenance/plan"),
    Capability("decisions","Decisions","decision","Track alternatives, assumptions, and actions","/decisions/workspaces"),
    Capability("audit","Audit","assurance","Inspect provenance, integrity, and system health","/audit"),
): capabilities.register(_cap)

def _rebind_graph(obj, graph, depth=2, seen=None):
    if depth < 0 or obj is None: return
    seen=seen or set()
    oid=id(obj)
    if oid in seen: return
    seen.add(oid)
    if hasattr(obj,'g'):
        try: obj.g=graph
        except Exception: pass
    if depth:
        for value in getattr(obj,'__dict__',{}).values():
            if value is not graph and hasattr(value,'__dict__'):
                _rebind_graph(value,graph,depth-1,seen)

def _runtime(identity: AccountIdentity):
    item=_runtime_cache.get(identity.account_id)
    if item is None:
        rg=TBOHK(account_manager.data_path(identity.account_id))
        item=(rg,TBOHKService(rg),KnowledgeIntelligence(rg),LivingKnowledge(rg),PersonalKnowledgeGraph(rg),DecisionWorkspace(rg),BoundedResearchCampaign(rg, TBOHKService(rg), ResearchAgent(rg)),PredictiveReasoner(rg),AdaptiveResearchController(rg),LearningCore(rg))
        _runtime_cache[identity.account_id]=item
        return item
    if len(item) == 10:
        return item
    rg=item[0]
    # Normalize legacy cached runtime tuples from pre-0.33 releases.
    svc=item[1]; intel=item[2]
    if len(item) == 9:
        living_rt, personal_rt, decision_rt, pred, adapt, lc = item[3:9]
        campaign_rt = BoundedResearchCampaign(rg, svc, ResearchAgent(rg))
    elif len(item) == 8:
        living_rt, personal_rt, pred, adapt, lc = item[3:8]
        decision_rt = DecisionWorkspace(rg); campaign_rt = BoundedResearchCampaign(rg, svc, ResearchAgent(rg))
    elif len(item) == 6:
        pred, adapt, lc = item[3:6]
        living_rt, personal_rt = LivingKnowledge(rg), PersonalKnowledgeGraph(rg)
        decision_rt = DecisionWorkspace(rg); campaign_rt = BoundedResearchCampaign(rg, svc, ResearchAgent(rg))
    elif len(item) == 5:
        pred, adapt = item[3:5]
        living_rt, personal_rt, lc = LivingKnowledge(rg), PersonalKnowledgeGraph(rg), LearningCore(rg)
        decision_rt = DecisionWorkspace(rg); campaign_rt = BoundedResearchCampaign(rg, svc, ResearchAgent(rg))
    else:
        living_rt, personal_rt, decision_rt = LivingKnowledge(rg), PersonalKnowledgeGraph(rg), DecisionWorkspace(rg)
        campaign_rt, pred, adapt, lc = BoundedResearchCampaign(rg, svc, ResearchAgent(rg)), PredictiveReasoner(rg), AdaptiveResearchController(rg), LearningCore(rg)
    item=(rg,svc,intel,living_rt,personal_rt,decision_rt,campaign_rt,pred,adapt,lc)
    _runtime_cache[identity.account_id]=item
    return item

def _bearer(value: str|None):
    if not value or not value.startswith("Bearer "): return ""
    return value[7:].strip()

@app.middleware("http")
async def serialize_db_requests(request, call_next):
    start=request_timer()
    request_id=request.headers.get("x-request-id") or __import__("uuid").uuid4().hex
    if request.url.path == "/health":
        response=await call_next(request)
        metrics.record(request.url.path, request.method, response.status_code, elapsed_ms(start), request_id)
        response.headers["x-request-id"]=request_id
        return response
    with DB_LOCK:
        token=_bearer(request.headers.get("authorization"))
        identity=account_manager.authenticate_token(token) if token else None
        global g,service,intelligence,living,personal_graph,decision_workspace,research_campaign,predictive,adaptive,learning_core,learning_experiments,learning_canary,release_control,production_runtime
        previous=(g,service,intelligence,living,personal_graph,decision_workspace,research_campaign,predictive,adaptive,learning_core,learning_experiments,learning_canary,release_control)
        if identity:
            g,service,intelligence,living,personal_graph,decision_workspace,research_campaign,predictive,adaptive,learning_core=_runtime(identity)
            learning_experiments=LearningExperimentEngine(g)
            learning_canary=LearningCanaryEngine(g)
            release_control=ReleaseControlEngine(g, release_control.release_private_key, release_control.deployment_public_key)
            production_runtime.g=g
            request.state.account=identity
        elif TOKEN and token != TOKEN and request.url.path not in {"/pricing","/account/register","/account/login","/billing/webhook"}:
            return JSONResponse({"detail":"authentication required"}, status_code=401)
        elif not identity and token == TOKEN and TOKEN:
            row=account_manager.db.execute("SELECT id FROM users WHERE email=?",('owner@local.tbohk',)).fetchone()
            request.state.account=account_manager.identity(row['id']) if row else None
        if not identity:
            _rebind_graph(service,g)
            _rebind_graph(intelligence,g)
            _rebind_graph(predictive,g)
            _rebind_graph(adaptive,g)
            _rebind_graph(learning_core,g)
            _rebind_graph(living,g)
            _rebind_graph(personal_graph,g)
            _rebind_graph(decision_workspace,g)
            _rebind_graph(learning_experiments,g)
            _rebind_graph(learning_canary,g)
            _rebind_graph(release_control,g)
        try:
            response=await call_next(request)
            account=getattr(request.state,"account",None)
            metrics.record(request.url.path, request.method, response.status_code, elapsed_ms(start), request_id, getattr(account,"account_id",None))
            response.headers["x-request-id"]=request_id
            return response
        finally:
            g,service,intelligence,living,personal_graph,decision_workspace,research_campaign,predictive,adaptive,learning_core,learning_experiments,learning_canary,release_control=previous

def _learn_safe(kind: str, task: str, outcome: str, *, success: bool|None=None, value: float|None=None, source: str="system", metadata: dict|None=None):
    """Learning telemetry must never become a hidden availability dependency."""
    try:
        return learning_core.record_experience(kind, task, outcome, success=success, value=value, source=source, metadata=metadata)
    except Exception:
        return None

def auth(authorization: str|None=Header(default=None)):
    bearer=_bearer(authorization)
    if bearer:
        identity=account_manager.authenticate_token(bearer)
        if identity: return identity
        if TOKEN and bearer == TOKEN: return None
        if TOKEN: raise HTTPException(401,"authentication required")
    if bearer:
        raise HTTPException(401,"authentication required")
    if TOKEN: raise HTTPException(401,"authentication required")
    return None

class NodeIn(BaseModel):
    kind: str = Field(min_length=1,max_length=100)
    content: str = Field(min_length=1,max_length=200000)
    status: str = "unknown"
    metadata: dict = Field(default_factory=dict)
class EdgeIn(BaseModel): source_id:str; relation:str; target_id:str
class StatusIn(BaseModel): status:str; reason:str=""
class ResearchIn(BaseModel): query:str=Field(min_length=1,max_length=1000); urls:list[str]=Field(default_factory=list); stopping_condition:str="all supplied URLs completed"
class StagingRunIn(BaseModel): question:str=Field(min_length=1,max_length=2000); include_common_crawl:bool=False; crawl_id:str|None=None
class CorpusIn(BaseModel): query:str=Field(min_length=1,max_length=1000); crawl_id:str=CommonCrawlProvider.DEFAULT_CRAWL; max_results:int=Field(default=8,ge=1,le=100); cursor:int|None=Field(default=None,ge=0)
class WebLearningIn(CorpusIn): max_claims:int=Field(default=20,ge=1,le=50)
class ClaimIn(BaseModel): content:str; evidence_ids:list[str]; subject:str|None=None; predicate:str|None=None; object_value:object|None=None; units:str|None=None; scope:str|None=None
class PlanIn(BaseModel): question:str=Field(min_length=1,max_length=2000)
class WorkspaceIn(BaseModel): question:str=Field(min_length=1,max_length=5000)
class RepairIn(BaseModel): target_id:str; description:str=Field(min_length=1,max_length=5000); expected_effect:str=Field(min_length=1,max_length=5000); risk:str="medium"
class ReviewVerifyIn(BaseModel): reviewer:str=Field(min_length=1,max_length=200)
class ConflictResolveIn(BaseModel): disposition:str; resolver:str=Field(min_length=1,max_length=200); claim_id:str|None=None; rationale:str=""; scope:str|None=None
class LearningExperienceIn(BaseModel):
    kind: str = Field(min_length=1,max_length=32)
    task: str = Field(min_length=1,max_length=5000)
    outcome: str = Field(min_length=1,max_length=20000)
    success: bool|None = None
    value: float|None = None
    source: str = Field(default="system",max_length=200)
    metadata: dict = Field(default_factory=dict)

class LearningCandidateIn(BaseModel):
    name: str = Field(min_length=1,max_length=300)
    target: str = Field(min_length=1,max_length=500)
    change: dict = Field(default_factory=dict)
    baseline_evaluation_id: str
    candidate_evaluation_id: str
    adversarial_passed: bool
    security_passed: bool
    latency_regression_pct: float = 0.0

class ReleasePrepareIn(BaseModel):
    candidate_id: str
    canary_id: str
    version: str = Field(min_length=1,max_length=100)
    artifact_sha256: str = Field(min_length=64,max_length=64)
    evaluation_suite: str = Field(min_length=1,max_length=300)
    benchmark_sha256: str = Field(min_length=64,max_length=64)
class ReleaseAuthorizeIn(BaseModel):
    operator: str = Field(min_length=1,max_length=200)
    deployment_signature: str = Field(min_length=1,max_length=1000)
class StorePurchaseIn(BaseModel):
    provider:str=Field(min_length=1,max_length=16)
    purchase:dict

class DeploymentIn(BaseModel):
    adapter: str = Field(min_length=1, max_length=32)
    artifact_path: str = Field(min_length=1, max_length=4096)
    artifact_sha256: str = Field(pattern=r"^[0-9a-fA-F]{64}$")

class StoreEventIn(BaseModel):
    provider:str=Field(min_length=1,max_length=16)
    event_id:str|None=None
    event_type:str=Field(min_length=1,max_length=200)
    occurred_at:str|None=None
    payload:dict

class EntitlementIn(BaseModel):
    provider:str=Field(min_length=1,max_length=32)
    external_id:str=Field(min_length=1,max_length=500)
    account_id:str|None=None
    plan:str=Field(min_length=1,max_length=32)
    status:str=Field(min_length=1,max_length=64)
    current_period_end:str|None=None
    cancel_at_period_end:bool=False
    raw:dict={}

class HypothesisIn(BaseModel):
    statement:str=Field(min_length=1,max_length=5000)
    evidence_ids:list[str]=Field(default_factory=list)
    predictions:list[str]=Field(default_factory=list)
    discriminators:list[str]=Field(default_factory=list)
    alternatives:list[str]=Field(default_factory=list)
class PredictionIn(BaseModel):
    hypothesis_id:str
    statement:str=Field(min_length=1,max_length=5000)
    discriminator:bool=False
class ObservationIn(BaseModel):
    prediction_id:str
    observation:str=Field(min_length=1,max_length=20000)
    evidence_id:str|None=None
class ExperimentIn(BaseModel):
    hypothesis_ids:list[str]
class InvestigationIn(BaseModel):
    hypothesis_ids:list[str]
    max_targets:int=Field(default=5,ge=1,le=20)
class AdaptiveResearchIn(BaseModel):
    question:str=Field(min_length=1,max_length=2000)
    hypothesis_ids:list[str]=Field(min_length=1)
    urls:list[str]=Field(min_length=1)
    max_cycles:int=Field(default=3,ge=1,le=10)
    max_targets:int=Field(default=1,ge=1,le=5)

class HypothesisGenerateIn(BaseModel):
    question:str=Field(min_length=1,max_length=2000)
    observations:list[str]=Field(default_factory=list)
    max_hypotheses:int=Field(default=4,ge=1,le=4)

class AutoIn(BaseModel): question:str=Field(min_length=1,max_length=2000); urls:list[str]=Field(default_factory=list); max_cycles:int=Field(default=3,ge=1,le=10)

class AccountRegisterIn(BaseModel):
    email:str=Field(min_length=5,max_length=320)
    password:str=Field(min_length=10,max_length=200)
    name:str=Field(min_length=1,max_length=200)
    plan:str="free"
class AccountLoginIn(BaseModel):
    email:str=Field(min_length=5,max_length=320)
    password:str=Field(min_length=10,max_length=200)
class CheckoutIn(BaseModel):
    plan:str
class PortalIn(BaseModel):
    pass
class DeleteAccountIn(BaseModel):
    confirmation:str=Field(min_length=1,max_length=100)
class EmailTokenIn(BaseModel):
    token:str=Field(min_length=20,max_length=200)
class PasswordResetRequestIn(BaseModel):
    email:str=Field(min_length=5,max_length=320)
class PasswordResetIn(BaseModel):
    token:str=Field(min_length=20,max_length=200)
    password:str=Field(min_length=10,max_length=200)

@app.post("/account/register")
def account_register(body:AccountRegisterIn):
    try:
        identity, token=account_manager.create_account(body.email,body.password,body.name,body.plan)
        verification=account_manager.issue_email_verification(identity.email)
        email_delivered=False
        if verification:
            try:
                email_delivered=email_sender.verification(identity.email,verification)
            except (OSError, smtplib.SMTPException):
                email_delivered=False
        return {"account":account_manager.account_summary(identity),"token":token,"email_verification":{"configured":email_sender.config.configured,"delivered":email_delivered}}
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/account/login")
def account_login(body:AccountLoginIn):
    try:
        identity, token=account_manager.authenticate_password(body.email,body.password)
        return {"account":account_manager.account_summary(identity),"token":token}
    except PermissionError as e: raise HTTPException(429,str(e),headers={"Retry-After":"900"})
    except ValueError as e: raise HTTPException(401,str(e))

@app.post("/account/verify-email")
def account_verify_email(body:EmailTokenIn):
    if not account_manager.verify_email(body.token): raise HTTPException(400,"invalid or expired verification token")
    return {"verified":True}

@app.post("/account/password-reset/request")
def password_reset_request(body:PasswordResetRequestIn):
    # Deliberately identical responses prevent account enumeration.
    reset=account_manager.request_password_reset(body.email)
    if reset:
        try:
            email_sender.password_reset(body.email.strip().lower(),reset)
        except (OSError, smtplib.SMTPException):
            pass
    return {"accepted":True}

@app.post("/account/password-reset/complete")
def password_reset_complete(body:PasswordResetIn):
    try:
        ok=account_manager.reset_password(body.token,body.password)
    except ValueError as e: raise HTTPException(400,str(e))
    if not ok: raise HTTPException(400,"invalid or expired reset token")
    return {"reset":True}

@app.get("/account",dependencies=[Depends(auth)])
def account_info(identity: AccountIdentity = Depends(auth)):
    return account_manager.account_summary(identity)

@app.get("/account/usage",dependencies=[Depends(auth)])
def account_usage(identity: AccountIdentity = Depends(auth)):
    return account_manager.account_summary(identity)["asks"]

@app.post("/account/logout",dependencies=[Depends(auth)])
def account_logout(authorization: str|None=Header(default=None)):
    token=_bearer(authorization)
    if token: account_manager.revoke_token(token)
    return {"logged_out":True}

@app.get("/account/sessions",dependencies=[Depends(auth)])
def account_sessions(identity: AccountIdentity = Depends(auth)):
    return {"sessions":account_manager.sessions(identity.user_id)}

@app.post("/account/sessions/revoke-all",dependencies=[Depends(auth)])
def account_revoke_all(identity: AccountIdentity = Depends(auth)):
    return {"revoked":account_manager.revoke_all_tokens(identity.user_id)}

@app.post("/account/delete",dependencies=[Depends(auth)])
def account_delete(body:DeleteAccountIn, identity: AccountIdentity = Depends(auth)):
    if body.confirmation.strip() != "DELETE MY ACCOUNT":
        raise HTTPException(400, "type DELETE MY ACCOUNT to confirm permanent deletion")
    row=account_manager.db.execute("SELECT stripe_subscription_id FROM accounts WHERE id=?",(identity.account_id,)).fetchone()
    subscription_id=row["stripe_subscription_id"] if row else None
    if subscription_id and billing.configured():
        try:
            billing.cancel_subscription(subscription_id)
        except Exception as e:
            raise HTTPException(503, f"billing cancellation could not be confirmed: {e}")
    item=_runtime_cache.pop(identity.account_id,None)
    if item:
        try: item[0].close()
        except Exception: pass
    try:
        account_manager.delete_account(identity.account_id)
        return {"deleted":True}
    except ValueError as e:
        raise HTTPException(404,str(e))
    except RuntimeError as e:
        raise HTTPException(500,str(e))

@app.post("/billing/checkout",dependencies=[Depends(auth)])
def billing_checkout(body:CheckoutIn, identity: AccountIdentity = Depends(auth)):
    if body.plan not in {"pro","unlimited"}: raise HTTPException(400,"checkout is only available for paid plans")
    try:
        session=billing.checkout(body.plan,identity.account_id,f"{PUBLIC_BASE_URL}/billing/success",f"{PUBLIC_BASE_URL}/billing/cancel")
        return {"checkout_url":session.get("url"),"session_id":session.get("id")}
    except Exception as e: raise HTTPException(503,str(e))

@app.post("/billing/portal",dependencies=[Depends(auth)])
def billing_portal(body:PortalIn, identity: AccountIdentity = Depends(auth)):
    row=account_manager.db.execute("SELECT stripe_customer_id FROM accounts WHERE id=?",(identity.account_id,)).fetchone()
    if not row or not row["stripe_customer_id"]: raise HTTPException(400,"no billing customer is attached to this account")
    try: return {"portal_url":billing.portal(row["stripe_customer_id"],f"{PUBLIC_BASE_URL}/account").get("url")}
    except Exception as e: raise HTTPException(503,str(e))

@app.post("/billing/webhook")
async def billing_webhook(request: Request):
    try:
        payload=await request.body(); event=billing.verify_webhook(payload,request.headers.get("stripe-signature",""))
        event_id=event.get('id')
        event_type=event.get('type','')
        # Stripe always supplies `id`; the deterministic payload fallback keeps
        # older signed fixtures/replayers idempotent without weakening real events.
        if not event_id: event_id='payload_'+__import__('hashlib').sha256(payload).hexdigest()
        if not event_type: raise ValueError('billing event type is required')
        if not account_manager.record_billing_event('stripe',event_id,event_type,event): return {"received":True,"duplicate":True}
        obj=event.get("data",{}).get("object",{}); metadata=obj.get("metadata",{}); account_id=metadata.get("account_id")
        if not account_id and event.get("type","").startswith("customer.subscription"):
            row=account_manager.db.execute("SELECT id FROM accounts WHERE stripe_subscription_id=?",(obj.get("id"),)).fetchone()
            account_id=row["id"] if row else None
        if account_id and event.get("type") in {"checkout.session.completed","customer.subscription.updated"}:
            plan=metadata.get("plan") or ("pro" if obj.get("items",{}).get("data",[{}])[0].get("price",{}).get("id")==billing.price_ids.get("pro") else "unlimited")
            status="active" if obj.get("status", "active") in {"active","trialing"} else obj.get("status", "active")
            account_manager.update_plan(account_id,plan,status,obj.get("customer"),obj.get("subscription") or obj.get("id"))
        elif event.get("type") in {"invoice.payment_failed","customer.subscription.past_due"}:
            if not account_id and event.get("type") == "invoice.payment_failed":
                sub_id = obj.get("subscription")
                row = account_manager.db.execute("SELECT id,plan FROM accounts WHERE stripe_subscription_id=?", (sub_id,)).fetchone() if sub_id else None
                account_id = row["id"] if row else None
                if row and not metadata.get("plan"):
                    metadata["plan"] = row["plan"]
            if account_id:
                account_manager.update_plan(account_id,metadata.get("plan","pro"),"past_due",obj.get("customer"),obj.get("subscription") or obj.get("id"))
        elif account_id and event.get("type")=="customer.subscription.deleted":
            account_manager.update_plan(account_id,"free","canceled")
        return {"received":True}
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/billing/entitlement", dependencies=[Depends(auth)])
def billing_entitlement(body: EntitlementIn, identity: AccountIdentity|None=Depends(auth)):
    account_id=body.account_id or (identity.account_id if identity else None)
    if not account_id or identity and body.account_id and body.account_id != identity.account_id:
        raise HTTPException(403,'account mismatch')
    try:
        e=normalize_entitlement(provider=body.provider,external_id=body.external_id,account_id=account_id,plan=body.plan,
            status=body.status,current_period_end=body.current_period_end,cancel_at_period_end=body.cancel_at_period_end,raw=body.raw)
        return account_manager.upsert_entitlement(**e.as_dict())
    except ValueError as exc: raise HTTPException(400,str(exc))

@app.post("/billing/store/verify", dependencies=[Depends(auth)])
def billing_store_verify(body:StorePurchaseIn, identity:AccountIdentity=Depends(auth)):
    try:
        verified=store_verifier.verify(body.provider, body.purchase, identity.account_id)
        row=account_manager.upsert_entitlement(identity.account_id, verified.provider, verified.entitlement_id(), verified.plan, verified.status, verified.current_period_end, verified.cancel_at_period_end, verified.raw)
        return {"verified":True,"purchase":verified.__dict__,"entitlement":row}
    except PurchaseVerificationError as exc:
        raise HTTPException(400,str(exc))

def _find_store_account(provider: str, external_ids: list[str]) -> str | None:
    ids=[x for x in external_ids if x]
    if not ids: return None
    placeholders=','.join('?' for _ in ids)
    row=account_manager.db.execute(f"SELECT account_id FROM entitlements WHERE provider=? AND external_id IN ({placeholders}) ORDER BY updated_at DESC LIMIT 1", [provider,*ids]).fetchone()
    return row["account_id"] if row else None

def _apply_store_purchase(verified, account_id: str):
    row=account_manager.upsert_entitlement(account_id, verified.provider, verified.entitlement_id(), verified.plan, verified.status, verified.current_period_end, verified.cancel_at_period_end, verified.raw)
    return row

@app.post("/billing/store/apple/notifications")
async def apple_store_notification(request: Request):
    try:
        body=await request.json()
        if not isinstance(body,dict) or not body.get("signedPayload"):
            raise PurchaseVerificationError("Apple signedPayload is required")
        _, notification=__import__('tbohk.store_providers',fromlist=['verify_apple_jws']).verify_apple_jws(body["signedPayload"], apple_store_verifier.root_pem)
        data=notification.get("data") or {}
        signed_tx=data.get("signedTransactionInfo")
        if not signed_tx: return JSONResponse({"received":True,"applied":False,"reason":"notification has no transaction"}, status_code=200)
        _, tx=__import__('tbohk.store_providers',fromlist=['verify_apple_jws']).verify_apple_jws(signed_tx, apple_store_verifier.root_pem)
        account_id=_find_store_account("apple", [str(tx.get("originalTransactionId") or ""), str(tx.get("transactionId") or "")])
        if not account_id: return JSONResponse({"received":True,"applied":False,"reason":"purchase not yet bound"}, status_code=200)
        verified=apple_store_verifier.verify({"signedTransactionInfo":signed_tx})
        event_id=str(notification.get("notificationUUID") or deterministic_event_id("apple", notification))
        if not account_manager.record_billing_event("apple",event_id,str(notification.get("notificationType") or "UNKNOWN"),notification):
            return {"received":True,"applied":True,"duplicate":True,"event_id":event_id}
        return {"received":True,"applied":True,"duplicate":False,"event_id":event_id,"entitlement":_apply_store_purchase(verified,account_id)}
    except PurchaseVerificationError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(400,"invalid Apple notification") from exc

@app.post("/billing/store/google/rtdn")
async def google_play_rtdn(request: Request):
    try:
        await google_rtdn_verifier.verify_oidc(request.headers.get("authorization"))
        body=await request.json()
        event=google_rtdn_verifier.decode_pubsub(body)
        token=str((event.get("subscriptionNotification") or {}).get("purchaseToken") or (event.get("voidedPurchaseNotification") or {}).get("purchaseToken") or "")
        if not token: return JSONResponse({"received":True,"applied":False,"reason":"notification has no purchase token"}, status_code=200)
        account_id=_find_store_account("google", [token])
        if not account_id: return JSONResponse({"received":True,"applied":False,"reason":"purchase not yet bound"}, status_code=200)
        verified=google_play_verifier.verify({"purchaseToken":token})
        kind=next((k for k in ("subscriptionNotification","oneTimeProductNotification","voidedPurchaseNotification") if event.get(k)),"UNKNOWN")
        event_id=deterministic_event_id("google", event)
        if not account_manager.record_billing_event("google",event_id,kind,event):
            return {"received":True,"applied":True,"duplicate":True,"event_id":event_id}
        return {"received":True,"applied":True,"duplicate":False,"event_id":event_id,"entitlement":_apply_store_purchase(verified,account_id)}
    except PurchaseVerificationError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(400,"invalid Google RTDN notification") from exc

@app.post("/billing/store/event", dependencies=[Depends(auth)])
def billing_store_event(body:StoreEventIn, identity:AccountIdentity=Depends(auth)):
    if body.provider.strip().lower() not in {"apple","google"}: raise HTTPException(400,"unsupported store provider")
    try: validate_event_timestamp(body.occurred_at)
    except PurchaseVerificationError as exc: raise HTTPException(400,str(exc))
    event_id=body.event_id or deterministic_event_id(body.provider.lower(), body.payload)
    if not account_manager.record_billing_event(body.provider.lower(), event_id, body.event_type, body.payload):
        return {"received":True,"duplicate":True,"event_id":event_id}
    return {"received":True,"duplicate":False,"event_id":event_id,"account_id":identity.account_id}

@app.get("/billing/entitlements", dependencies=[Depends(auth)])
def billing_entitlements(identity: AccountIdentity|None=Depends(auth)):
    if not identity: raise HTTPException(401,'authentication required')
    return account_manager.entitlement_state(identity.account_id)

@app.get("/billing/provider-readiness",dependencies=[Depends(auth)])
def billing_provider_readiness():
    # Never expose secret values; only missing/configured state is returned.
    return provider_readiness()

@app.get("/observability",dependencies=[Depends(auth)])
def observability_snapshot():
    return metrics.snapshot()

@app.get("/observability/recent",dependencies=[Depends(auth)])
def observability_recent(limit: int = 100):
    try: return metrics.recent(limit)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get("/production/readiness",dependencies=[Depends(auth)])
def production_readiness():
    return production_runtime.readiness()

@app.get("/metrics")
def prometheus_metrics():
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(production_runtime.metrics_prometheus(), media_type="text/plain; version=0.0.4")

@app.post("/production/worker/run-once",dependencies=[Depends(auth)])
def production_worker_run_once(limit: int = 1):
    if limit < 1 or limit > 20: raise HTTPException(400,"limit must be between 1 and 20")
    return production_runtime.run_once(limit=limit)

@app.post("/evaluation/run", dependencies=[Depends(auth)])
def evaluation_run(include_mutation: bool = True):
    try:
        report = EvaluationHarness(TBOHK()).run(include_mutation=include_mutation)
        return {"harness_version": report.harness_version, "assessed_at": report.assessed_at, "total": report.total, "passed": report.passed, "failed": report.failed, "passed_all": report.passed_all, "suites": [s.__dict__ for s in report.suites], "maintenance_actions": list(report.maintenance_actions)}
    except Exception as exc:
        raise HTTPException(500, f"evaluation failed: {exc}")


@app.get("/system/capabilities",dependencies=[Depends(auth)])
def system_capabilities():
    return {"version":__version__,"capabilities":capabilities.list(),"query":QueryEngine(g).health()}

@app.get("/system/overview",dependencies=[Depends(auth)])
def system_overview():
    qe=QueryEngine(g); wf=WorkflowEngine(g)
    stats=service.stats()
    return {"version":__version__,"stats":stats,"query":qe.health(),"tasks":wf.plan(20),"schema":g.migrations.verify()}

@app.get("/command-center",dependencies=[Depends(auth)])
def command_center(limit:int=12):
    """Return a bounded, read-only operational health snapshot for the workspace."""
    limit=max(1,min(int(limit),50))
    counts=g.db.execute("SELECT kind, COUNT(*) AS count FROM nodes GROUP BY kind ORDER BY count DESC, kind").fetchall()
    status_rows=g.db.execute("SELECT status, COUNT(*) AS count FROM nodes GROUP BY status ORDER BY count DESC, status").fetchall()
    open_claims=g.db.execute("SELECT id,kind,status,content,created_at FROM nodes WHERE kind='Claim' AND status IN ('unknown','proposed','stale','contradicted','review') ORDER BY rowid DESC LIMIT ?",(limit,)).fetchall()
    conflicts=g.db.execute("SELECT id,content,status,created_at FROM nodes WHERE kind='ConflictSet' AND status='proposed' ORDER BY rowid DESC LIMIT ?",(limit,)).fetchall()
    experiences=g.db.execute("SELECT id,metadata,created_at FROM nodes WHERE kind='LearningExperience' ORDER BY rowid DESC LIMIT ?",(limit,)).fetchall()
    resolution={"improved":0,"unchanged":0,"expanded":0,"unknown":0}
    action_stats={}
    recent=[]
    import json
    for row in experiences:
        meta=json.loads(row["metadata"])
        nested=meta.get("metadata") if isinstance(meta.get("metadata"),dict) else {}
        signal=nested.get("resolution_signal","unknown")
        resolution[signal]=resolution.get(signal,0)+1
        action=nested.get("attention_action")
        if action:
            a=action_stats.setdefault(action,{"observations":0,"successes":0})
            a["observations"]+=1
            if meta.get("success") is True: a["successes"]+=1
        recent.append({"id":row["id"],"kind":meta.get("experience_kind"),"task":meta.get("task"),"success":meta.get("success"),"resolution_signal":signal,"action":action,"created_at":row["created_at"]})
    for a in action_stats.values():
        n=a["observations"]; a["success_rate"]=(a["successes"]+1)/(n+2)
    tasks=WorkflowEngine(g).plan(limit)
    return {
        "version":__version__,
        "graph":{"nodes":sum(int(r["count"]) for r in counts),"edges":g.db.execute("SELECT COUNT(*) AS count FROM edges").fetchone()["count"],"kinds":{r["kind"]:r["count"] for r in counts},"statuses":{r["status"]:r["count"] for r in status_rows}},
        "attention":{"open_claims":[dict(r) for r in open_claims],"conflicts":[dict(r) for r in conflicts],"counts":{"open_claims":len(open_claims),"conflicts":len(conflicts)}},
        "learning":{"resolution_counts":resolution,"action_signals":action_stats,"recent":recent,"model":learning_core.self_model(limit=500,persist=False)},
        "maintenance":{"tasks":tasks},
        "boundary":"Read-only bounded synthesis of existing system state. It does not change knowledge truth, status, history, authorization, or deployment state.",
    }

@app.get("/system/search",dependencies=[Depends(auth)])
def system_search(q:str,limit:int=50):
    result=QueryEngine(g).search(q,limit)
    return {"query":result.query,"items":list(result.items),"elapsed_ms":round(result.elapsed_ms,3),"cached":result.cached}

@app.get("/system/related/{node_id}",dependencies=[Depends(auth)])
def system_related(node_id:str,limit:int=20):
    return {"node_id":node_id,"items":QueryEngine(g).related(node_id,limit)}

@app.get("/system/tasks",dependencies=[Depends(auth)])
def system_tasks(limit:int=25):
    return {"tasks":WorkflowEngine(g).plan(limit)}

@app.get("/system/kernel",dependencies=[Depends(auth)])
def system_kernel(limit:int=500):
    return kernel.graph_invariants(limit)

@app.get("/system/temporal",dependencies=[Depends(auth)])
def system_temporal(at:str|None=None, kinds:str="", limit:int=200):
    parsed=[x.strip() for x in kinds.split(",") if x.strip()]
    return TemporalQuery(g).active(at=at,kinds=parsed,limit=limit)

@app.get("/system/node/{node_id}/inspect",dependencies=[Depends(auth)])
def system_node_inspect(node_id:str):
    try: return kernel.inspect(node_id)
    except KeyError: raise HTTPException(404,"node not found")

@app.post("/system/tasks/{task_id}/execute",dependencies=[Depends(auth)])
def system_execute_task(task_id:str, max_attempts:int=1):
    try: return executor.execute(task_id,max_attempts=max_attempts).__dict__
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/system/tasks",dependencies=[Depends(auth)])
def system_create_task(body:dict):
    return WorkflowEngine(g).create(str(body.get("kind","maintenance")),str(body.get("title","")),str(body.get("reason","user requested")),body.get("target_id"),int(body.get("priority",50)))

@app.get("/health")
def health(): return {"ok":True,"service":"TBOHK","version":app.version}

@app.get("/pricing")
def pricing(): return catalog()
@app.get("/stats",dependencies=[Depends(auth)])
def stats(): return service.stats()
@app.get("/audit",dependencies=[Depends(auth)])
def audit(as_of:str|None=None): return g.audit(as_of)
@app.get("/release-audit",dependencies=[Depends(auth)])
def release_audit():
    r=ReleaseAuditor(g).audit(); return {"ok":r.passed,"findings":[f.__dict__ for f in r.findings]}
@app.get("/nodes",dependencies=[Depends(auth)])
def nodes(q:str="",limit:int=50): return service.search_nodes(q,limit)
@app.get("/nodes/{node_id}",dependencies=[Depends(auth)])
def node(node_id:str):
    try:return service.node(node_id)
    except KeyError:raise HTTPException(404,"node not found")
@app.post("/nodes",dependencies=[Depends(auth)])
def create_node(body:NodeIn):
    try:return service._node_dict(g.add_node(body.kind,body.content,body.status,body.metadata))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))
@app.post("/edges",dependencies=[Depends(auth)])
def create_edge(body:EdgeIn):
    try:g.link(body.source_id,body.relation,body.target_id);return {"ok":True}
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))
@app.post("/nodes/{node_id}/status",dependencies=[Depends(auth)])
def set_status(node_id:str,body:StatusIn):
    try:
        node=g.get(node_id)
        if not node: raise KeyError(node_id)
        if body.status in {'verified','recovered'} and node.kind in {'Claim','Knowledge','Decision','Plan','Action','AuthorityGrant','ChangeProposal','RecoveryProposal','ReasoningActivity'}:
            raise PermissionError('protected status transitions must use the governing workflow')
        g.set_status(node_id,body.status,body.reason);return service.node(node_id)
    except PermissionError as e: raise HTTPException(403,str(e))
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))
@app.get("/corpus/status",dependencies=[Depends(auth)])
def corpus_status():
    rows=g.db.execute("SELECT COUNT(*) FROM nodes WHERE kind='CorpusIngestion'").fetchone()[0]
    evidence=g.db.execute("SELECT COUNT(*) FROM nodes WHERE kind='Evidence' AND json_extract(metadata,'$.provider_id')='common-crawl'").fetchone()[0]
    origins=g.db.execute("SELECT COUNT(DISTINCT json_extract(metadata,'$.origin_id')) FROM nodes WHERE kind='Evidence' AND json_extract(metadata,'$.provider_id')='common-crawl'").fetchone()[0]
    return {"batches":rows,"evidence":evidence,"independent_origins":origins,"learning_boundary":"observations_and_evidence_only_until_epistemic_verification"}

@app.post("/corpus/learn",dependencies=[Depends(auth)])
def corpus_learn(body:WebLearningIn):
    """Run one bounded web-learning cycle: evidence -> candidates -> verification queue -> conflicts."""
    try:
        return CorpusLearningEngine(g).learn_batch(body.query, crawl_id=body.crawl_id, max_results=body.max_results,
            cursor=str(body.cursor) if body.cursor is not None else None, max_claims=body.max_claims)
    except Exception as e:
        _learn_safe("failure", body.query, str(e), success=False, source="common-crawl-learning", metadata={"crawl_id":body.crawl_id})
        raise HTTPException(400,str(e))

@app.post("/corpus/ingest",dependencies=[Depends(auth)])
def corpus_ingest(body:CorpusIn):
    """Ingest one bounded Common Crawl batch into TBOHK as unverified source evidence."""
    try:
        return CorpusLearningEngine(g).ingest_batch(body.query, crawl_id=body.crawl_id, max_results=body.max_results, cursor=str(body.cursor) if body.cursor is not None else None)
    except Exception as e:
        _learn_safe("failure", body.query, str(e), success=False, source="common-crawl", metadata={"crawl_id":body.crawl_id})
        raise HTTPException(400, str(e))

@app.post("/staging/run",dependencies=[Depends(auth)])
def staging_run(body:StagingRunIn):
    """Execute the real networked staging workflow from configured staging sources."""
    try:
        return StagingOrchestrator(g).run_dict(body.question, include_common_crawl=body.include_common_crawl, crawl_id=body.crawl_id)
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/research",dependencies=[Depends(auth)])
def research(body:ResearchIn):
    if not body.urls: raise HTTPException(400,"at least one explicit public URL is required in v0.2")
    try:
        out=ResearchChain(g,[DirectURLProvider(body.urls)]).run(body.query,body.stopping_condition)
        _learn_safe("research", body.query, f"completed research over {len(body.urls)} explicit source URL(s)", success=True, value=float(len(out.get("results", []))), metadata={"url_count":len(body.urls)})
        return {"record":out["research_record"],"results":[{"snapshot":service._node_dict(s),"evidence":service._node_dict(e)} for s,e in out["results"]]}
    except Exception as e:
        _learn_safe("failure", body.query, str(e), success=False, source="research", metadata={"url_count":len(body.urls)})
        raise HTTPException(400,str(e))
@app.post("/claims",dependencies=[Depends(auth)])
def claim(body:ClaimIn):
    try:
        return service.create_claim(body.content,body.evidence_ids,subject=body.subject,predicate=body.predicate,object_value=body.object_value,units=body.units,scope=body.scope)
    except Exception as e:raise HTTPException(400,str(e))
@app.get("/explain/{node_id}",dependencies=[Depends(auth)])
def explain(node_id:str):
    try:return service.explain_node(node_id)
    except Exception as e:raise HTTPException(400,str(e))

@app.post("/research/plan",dependencies=[Depends(auth)])
def research_plan(body:PlanIn):
    try:return asdict(intelligence.plan_research(body.question))
    except Exception as e:raise HTTPException(400,str(e))

@app.get("/knowledge",dependencies=[Depends(auth)])
def knowledge(q:str=""): return intelligence.knowledge_overview(q)

class DecisionWorkspaceIn(BaseModel):
    title: str = Field(min_length=1,max_length=500)
    objective: str = ""
    question: str = ""
    requirements: list[str] = []
    constraints: list[str] = []
    alternatives: list[dict|str] = []
    assumptions: list[dict|str] = []
    unknowns: list[dict|str] = []
    entity_id: str|None = None

class EntityIn(BaseModel):
    name:str=Field(min_length=1,max_length=500)
    entity_type:str="topic"
    aliases:list[str]=Field(default_factory=list)
    identifiers:dict[str,str]=Field(default_factory=dict)
    description:str=""

class EntityAttachIn(BaseModel):
    entity_id:str
    node_id:str
    relation:str="about"

@app.get("/knowledge/entities",dependencies=[Depends(auth)])
def entity_context(name:str, identifier_type:str|None=None, identifier:str|None=None):
    ids={identifier_type:identifier} if identifier_type and identifier else None
    try:return personal_graph.context(name,identifiers=ids)
    except Exception as e: raise HTTPException(400,str(e))


@app.post("/decisions/workspaces",dependencies=[Depends(auth)])
def decision_workspace_create(body:DecisionWorkspaceIn):
    try:
        return asdict(decision_workspace.create(body.title,objective=body.objective,question=body.question,requirements=body.requirements,constraints=body.constraints,alternatives=body.alternatives,assumptions=body.assumptions,unknowns=body.unknowns,entity_id=body.entity_id))
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/decisions/workspaces/{decision_id}",dependencies=[Depends(auth)])
def decision_workspace_get(decision_id:str):
    try: return decision_workspace.inspect(decision_id)
    except Exception as e: raise HTTPException(400,str(e))

class ResearchCampaignIn(BaseModel):
    question: str = Field(min_length=1,max_length=2000)
    claim_ids: list[str] = Field(default_factory=list)
    max_tasks: int = Field(default=8, ge=1, le=50)
    max_sources: int = Field(default=8, ge=0, le=50)

@app.post("/research/campaigns",dependencies=[Depends(auth)])
def research_campaign_create(body:ResearchCampaignIn):
    try: return research_campaign.create(body.question, claim_ids=body.claim_ids, max_tasks=body.max_tasks, max_sources=body.max_sources)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/research/campaigns/{campaign_id}",dependencies=[Depends(auth)])
def research_campaign_get(campaign_id:str):
    try: return research_campaign.inspect(campaign_id)
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/research/campaigns/{campaign_id}/execute",dependencies=[Depends(auth)])
def research_campaign_execute(campaign_id:str, max_tasks:int|None=None):
    try: return research_campaign.execute(campaign_id, max_tasks=max_tasks)
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/knowledge/entities",dependencies=[Depends(auth)])
def entity_create(body:EntityIn):
    try:
        r=personal_graph.create_or_get(body.name,entity_type=body.entity_type,aliases=body.aliases,identifiers=body.identifiers,description=body.description)
        return {"entity":{"id":r["entity"].id,"kind":r["entity"].kind,"content":r["entity"].content,"metadata":r["entity"].metadata},"created":r["created"],"match":r["match"]}
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/knowledge/entities/{entity_id}",dependencies=[Depends(auth)])
def entity_profile(entity_id:str):
    try:return personal_graph.profile(entity_id)
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/knowledge/entities/attach",dependencies=[Depends(auth)])
def entity_attach(body:EntityAttachIn):
    try:return personal_graph.attach(body.entity_id,body.node_id,body.relation)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/knowledge/living",dependencies=[Depends(auth)])
def living_knowledge(subject:str, as_of:str|None=None):
    try: return living.snapshot(subject, as_of=as_of)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/knowledge/living/history",dependencies=[Depends(auth)])
def living_history(subject:str, limit:int=20):
    try: return living.history(subject, limit=limit)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/knowledge/living/triggers",dependencies=[Depends(auth)])
def living_triggers(subject:str, as_of:str|None=None):
    try: return {"subject":subject,"triggers":living.review_triggers(subject, as_of=as_of)}
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/knowledge/living/snapshot",dependencies=[Depends(auth)])
def living_snapshot(body:PlanIn):
    try: return living.record_snapshot(body.question)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/intelligence/research-agent",dependencies=[Depends(auth)])
def intelligence_research_agent(q:str, claim_ids:str=""):
    try:
        ids=[x.strip() for x in claim_ids.split(",") if x.strip()] or None
        return ResearchAgent(g).run_diagnostics(q, claim_ids=ids)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/intelligence/gaps",dependencies=[Depends(auth)])
def intelligence_gaps(q:str, claim_ids:str=""):
    try:
        ids=[x.strip() for x in claim_ids.split(",") if x.strip()] or None
        return ResearchAgent(g).gaps(q, claim_ids=ids)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/intelligence/claim/{claim_id}/lineage",dependencies=[Depends(auth)])
def intelligence_claim_lineage(claim_id:str):
    try: return ResearchAgent(g).claim_lineage(claim_id)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/intelligence/claim/{claim_id}/challenge",dependencies=[Depends(auth)])
def intelligence_claim_challenge(claim_id:str):
    try: return ResearchAgent(g).challenge_claim(claim_id)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/intelligence/claim/{claim_id}/leverage",dependencies=[Depends(auth)])
def intelligence_claim_leverage(claim_id:str):
    try: return ResearchAgent(g).claim_leverage(claim_id)
    except Exception as e: raise HTTPException(400,str(e))


@app.get("/answer",dependencies=[Depends(auth)])
def answer(q:str):
    try: return AnswerPresenter(g).build(q)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/answer/stream",dependencies=[Depends(auth)])
def answer_stream(q: str):
    """Stream the already-computed answer structure in deterministic stages.

    This is transport streaming, not hidden model streaming: every chunk is derived
    from the same server-authoritative AnswerPresenter result.
    """
    import json
    try: result=AnswerPresenter(g).build(q)
    except Exception as e: raise HTTPException(400,str(e))
    def chunks():
        yield "event: headline\ndata:"+json.dumps({"headline":result["headline"],"summary":result["summary"]})+"\n\n"
        for item in result["items"]: yield "event: claim\ndata:"+json.dumps(item) + "\n\n"
        yield "event: sources\ndata:"+json.dumps({"sources":result["sources"],"citation_quality":result.get("citation_quality",{})})+"\n\n"
        yield "event: complete\ndata:"+json.dumps({"truth_boundary":result["truth_boundary"],"next_actions":result["next_actions"]})+"\n\n"
    return StreamingResponse(chunks(), media_type="text/event-stream", headers={"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"})

@app.post("/answer/citations/verify",dependencies=[Depends(auth)])
def verify_answer_citations(source_ids: list[str]):
    try: return citation_status(g, source_ids)
    except Exception as e: raise HTTPException(400,str(e))

@app.post("/workspace",dependencies=[Depends(auth)])
def workspace(body:WorkspaceIn, identity: AccountIdentity|None = Depends(auth)):
    try:
        if identity:
            identity=account_manager.consume_ask(identity.account_id)
        result=QuestionWorkspace(g).as_dict(QuestionWorkspace(g).open(body.question))
        _learn_safe("interaction", body.question, "knowledge workspace created", success=True, value=float(result.get("assessment", {}).get("evidence_count", 0)), source="workspace")
        if identity:
            result["usage"]={"used":identity.ask_used,"limit":identity.ask_limit,"remaining":max(0,identity.ask_limit-identity.ask_used),"month":account_manager._month()}
        return result
    except QuotaExceeded as e:
        _learn_safe("failure", body.question, str(e), success=False, source="workspace", metadata={"failure_class":"quota"})
        raise HTTPException(429, {"code":"ask_limit_reached","message":str(e),"used":e.used,"limit":e.limit})
    except Exception as e:
        _learn_safe("failure", body.question, str(e), success=False, source="workspace", metadata={"failure_class":"workspace_failure"})
        raise HTTPException(400,str(e))

@app.post("/assurance/pipeline",dependencies=[Depends(auth)])
def assurance_pipeline():
    try: return asdict(AssurancePipeline(g).run())
    except Exception as e: raise HTTPException(500,str(e))

@app.post("/repairs",dependencies=[Depends(auth)])
def repair(body:RepairIn):
    try:
        candidate=SelfRepairController(g).propose(body.target_id,body.description,expected_effect=body.expected_effect,risk=body.risk)
        return asdict(candidate)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/gaps",dependencies=[Depends(auth)])
def gaps(q:str): return {"question":q,"gaps":intelligence.gaps(q)}

@app.get("/conflicts",dependencies=[Depends(auth)])
def conflicts(): return {"conflicts":intelligence.conflicts()}

@app.get("/corpus/verification-queue",dependencies=[Depends(auth)])
def corpus_verification_queue(limit:int=50):
    try: return CorpusLearningEngine(g).verification_triage(limit)
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/corpus/research-tactics",dependencies=[Depends(auth)])
def corpus_research_tactics(claim_id:str, limit:int=5):
    try: return CorpusLearningEngine(g).recommend_research_tactics(claim_id, limit=limit)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get("/corpus/research-tactic-history",dependencies=[Depends(auth)])
def corpus_research_tactic_history(limit:int=50):
    try: return CorpusLearningEngine(g).research_tactic_history(limit=limit)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/corpus/verification-feedback",dependencies=[Depends(auth)])
def corpus_verification_feedback(body:dict):
    try:
        return CorpusLearningEngine(g).record_verification_feedback(str(body.get("task_id","")), outcome=str(body.get("outcome","")), evidence_pattern=str(body.get("evidence_pattern","")), notes=str(body.get("notes","")))
    except ValueError as e: raise HTTPException(400,str(e))

@app.get("/operations/queue",dependencies=[Depends(auth)])
def operations_queue(limit:int=20):
    """Return one bounded, deterministic operator queue across existing review signals.

    This is an orchestration view only: it never changes knowledge, truth status,
    authorization, or action state. Structural priority is used solely to order
    work that already has an explicit review/research signal.
    """
    try:
        limit=max(1,min(int(limit),100))
        items=[]
        verification=CorpusLearningEngine(g).verification_triage(min(100,limit*3))
        for x in verification.get("items",[]):
            items.append({"type":"verification","priority":float(x.get("priority",0)),"id":x.get("task_id"),"title":"Verification task","reason":x.get("reason","Verification evidence needs review."),"target_id":x.get("claim_id"),"action":"review"})
        rq=review_queue()
        for c in rq.get("claims",[]):
            evidence=int(c.get("evidence_count",0))
            items.append({"type":"claim","priority":30.0+(10.0 if evidence==0 else 0.0),"id":c["id"],"title":"Review proposed claim","reason":"Proposed claim requires explicit human review before status change.","target_id":c["id"],"action":"review"})
        for c in rq.get("conflicts",[]):
            items.append({"type":"conflict","priority":60.0,"id":c["id"],"title":"Resolve conflict set","reason":c.get("reason") or "Conflicting claims require explicit reconciliation.","target_id":c["id"],"action":"review"})
        # Deduplicate the same target/type while retaining the strongest structural signal.
        best={}
        for item in items:
            key=(item["type"],item["id"])
            if key not in best or item["priority"]>best[key]["priority"]: best[key]=item
        rows=sorted(best.values(),key=lambda x:(-x["priority"],x["type"],str(x["id"])))[:limit]
        return {"items":rows,"total":len(best),"ordering":"structural_need_only","not_a_truth_score":True,"boundary":"Read-only orchestration. Queue order recommends work; it never establishes truth, changes knowledge status, authorizes actions, or replaces human judgment."}
    except (ValueError,TypeError) as e:
        raise HTTPException(400,str(e))

@app.get("/review/queue",dependencies=[Depends(auth)])
def review_queue():
    claims=[]
    for row in g.db.execute("SELECT id FROM nodes WHERE kind='Claim' AND status='proposed' ORDER BY rowid DESC LIMIT 100").fetchall():
        n=g.get(row['id']); evidence=[e['source_id'] for e in g.edges(n.id,'in','evidence_for')]
        claims.append({"id":n.id,"content":n.content,"status":n.status,"evidence_count":len(evidence),"evidence_ids":evidence,"metadata":n.metadata})
    conflict_rows=g.db.execute("SELECT id FROM nodes WHERE kind='ConflictSet' AND status='proposed' ORDER BY rowid DESC LIMIT 100").fetchall()
    open_conflicts=[]
    for row in conflict_rows:
        n=g.get(row['id']); members=[g.get(e['target_id']) for e in g.edges(n.id,'out','contains')]
        open_conflicts.append({"id":n.id,"content":n.content,"reason":n.metadata.get('reason',''),"claims":[{"id":m.id,"content":m.content,"status":m.status} for m in members if m]})
    return {"claims":claims,"conflicts":open_conflicts}

@app.post("/review/claims/{node_id}/verify",dependencies=[Depends(auth)])
def review_verify_claim(node_id:str, body:ReviewVerifyIn):
    try:
        return service._node_dict(intelligence.epistemic.verify_claim(node_id, reviewer=body.reviewer))
    except PermissionError as e: raise HTTPException(403,str(e))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.post("/review/conflicts/{conflict_id}/resolve",dependencies=[Depends(auth)])
def review_resolve_conflict(conflict_id:str, body:ConflictResolveIn):
    try:
        resolution=intelligence.epistemic.resolve_conflict(conflict_id, body.disposition, resolver=body.resolver, claim_id=body.claim_id, rationale=body.rationale, scope=body.scope)
        return service._node_dict(resolution)
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/learning/dashboard",dependencies=[Depends(auth)])
def learning_dashboard():
    try: return learning_core.dashboard()
    except Exception as e: raise HTTPException(500,str(e))

@app.post("/learning/experience",dependencies=[Depends(auth)])
def learning_experience(body: LearningExperienceIn):
    try: return asdict(learning_core.record_experience(body.kind, body.task, body.outcome, success=body.success, value=body.value, source=body.source, metadata=body.metadata))
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/learning/benchmark",dependencies=[Depends(auth)])
def learning_benchmark():
    try: return learning_core.run_benchmark(record=True)
    except Exception as e: raise HTTPException(500,str(e))

@app.post("/learning/datasets",dependencies=[Depends(auth)])
def learning_dataset(limit: int = 500, validation_fraction: float = 0.2):
    try:
        return learning_core.build_dataset(limit=limit, validation_fraction=validation_fraction, record=True)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(500, str(exc))

@app.post("/learning/plan",dependencies=[Depends(auth)])
def learning_plan():
    try: return asdict(learning_core.plan())
    except Exception as e: raise HTTPException(500,str(e))

@app.post("/learning/experiments",dependencies=[Depends(auth)])
def learning_experiment(dataset_id: str, epochs: int = 8, learning_rate: float = 0.2):
    try:
        return asdict(learning_experiments.run(dataset_id, epochs=epochs, learning_rate=learning_rate))
    except ValueError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(500,str(e))

@app.get("/learning/experiments/{experiment_id}",dependencies=[Depends(auth)])
def learning_experiment_report(experiment_id: str):
    try: return learning_experiments.report(experiment_id)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/learning/canaries",dependencies=[Depends(auth)])
def learning_canary_run(experiment_id: str, observations: int, error_rate: float, latency_ms: float, baseline_latency_ms: float, max_error_rate: float = 0.05, max_latency_regression_pct: float = 10.0):
    try:
        return asdict(learning_canary.run(experiment_id, observations=observations, error_rate=error_rate, latency_ms=latency_ms, baseline_latency_ms=baseline_latency_ms, max_error_rate=max_error_rate, max_latency_regression_pct=max_latency_regression_pct))
    except ValueError as e: raise HTTPException(400,str(e))
    except Exception as e: raise HTTPException(500,str(e))

@app.get("/learning/canaries/{canary_id}",dependencies=[Depends(auth)])
def learning_canary_report(canary_id: str):
    try: return learning_canary.report(canary_id)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/release/prepare",dependencies=[Depends(auth)])
def release_prepare(body: ReleasePrepareIn):
    try: return asdict(release_control.prepare(body.candidate_id, body.canary_id, version=body.version, artifact_sha256=body.artifact_sha256, evaluation_suite=body.evaluation_suite, benchmark_sha256=body.benchmark_sha256))
    except ValueError as e: raise HTTPException(400,str(e))
@app.post("/release/{release_id}/authorize",dependencies=[Depends(auth)])
def release_authorize(release_id: str, body: ReleaseAuthorizeIn):
    try: return asdict(release_control.authorize(release_id, operator=body.operator, deployment_signature=body.deployment_signature))
    except ValueError as e: raise HTTPException(400,str(e))
@app.post("/release/{release_id}/stage",dependencies=[Depends(auth)])
def release_stage(release_id: str, traffic_percent: float):
    try: return asdict(release_control.stage(release_id, traffic_percent=traffic_percent))
    except ValueError as e: raise HTTPException(400,str(e))
@app.post("/release/{release_id}/health",dependencies=[Depends(auth)])
def release_health(release_id: str, observations: int, error_rate: float, latency_ms: float, max_error_rate: float = 0.05, max_latency_ms: float|None = None):
    try: return asdict(release_control.health_gate(release_id, observations=observations, error_rate=error_rate, latency_ms=latency_ms, max_error_rate=max_error_rate, max_latency_ms=max_latency_ms))
    except ValueError as e: raise HTTPException(400,str(e))
@app.post("/release/{release_id}/complete",dependencies=[Depends(auth)])
def release_complete(release_id: str):
    try: return asdict(release_control.complete(release_id))
    except ValueError as e: raise HTTPException(400,str(e))
@app.post("/release/{release_id}/deploy",dependencies=[Depends(auth)])
def release_deploy(release_id: str, body: DeploymentIn):
    try:
        report = release_control.report(release_id)
        if report.get("state") != "completed":
            raise ValueError("release must be health-gated and completed before deployment")
        result = deployment_manager.deploy(body.adapter, release_id, body.artifact_path, body.artifact_sha256)
        g.update_metadata(release_id, {"deployment": asdict(result)}, reason="explicit deployment adapter execution")
        return asdict(result)
    except DeploymentError as e: raise HTTPException(400,str(e))
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/release/{release_id}/rollback",dependencies=[Depends(auth)])
def release_rollback(release_id: str, adapter: str):
    try:
        result = deployment_manager.rollback(adapter, release_id)
        g.update_metadata(release_id, {"rollback_execution": asdict(result)}, reason="explicit deployment rollback")
        return asdict(result)
    except DeploymentError as e: raise HTTPException(400,str(e))

@app.get("/release/{release_id}/deployment-health",dependencies=[Depends(auth)])
def release_deployment_health(release_id: str, adapter: str):
    try:
        release_control.report(release_id)
        return deployment_manager.health(adapter)
    except DeploymentError as e: raise HTTPException(400,str(e))

@app.get("/release/{release_id}",dependencies=[Depends(auth)])
def release_report(release_id: str):
    try: return release_control.report(release_id)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/learning/candidates",dependencies=[Depends(auth)])
def learning_candidate(body: LearningCandidateIn):
    try: return {"candidate_id": learning_core.propose_candidate(body.name, body.target, body.change, baseline_evaluation_id=body.baseline_evaluation_id, candidate_evaluation_id=body.candidate_evaluation_id, adversarial_passed=body.adversarial_passed, security_passed=body.security_passed, latency_regression_pct=body.latency_regression_pct)}
    except ValueError as e: raise HTTPException(400,str(e))

@app.post("/learning/candidates/{candidate_id}/promote",dependencies=[Depends(auth)])
def learning_promote(candidate_id: str):
    try: return asdict(learning_core.promotion_gate(candidate_id))
    except ValueError as e: raise HTTPException(400,str(e))

@app.get("/assurance/invariants",dependencies=[Depends(auth)])
def assurance_invariants():
    from .invariants import registry, transition_matrix
    return {"invariants":registry(),"transitions":transition_matrix(__import__("tbohk.core",fromlist=["STATUSES"]).STATUSES)}

@app.get("/assurance/migrations",dependencies=[Depends(auth)])
def assurance_migrations():
    return g.migrations.verify()

@app.get("/assurance/selfcare",dependencies=[Depends(auth)])
def assurance_selfcare():
    from .selfcare import SelfCareEngine
    return SelfCareEngine.as_dict(SelfCareEngine(g).inspect())

@app.get("/synthesis",dependencies=[Depends(auth)])
def synthesis(q:str=""):
    return intelligence.synthesize(q)

@app.get("/causal/{node_id}",dependencies=[Depends(auth)])
def causal(node_id:str):
    try:
        return asdict(intelligence.causal.assess(node_id))
    except Exception as e:
        raise HTTPException(400,str(e))

@app.post("/hypotheses",dependencies=[Depends(auth)])
def create_hypothesis(body:HypothesisIn):
    try:return asdict(intelligence.hypotheses.create(body.statement,body.evidence_ids,body.predictions,body.discriminators,body.alternatives))
    except Exception as e:raise HTTPException(400,str(e))

@app.post("/hypotheses/generate",dependencies=[Depends(auth)])
def generate_hypotheses(body:HypothesisGenerateIn):
    try:return {"hypotheses":[asdict(h) for h in intelligence.hypotheses.generate_alternatives(body.question,body.observations,body.max_hypotheses)]}
    except Exception as e:raise HTTPException(400,str(e))

@app.get("/hypotheses/compare",dependencies=[Depends(auth)])
def compare_hypotheses(ids:str):
    try:return asdict(intelligence.hypotheses.compare([x.strip() for x in ids.split(',') if x.strip()]))
    except Exception as e:raise HTTPException(400,str(e))

@app.post("/predictions",dependencies=[Depends(auth)])
def create_prediction(body:PredictionIn):
    try:
        result=asdict(predictive.create_prediction(body.hypothesis_id,body.statement,discriminator=body.discriminator))
        _learn_safe("prediction", body.statement, "prediction created", success=True, source="prediction", metadata={"hypothesis_id":body.hypothesis_id})
        return result
    except Exception as e:
        _learn_safe("failure", body.statement, str(e), success=False, source="prediction", metadata={"failure_class":"prediction_creation"})
        raise HTTPException(400,str(e))

@app.post("/predictions/observe",dependencies=[Depends(auth)])
def observe_prediction(body:ObservationIn):
    try:
        result=asdict(predictive.assess_observation(body.prediction_id,body.observation,body.evidence_id))
        _learn_safe("outcome", body.prediction_id, body.observation, success=True, source="prediction_outcome", metadata={"prediction_id":body.prediction_id})
        return result
    except Exception as e:
        _learn_safe("failure", body.prediction_id, str(e), success=False, source="prediction_outcome", metadata={"failure_class":"observation_assessment"})
        raise HTTPException(400,str(e))

@app.post("/experiments/design",dependencies=[Depends(auth)])
def experiment_design(body:ExperimentIn):
    try:return asdict(predictive.design_experiment(body.hypothesis_ids))
    except Exception as e:raise HTTPException(400,str(e))

@app.post("/investigation/plan",dependencies=[Depends(auth)])
def investigation_plan(body:InvestigationIn):
    try:return asdict(intelligence.investigator.plan(body.hypothesis_ids,body.max_targets))
    except Exception as e:raise HTTPException(400,str(e))

@app.post("/adaptive-research",dependencies=[Depends(auth)])
def adaptive_research(body:AdaptiveResearchIn):
    try:
        provider=DirectURLProvider(body.urls)
        return asdict(adaptive.run(body.question,body.hypothesis_ids,[provider],max_cycles=body.max_cycles,max_targets=body.max_targets))
    except Exception as e:raise HTTPException(400,str(e))


@app.get("/investigation/health/history",dependencies=[Depends(auth)])
def investigation_health_history(roots:str, limit:int=20):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        return {"roots":root_ids,"snapshots":list(InvestigationHealthHistory(g).history(root_ids,limit=limit))}
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.get("/investigation/{run_id}/state",dependencies=[Depends(auth)])
def investigation_state(run_id:str):
    try:
        return asdict(InvestigationStateEngine(g).build(run_id))
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/investigation/{run_id}/history",dependencies=[Depends(auth)])
def investigation_history(run_id:str):
    try:
        return {"run_id":run_id, "states":list(InvestigationStateEngine(g).history(run_id))}
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/investigation/{run_id}/delta",dependencies=[Depends(auth)])
def investigation_delta(run_id:str, from_state_id:str|None=None, to_state_id:str|None=None):
    try:
        engine=InvestigationStateEngine(g)
        history=engine.history(run_id)
        if not history: raise ValueError("no investigation state history")
        target=to_state_id or history[-1]["id"]
        if from_state_id is None:
            target_meta=g.get(target).metadata
            prev=target_meta.get("previous_state_id")
        else:
            prev=from_state_id
        return asdict(engine.delta(run_id,prev,target))
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/hypotheses/{node_id}/assessment",dependencies=[Depends(auth)])
def hypothesis_assessment(node_id:str):
    try:return predictive.update_assessment(node_id)
    except Exception as e:raise HTTPException(400,str(e))

@app.get("/hypotheses/{node_id}",dependencies=[Depends(auth)])
def hypothesis(node_id:str):
    try:return intelligence.hypotheses.assess(node_id)
    except Exception as e:raise HTTPException(400,str(e))

@app.get("/investigation/{run_id}/impact",dependencies=[Depends(auth)])
def investigation_impact(run_id:str, roots:str, max_nodes:int=10000):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        report=DependencyImpactAnalyzer(g).analyze_investigation(run_id, root_ids, max_nodes=max_nodes)
        return asdict(report)
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.get("/investigation/health",dependencies=[Depends(auth)])
def investigation_health(roots:str, max_nodes:int=5000):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        return asdict(InvestigationHealthAnalyzer(g).analyze(root_ids,max_nodes=max_nodes))
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.post("/investigation/health/snapshot",dependencies=[Depends(auth)])
def investigation_health_snapshot(roots:str, max_nodes:int=5000):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        health=asdict(InvestigationHealthAnalyzer(g).analyze(root_ids,max_nodes=max_nodes))
        return asdict(InvestigationHealthHistory(g).snapshot(root_ids, health=health))
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.get("/graph/neighborhood/{node_id}",dependencies=[Depends(auth)])
def graph_neighborhood(node_id:str, limit:int=80):
    """Return a bounded, read-only neighborhood for an explicitly selected node."""
    try:
        node=g.get(node_id)
        if node is None: raise ValueError("node not found")
        rows=GraphProjection(g).neighborhood(node_id, limit=limit)
        return {"node":{"id":node.id,"kind":node.kind,"status":node.status,"content":node.content,"metadata":node.metadata},"neighbors":rows,"limit":max(1,min(int(limit),500))}
    except ValueError as e: raise HTTPException(404,str(e))

@app.get("/graph/map/{node_id}",dependencies=[Depends(auth)])
def graph_map(node_id:str, depth:int=2, max_nodes:int=60, kinds:str="", statuses:str="", relations:str=""):
    """Return a bounded, read-only graph map rooted at one explicit node."""
    root=g.get(node_id)
    if root is None: raise HTTPException(404,"node not found")
    depth=max(0,min(int(depth),4)); max_nodes=max(1,min(int(max_nodes),200))
    kind_filter={x.strip() for x in kinds.split(",") if x.strip()}
    status_filter={x.strip() for x in statuses.split(",") if x.strip()}
    relation_filter={x.strip() for x in relations.split(",") if x.strip()}
    nodes={root.id:root}; edges=[]; seen_edges=set(); frontier=[(root.id,0)]
    while frontier and len(nodes)<max_nodes:
        cur,d=frontier.pop(0)
        if d>=depth: continue
        for edge in sorted(g.edges(cur,direction="both"), key=lambda e:(e["relation"],e["source_id"],e["target_id"])):
            if relation_filter and edge["relation"] not in relation_filter: continue
            key=(edge["source_id"],edge["relation"],edge["target_id"])
            if key in seen_edges: continue
            other=edge["target_id"] if edge["source_id"]==cur else edge["source_id"]
            n=g.get(other)
            if not n: continue
            if kind_filter and n.kind not in kind_filter and n.id!=root.id: continue
            if status_filter and n.status not in status_filter and n.id!=root.id: continue
            seen_edges.add(key); edges.append({"source_id":edge["source_id"],"target_id":edge["target_id"],"relation":edge["relation"]})
            if n.id not in nodes and len(nodes)<max_nodes:
                nodes[n.id]=n; frontier.append((n.id,d+1))
    return {"root":root.id,"depth":depth,"limit":max_nodes,"nodes":[{"id":n.id,"kind":n.kind,"status":n.status,"content":n.content} for n in sorted(nodes.values(),key=lambda x:x.id)],"edges":edges,"truncated":bool(frontier)}

@app.get("/graph/attention/{node_id}",dependencies=[Depends(auth)])
def graph_attention(node_id:str, max_nodes:int=200):
    """Return a bounded, read-only action brief for one knowledge object.

    This composes existing graph, gap, conflict, and impact analysis without
    creating a second source of truth or mutating the selected object.
    """
    try:
        node=g.get(node_id)
        if node is None: raise ValueError("node not found")
        max_nodes=max(1,min(int(max_nodes),500))
        gaps=[]
        conflicts=[]
        if node.kind == "Claim":
            intel=KnowledgeIntelligence(g)
            gaps=intel.gaps(node.content, [node.id])
            conflicts=intel.conflicts([node.id])
        impact_report=DependencyImpactAnalyzer(g).analyze([node.id], max_nodes=max_nodes)
        impact_items=[asdict(x) for x in impact_report.items]
        critical=sum(1 for x in gaps if x.get("severity")=="critical")
        high=sum(1 for x in gaps if x.get("severity")=="high")
        contradicted=any(node.id in {c.get("claim_a",{}).get("id"), c.get("claim_b",{}).get("id")} for c in conflicts)
        if contradicted:
            attention="conflict"
        elif critical:
            attention="critical_gap"
        elif high or any(x["impact"] in {"disproven","potentially_invalidated"} for x in impact_report.items):
            attention="review"
        elif impact_report.items:
            attention="dependency_review"
        else:
            attention="monitor"
        actions=[]
        if gaps: actions.append({"type":"research","label":"Research evidence gaps","reason":"Explicit evidence or verification gaps remain."})
        if conflicts: actions.append({"type":"conflict","label":"Review conflicting claims","reason":"Contradictory relationships are attached to this claim."})
        if impact_report.items: actions.append({"type":"impact","label":"Review downstream impact","reason":"Other knowledge objects depend on this object."})
        if node.kind == "Claim": actions.append({"type":"lineage","label":"Inspect claim lineage","reason":"Trace the claim back through evidence and derivation."})
        if not actions: actions.append({"type":"monitor","label":"Monitor","reason":"No immediate graph-level review trigger was detected."})
        profile=learning_core.attention_profile([a["type"] for a in actions])
        for a in actions:
            signal=profile.get(a["type"],{})
            a["learning_signal"]={"observations":signal.get("observations",0),"success_rate":signal.get("success_rate",0.5),"confidence":signal.get("confidence","prior_only")}
        actions.sort(key=lambda a:(-float(a["learning_signal"]["success_rate"]), -int(a["learning_signal"]["observations"]), a["type"]))
        return {
            "node":{"id":node.id,"kind":node.kind,"status":node.status,"content":node.content},
            "attention":attention,
            "summary":{"gap_count":len(gaps),"critical_gaps":critical,"high_gaps":high,"conflict_count":len(conflicts),"impact_count":len(impact_items)},
            "gaps":gaps[:30],
            "conflicts":conflicts[:20],
            "impact":{"counts":impact_report.counts,"items":impact_items[:50]},
            "actions":actions,
            "boundary":"Read-only bounded synthesis. It recommends review paths but never changes truth, status, history, or authorization."
        }
    except ValueError as e:
        raise HTTPException(404,str(e))
    except Exception as e:
        raise HTTPException(400,str(e))


class AttentionFeedbackIn(BaseModel):
    action: str = Field(min_length=1,max_length=32)
    success: bool
    note: str = Field(default="",max_length=2000)
    baseline: dict[str,Any] = Field(default_factory=dict)

@app.post("/graph/attention/{node_id}/feedback",dependencies=[Depends(auth)])
def graph_attention_feedback(node_id:str, body:AttentionFeedbackIn):
    try:
        current=graph_attention(node_id, max_nodes=200).get("summary",{})
        x=learning_core.attention_feedback(node_id, body.action, success=body.success, note=body.note, source="user", baseline=body.baseline, current=current)
        meta=x and g.get(x.experience_id).metadata or {}
        return {"recorded":True,"experience_id":x.experience_id,"action":body.action,"success":body.success,"state_delta":meta.get("metadata",{}).get("state_delta",{}),"resolution_signal":meta.get("metadata",{}).get("resolution_signal","unknown"),"learning_boundary":"Explicit user experience signal plus bounded before/after state measurement; it does not alter knowledge truth, status, history, or authorization."}
    except ValueError as e: raise HTTPException(400,str(e))


@app.get("/impact",dependencies=[Depends(auth)])
def impact(roots:str, run_id:str|None=None, max_nodes:int=10000):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        report=DependencyImpactAnalyzer(g).analyze(root_ids, run_id=run_id, max_nodes=max_nodes)
        return asdict(report)
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.post("/reevaluation-queue",dependencies=[Depends(auth)])
def create_reevaluation_queue(roots:str, run_id:str|None=None, max_nodes:int=10000, reuse_existing:bool=True):
    try:
        root_ids=[x.strip() for x in roots.split(",") if x.strip()]
        return asdict(ReEvaluationController(g).create(root_ids, run_id=run_id, max_nodes=max_nodes, reuse_existing=reuse_existing))
    except (ValueError,KeyError) as e:
        raise HTTPException(400,str(e))

@app.get("/reevaluation-queue/{queue_id}",dependencies=[Depends(auth)])
def get_reevaluation_queue(queue_id:str):
    try:return asdict(ReEvaluationController(g).get(queue_id))
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))

@app.get("/reevaluation-item/{item_id}/policy",dependencies=[Depends(auth)])
def reevaluation_policy(item_id:str):
    try:return asdict(ReEvaluationWorkflow(g).policy(item_id))
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))

@app.post("/reevaluation-item/{item_id}/assessment",dependencies=[Depends(auth)])
def reevaluation_assessment(item_id:str, assessor_id:str, outcome:str, evidence_ids:str="", observation_ids:str="", rationale:str=""):
    try:
        ev=[x.strip() for x in evidence_ids.split(",") if x.strip()]
        obs=[x.strip() for x in observation_ids.split(",") if x.strip()]
        return asdict(ReEvaluationWorkflow(g).submit(item_id, assessor_id=assessor_id, outcome=outcome, evidence_ids=ev, observation_ids=obs, rationale=rationale))
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))

@app.post("/reevaluation-item/{item_id}/propose-transition",dependencies=[Depends(auth)])
def reevaluation_transition(item_id:str):
    try:return asdict(ReEvaluationWorkflow(g).propose_transition(item_id))
    except (ValueError,KeyError) as e:raise HTTPException(400,str(e))


@app.get("/maintenance/plan",dependencies=[Depends(auth)])
def maintenance_plan(max_tasks:int=100, include_clean:bool=False):
    try: return asdict(ContinuousMaintenanceEngine(g).plan(max_tasks=max_tasks, include_clean=include_clean))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/evidence/{evidence_id}/spans",dependencies=[Depends(auth)])
def evidence_spans(evidence_id:str):
    try: return [asdict(x) for x in EvidencePrecision(g).spans(evidence_id)]
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.post("/evidence/{evidence_id}/span",dependencies=[Depends(auth)])
def add_evidence_span(evidence_id:str, locator:str, quote:str, extraction_method:str="manual", start_offset:int|None=None, end_offset:int|None=None):
    try: return asdict(EvidencePrecision(g).add_span(evidence_id,locator,quote,extraction_method=extraction_method,start_offset=start_offset,end_offset=end_offset))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/knowledge/{node_id}/unknowns",dependencies=[Depends(auth)])
def knowledge_unknowns(node_id:str):
    try: return [asdict(x) for x in NegativeKnowledge(g).list(node_id)]
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.post("/unknowns",dependencies=[Depends(auth)])
def create_unknown(question:str, subject_id:str|None=None, scope:str="current investigation", basis:str="insufficient evidence"):
    try: return asdict(NegativeKnowledge(g).record(question,subject_id=subject_id,scope=scope,basis=basis))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/knowledge/{node_id}/validity",dependencies=[Depends(auth)])
def knowledge_validity(node_id:str, as_of:str|None=None):
    try: return asdict(TemporalValidity(g).assess(node_id,as_of=as_of))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/verification-policy/{node_id}",dependencies=[Depends(auth)])
def verification_policy(node_id:str, required_evidence:int=1, minimum_independent:int=2, require_spans:bool=False):
    try: return asdict(VerificationPolicyEngine(g).assess(node_id,required_evidence=required_evidence,minimum_independent=minimum_independent,require_spans=require_spans))
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.get("/sources/independence",dependencies=[Depends(auth)])
def source_independence(evidence_ids:str):
    try: return SourceIndependence(g).analyze([x.strip() for x in evidence_ids.split(',') if x.strip()])
    except (ValueError,KeyError) as e: raise HTTPException(400,str(e))

@app.post("/audit/digest",dependencies=[Depends(auth)])
def audit_digest():
    try:
        d,n=CryptographicAudit(g).record(); return {"digest":d.digest,"events_head":d.events_head,"revisions_head":d.revisions_head,"record_id":n.id,"generated_at":d.generated_at}
    except Exception as e: raise HTTPException(500,str(e))

@app.post("/autonomous-run",dependencies=[Depends(auth)])
def autonomous_run(body:AutoIn):
    if not body.urls: raise HTTPException(400,"at least one explicit public URL is required")
    try:
        return intelligence.run_bounded(body.question,[DirectURLProvider(body.urls)],max_cycles=body.max_cycles)
    except Exception as e: raise HTTPException(400,str(e))


@app.get("/assurance/system",dependencies=[Depends(auth)])
def assurance_system():
    try:
        snap=SystemAssuranceEngine(g, __import__("pathlib").Path(__file__).resolve().parent).snapshot()
        return SystemAssuranceEngine(g, __import__("pathlib").Path(__file__).resolve().parent).health(snap) | {"architecture_digest":snap.architecture.digest,"constitution_digest":snap.constitution.digest}
    except Exception as e: raise HTTPException(500,str(e))

@app.get("/assurance/system/contracts",dependencies=[Depends(auth)])
def assurance_system_contracts():
    try:
        snap=SystemAssuranceEngine(g, __import__("pathlib").Path(__file__).resolve().parent).snapshot()
        return {"contracts":[c.__dict__ for c in snap.contracts],"invariants":[i.__dict__ for i in snap.invariants]}
    except Exception as e: raise HTTPException(500,str(e))

@app.get("/assurance/system/architecture",dependencies=[Depends(auth)])
def assurance_system_architecture():
    try:
        snap=SystemAssuranceEngine(g, __import__("pathlib").Path(__file__).resolve().parent).snapshot()
        return {"nodes":[n.__dict__ for n in snap.architecture.nodes],"edges":[e.__dict__ for e in snap.architecture.edges],"digest":snap.architecture.digest}
    except Exception as e: raise HTTPException(500,str(e))

@app.get("/legal/privacy", response_class=HTMLResponse)
def privacy_policy():
    return HTMLResponse("""<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>TBOHK Privacy</title><style>body{font:16px/1.6 system-ui;max-width:820px;margin:40px auto;padding:0 20px;background:#070a0f;color:#eef2f7}a{color:#a9c9f5}h1,h2{line-height:1.2}</style></head><body><h1>TBOHK Privacy Policy</h1><p>Effective date: September 26, 2026.</p><h2>What we process</h2><p>TBOHK processes account identifiers, authentication credentials in protected form, usage records, research inputs, knowledge records, billing identifiers, and security/audit events needed to operate the service.</p><h2>Why we process it</h2><p>We use this information to authenticate accounts, enforce plan limits, operate research and knowledge features, process billing, prevent abuse, maintain security, and provide support.</p><h2>Research sources</h2><p>Sources submitted for research are retained as provenance records so answers can remain auditable. Do not submit information you are not authorized to disclose.</p><h2>Deletion</h2><p>Account deletion is available from Account settings and removes the account credentials, usage records, entitlements, and tenant database subject to necessary billing/legal records.</p><h2>Contact</h2><p>Support contact is published at <a href=\"/support\">/support</a>.</p></body></html>""")

@app.get("/legal/terms", response_class=HTMLResponse)
def terms_of_service():
    return HTMLResponse("""<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>TBOHK Terms</title><style>body{font:16px/1.6 system-ui;max-width:820px;margin:40px auto;padding:0 20px;background:#070a0f;color:#eef2f7}a{color:#a9c9f5}h1,h2{line-height:1.2}</style></head><body><h1>TBOHK Terms of Service</h1><p>Effective date: September 26, 2026.</p><h2>Service</h2><p>TBOHK provides an auditable knowledge and research workspace. Service output is evidence-organized information, not a guarantee of truth, professional advice, or a substitute for appropriate expert review.</p><h2>Accounts</h2><p>You are responsible for maintaining control of your credentials and for activity performed through your account. Do not share authentication tokens.</p><h2>Research and content</h2><p>You must have the right to submit research sources and content. You remain responsible for how you use generated or retrieved information.</p><h2>Billing</h2><p>Plans, usage limits, and billing terms are presented in the application. Paid subscriptions may be managed through the configured billing provider and are subject to the provider's applicable terms.</p><h2>Acceptable use</h2><p>Do not use TBOHK to violate law, rights, security controls, or third-party terms, or to submit information you are not authorized to process.</p><h2>Support</h2><p>Support contact is published at <a href=\"/support\">/support</a>.</p></body></html>""")

@app.get("/support", response_class=HTMLResponse)
def support_page():
    contact=os.getenv("TBOHK_SUPPORT_EMAIL", "support@example.com")
    return HTMLResponse(f"""<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>TBOHK Support</title><style>body{{font:16px/1.6 system-ui;max-width:820px;margin:40px auto;padding:0 20px;background:#070a0f;color:#eef2f7}}a{{color:#a9c9f5}}h1,h2{{line-height:1.2}}</style></head><body><h1>TBOHK Support</h1><p>For account, billing, security, or product issues, contact <a href=\"mailto:{contact}\">{contact}</a>.</p><h2>Before contacting support</h2><ul><li>Include the affected account email.</li><li>Include the approximate time and endpoint/action involved.</li><li>Never send your password, API token, recovery token, or payment-card details.</li></ul><h2>Account deletion</h2><p>Signed-in users can permanently delete their account from Account settings.</p></body></html>""")

@app.get("/",response_class=HTMLResponse)
def home():
    return page(__version__)
