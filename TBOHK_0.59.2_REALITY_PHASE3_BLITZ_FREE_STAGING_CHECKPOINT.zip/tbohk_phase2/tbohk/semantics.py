from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
import json
from .core import TBOHK

METHODS = {
    "deductive": {"requires": "rule", "default_disposition": "derived"},
    "inductive": {"requires": "observations", "default_disposition": "generalization"},
    "abductive": {"requires": "observations", "default_disposition": "candidate_explanation"},
    "defeasible": {"requires": "rule", "default_disposition": "defeasible"},
    "analogical": {"requires": "analogy", "default_disposition": "analogy"},
    "counterfactual": {"requires": "world_model", "default_disposition": "hypothetical"},
    "aggregative": {"requires": "aggregation", "default_disposition": "aggregate"},
}

ROLES = {"necessary", "sufficient", "contributory", "defeater", "assumption", "background"}

@dataclass(frozen=True)
class SemanticResult:
    activity_id: str
    conclusion_id: str
    method: str
    premise_ids: tuple[str, ...]
    assumption_ids: tuple[str, ...]
    defeater_ids: tuple[str, ...]
    branch_id: str | None = None

class SemanticReasoningEngine:
    """G4.2 semantic reasoning layer.

    This layer makes inference semantics explicit without asserting truth. It is
    intentionally independent from the existing small set of executable G4 rules.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def _norm(v):
        if isinstance(v, dict): return {str(k): SemanticReasoningEngine._norm(x) for k,x in sorted(v.items())}
        if isinstance(v, list): return [SemanticReasoningEngine._norm(x) for x in v]
        return v

    def _claims(self, ids):
        out=[]
        for cid in ids:
            n=self.g.get(cid)
            if not n or n.kind != "Claim": raise ValueError(f"not a claim: {cid}")
            if n.status not in {"supported","verified"}: raise ValueError(f"unsupported premise: {cid}")
            out.append(n)
        return out

    def add_assumption(self, content: str, *, structured=None, scope=None, authority="analyst"):
        return self.g.add_node("Assumption", content, "proposed", {
            "structured": structured or {}, "scope": scope, "authority": authority,
            "created_at": datetime.now(timezone.utc).isoformat()
        })

    def add_defeater(self, content: str, *, structured=None, scope=None, authority="analyst"):
        return self.g.add_node("Defeater", content, "proposed", {
            "structured": structured or {}, "scope": scope, "authority": authority,
            "created_at": datetime.now(timezone.utc).isoformat()
        })

    def propose(self, method: str, premise_ids: list[str], *, conclusion: str,
                structured: dict[str, Any] | None = None, premise_roles: dict[str,str] | None = None,
                assumption_ids: list[str] | None = None, defeater_ids: list[str] | None = None,
                rule_id: str | None = None, counterfactual: dict[str,Any] | None = None,
                assessor="system", disposition=None):
        if method not in METHODS: raise ValueError(f"unsupported reasoning method: {method}")
        if not premise_ids: raise ValueError("reasoning requires at least one premise")
        if len(set(premise_ids)) != len(premise_ids): raise ValueError("duplicate premises")
        self._claims(premise_ids)
        premise_roles = premise_roles or {}
        for pid, role in premise_roles.items():
            if pid not in premise_ids: raise ValueError(f"role assigned to non-premise: {pid}")
            if role not in ROLES: raise ValueError(f"invalid premise role: {role}")
        assumptions=[]
        for aid in assumption_ids or []:
            n=self.g.get(aid)
            if not n or n.kind != "Assumption": raise ValueError(f"not an assumption: {aid}")
            assumptions.append(n)
        defeaters=[]
        for did in defeater_ids or []:
            n=self.g.get(did)
            if not n or n.kind != "Defeater": raise ValueError(f"not a defeater: {did}")
            defeaters.append(n)
        if method == "counterfactual":
            if not isinstance(counterfactual, dict) or not counterfactual.get("intervention"):
                raise ValueError("counterfactual reasoning requires an explicit intervention")
        if method == "deductive" and not rule_id:
            raise ValueError("deductive reasoning requires rule_id")
        if rule_id:
            rule=self.g.get(rule_id)
            if not rule or rule.kind != "ReasoningRule": raise ValueError("invalid rule_id")
        if rule_id is None:
            semantic_rule_payload={"rule_type":f"semantic_{method}","name":f"G4.2 {method}","schema":{"method":method},"authority":"semantic-layer"}
            semantic_rule_payload["rule_sha256"]=self.g._hash(json.dumps(semantic_rule_payload, sort_keys=True))
            semantic_rule=self.g.add_node("ReasoningRule", f"G4.2 {method}", "supported", semantic_rule_payload)
            rule_id=semantic_rule.id
        activity=self.g.add_node("ReasoningActivity", f"{method} inference", "supported", {
            "semantic_layer":"G4.2", "method":method, "premise_ids":premise_ids,
            "premise_roles":premise_roles, "assumption_ids":[x.id for x in assumptions],
            "defeater_ids":[x.id for x in defeaters], "rule_id":rule_id,
            "counterfactual":counterfactual, "assessor":assessor,
            "performed_at":datetime.now(timezone.utc).isoformat(), "conclusion_id":None,
            "disposition":disposition or METHODS[method]["default_disposition"]
        })
        for pid in premise_ids:
            self.g.link(pid,"premise_of",activity.id)
            self.g.link(activity.id,"uses",pid)
        for a in assumptions: self.g.link(activity.id,"assumes",a.id)
        for d in defeaters: self.g.link(d.id,"defeats",activity.id)
        if rule_id: self.g.link(activity.id,"applies_rule",rule_id)
        branch_id=None
        if method == "counterfactual":
            branch=self.g.add_node("CounterfactualBranch", "counterfactual branch", "proposed", {
                "intervention":counterfactual["intervention"], "baseline":counterfactual.get("baseline"),
                "scope":counterfactual.get("scope"), "activity_id":activity.id
            })
            branch_id=branch.id; self.g.link(activity.id,"creates_branch",branch.id)
        metadata={"derived":True,"origin":"reasoning","reasoning_activity_id":activity.id,
                   "reasoning_method":method,"premise_ids":premise_ids,"premise_roles":premise_roles,
                   "assumption_ids":[x.id for x in assumptions],"defeater_ids":[x.id for x in defeaters],
                   "structured":structured or {},"epistemic_disposition":disposition or METHODS[method]["default_disposition"]}
        if branch_id: metadata["counterfactual_branch_id"]=branch_id
        claim=self.g.add_node("Claim", conclusion, "proposed", metadata)
        self.g.update_metadata(activity.id, {"conclusion_id": claim.id}, reason="reasoning conclusion linked")
        self.g.link(activity.id,"derives",claim.id); self.g.link(activity.id,"produces",claim.id); self.g.link(claim.id,"generated_by",activity.id)
        for pid in premise_ids: self.g.link(claim.id,"derived_from",pid)
        return SemanticResult(activity.id,claim.id,method,tuple(premise_ids),tuple(x.id for x in assumptions),tuple(x.id for x in defeaters),branch_id)

    def assess(self, activity_id: str, *, assessor="independent-review"):
        a=self.g.get(activity_id)
        if not a or a.kind != "ReasoningActivity": raise ValueError("not a reasoning activity")
        m=a.metadata
        method=m.get("method")
        findings=[]; status="adequate"
        if method not in METHODS: findings.append("unknown reasoning method"); status="invalid"
        if method == "deductive" and not m.get("rule_id"): findings.append("deductive inference lacks rule"); status="invalid"
        if method == "counterfactual" and not m.get("counterfactual",{}).get("intervention"): findings.append("counterfactual lacks intervention"); status="invalid"
        if not m.get("premise_roles") and method in {"deductive","defeasible"}: findings.append("premise roles are not explicit")
        if m.get("assumption_ids"): findings.append("conclusion depends on explicit assumptions")
        if m.get("defeater_ids"): findings.append("conclusion has explicit defeater exposure")
        node=self.g.add_node("ReasoningAssessment",f"Assessment of {activity_id}","supported",{
            "activity_id":activity_id,"assessor":assessor,"assessed_at":datetime.now(timezone.utc).isoformat(),
            "status":status,"findings":findings,"method":method
        })
        self.g.link(node.id,"evaluates",activity_id)
        return node
