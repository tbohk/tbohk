from __future__ import annotations
from dataclasses import dataclass
from .core import TBOHK

@dataclass(frozen=True)
class LearningSnapshot:
    cycle: int
    new_evidence: int
    new_origins: int
    new_providers: int
    novel_evidence: int
    marginal_value: int
    unresolved_targets: int
    stop_recommended: bool
    rationale: tuple[str, ...]

class AdaptiveLearningEngine:
    """Auditable, deterministic learning-state tracker for adaptive research.

    It measures information acquired by a research cycle without assigning
    truth probabilities. Repeated evidence has lower marginal value; distinct
    origins/providers and genuinely new material preserve value. The engine
    recommends stopping when a bounded cycle adds no novel evidence.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def update(self, run_id: str, cycle: int, evidence_nodes: list, unresolved_targets: int) -> LearningSnapshot:
        run = self.g.get(run_id)
        if not run or run.kind != 'AdaptiveResearchRun':
            raise ValueError('invalid adaptive research run')
        prior_ids = set()
        prior_origins = set()
        prior_providers = set()
        prior_texts = set()
        for e in self.g.edges(run_id, direction='out', relation='contains'):
            n = self.g.get(e['target_id'])
            if not n or n.kind != 'AdaptiveResearchCycle' or int(n.metadata.get('cycle', 0)) >= cycle:
                continue
            for eid in n.metadata.get('evidence_ids', []):
                prior_ids.add(eid)
                ev = self.g.get(eid)
                if ev:
                    prior_origins.add(ev.metadata.get('origin_id'))
                    prior_providers.add(ev.metadata.get('provider_id'))
                    prior_texts.add(ev.content.strip())
        ids = {n.id for n in evidence_nodes}
        origins = {n.metadata.get('origin_id') for n in evidence_nodes if n.metadata.get('origin_id')}
        providers = {n.metadata.get('provider_id') for n in evidence_nodes if n.metadata.get('provider_id')}
        novel = {n.content.strip() for n in evidence_nodes if n.content.strip() not in prior_texts}
        new_evidence = len(ids - prior_ids)
        new_origins = len(origins - prior_origins)
        new_providers = len(providers - prior_providers)
        novel_evidence = len(novel)
        marginal_value = novel_evidence * 2 + new_origins + new_providers
        stop = unresolved_targets <= 0 or marginal_value == 0
        rationale = []
        if novel_evidence:
            rationale.append(f'{novel_evidence} novel evidence item(s)')
        else:
            rationale.append('no novel evidence in this cycle')
        if new_origins:
            rationale.append(f'{new_origins} new evidence origin(s)')
        if new_providers:
            rationale.append(f'{new_providers} new provider(s)')
        if unresolved_targets <= 0:
            rationale.append('no unresolved informative target remains')
        elif marginal_value == 0:
            rationale.append('marginal informational value reached zero')
        return LearningSnapshot(cycle, new_evidence, new_origins, new_providers, novel_evidence,
                                marginal_value, unresolved_targets, stop, tuple(rationale))

    def record(self, run_id: str, snapshot: LearningSnapshot, evidence_ids: list[str]) -> str:
        n = self.g.add_node('AdaptiveLearningState', f'learning cycle {snapshot.cycle}', 'supported', {
            'run_id': run_id, 'cycle': snapshot.cycle, 'new_evidence': snapshot.new_evidence,
            'new_origins': snapshot.new_origins, 'new_providers': snapshot.new_providers,
            'novel_evidence': snapshot.novel_evidence, 'marginal_value': snapshot.marginal_value,
            'unresolved_targets': snapshot.unresolved_targets, 'stop_recommended': snapshot.stop_recommended,
            'rationale': list(snapshot.rationale), 'evidence_ids': list(evidence_ids),
            'truth_boundary': 'information-value assessment is a stopping heuristic, not a truth or probability score',
        })
        for eid in evidence_ids:
            if self.g.get(eid):
                self.g.link(n.id, 'observes', eid)
        return n.id
