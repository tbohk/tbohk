from __future__ import annotations
from datetime import datetime, timezone
from typing import Any

class TemporalQuery:
    """Read-only temporal view over node metadata; malformed intervals are surfaced."""
    def __init__(self, graph): self.g=graph
    @staticmethod
    def _parse(v):
        if not v: return None
        try:
            d=datetime.fromisoformat(str(v).replace('Z','+00:00'))
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
        except Exception: return None
    def active(self, *, at=None, kinds=None, limit=200):
        when=self._parse(at) or datetime.now(timezone.utc)
        kinds=list(kinds or [])
        args=[]; where=[]
        if kinds: where.append("kind IN (%s)" % ','.join('?'*len(kinds))); args.extend(kinds)
        rows=self.g.db.execute("SELECT * FROM nodes" + (" WHERE "+" AND ".join(where) if where else "") + " ORDER BY rowid DESC LIMIT ?",(*args,max(1,min(int(limit),1000)))).fetchall()
        out=[]; invalid=[]
        for r in rows:
            m=__import__('json').loads(r['metadata']); start=self._parse(m.get('valid_from')); end=self._parse(m.get('valid_until'))
            if m.get('valid_from') and start is None or m.get('valid_until') and end is None or (start and end and end < start):
                invalid.append(r['id']); continue
            if (start is None or start <= when) and (end is None or when < end): out.append(dict(r))
        return {"at":when.isoformat(),"items":out,"invalid_intervals":invalid}
