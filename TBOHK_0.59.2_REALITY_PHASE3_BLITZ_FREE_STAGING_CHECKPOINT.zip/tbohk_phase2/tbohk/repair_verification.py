"""Closed-loop verification for bounded repair candidates.

Repairs are never applied to authoritative source by this module. A candidate
is validated against a baseline, a controlled post-repair observation, and an
independent gate. The result is deterministic and auditable.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Callable, Any

@dataclass(frozen=True)
class RepairVerification:
    repair_id: str
    reproduced_failure: bool
    repair_effective: bool
    regression_passed: bool
    accepted: bool
    failures: tuple[str, ...]
    digest: str

class RepairVerifier:
    VERSION = "RV1.0-1"

    @staticmethod
    def _digest(payload: Any) -> str:
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

    def verify(self, repair_id: str, *, reproduce: Callable[[], Any], apply_candidate: Callable[[], Any], regression: Callable[[], Any]) -> RepairVerification:
        failures: list[str] = []
        try:
            reproduced = bool(reproduce())
        except Exception as exc:
            reproduced = False
            failures.append(f"reproduce:{type(exc).__name__}")
        if not reproduced:
            failures.append("original-failure-not-reproduced")
        try:
            effective = bool(apply_candidate())
        except Exception as exc:
            effective = False
            failures.append(f"repair:{type(exc).__name__}")
        if not effective:
            failures.append("repair-not-effective")
        try:
            passed = bool(regression())
        except Exception as exc:
            passed = False
            failures.append(f"regression:{type(exc).__name__}")
        if not passed:
            failures.append("regression-gate-failed")
        accepted = reproduced and effective and passed and not failures
        payload = {"version": self.VERSION, "repair_id": repair_id, "reproduced_failure": reproduced, "repair_effective": effective, "regression_passed": passed, "accepted": accepted, "failures": failures}
        return RepairVerification(repair_id, reproduced, effective, passed, accepted, tuple(failures), self._digest(payload))
