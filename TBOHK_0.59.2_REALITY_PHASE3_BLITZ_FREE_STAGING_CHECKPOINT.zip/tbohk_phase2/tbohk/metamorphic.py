from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib, json
from .core import TBOHK
from .research import ResearchChain, MockProvider, SourceDocument
from .epistemic import EpistemicEngine
from .reasoning import ReasoningEngine
from .semantics import SemanticReasoningEngine

SUITE_VERSION = "G4.8-1"

@dataclass(frozen=True)
class MetamorphicCase:
    case_id: str
    property: str
    purpose: str

@dataclass(frozen=True)
class MetamorphicResult:
    case_id: str
    passed: bool
    findings: tuple[str, ...]

@dataclass(frozen=True)
class MetamorphicReport:
    suite_version: str
    suite_sha256: str
    total: int
    passed: int
    failed: int
    results: tuple[MetamorphicResult, ...]
    assessed_at: str

CASES = (
    MetamorphicCase("G48-001", "premise_permutation", "reordering independent conjunction premises preserves semantics"),
    MetamorphicCase("G48-002", "duplicate_invariance", "duplicating a premise cannot manufacture additional support"),
    MetamorphicCase("G48-003", "identifier_renaming", "internal identifiers do not determine inference semantics"),
    MetamorphicCase("G48-004", "equivalent_representation", "equivalent structured representations preserve semantics"),
    MetamorphicCase("G48-005", "irrelevant_evidence", "irrelevant evidence cannot strengthen a derivation"),
    MetamorphicCase("G48-006", "necessary_premise_removal", "removing a necessary premise cannot strengthen the result"),
    MetamorphicCase("G48-007", "assumption_locality", "changing an assumption affects only dependent reasoning"),
    MetamorphicCase("G48-008", "unrelated_conflict_locality", "unrelated conflict does not contaminate a separate inference"),
    MetamorphicCase("G48-009", "provider_identity_invariance", "provider relabeling without origin change does not create independence"),
    MetamorphicCase("G48-010", "irrelevant_order", "ordering unrelated evidence does not alter semantic content"),
    MetamorphicCase("G48-011", "rule_fingerprint_sensitivity", "changing a rule definition changes its identity fingerprint"),
    MetamorphicCase("G48-012", "counterfactual_isolation", "equivalent real-world premises cannot collapse a counterfactual branch"),
)

def suite_manifest() -> str:
    return json.dumps({"version": SUITE_VERSION, "cases":[c.__dict__ for c in CASES]}, sort_keys=True, separators=(",", ":"))

def suite_sha256() -> str:
    return hashlib.sha256(suite_manifest().encode()).hexdigest()

def _doc(source, provider, origin, text):
    now="2026-01-01T00:00:00+00:00"
    return SourceDocument(source, source, f"https://example/{source}", text, provider, now, origin, now)

def _base():
    a=MockProvider("p1",[_doc("s1","p1","o1","A is true.")])
    b=MockProvider("p2",[_doc("s2","p2","o2","B is true.")])
    g=TBOHK(); out=ResearchChain(g,[a,b]).run("true")
    return g,out

def _claims(g,out):
    e=EpistemicEngine(g)
    a=e.propose_claim("A",[out["results"][0][1].id]); g.set_status(a.id,"supported","fixture")
    b=e.propose_claim("B",[out["results"][1][1].id]); g.set_status(b.id,"supported","fixture")
    return a,b

def run_case(case_id):
    g,out=_base(); a,b=_claims(g,out); rr=ReasoningEngine(g)
    if case_id=="G48-001":
        r=rr.add_rule("conj","conjunction",{"consequent":{"all":True},"required_semantics":[a.metadata["structured"],b.metadata["structured"]]})
        x=rr.derive(r.id,[a.id,b.id]); y=rr.derive(r.id,[b.id,a.id])
        return g.get(x.conclusion_id).metadata["structured"]==g.get(y.conclusion_id).metadata["structured"],"premise permutation preserved conjunction semantics"
    if case_id=="G48-002":
        r=rr.add_rule("id","identity",{"consequent":a.metadata["structured"]})
        try: rr.derive(r.id,[a.id,a.id])
        except ValueError: return True,"duplicate premise rejected"
        return False,"duplicate premise accepted"
    if case_id=="G48-003":
        r=rr.add_rule("id","identity",{"consequent":a.metadata["structured"]})
        x=rr.derive(r.id,[a.id])
        g2,out2=_base(); aa,_=_claims(g2,out2); r2=ReasoningEngine(g2).add_rule("id2","identity",{"consequent":aa.metadata["structured"]})
        y=ReasoningEngine(g2).derive(r2.id,[aa.id])
        return g.get(x.conclusion_id).metadata["structured"]==g2.get(y.conclusion_id).metadata["structured"],"identifier renaming does not alter semantic result"
    if case_id=="G48-004":
        r=rr.add_rule("id","identity",{"consequent":{"subject":"A","predicate":"is","object":True}})
        a2=g.add_node("Claim","A equivalent", "supported", {"structured":{"predicate":"is","subject":"A","object":True}})
        x=rr.derive(r.id,[a2.id])
        return x is not None,"equivalent structured key ordering preserved"
    if case_id=="G48-005":
        r=rr.add_rule("id","identity",{"consequent":a.metadata["structured"]}); x=rr.derive(r.id,[a.id])
        irrelevant=g.add_node("Evidence","irrelevant","supported",{})
        return g.get(x.conclusion_id).metadata["structured"]==a.metadata["structured"],"irrelevant evidence does not alter derivation"
    if case_id=="G48-006":
        r=rr.add_rule("conj","conjunction",{"consequent":{"all":True},"required_semantics":[a.metadata["structured"],b.metadata["structured"]]})
        try: rr.derive(r.id,[a.id])
        except ValueError: return True,"necessary premise removal rejected"
        return False,"necessary premise removal accepted"
    if case_id=="G48-007":
        se=SemanticReasoningEngine(g); ass=se.add_assumption("condition"); x=se.propose("defeasible",[a.id],conclusion="normally",assumption_ids=[ass.id])
        y=se.propose("defeasible",[b.id],conclusion="normally")
        return ass.id in x.assumption_ids and not ass.id in y.assumption_ids,"assumption dependency remains local"
    if case_id=="G48-008":
        e=EpistemicEngine(g); c=e.propose_claim("not B",[out["results"][0][1].id])
        conflict=e.contradict(b.id,c.id)
        return g.get(a.id).status=="supported" and g.get(b.id).status=="supported" and conflict.status=="proposed","unrelated conflict does not mutate separate claims"
    if case_id=="G48-009":
        # Start with distinct providers but collapse their upstream origin lineage.
        for sid in (out["results"][0][0].id,out["results"][1][0].id):
            row=g.get(sid); md=dict(row.metadata); md["provider_id"]="same-provider"; md["origin_id"]="shared-origin"; g.db.execute("UPDATE nodes SET metadata=? WHERE id=?",(json.dumps(md,sort_keys=True),sid))
        for _,eid in out["results"]:
            row=g.get(eid.id); md=dict(row.metadata); md["origin_id"]="shared-origin"; md["provider_id"]="same-provider"; g.db.execute("UPDATE nodes SET metadata=? WHERE id=?",(json.dumps(md,sort_keys=True),eid.id))
        for sid in (out["results"][0][0].id,out["results"][1][0].id):
            snap=g.get(sid)
            # Evidence points to snapshots, and the snapshot is the authoritative origin lineage.
            pass
        g.db.commit()
        e=EpistemicEngine(g)
        c=e.propose_claim("A corroborated",[out["results"][0][1].id,out["results"][1][1].id])
        try: e.verify_claim(c.id)
        except ValueError as exc: return "independent origin" in str(exc),"provider relabeling cannot create independent origins"
        return False,"shared origin was incorrectly treated as independent"
    if case_id=="G48-010":
        x=[a.metadata["structured"],b.metadata["structured"]]; y=list(reversed(x))
        return {json.dumps(v,sort_keys=True) for v in x}=={json.dumps(v,sort_keys=True) for v in y},"unrelated evidence ordering is semantically invariant"
    if case_id=="G48-011":
        r1=rr.add_rule("r1","identity",{"consequent":a.metadata["structured"]})
        r2=rr.add_rule("r2","identity",{"consequent":{"subject":"A","predicate":"different","object":True}})
        return r1.metadata["rule_sha256"]!=r2.metadata["rule_sha256"],"changed rule definition changes fingerprint"
    if case_id=="G48-012":
        se=SemanticReasoningEngine(g); x=se.propose("counterfactual",[a.id],conclusion="would change",counterfactual={"intervention":"remove A"})
        return x.branch_id is not None and g.get(x.conclusion_id).metadata.get("counterfactual_branch_id")==x.branch_id,"counterfactual branch remains explicit"
    raise KeyError(case_id)

class MetamorphicSuite:
    """Fixed metamorphic-property suite. Non-mutating except local fixture construction."""
    def run(self, *, as_of=None):
        results=[]
        for c in CASES:
            try: passed,finding=run_case(c.case_id)
            except Exception as exc: passed=False; finding=f"unexpected exception: {type(exc).__name__}: {exc}"
            results.append(MetamorphicResult(c.case_id,bool(passed),(finding,)))
        stamp=as_of or datetime.now(timezone.utc).isoformat()
        return MetamorphicReport(SUITE_VERSION,suite_sha256(),len(results),sum(x.passed for x in results),sum(not x.passed for x in results),tuple(results),stamp)
    def record(self, graph:TBOHK, *, assessor="independent-metamorphic-suite", as_of=None):
        report=self.run(as_of=as_of)
        node=graph.add_node("MetamorphicRun",f"G4.8 metamorphic suite {report.suite_version}","supported",{
            "suite_version":report.suite_version,"suite_sha256":report.suite_sha256,"assessor":assessor,
            "assessed_at":report.assessed_at,"total":report.total,"passed":report.passed,"failed":report.failed,
            "results":[{"case_id":r.case_id,"passed":r.passed,"findings":list(r.findings)} for r in report.results]
        })
        return report,node
