from __future__ import annotations
import hashlib, json, sqlite3, uuid, threading
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

STATUSES = {
    "unknown", "proposed", "supported", "verified", "contradicted",
    "superseded", "stale", "rejected", "failed", "recovered", "resolved"
}

RELATIONS = {
    "supports", "evidence_for", "verified_by", "derived_from", "contradicts",
    "generated_by", "uses", "dispatches", "produces", "about", "based_on",
    "supersedes", "same_as", "independent_of", "member_of", "contains",
    "observes", "attributed_to", "invalidates", "documents", "resolves",
    "records", "evaluates", "originates_from", "derived_from_origin", "applies_rule", "premise_of", "derives", "assumes", "defeats", "creates_branch", "approved_by", "depends_on", "governed_by", "proposes", "authorizes", "validates", "reverses", "evaluates_against", "predicts", "evaluated_by"
}

@dataclass(frozen=True)
class Node:
    id: str
    kind: str
    status: str
    content: str
    created_at: str
    metadata: dict[str, Any]

class TBOHK:
    """Auditable knowledge substrate for the hardened G2/G3 research/epistemic slice."""
    def __init__(self, path=":memory:"):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self._closed = False
        self._write_lock = threading.RLock()
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA busy_timeout=5000")
        self.db.execute("PRAGMA recursive_triggers=ON")
        self.db.execute("PRAGMA trusted_schema=OFF")
        if path != ":memory:":
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS nodes(
          id TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL,
          content TEXT NOT NULL, metadata TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS edges(
          source_id TEXT NOT NULL REFERENCES nodes(id), relation TEXT NOT NULL,
          target_id TEXT NOT NULL REFERENCES nodes(id), created_at TEXT NOT NULL,
          PRIMARY KEY(source_id, relation, target_id));
        CREATE TABLE IF NOT EXISTS events(
          id TEXT PRIMARY KEY, event_type TEXT NOT NULL, subject_id TEXT NOT NULL,
          payload TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS revisions(
          id TEXT PRIMARY KEY, node_id TEXT NOT NULL REFERENCES nodes(id),
          old_status TEXT, new_status TEXT, old_content TEXT, new_content TEXT,
          reason TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_edges_target_relation ON edges(target_id, relation);
        CREATE INDEX IF NOT EXISTS idx_edges_source_relation ON edges(source_id, relation);
        CREATE INDEX IF NOT EXISTS idx_events_subject ON events(subject_id);
        ''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS ledger_chain(
          table_name TEXT NOT NULL, row_id TEXT NOT NULL, chain_prev TEXT NOT NULL, chain_hash TEXT NOT NULL,
          PRIMARY KEY(table_name,row_id));''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS ledger_anchor(
          table_name TEXT PRIMARY KEY, row_count INTEGER NOT NULL, head_row_id TEXT, head_hash TEXT NOT NULL);''')
        # Never silently reconstruct a missing ledger entry. Doing so would turn
        # tamper evidence into tamper repair during database open. Fresh databases
        # are initialized below; damaged/legacy ledgers remain visibly non-clean
        # until an explicit migration or recovery workflow is performed.
        self._ensure_ledger_anchors()
        from .migrations import MigrationManager
        self.migrations = MigrationManager(self.db)
        self.migrations.migrate()
        self.db.commit()

    def close(self):
        """Close the backing SQLite connection exactly once."""
        if not getattr(self, "_closed", True):
            self.db.close()
            self._closed = True

    def __enter__(self):
        if getattr(self, "_closed", False):
            raise RuntimeError("TBOHK instance is closed")
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def __del__(self):
        # Best-effort cleanup for callers that construct a graph without an
        # explicit context manager. Bypass an overridden close() so a failed
        # or monkeypatched lifecycle hook cannot leak the SQLite connection.
        try:
            db = getattr(self, "db", None)
            if db is not None and not getattr(self, "_closed", True):
                db.close()
                self._closed = True
        except Exception:
            pass

    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _id(prefix): return f"{prefix}_{uuid.uuid4().hex}"
    @staticmethod
    def _hash(text: str) -> str: return hashlib.sha256(text.encode("utf-8")).hexdigest()

    @classmethod
    def _metadata_hash(cls, metadata: dict[str, Any]) -> str:
        canonical={k:v for k,v in metadata.items() if k != "metadata_sha256"}
        return cls._hash(json.dumps(canonical, sort_keys=True, separators=(",",":"), ensure_ascii=False))

    def _chain_append(self, table, row_id, values):
        prev_row=self.db.execute("SELECT chain_hash FROM ledger_chain WHERE table_name=? ORDER BY rowid DESC LIMIT 1",(table,)).fetchone()
        prev=(prev_row[0] if prev_row else "GENESIS")
        canonical=json.dumps(dict(values),sort_keys=True,separators=(",",":"))
        digest=hashlib.sha256((prev+"|"+canonical).encode()).hexdigest()
        self.db.execute("INSERT OR REPLACE INTO ledger_chain(table_name,row_id,chain_prev,chain_hash) VALUES (?,?,?,?)",(table,row_id,prev,digest))
        count=self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        self.db.execute("INSERT INTO ledger_anchor(table_name,row_count,head_row_id,head_hash) VALUES (?,?,?,?) ON CONFLICT(table_name) DO UPDATE SET row_count=excluded.row_count,head_row_id=excluded.head_row_id,head_hash=excluded.head_hash",(table,count,row_id,digest))
    def _ensure_ledger_anchors(self):
        for table in ('events','revisions'):
            row=self.db.execute("SELECT row_id,chain_hash FROM ledger_chain WHERE table_name=? ORDER BY rowid DESC LIMIT 1",(table,)).fetchone()
            count=self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            if row:
                self.db.execute("INSERT OR IGNORE INTO ledger_anchor(table_name,row_count,head_row_id,head_hash) VALUES (?,?,?,?)",(table,count,row['row_id'],row['chain_hash']))
            else:
                self.db.execute("INSERT OR IGNORE INTO ledger_anchor(table_name,row_count,head_row_id,head_hash) VALUES (?,?,?,?)",(table,count,None,'GENESIS'))
    def _rebuild_missing_ledger_entries(self):
        for table in ('events','revisions'):
            rows=self.db.execute(f'SELECT * FROM {table} ORDER BY rowid').fetchall()
            prev=self.db.execute("SELECT row_id FROM ledger_chain WHERE table_name=? ORDER BY rowid DESC LIMIT 1",(table,)).fetchone()
            start_after=prev[0] if prev else None
            found=start_after is None
            for r in rows:
                if not found:
                    if r['id']==start_after: found=True
                    continue
                d=dict(r); canonical={k:d[k] for k in d if k!='rowid'}
                self._chain_append(table,r['id'],canonical)
    def _event(self, typ, subject, payload):
        eid=self._id("evt"); now=self._now(); payload_text=json.dumps(payload, sort_keys=True)
        self.db.execute("INSERT INTO events VALUES (?,?,?,?,?)",(eid,typ,subject,payload_text,now))
        self._chain_append('events',eid,{'id':eid,'event_type':typ,'subject_id':subject,'payload':payload_text,'created_at':now})

    def add_node(self, kind, content, status="unknown", metadata=None):
        if status not in STATUSES: raise ValueError("invalid status")
        metadata = dict(metadata or {})
        metadata["content_sha256"] = self._hash(content)
        metadata.pop("metadata_sha256", None)
        metadata["metadata_sha256"] = self._metadata_hash(metadata)
        nid, now = self._id(kind.lower()), self._now()
        with self._write_lock:
            try:
                self.db.execute("INSERT INTO nodes VALUES (?,?,?,?,?,?)",
                                (nid, kind, status, content, json.dumps(metadata, sort_keys=True), now))
                self._event("node.created", nid, {"kind": kind, "status": status})
                self.db.commit()
                return Node(nid, kind, status, content, now, metadata)
            except Exception:
                self.db.rollback()
                raise

    def link(self, source_id, relation, target_id):
        if source_id == target_id: raise ValueError("self-link forbidden")
        if relation not in RELATIONS: raise ValueError(f"unknown relation: {relation}")
        for nid in (source_id, target_id):
            if not self.db.execute("SELECT 1 FROM nodes WHERE id=?", (nid,)).fetchone(): raise KeyError(nid)
        with self._write_lock:
            try:
                self.db.execute("INSERT INTO edges VALUES (?,?,?,?)",
                                (source_id, relation, target_id, self._now()))
                self._event("edge.created", source_id, {"relation": relation, "target_id": target_id})
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise

    def update_metadata(self, node_id, updates, *, replace=False, reason="metadata update"):
        node = self.get(node_id)
        if not node:
            raise KeyError(node_id)
        if not isinstance(updates, dict):
            raise TypeError("metadata updates must be a dict")
        old = dict(node.metadata)
        new = dict(updates) if replace else {**old, **updates}
        new["content_sha256"] = self._hash(node.content)
        new.pop("metadata_sha256", None)
        new["metadata_sha256"] = self._metadata_hash(new)
        json.dumps(new, sort_keys=True)
        now = self._now()
        with self._write_lock:
            try:
                self.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(new, sort_keys=True), node_id))
                self._event("metadata.updated", node_id, {
                    "reason": reason, "old_metadata": old, "new_metadata": new,
                })
                self.db.commit()
                return self.get(node_id)
            except Exception:
                self.db.rollback()
                raise

    def set_status(self, node_id, status, reason=""):
        if status not in STATUSES: raise ValueError("invalid status")
        row = self.db.execute("SELECT status, content FROM nodes WHERE id=?", (node_id,)).fetchone()
        if not row: raise KeyError(node_id)
        old = row[0]
        with self._write_lock:
            try:
                self.db.execute("UPDATE nodes SET status=? WHERE id=?", (status, node_id))
                rid=self._id("rev"); now=self._now()
                self.db.execute("INSERT INTO revisions VALUES (?,?,?,?,?,?,?,?)",
                                 (rid, node_id, old, status, row[1], row[1], reason, now))
                self._chain_append('revisions',rid,{'id':rid,'node_id':node_id,'old_status':old,'new_status':status,'old_content':row[1],'new_content':row[1],'reason':reason,'created_at':now})
                self._event("status.changed", node_id, {"old": old, "new": status, "reason": reason})
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise

    def get(self, node_id):
        r = self.db.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()
        return None if not r else Node(r["id"], r["kind"], r["status"], r["content"], r["created_at"], json.loads(r["metadata"]))

    def edges(self, node_id, direction="both", relation=None):
        if direction not in {"out", "in", "both"}:
            raise ValueError("direction must be out, in, or both")
        if direction == "out":
            clauses, args = ["source_id=?"], [node_id]
        elif direction == "in":
            clauses, args = ["target_id=?"], [node_id]
        else:
            clauses, args = ["(source_id=? OR target_id=?)"], [node_id, node_id]
        if relation:
            if relation not in RELATIONS:
                raise ValueError(f"unknown relation: {relation}")
            clauses.append("relation=?"); args.append(relation)
        sql = "SELECT * FROM edges WHERE " + " AND ".join(clauses)
        return [dict(r) for r in self.db.execute(sql, args)]

    def events(self, subject_id):
        return [dict(r) for r in self.db.execute("SELECT * FROM events WHERE subject_id=? ORDER BY rowid", (subject_id,))]

    def revisions(self, node_id):
        return [dict(r) for r in self.db.execute("SELECT * FROM revisions WHERE node_id=? ORDER BY rowid", (node_id,))]

    @staticmethod
    def _parse_time(value):
        if not value: return None
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError): return None

    def _supporting_evidence(self, claim_id):
        rows = self.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation='evidence_for'",
            (claim_id,)
        ).fetchall()
        return [self.get(r[0]) for r in rows if self.get(r[0])]

    def _snapshot_for_evidence(self, evidence_id):
        for edge in self.edges(evidence_id, direction="out", relation="derived_from"):
            snap = self.get(edge["target_id"])
            if snap and snap.kind == "SourceSnapshot":
                return snap
        return None

    def _temporal_valid(self, snapshot, as_of):
        if not snapshot:
            return False
        meta = snapshot.metadata
        valid_from = self._parse_time(meta.get("valid_from"))
        valid_until = self._parse_time(meta.get("valid_until"))
        if valid_from and as_of < valid_from:
            return False
        if valid_until and as_of > valid_until:
            return False
        return True

    def temporal_invalidation(self, as_of=None):
        """Mark verified claims and dependent knowledge stale when all support is temporally invalid.

        This is an explicit maintenance operation; audit() remains observational.
        """
        as_of = self._parse_time(as_of) if isinstance(as_of, str) else as_of
        as_of = as_of or datetime.now(timezone.utc)
        changed = []
        for row in self.db.execute("SELECT id FROM nodes WHERE kind='Claim' AND status='verified'"):
            claim = self.get(row["id"])
            evidence = self._supporting_evidence(claim.id)
            if not evidence:
                continue
            snapshots = [self._snapshot_for_evidence(ev.id) for ev in evidence]
            if len(snapshots) == len(evidence) and snapshots and all(not self._temporal_valid(snap, as_of) for snap in snapshots):
                self.set_status(claim.id, "stale", f"all supporting source snapshots temporally invalid at {as_of.isoformat()}")
                self._event("claim.temporally_invalidated", claim.id, {"as_of": as_of.isoformat(), "evidence_ids": [e.id for e in evidence]})
                changed.append(claim.id)
        for row in self.db.execute("SELECT id FROM nodes WHERE kind='Knowledge' AND status='verified'"):
            knowledge_id = row["id"]
            claim_edges = self.db.execute(
                "SELECT source_id FROM edges WHERE target_id=? AND relation='based_on'", (knowledge_id,)
            ).fetchall()
            claim_ids = [r[0] for r in claim_edges]
            if claim_ids and all(self.get(cid).status == "stale" for cid in claim_ids if self.get(cid)):
                self.set_status(knowledge_id, "stale", "all supporting claims are stale")
                self._event("knowledge.temporally_invalidated", knowledge_id, {"as_of": as_of.isoformat(), "claim_ids": claim_ids})
                changed.append(knowledge_id)
        return {"as_of": as_of.isoformat(), "invalidated": changed}

    def audit(self, as_of=None):
        try:
            return self._audit(as_of)
        except Exception as exc:
            return {"ok": False, "problems": [("SYSTEM", "audit_exception", f"{type(exc).__name__}: {exc}")]}

    def _audit(self, as_of=None):
        problems = []
        as_of = self._parse_time(as_of) if isinstance(as_of, str) else as_of
        as_of = as_of or datetime.now(timezone.utc)

        # Generic verified-node support invariant.
        for r in self.db.execute("SELECT id,kind,status FROM nodes"):
            if r["status"] == "verified" and r["kind"] in {"Claim", "Decision", "Knowledge"}:
                ok = self.db.execute(
                    "SELECT 1 FROM edges WHERE target_id=? AND relation IN ('supports','evidence_for','verified_by','based_on','approved_by') LIMIT 1",
                    (r["id"],)).fetchone()
                if not ok: problems.append((r["id"], "verified_without_support"))

        # Node integrity fields are system-owned and detect direct metadata tampering
        # even when no checkpoint exists. Legacy nodes without the digest remain
        # auditable but are not silently mutated during observation.
        for r in self.db.execute("SELECT id,content,metadata FROM nodes"):
            meta = json.loads(r["metadata"])
            if meta.get("content_sha256") != self._hash(r["content"]):
                problems.append((r["id"], "content_hash_mismatch"))
            if "metadata_sha256" in meta and meta["metadata_sha256"] != self._metadata_hash(meta):
                problems.append((r["id"], "metadata_hash_mismatch"))

        # Source snapshot integrity + temporal sanity.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='SourceSnapshot'"):
            meta = json.loads(r["metadata"])
            for field, code in [
                ("source_id", "snapshot_without_source_id"),
                ("provider_id", "snapshot_without_provider_id"),
                ("origin_id", "snapshot_without_origin_id"),
                ("retrieved_at", "snapshot_without_retrieval_time"),
            ]:
                if not meta.get(field): problems.append((r["id"], code))
            if not meta.get("uri"): problems.append((r["id"], "snapshot_without_uri"))
            if meta.get("content_sha256") != self._hash(r["content"]): problems.append((r["id"], "snapshot_hash_mismatch"))
            retrieved = self._parse_time(meta.get("retrieved_at"))
            published = self._parse_time(meta.get("published_at"))
            valid_from = self._parse_time(meta.get("valid_from"))
            valid_until = self._parse_time(meta.get("valid_until"))
            if meta.get("retrieved_at") and retrieved is None: problems.append((r["id"], "invalid_retrieval_time"))
            if meta.get("published_at") and published is None: problems.append((r["id"], "invalid_publication_time"))
            if meta.get("valid_from") and valid_from is None: problems.append((r["id"], "invalid_valid_from"))
            if meta.get("valid_until") and valid_until is None: problems.append((r["id"], "invalid_valid_until"))
            if valid_from and valid_until and valid_until < valid_from: problems.append((r["id"], "invalid_validity_interval"))

        # Evidence must retain precise provenance and an explicit epistemic polarity.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='Evidence'"):
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='derived_from'", (r["id"],)).fetchone():
                problems.append((r["id"], "evidence_without_source_snapshot"))
            meta = json.loads(r["metadata"])
            locator = meta.get("locator")
            if not locator: problems.append((r["id"], "evidence_without_locator"))
            elif not isinstance(locator, dict) or locator.get("type") not in {
                "document", "text_quote", "text_position", "fragment", "xpath", "css", "data_position"
            }:
                problems.append((r["id"], "evidence_invalid_locator"))
            if not meta.get("extraction_method"): problems.append((r["id"], "evidence_without_extraction_method"))
            if not meta.get("observation_time"): problems.append((r["id"], "evidence_without_observation_time"))
            elif self._parse_time(meta.get("observation_time")) is None:
                problems.append((r["id"], "invalid_observation_time"))
            polarity = meta.get("polarity", "supports")
            if polarity not in {"supports", "refutes", "neutral", "unknown"}:
                problems.append((r["id"], "invalid_evidence_polarity"))
            if polarity == "supports" and not meta.get("observation_basis"):
                problems.append((r["id"], "supporting_evidence_without_observation_basis"))

        # Research records must document what was attempted.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ResearchRecord'"):
            meta = json.loads(r["metadata"])
            for field in ("query", "providers_consulted", "result_counts", "failures", "stopping_condition"):
                if field not in meta: problems.append((r["id"], f"research_record_without_{field}"))

        # Claim assessments must preserve explicit evidence relationships and dimensions.
        allowed_claim_relations = {"entails", "supports", "correlates", "insufficient", "refutes", "unassessed"}
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ClaimAssessment'"):
            meta = json.loads(r["metadata"])
            if not meta.get("claim_id"): problems.append((r["id"], "claim_assessment_without_claim_id"))
            claim_id = meta.get("claim_id")
            claim = self.get(claim_id) if claim_id else None
            if not claim or claim.kind != "Claim": problems.append((r["id"], "claim_assessment_invalid_claim"))
            results = meta.get("evidence_results", {})
            if not isinstance(results, dict) or not results:
                problems.append((r["id"], "claim_assessment_without_evidence_results"))
            else:
                for eid, relation in results.items():
                    ev = self.get(eid)
                    if not ev or ev.kind != "Evidence": problems.append((r["id"], "claim_assessment_invalid_evidence"))
                    if relation not in allowed_claim_relations: problems.append((r["id"], "claim_assessment_invalid_relation"))
            if not meta.get("dimensions"): problems.append((r["id"], "claim_assessment_without_dimensions"))
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='evaluates' AND target_id=?", (r["id"], claim_id)).fetchone():
                problems.append((r["id"], "claim_assessment_without_evaluates_edge"))

        # Claim synthesis must remain auditable and must not masquerade as truth.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ClaimSynthesis'"):
            meta = json.loads(r["metadata"])
            claim_id = meta.get("claim_id")
            claim = self.get(claim_id) if claim_id else None
            if not claim or claim.kind != "Claim": problems.append((r["id"], "claim_synthesis_invalid_claim"))
            if meta.get("disposition") not in {"unsupported", "refuted", "contested", "entailed", "supported", "indeterminate"}:
                problems.append((r["id"], "claim_synthesis_invalid_disposition"))
            for field in ("supporting_evidence_ids", "refuting_evidence_ids", "limitations"):
                if not isinstance(meta.get(field), list): problems.append((r["id"], f"claim_synthesis_invalid_{field}"))
            if not meta.get("synthesized_at") or self._parse_time(meta.get("synthesized_at")) is None:
                problems.append((r["id"], "claim_synthesis_invalid_timestamp"))
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='evaluates' AND target_id=?", (r["id"], claim_id)).fetchone():
                problems.append((r["id"], "claim_synthesis_without_evaluates_edge"))

        # Verification is policy-driven: the policy requirements are copied onto the Claim
        # so audit remains independent of the EpistemicEngine implementation.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='Claim' AND status='verified'"):
            claim_meta = json.loads(r["metadata"])
            verification = self.db.execute(
                "SELECT 1 FROM edges e JOIN nodes v ON v.id=e.source_id "
                "WHERE e.target_id=? AND e.relation='verified_by' AND v.kind='Verification' LIMIT 1",
                (r["id"],)
            ).fetchone()
            if not verification:
                problems.append((r["id"], "verified_claim_without_verification_node"))
            evs = self.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='evidence_for'", (r["id"],)).fetchall()
            if not evs:
                problems.append((r["id"], "verified_claim_without_evidence")); continue
            evidence = [self.get(e[0]) for e in evs if self.get(e[0])]
            groups = []
            for ev in evidence:
                snap = self._snapshot_for_evidence(ev.id)
                if not snap: continue
                meta = snap.metadata
                origin = meta.get("origin_id")
                roots = set(meta.get("upstream_origin_ids") or []) or ({origin} if origin else set())
                # Expand documented upstream lineage.
                pending = list(roots); seen = set()
                while pending:
                    oid = pending.pop()
                    if oid in seen: continue
                    seen.add(oid)
                    for row in self.db.execute("SELECT metadata FROM nodes WHERE kind='Origin'"):
                        om = json.loads(row[0])
                        if om.get("origin_id") == oid:
                            pending.extend(om.get("upstream_origin_ids") or [])
                roots = seen or ({origin} if origin else set())
                transform = meta.get("transformation_id")
                placed = False
                for group in groups:
                    if roots & group["roots"] or (transform and transform in group["transforms"]):
                        group["roots"].update(roots)
                        if transform: group["transforms"].add(transform)
                        group["evidence"].append(ev.id)
                        placed = True; break
                if not placed:
                    groups.append({"roots": set(roots), "transforms": {transform} if transform else set(), "evidence": [ev.id]})
            required = int(claim_meta.get("verification_min_independent_origins", 2))
            if len(groups) < required:
                problems.append((r["id"], "verification_lacks_independent_origin_support"))
            if claim_meta.get("verification_require_locator", True):
                missing = [e[0] for e in evs if not (self.get(e[0]) and self.get(e[0]).metadata.get("locator"))]
                if missing: problems.append((r["id"], "verification_lacks_evidence_locator"))

        # Conflict sets must contain at least two distinct claims.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ConflictSet'"):
            members = self.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='contains'", (r["id"],)).fetchall()
            claim_ids = [x[0] for x in members if self.get(x[0]) and self.get(x[0]).kind == "Claim"]
            if len(set(claim_ids)) < 2: problems.append((r["id"], "conflict_set_without_two_claims"))

        # Resolved conflicts require a first-class resolution record.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ConflictSet' AND status='resolved'"):
            if not self.db.execute("SELECT 1 FROM edges WHERE target_id=? AND relation='resolves'", (r["id"],)).fetchone():
                problems.append((r["id"], "resolved_conflict_without_resolution"))

        for r in self.db.execute("SELECT * FROM nodes WHERE kind='Knowledge' AND status='verified'"):
            meta = json.loads(r["metadata"])
            epistemic_type = meta.get("epistemic_type", "assertion")
            if epistemic_type not in {"assertion", "negation", "absence_of_evidence", "unknown"}:
                problems.append((r["id"], "invalid_knowledge_epistemic_type"))
            if epistemic_type == "absence_of_evidence":
                if not meta.get("absence_scope"):
                    problems.append((r["id"], "absence_knowledge_without_scope"))
            elif not self.db.execute("SELECT 1 FROM edges e JOIN nodes c ON c.id=e.source_id WHERE e.target_id=? AND e.relation IN ('based_on','supports') AND c.kind='Claim' AND c.status='verified'", (r["id"],)).fetchone():
                problems.append((r["id"], "knowledge_without_verified_claim"))

        # Temporal validity is auditable without mutating state.
        for r in self.db.execute("SELECT id FROM nodes WHERE kind='Claim' AND status='verified'"):
            claim = self.get(r["id"])
            evidence = self._supporting_evidence(claim.id)
            if evidence:
                snapshots = [self._snapshot_for_evidence(ev.id) for ev in evidence]
                if len(snapshots) == len(evidence) and snapshots and all(not self._temporal_valid(snap, as_of) for snap in snapshots):
                    problems.append((claim.id, "verified_claim_supported_only_by_temporally_invalid_evidence"))
        # Evidence assessments must point to real Evidence and preserve assessor/time/dimensions.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='EvidenceAssessment'"):
            meta = json.loads(r["metadata"])
            target = self.db.execute(
                "SELECT 1 FROM edges e JOIN nodes n ON n.id=e.target_id WHERE e.source_id=? AND e.relation='evaluates' AND n.kind='Evidence' LIMIT 1",
                (r["id"],)).fetchone()
            if not target: problems.append((r["id"], "assessment_without_evidence"))
            if not meta.get("assessor"): problems.append((r["id"], "assessment_without_assessor"))
            if not meta.get("assessed_at"): problems.append((r["id"], "assessment_without_timestamp"))
            dims = meta.get("dimensions")
            if not isinstance(dims, dict): problems.append((r["id"], "assessment_without_dimensions"))

        # G4.2 semantic reasoning invariants. Semantic reasoning must expose its method,
        # dependencies, and any hypothetical/exceptional branches without auto-verifying results.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ReasoningActivity'"):
            meta=json.loads(r["metadata"]); method=meta.get("method")
            if meta.get("semantic_layer") == "G4.2":
                if method not in {"deductive","inductive","abductive","defeasible","analogical","counterfactual","aggregative"}:
                    problems.append((r["id"],"semantic_reasoning_invalid_method"))
                if not isinstance(meta.get("premise_roles",{}),dict): problems.append((r["id"],"semantic_reasoning_invalid_premise_roles"))
                if method == "counterfactual" and not isinstance(meta.get("counterfactual"),dict): problems.append((r["id"],"counterfactual_missing_branch_spec"))
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='Assumption'"):
            meta=json.loads(r["metadata"]);
            if not meta.get("authority"): problems.append((r["id"],"assumption_without_authority"))
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='Defeater'"):
            uses=self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='defeats'",(r["id"],)).fetchone()
            if not uses: problems.append((r["id"],"orphan_defeater"))
        for r in self.db.execute("SELECT * FROM nodes WHERE kind='ReasoningAssessment'"):
            meta=json.loads(r["metadata"]);
            if not meta.get("assessor") or not meta.get("assessed_at"): problems.append((r["id"],"reasoning_assessment_missing_reviewer_metadata"))
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='evaluates'",(r["id"],)).fetchone(): problems.append((r["id"],"reasoning_assessment_without_target"))

        # Reasoning provenance invariants. A reasoning activity must identify a rule,
        # consume at least one supported/verified Claim, and produce a proposed Claim.
        for r in self.db.execute("SELECT id FROM nodes WHERE kind=\'ReasoningActivity\'"):
            rid = r["id"]
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation=\'applies_rule\' AND target_id IN (SELECT id FROM nodes WHERE kind=\'ReasoningRule\')", (rid,)).fetchone():
                problems.append((rid, "reasoning_activity_without_rule"))
            premises = self.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation=\'uses\'", (rid,)).fetchall()
            if not premises:
                problems.append((rid, "reasoning_activity_without_premise"))
            for pr in premises:
                n = self.get(pr["target_id"])
                if not n or n.kind != "Claim" or n.status not in {"supported", "verified"}:
                    problems.append((rid, "reasoning_activity_uses_unsupported_premise"))
            outputs = self.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation=\'produces\'", (rid,)).fetchall()
            if len(outputs) != 1:
                problems.append((rid, "reasoning_activity_output_count_invalid"))
            for out in outputs:
                n = self.get(out["target_id"])
                if not n or n.kind != "Claim":
                    problems.append((rid, "reasoning_activity_output_not_claim"))
                elif n.metadata.get("reasoning_activity_id") != rid:
                    problems.append((rid, "derived_claim_missing_reasoning_provenance"))
        for r in self.db.execute("SELECT id FROM nodes WHERE kind=\'Claim\' AND metadata LIKE ?", ("%\"origin\": \"reasoning\"%",)):
            cid = r["id"]
            if not self.db.execute("SELECT 1 FROM edges WHERE target_id=? AND relation=\'produces\'", (cid,)).fetchone():
                problems.append((cid, "reasoning_claim_without_producing_activity"))

        # Reasoning activities must preserve premises, rule provenance, and derived conclusion.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind=\'ReasoningActivity\'"):
            meta = json.loads(r["metadata"])
            rule_id = meta.get("rule_id")
            conclusion_id = meta.get("conclusion_id")
            premise_ids = meta.get("premise_ids")
            rule = self.get(rule_id) if rule_id else None
            conclusion = self.get(conclusion_id) if conclusion_id else None
            if not rule or rule.kind != "ReasoningRule": problems.append((r["id"], "reasoning_without_rule"))
            if not conclusion or conclusion.kind != "Claim": problems.append((r["id"], "reasoning_without_claim_conclusion"))
            if not isinstance(premise_ids, list) or not premise_ids: problems.append((r["id"], "reasoning_without_premises"))
            else:
                for pid in premise_ids:
                    premise = self.get(pid)
                    if not premise or premise.kind != "Claim": problems.append((r["id"], "reasoning_invalid_premise"))
                    if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation=\'premise_of\' AND target_id=?", (pid, r["id"])).fetchone():
                        problems.append((r["id"], "reasoning_missing_premise_edge"))
            if rule and not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation=\'applies_rule\' AND target_id=?", (r["id"], rule.id)).fetchone():
                problems.append((r["id"], "reasoning_missing_rule_edge"))
            if conclusion and not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation=\'derives\' AND target_id=?", (r["id"], conclusion.id)).fetchone():
                problems.append((r["id"], "reasoning_missing_conclusion_edge"))
            if conclusion and conclusion.status == "verified":
                problems.append((r["id"], "reasoning_auto_verified_conclusion"))
            if not meta.get("method") or not meta.get("performed_at") or self._parse_time(meta.get("performed_at")) is None:
                problems.append((r["id"], "reasoning_missing_method_or_timestamp"))

        for r in self.db.execute("SELECT * FROM nodes WHERE kind=\'ReasoningRule\'"):
            meta = json.loads(r["metadata"])
            if not meta.get("rule_type") or not meta.get("rule_sha256"):
                problems.append((r["id"], "reasoning_rule_missing_identity"))
            if meta.get("rule_sha256") != self._hash(json.dumps({k:v for k,v in meta.items() if k not in {"rule_sha256", "content_sha256", "metadata_sha256"}}, sort_keys=True)):
                problems.append((r["id"], "reasoning_rule_hash_mismatch"))

        # G4.3 independent inference assessments must target reasoning activities
        # and must never silently promote the conclusion.
        for r in self.db.execute("SELECT * FROM nodes WHERE kind=\'InferenceAssessment\'"):
            meta = json.loads(r["metadata"])
            target = meta.get("activity_id")
            activity = self.get(target) if target else None
            if not activity or activity.kind != "ReasoningActivity":
                problems.append((r["id"], "inference_assessment_without_reasoning_activity"))
            if not meta.get("assessor") or not meta.get("assessed_at"):
                problems.append((r["id"], "inference_assessment_missing_reviewer_metadata"))
            if meta.get("verdict") not in {"warranted","conditionally_warranted","insufficient","invalid","contested"}:
                problems.append((r["id"], "inference_assessment_invalid_verdict"))
            if not self.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='evaluates' AND target_id=?", (r["id"], target)).fetchone():
                problems.append((r["id"], "inference_assessment_missing_evaluates_edge"))
            if activity and meta.get("conclusion_id"):
                conclusion = self.get(meta["conclusion_id"])
                if conclusion and conclusion.status == "verified":
                    problems.append((r["id"], "inference_assessment_cannot_certify_conclusion"))

        return {"ok": not problems, "problems": problems}
