from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import base64
import hashlib
import json
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


@dataclass(frozen=True)
class ReleaseManifest:
    release_id: str
    candidate_id: str
    canary_id: str
    version: str
    artifact_sha256: str
    evaluation_suite: str
    benchmark_sha256: str
    created_at: str
    manifest_sha256: str


@dataclass(frozen=True)
class ReleaseDecision:
    release_id: str
    state: str
    authorized: bool
    rollback_required: bool
    reasons: tuple[str, ...]
    decided_at: str


class ReleaseControlEngine:
    """Explicit release authority around learning artifacts.

    The engine records signed release identity, operator authorization, staged
    rollout state, health decisions, and rollback evidence. It never performs
    deployment itself and never changes production routing or model state.
    """

    RELEASE_STATES = {"prepared", "authorized", "staged", "active", "rolled_back", "completed", "blocked"}

    def __init__(self, graph, release_private_key: Ed25519PrivateKey | None = None, deployment_public_key: bytes | None = None):
        self.g = graph
        self.release_private_key = release_private_key
        self.deployment_public_key = deployment_public_key

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _canonical(value: dict[str, Any]) -> bytes:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()

    @classmethod
    def _digest(cls, value: dict[str, Any]) -> str:
        return hashlib.sha256(cls._canonical(value)).hexdigest()

    @staticmethod
    def _id(release_id: str, action: str) -> bytes:
        return f"TBOHK:{release_id}:{action}".encode()

    def prepare(self, candidate_id: str, canary_id: str, *, version: str, artifact_sha256: str, evaluation_suite: str, benchmark_sha256: str) -> ReleaseManifest:
        candidate = self.g.get(candidate_id)
        canary = self.g.get(canary_id)
        if not candidate or candidate.kind not in {"LearningCandidate", "LearningExperiment"}:
            raise ValueError("invalid learning candidate")
        if not canary or canary.kind != "LearningCanary":
            raise ValueError("invalid learning canary")
        if canary.metadata.get("decision") != "continue":
            raise ValueError("canary did not authorize continuation")
        if candidate.kind == "LearningExperiment":
            if candidate.metadata.get("status") != "candidate_ready":
                raise ValueError("experiment is not candidate-ready")
        elif candidate.status not in {"verified", "supported"}:
            raise ValueError("candidate is not verified")
        if not version or not artifact_sha256 or not evaluation_suite or not benchmark_sha256:
            raise ValueError("release manifest fields are required")
        payload = {
            "candidate_id": candidate_id, "canary_id": canary_id, "version": version,
            "artifact_sha256": artifact_sha256, "evaluation_suite": evaluation_suite,
            "benchmark_sha256": benchmark_sha256,
        }
        provisional = dict(payload, release_id="pending")
        node = self.g.add_node("Release", "Release control artifact", "proposed", {"state": "prepared", "immutable_manifest": provisional})
        release_id = node.id
        immutable = dict(payload, release_id=release_id)
        manifest_sha256 = self._digest(immutable)
        immutable["manifest_sha256"] = manifest_sha256
        manifest = ReleaseManifest(release_id, candidate_id, canary_id, version, artifact_sha256, evaluation_suite, benchmark_sha256, node.created_at, manifest_sha256)
        meta = asdict(manifest)
        meta["state"] = "prepared"
        meta["immutable_manifest"] = immutable
        if self.release_private_key is not None:
            sig = self.release_private_key.sign(self._canonical(immutable))
            meta["release_signature"] = base64.b64encode(sig).decode()
            meta["release_public_key"] = base64.b64encode(self.release_private_key.public_key().public_bytes_raw()).decode()
        self.g.update_metadata(node.id, meta, replace=True, reason="finalized immutable release manifest")
        self.g.link(node.id, "based_on", candidate_id)
        self.g.link(node.id, "evaluates", canary_id)
        return manifest

    def _release(self, release_id: str):
        node = self.g.get(release_id)
        if not node or node.kind != "Release":
            raise ValueError("invalid release")
        return node

    def _verify_release_signature(self, node) -> bool:
        sig = node.metadata.get("release_signature")
        pub = node.metadata.get("release_public_key")
        immutable = node.metadata.get("immutable_manifest")
        if not sig or not pub or not immutable:
            return self.release_private_key is None
        try:
            expected = immutable.get("manifest_sha256")
            actual_payload = dict(immutable)
            actual_payload.pop("manifest_sha256", None)
            if expected != self._digest(actual_payload):
                return False
            Ed25519PublicKey.from_public_bytes(base64.b64decode(pub)).verify(base64.b64decode(sig), self._canonical(immutable))
            return True
        except Exception:
            return False

    def authorize(self, release_id: str, *, operator: str, deployment_signature: str) -> ReleaseDecision:
        node = self._release(release_id)
        if not operator.strip():
            raise ValueError("operator is required")
        if node.metadata.get("state") != "prepared":
            raise ValueError("release is not prepared")
        if self.deployment_public_key is None:
            raise ValueError("deployment authorization key is not configured")
        immutable = node.metadata["immutable_manifest"]
        message = self._id(release_id, "authorize") + b":" + self._canonical(immutable)
        try:
            Ed25519PublicKey.from_public_bytes(self.deployment_public_key).verify(base64.b64decode(deployment_signature), message)
        except Exception as exc:
            raise ValueError("deployment authorization signature invalid") from exc
        if not self._verify_release_signature(node):
            raise ValueError("release signature invalid")
        self.g.update_metadata(node.id, {"state": "authorized", "authorized_by": operator, "authorized_at": self._now(), "deployment_signature": deployment_signature}, reason="explicit deployment authorization")
        self.g.set_status(node.id, "supported", "explicit deployment authorization verified")
        return ReleaseDecision(release_id, "authorized", True, False, (), self._now())

    def stage(self, release_id: str, *, traffic_percent: float) -> ReleaseDecision:
        node = self._release(release_id)
        if node.metadata.get("state") != "authorized":
            raise ValueError("release is not authorized")
        if not 0 < traffic_percent <= 100:
            raise ValueError("traffic_percent must be in (0,100]")
        self.g.update_metadata(node.id, {"state": "staged", "traffic_percent": float(traffic_percent), "staged_at": self._now()}, reason="staged rollout")
        return ReleaseDecision(release_id, "staged", True, False, (), self._now())

    def health_gate(self, release_id: str, *, observations: int, error_rate: float, latency_ms: float, max_error_rate: float = 0.05, max_latency_ms: float | None = None) -> ReleaseDecision:
        node = self._release(release_id)
        if node.metadata.get("state") not in {"staged", "active"}:
            raise ValueError("release is not staged")
        if observations < 1 or error_rate < 0 or latency_ms < 0 or max_error_rate < 0 or max_error_rate > 1:
            raise ValueError("invalid health gate inputs")
        reasons: list[str] = []
        if error_rate > max_error_rate:
            reasons.append("release error rate exceeds budget")
        if max_latency_ms is not None and latency_ms > max_latency_ms:
            reasons.append("release latency exceeds budget")
        rollback = bool(reasons)
        state = "rolled_back" if rollback else "active"
        self.g.update_metadata(node.id, {"state": state, "health": {"observations": observations, "error_rate": error_rate, "latency_ms": latency_ms, "max_error_rate": max_error_rate, "max_latency_ms": max_latency_ms, "reasons": reasons}, "health_checked_at": self._now()}, reason="health-gated rollout decision")
        if rollback:
            rb = self.g.add_node("ReleaseRollback", f"Rollback {release_id}", "recovered", {"release_id": release_id, "reasons": reasons, "created_at": self._now(), "rollback_sha256": self._digest({"release_id": release_id, "reasons": reasons})})
            self.g.link(node.id, "reverses", rb.id)
        return ReleaseDecision(release_id, state, True, rollback, tuple(reasons), self._now())

    def complete(self, release_id: str) -> ReleaseDecision:
        node = self._release(release_id)
        if node.metadata.get("state") != "active":
            raise ValueError("release is not active")
        self.g.update_metadata(node.id, {"state": "completed", "completed_at": self._now()}, reason="release completed")
        self.g.set_status(node.id, "verified", "health-gated release completed")
        return ReleaseDecision(release_id, "completed", True, False, (), self._now())

    def report(self, release_id: str) -> dict[str, Any]:
        node = self._release(release_id)
        return {"release_id": node.id, **node.metadata, "status": node.status}
