from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True)
class ModelRequest:
    provider:str; operation:str; input:Any; budget:dict[str,Any]

@dataclass(frozen=True)
class ModelResponse:
    provider:str; operation:str; output:Any; deterministic:bool; metadata:dict[str,Any]

class ModelGateway:
    """Provider-neutral model boundary. Providers are explicit adapters; no hidden fallback."""
    def __init__(self): self._providers={}
    def register(self,name:str, handler:Callable[[ModelRequest],Any]):
        if not name.strip(): raise ValueError('provider required')
        self._providers[name]=handler
    def providers(self): return tuple(sorted(self._providers))
    def invoke(self, provider, operation, input, *, budget=None):
        if provider not in self._providers: raise KeyError(provider)
        req=ModelRequest(provider,operation,input,budget or {})
        out=self._providers[provider](req)
        if isinstance(out,ModelResponse): return out
        return ModelResponse(provider,operation,out,True,{'adapter':'explicit'})
