from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class RepairAction:
    action_id:str; source:str; action:str; bounded:bool=True; reversible:bool=True; requires_authority:bool=False
class RepairPlanner:
    ALLOWED={"recheck","rebuild_projection","replay","quarantine","refresh"}
    def plan(self, signals):
        out=[]
        for i,s in enumerate(signals):
            action=s.action.split(":",1)[0]
            if action not in self.ALLOWED: action="recheck"
            out.append(RepairAction(f"repair-{i+1:04d}",s.check_id,action))
        return tuple(out)
