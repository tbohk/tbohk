from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timezone
import base64, json, os
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from .serialization import canonical_bytes, sha256

@dataclass(frozen=True)
class ExternalAnchor:
    sequence: int
    checkpoint_id: str
    manifest_sha256: str
    created_at: str
    key_id: str
    public_key: str
    signature: str

class AnchorStore:
    """Append-only signed checkpoint anchors stored outside the live SQLite DB.

    The file is a prototype external trust domain: it deliberately cannot be used by
    TBOHK's database to make a damaged checkpoint appear clean. Production deployment
    should mirror these records to independent/offline infrastructure.
    """
    def __init__(self, path: str | os.PathLike[str], private_key: Ed25519PrivateKey | None = None, key_id: str = "tbohk-anchor-1"):
        self.path=Path(path).expanduser().resolve(); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.private_key=private_key; self.key_id=key_id
    @staticmethod
    def generate_key() -> Ed25519PrivateKey: return Ed25519PrivateKey.generate()
    def _records(self):
        if not self.path.exists(): return []
        out=[]
        for line in self.path.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            out.append(ExternalAnchor(**json.loads(line)))
        return out
    def append(self, checkpoint_id: str, manifest: dict, manifest_sha256: str | None = None) -> ExternalAnchor:
        if self.private_key is None: raise ValueError("private key required for anchoring")
        digest=manifest_sha256 or sha256(manifest); records=self._records(); seq=(records[-1].sequence+1) if records else 1
        created=datetime.now(timezone.utc).isoformat()
        payload={"sequence":seq,"checkpoint_id":checkpoint_id,"manifest_sha256":digest,"created_at":created,"key_id":self.key_id}
        raw=canonical_bytes(payload); sig=base64.b64encode(self.private_key.sign(raw)).decode(); pub=base64.b64encode(self.private_key.public_key().public_bytes_raw()).decode()
        anchor=ExternalAnchor(**{**payload,"public_key":pub,"signature":sig})
        if records and records[-1].sequence >= anchor.sequence: raise RuntimeError("anchor sequence regression")
        with self.path.open('a',encoding='utf-8') as fh: fh.write(json.dumps(asdict(anchor),sort_keys=True,separators=(',',':'))+'\n'); fh.flush(); os.fsync(fh.fileno())
        return anchor
    @staticmethod
    def verify_file(path: str | os.PathLike[str], trusted_public_keys: dict[str,bytes]) -> dict:
        store=AnchorStore(path); records=store._records(); findings=[]; last=0
        for a in records:
            if a.sequence != last+1: findings.append(f"sequence_gap:{a.sequence}")
            last=a.sequence
            pub=trusted_public_keys.get(a.key_id)
            try:
                key=base64.b64decode(a.public_key); raw=canonical_bytes({"sequence":a.sequence,"checkpoint_id":a.checkpoint_id,"manifest_sha256":a.manifest_sha256,"created_at":a.created_at,"key_id":a.key_id})
                if pub is None: findings.append(f"untrusted_key:{a.key_id}")
                elif pub != key: findings.append(f"public_key_mismatch:{a.sequence}")
                Ed25519PublicKey.from_public_bytes(key).verify(base64.b64decode(a.signature),raw)
            except Exception as exc: findings.append(f"signature_invalid:{a.sequence}:{type(exc).__name__}")
        return {"ok":not findings,"count":len(records),"findings":findings}
