from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from .core import TBOHK
from .research import ResearchChain, MockProvider, SourceDocument
from .epistemic import EpistemicEngine, VerificationPolicy
from .reasoning import ReasoningEngine
from .inference import InferenceEvaluator
from .explanation import ExplanationReconstructor
from .benchmark import corpus_sha256
from .metamorphic import suite_sha256

SUITE_VERSION = "G4.9-1"

@dataclass(frozen=True)
class MutationCase:
    case_id: str
    mutation: str
    detector: str

@dataclass(frozen=True)
class MutationResult:
    case_id: str
    detected: bool
    detector: str
    findings: tuple[str, ...]

@dataclass(frozen=True)
class MutationReport:
    suite_version: str
    total: int
    detected: int
    missed: int
    results: tuple[MutationResult, ...]
    assessed_at: str

CASES = (
    MutationCase("G49-001", "tamper_source_snapshot_content", "graph_audit"),
    MutationCase("G49-002", "remove_evidence_snapshot_provenance", "graph_audit"),
    MutationCase("G49-003", "remove_evidence_locator", "graph_audit"),
    MutationCase("G49-004", "tamper_reasoning_rule_definition", "graph_audit"),
    MutationCase("G49-005", "remove_reasoning_premise_edge", "graph_audit"),
    MutationCase("G49-006", "auto_verify_derived_claim", "graph_audit"),
    MutationCase("G49-007", "corrupt_inference_verdict", "graph_audit"),
    MutationCase("G49-008", "remove_inference_target_edge", "graph_audit"),
    MutationCase("G49-009", "collapse_independent_origins", "graph_audit"),
    MutationCase("G49-010", "delete_explanation_provenance_edge", "explanation_trace"),
    MutationCase("G49-011", "tamper_recorded_benchmark_hash", "benchmark_integrity"),
    MutationCase("G49-012", "tamper_recorded_metamorphic_hash", "metamorphic_integrity"),
)


def _doc(source, provider, origin, text="Water freezes at 0 C."):
    now = "2026-01-01T00:00:00+00:00"
    return SourceDocument(source, source, f"https://example/{source}", text, provider, now, origin, now)


def _base():
    a = MockProvider("p1", [_doc("s1", "p1", "origin-A")])
    b = MockProvider("p2", [_doc("s2", "p2", "origin-B")])
    g = TBOHK()
    out = ResearchChain(g, [a, b]).run("freezes")
    e = EpistemicEngine(g, {"single": VerificationPolicy("single", min_independent_origins=1), "double": VerificationPolicy("double", min_independent_origins=2)})
    c1 = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id, out["results"][1][1].id], policy_id="double")
    c2 = e.propose_claim("Water freezes at 0 C.", [out["results"][1][1].id], policy_id="single")
    g.set_status(c1.id, "supported", "mutation fixture")
    g.set_status(c2.id, "supported", "mutation fixture")
    rr = ReasoningEngine(g)
    rule = rr.add_rule("identity", "identity", {"consequent": c1.metadata["structured"]})
    result = rr.derive(rule.id, [c1.id])
    assessment = InferenceEvaluator(g).record(result.activity_id, assessor="mutation-fixture")
    e.verify_claim(c1.id)
    return g, out, c1, c2, rule, result, assessment


def _problem_codes(g):
    return {p[1] for p in g.audit()["problems"]}


def run_case(case_id: str) -> MutationResult:
    g, out, c1, c2, rule, result, assessment = _base()
    findings=[]
    detector=""
    detected=False
    if case_id == "G49-001":
        snap = out["results"][0][0]
        g.db.execute("UPDATE nodes SET content=? WHERE id=?", ("CORRUPTED SOURCE", snap.id)); g.db.commit()
        detected = "snapshot_hash_mismatch" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-002":
        ev = out["results"][0][1]
        g.db.execute("DELETE FROM edges WHERE source_id=? AND relation='derived_from'", (ev.id,)); g.db.commit()
        detected = "evidence_without_source_snapshot" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-003":
        ev = out["results"][0][1]; row=g.get(ev.id); md=dict(row.metadata); md.pop("locator",None)
        g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(md,sort_keys=True),ev.id)); g.db.commit()
        detected = "evidence_without_locator" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-004":
        md=dict(rule.metadata); md["schema"]={"tampered":True}
        g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(md,sort_keys=True),rule.id)); g.db.commit()
        detected = "reasoning_rule_hash_mismatch" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-005":
        g.db.execute("DELETE FROM edges WHERE source_id=? AND relation='premise_of' AND target_id=?", (c1.id,result.activity_id)); g.db.commit()
        detected = "reasoning_missing_premise_edge" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-006":
        g.set_status(result.conclusion_id,"verified","fault injection")
        detected = "reasoning_auto_verified_conclusion" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-007":
        assessment_nodes=[g.get(e["source_id"]) for e in g.edges(result.activity_id,"in","evaluates") if g.get(e["source_id"]) and g.get(e["source_id"]).kind=="InferenceAssessment"]
        node=assessment_nodes[0]
        md=dict(node.metadata); md["verdict"]="fabricated"
        g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(md,sort_keys=True),node.id)); g.db.commit()
        detected = "inference_assessment_invalid_verdict" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-008":
        assessment_nodes=[g.get(e["source_id"]) for e in g.edges(result.activity_id,"in","evaluates") if g.get(e["source_id"]) and g.get(e["source_id"]).kind=="InferenceAssessment"]
        node=assessment_nodes[0]
        g.db.execute("DELETE FROM edges WHERE source_id=? AND relation='evaluates' AND target_id=?", (node.id,result.activity_id)); g.db.commit()
        detected = "inference_assessment_missing_evaluates_edge" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-009":
        for _, ev in out["results"]:
            md=dict(ev.metadata); md["origin_id"]="origin-A"
            g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(md,sort_keys=True),ev.id))
        for snap, _ in out["results"]:
            md=dict(snap.metadata); md["origin_id"]="origin-A"
            g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(md,sort_keys=True),snap.id))
        g.db.commit()
        detected = "verification_lacks_independent_origin_support" in _problem_codes(g); detector="graph_audit"
    elif case_id == "G49-010":
        trace=ExplanationReconstructor(g).trace(result.conclusion_id)
        before=trace.complete
        g.db.execute("DELETE FROM edges WHERE source_id=? AND relation='derived_from' AND target_id=?", (result.conclusion_id,c1.id)); g.db.commit()
        after=ExplanationReconstructor(g).trace(result.conclusion_id)
        detected = before and not after.complete; findings.append(f"trace_complete_before={before}"); findings.append(f"trace_complete_after={after.complete}"); detector="explanation_trace"
    elif case_id == "G49-011":
        node= g.add_node("BenchmarkRun","recorded benchmark","supported", {"corpus_version":"G4.7-1","corpus_sha256":"tampered","assessor":"fixture","assessed_at":"2026-01-01T00:00:00+00:00"})
        recorded=node.metadata.get("corpus_sha256")
        detected = recorded != corpus_sha256(); findings.append("recorded benchmark hash differs from independent corpus hash"); detector="benchmark_integrity"
    elif case_id == "G49-012":
        node=g.add_node("MetamorphicRun","recorded metamorphic","supported", {"suite_version":"G4.8-1","suite_sha256":"tampered","assessor":"fixture","assessed_at":"2026-01-01T00:00:00+00:00"})
        recorded=node.metadata.get("suite_sha256")
        detected = recorded != suite_sha256(); findings.append("recorded metamorphic hash differs from independent suite hash"); detector="metamorphic_integrity"
    else:
        raise KeyError(case_id)
    if detected: findings.append("fault was detected by the designated detector")
    else: findings.append("FAULT NOT DETECTED")
    return MutationResult(case_id, bool(detected), detector, tuple(findings))


class MutationSuite:
    """Deliberately corrupts isolated fixtures and verifies independent detection.

    Mutations never run against a release graph. A mutation is considered a
    success only when the designated detection path exposes it.
    """
    def run(self, *, as_of=None):
        results=[]
        for case in CASES:
            try: results.append(run_case(case.case_id))
            except Exception as exc: results.append(MutationResult(case.case_id,False,case.detector,(f"unexpected exception: {type(exc).__name__}: {exc}",)))
        stamp=as_of or datetime.now(timezone.utc).isoformat()
        return MutationReport(SUITE_VERSION,len(results),sum(r.detected for r in results),sum(not r.detected for r in results),tuple(results),stamp)

    def record(self, graph:TBOHK, *, assessor="independent-mutation-suite", as_of=None):
        report=self.run(as_of=as_of)
        node=graph.add_node("MutationRun",f"G4.9 mutation suite {report.suite_version}","supported",{
            "suite_version":report.suite_version,"assessor":assessor,"assessed_at":report.assessed_at,
            "total":report.total,"detected":report.detected,"missed":report.missed,
            "results":[{"case_id":r.case_id,"detected":r.detected,"detector":r.detector,"findings":list(r.findings)} for r in report.results]
        })
        return report,node
