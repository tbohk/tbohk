from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

@dataclass(frozen=True)
class WorkflowTask:
    id: str
    kind: str
    title: str
    status: str
    priority: int
    reason: str
    target_id: str|None
    created_at: str
    reversible: bool = True

class WorkflowEngine:
    """Bounded task/readiness layer; never changes claim truth implicitly."""
    def __init__(self, graph): self.g=graph
    def plan(self, limit=25):
        rows=self.g.db.execute("SELECT id,kind,status,content,created_at FROM nodes WHERE kind IN ('MaintenanceTask','ReEvaluationItem','VerificationTask','Unknown','ConflictSet') AND status NOT IN ('resolved','rejected','verified') ORDER BY rowid DESC LIMIT ?",(max(1,min(limit,100)),)).fetchall()
        out=[]
        for r in rows:
            priority=90 if r['kind']=='ConflictSet' else 80 if r['kind']=='VerificationTask' else 70 if r['kind']=='ReEvaluationItem' else 60
            out.append(asdict(WorkflowTask(r['id'],r['kind'],r['content'][:120],r['status'],priority,'existing system signal',r['id'],r['created_at'])))
        return sorted(out,key=lambda x:(-x['priority'],x['created_at']))
    def create(self,kind,title,reason,target_id=None,priority=50):
        now=datetime.now(timezone.utc).isoformat(); content=title.strip()
        if not content: raise ValueError('task title required')
        node=self.g.add_node('MaintenanceTask',content,'proposed',{'task_kind':kind,'reason':reason,'target_id':target_id,'priority':int(priority),'reversible':True,'created_at':now})
        if target_id and self.g.get(target_id): self.g.link(node.id,'about',target_id)
        return asdict(WorkflowTask(node.id,kind,content,'proposed',int(priority),reason,target_id,now,True))
