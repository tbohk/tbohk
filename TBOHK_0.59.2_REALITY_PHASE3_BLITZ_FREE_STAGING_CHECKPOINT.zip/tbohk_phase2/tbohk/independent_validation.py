from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import base64, hashlib, json

@dataclass(frozen=True)
class IndependentFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    invariant: str
    blocks_release: bool
    evidence: str

@dataclass(frozen=True)
class IndependentValidationReport:
    passed: bool
    findings: tuple[IndependentFinding, ...]
    checks_run: int

class IndependentSystemValidator:
    """G16 validator using direct observations of graph state rather than prior gate auditors.

    It is intentionally a separate validation path: it does not invoke GateAuditor,
    AdversarialValidator, IntegrityAuditor, TrustAuditor, or ReleaseAuditor.
    """
    def __init__(self, graph):
        self.g = graph
        self.checks_run = 0

    def _add(self, out, code, severity, ids, invariant, evidence, blocks=True):
        out.append(IndependentFinding(code, severity, tuple(ids), invariant, blocks, evidence))

    def run(self) -> IndependentValidationReport:
        out = []
        self._check_core_graph(out)
        self._check_provenance(out)
        self._check_authority(out)
        self._check_actions(out)
        self._check_autonomy(out)
        self._check_reality(out)
        self._check_checkpoint_records(out)
        self._check_untrusted_input_boundary(out)
        return IndependentValidationReport(not any(f.blocks_release for f in out), tuple(out), self.checks_run)

    def _rows(self, sql, args=()):
        self.checks_run += 1
        return self.g.db.execute(sql, args).fetchall()

    def _check_core_graph(self, out):
        # Verified epistemic objects require a provenance/support edge.
        for r in self._rows("SELECT id,kind FROM nodes WHERE status='verified' AND kind IN ('Claim','Decision','Knowledge')"):
            ok = self._rows("SELECT 1 FROM edges WHERE target_id=? AND relation IN ('supports','evidence_for','verified_by','based_on','approved_by') LIMIT 1", (r['id'],))
            if not ok:
                self._add(out,'verified_without_support','critical',[r['id']], 'I2', 'verified node has no supporting/verification edge')
        # Self edges are forbidden at the data level.
        for r in self._rows("SELECT source_id,relation,target_id FROM edges WHERE source_id=target_id"):
            self._add(out,'self_link','critical',[r['source_id']], 'I1', f"self edge relation={r['relation']}")

    def _check_provenance(self, out):
        for r in self._rows("SELECT id,kind,metadata FROM nodes WHERE kind='Activity'"):
            m=json.loads(r['metadata'])
            agent=m.get('attributed_to')
            if not agent or not self.g.get(agent) or self.g.get(agent).kind!='Agent':
                self._add(out,'activity_without_agent','critical',[r['id']], 'I3', 'activity attribution does not resolve to an Agent')
        for r in self._rows("SELECT source_id,target_id FROM edges WHERE relation='generated_by'"):
            target=self.g.get(r['target_id'])
            if not target or target.kind!='Activity':
                self._add(out,'generated_by_non_activity','critical',[r['source_id'],r['target_id']], 'I3', 'generated_by target is not an Activity')

    def _check_authority(self, out):
        now=datetime.now(timezone.utc)
        for r in self._rows("SELECT id,metadata,status FROM nodes WHERE kind='AuthorityGrant'"):
            m=json.loads(r['metadata'])
            if m.get('expires_at'):
                try:
                    if datetime.fromisoformat(m['expires_at'].replace('Z','+00:00')) <= now and r['status']=='verified':
                        self._add(out,'expired_verified_authority','critical',[r['id']], 'I5', 'verified authority is expired')
                except ValueError:
                    self._add(out,'malformed_authority_expiry','critical',[r['id']], 'I5', 'authority expiry is not parseable')
        for r in self._rows("SELECT id,metadata,status FROM nodes WHERE kind='Action' AND status IN ('supported','verified')"):
            m=json.loads(r['metadata']); gid=m.get('authority_grant_id'); grant=self.g.get(gid) if gid else None
            if not grant or grant.kind!='AuthorityGrant' or grant.status!='verified':
                self._add(out,'action_without_verified_authority','critical',[r['id']], 'I5', 'action state is executable/verified without verified authority')
            elif 'execute_action' not in grant.metadata.get('capabilities',[]):
                self._add(out,'authority_without_execute_capability','critical',[r['id'],grant.id], 'I5', 'action is linked to a grant lacking execute_action')
            else:
                scope=grant.metadata.get('scope')
                target=m.get('target')
                allowed = scope in (None,'*') or target in (scope if isinstance(scope,list) else [scope])
                if not allowed:
                    self._add(out,'authority_scope_mismatch','critical',[r['id'],grant.id], 'I5', 'authority scope does not cover action target')

    def _check_actions(self, out):
        for r in self._rows("SELECT id,metadata,status FROM nodes WHERE kind='Action' AND status='verified'"):
            aid=r['id']; m=json.loads(r['metadata'])
            verified = self._rows("SELECT 1 FROM edges WHERE target_id=? AND relation='verified_by' LIMIT 1", (aid,))
            records = self._rows("SELECT 1 FROM edges WHERE target_id=? AND relation='records' LIMIT 1", (aid,))
            if not verified and not records:
                self._add(out,'verified_action_without_observation','critical',[aid], 'I7', 'verified action has no incoming post-action verification/observation record')
            executions=self._rows("SELECT id FROM events WHERE subject_id=? AND event_type='action.executed'", (aid,))
            if len(executions)>1:
                self._add(out,'action_replay','critical',[aid], 'I7', f'{len(executions)} execution events exist for one action')
            if not m.get('rollback'):
                self._add(out,'verified_action_without_rollback','high',[aid], 'I7', 'consequential verified action has no rollback/compensation metadata')

    def _check_autonomy(self, out):
        for r in self._rows("SELECT id,kind FROM nodes WHERE kind IN ('AutonomousRun','ChangeProposal','Evaluation')"):
            if r['kind'] in ('AutonomousRun','Evaluation') and self._rows("SELECT 1 FROM edges WHERE source_id=? AND relation IN ('authorizes','approved_by') LIMIT 1", (r['id'],)):
                self._add(out,'autonomy_self_authorization','critical',[r['id']], 'I6', 'autonomous/evaluation/proposal node directly authorizes or approves authority')
        for r in self._rows("SELECT id,metadata FROM nodes WHERE kind='ChangeProposal' AND status='verified'"):
            m=json.loads(r['metadata'])
            if m.get('proposer')=='autonomous-loop':
                assessments=self._rows("SELECT 1 FROM nodes WHERE kind='GovernanceAssessment' AND json_extract(metadata,'$.proposal_id')=? AND json_extract(metadata,'$.allowed')=1", (r['id'],))
                if not assessments:
                    self._add(out,'autonomous_change_without_external_assessment','critical',[r['id']], 'I6', 'autonomous change reached verified state without a governance assessment')

    def _check_reality(self, out):
        for r in self._rows("SELECT id,metadata FROM nodes WHERE kind='Observation'"):
            m=json.loads(r['metadata'])
            if m.get('external') is not True:
                continue
            if not m.get('source') or not m.get('observed_at') or not m.get('retrieved_at'):
                self._add(out,'external_observation_missing_provenance','high',[r['id']], 'I2', 'external observation lacks source/time provenance')
            try:
                observed=datetime.fromisoformat(m['observed_at'].replace('Z','+00:00'))
                retrieved=datetime.fromisoformat(m['retrieved_at'].replace('Z','+00:00'))
                if retrieved < observed:
                    self._add(out,'observation_time_inversion','critical',[r['id']], 'I2', 'retrieval precedes observation')
            except Exception:
                self._add(out,'observation_time_malformed','critical',[r['id']], 'I2', 'observation timestamps are malformed')
        for r in self._rows("SELECT id,metadata FROM nodes WHERE kind='PostActionVerification'"):
            m=json.loads(r['metadata']); aid=m.get('action_id'); oid=m.get('observation_id')
            if not self.g.get(aid) or not self.g.get(oid) or self.g.get(oid).kind!='Observation':
                self._add(out,'post_action_verification_missing_observation','critical',[r['id']], 'I7', 'post-action verification does not resolve to an Observation')
            if m.get('verified') and m.get('expected_effect') != m.get('actual_effect'):
                self._add(out,'forged_post_action_verification','critical',[r['id']], 'I7', 'verification claims success despite effect mismatch')

    def _check_checkpoint_records(self, out):
        for r in self._rows("SELECT id,metadata FROM nodes WHERE kind='Checkpoint'"):
            try:
                m=json.loads(r['metadata']); manifest=m.get('manifest'); digest=m.get('manifest_sha256')
                raw=json.dumps(manifest,sort_keys=True).encode()
                if hashlib.sha256(raw).hexdigest()!=digest:
                    self._add(out,'checkpoint_manifest_mismatch','critical',[r['id']], 'I9', 'checkpoint manifest digest does not match manifest')
                if 'public_attestation' in m:
                    a=m['public_attestation']
                    for k in ('algorithm','key_id','manifest_sha256','public_key','signature'):
                        if not a.get(k): self._add(out,'malformed_public_attestation','critical',[r['id']], 'I9', f'attestation missing {k}')
            except Exception:
                self._add(out,'checkpoint_record_corrupt','critical',[r['id']], 'I9', 'checkpoint metadata is not valid structured JSON')

    def _check_untrusted_input_boundary(self, out):
        # Research/source content may contain instruction-like text; it must never
        # become an authority grant, capability, or approval merely by ingestion.
        rows=self._rows("SELECT id,kind,content FROM nodes WHERE kind IN ('SourceSnapshot','Evidence','Observation')")
        for r in rows:
            content=(r['content'] or '').lower()
            if any(token in content for token in ('ignore previous instructions','system prompt','grant authority','execute_action')):
                linked=self._rows("SELECT target_id,relation FROM edges WHERE source_id=?", (r['id'],))
                dangerous=[e for e in linked if e['relation'] in ('authorizes','approved_by')]
                if dangerous:
                    self._add(out,'untrusted_content_crossed_authority_boundary','critical',[r['id']]+[e['target_id'] for e in dangerous], 'I5', 'instruction-like source content is directly connected to authority')
