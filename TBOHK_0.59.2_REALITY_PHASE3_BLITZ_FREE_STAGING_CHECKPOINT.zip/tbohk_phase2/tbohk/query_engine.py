from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass
import threading, time
from typing import Any

@dataclass(frozen=True)
class QueryResult:
    query: str
    items: tuple[dict[str,Any], ...]
    elapsed_ms: float
    cached: bool

class QueryEngine:
    """Fast read layer over SQLite. It is deliberately non-authoritative."""
    def __init__(self, graph, max_cache=128, ttl=15.0):
        self.g=graph; self.max_cache=max_cache; self.ttl=ttl; self._cache=OrderedDict(); self._lock=threading.RLock()
        self._fts=False
        try:
            self.g.db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS node_search USING fts5(id UNINDEXED, kind, content)")
            count=self.g.db.execute("SELECT COUNT(*) FROM node_search").fetchone()[0]
            if count == 0:
                self.g.db.execute("INSERT INTO node_search(id,kind,content) SELECT id,kind,content FROM nodes")
            self.g.db.commit(); self._fts=True
        except Exception: self._fts=False
    def invalidate(self):
        with self._lock: self._cache.clear()
    def _search(self,q,limit):
        if self._fts:
            rows=self.g.db.execute("SELECT n.* FROM node_search s JOIN nodes n ON n.id=s.id WHERE node_search MATCH ? ORDER BY n.rowid DESC LIMIT ?",(q,limit)).fetchall()
        else:
            like=f"%{q.lower()}%"
            rows=self.g.db.execute("SELECT * FROM nodes WHERE lower(content) LIKE ? OR lower(kind) LIKE ? ORDER BY rowid DESC LIMIT ?",(like,like,limit)).fetchall()
        return tuple(dict(r) for r in rows)
    def search(self,q,limit=50):
        q=' '.join(str(q).split()).strip()
        if not q: return QueryResult(q,(),0.0,False)
        limit=max(1,min(int(limit),200)); key=(q.lower(),limit)
        now=time.monotonic()
        with self._lock:
            hit=self._cache.get(key)
            if hit and now-hit[0] < self.ttl:
                self._cache.move_to_end(key); return QueryResult(q,hit[1],(now-hit[0])*1000,True)
        start=time.perf_counter(); items=self._search(q.replace('"',' '),limit); elapsed=(time.perf_counter()-start)*1000
        with self._lock:
            self._cache[key]=(time.monotonic(),items); self._cache.move_to_end(key)
            while len(self._cache)>self.max_cache: self._cache.popitem(last=False)
        return QueryResult(q,items,elapsed,False)
    def related(self,node_id,limit=20):
        rows=self.g.db.execute("SELECT n.* FROM edges e JOIN nodes n ON n.id=CASE WHEN e.source_id=? THEN e.target_id ELSE e.source_id END WHERE e.source_id=? OR e.target_id=? ORDER BY n.rowid DESC LIMIT ?",(node_id,node_id,node_id,limit)).fetchall()
        return [dict(r) for r in rows]
    def path(self, source_id, target_id, max_depth=4):
        """Bounded breadth-first path search; read-only and deterministic."""
        max_depth=max(1,min(int(max_depth),8))
        if source_id==target_id: return [source_id]
        frontier=[source_id]; parent={source_id:None}
        for _ in range(max_depth):
            if not frontier: break
            marks=','.join('?'*len(frontier))
            rows=self.g.db.execute(f"SELECT source_id,relation,target_id FROM edges WHERE source_id IN ({marks}) OR target_id IN ({marks})",frontier+frontier).fetchall()
            nxt=[]
            for r in rows:
                a,b=r['source_id'],r['target_id']
                for u,v in ((a,b),(b,a)):
                    if u in parent or v in parent: continue
                    parent[v]=(u,r['relation']); nxt.append(v)
                    if v==target_id:
                        path=[]; cur=v
                        while cur is not None:
                            path.append(cur); cur=parent[cur][0] if parent[cur] else None
                        return list(reversed(path))
            frontier=nxt
        return []

    def health(self):
        with self._lock: cached=len(self._cache)
        return {"fts5":self._fts,"cache_entries":cached,"cache_limit":self.max_cache,"ttl_seconds":self.ttl}
