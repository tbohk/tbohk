from __future__ import annotations
import hashlib, re
from dataclasses import asdict, dataclass
from typing import Any

@dataclass(frozen=True)
class EntityMatch:
    entity_id: str
    canonical_name: str
    score: int
    match_type: str

class PersonalKnowledgeGraph:
    """Tenant-local reusable entity/context index over the durable graph.

    Resolution is deliberately conservative: exact canonical/alias/identifier
    matches are reused; fuzzy matches are suggestions and never silently merge.
    Provenance remains on the original claims/evidence.
    """
    ENTITY_KIND = "KnowledgeEntity"
    MAX_ENTITIES = 500
    MAX_LINKS = 200

    def __init__(self, graph): self.g = graph
    @staticmethod
    def _norm(v): return re.sub(r"[^a-z0-9]+", " ", str(v or "").casefold()).strip()
    @classmethod
    def _key(cls, name): return hashlib.sha256(cls._norm(name).encode()).hexdigest()[:24]

    def _entities(self):
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind=? ORDER BY rowid DESC LIMIT ?",(self.ENTITY_KIND,self.MAX_ENTITIES)).fetchall()
        return [self.g.get(r[0]) for r in rows if self.g.get(r[0])]

    def resolve(self, name: str, *, identifiers: dict[str,str]|None=None):
        key=self._norm(name); ids={self._norm(k):self._norm(v) for k,v in (identifiers or {}).items() if v}
        exact=[]
        for e in self._entities():
            m=e.metadata or {}; canon=self._norm(m.get("canonical_name") or e.content)
            aliases={self._norm(x) for x in (m.get("aliases") or [])}
            eid={self._norm(k):self._norm(v) for k,v in (m.get("identifiers") or {}).items() if v}
            if key and (key==canon or key in aliases): exact.append(EntityMatch(e.id,e.content,100,"canonical" if key==canon else "alias")); continue
            if ids and any(ids.get(k) and ids.get(k)==v for k,v in eid.items()): exact.append(EntityMatch(e.id,e.content,100,"identifier")); continue
        return [asdict(x) for x in exact[:20]]

    def create_or_get(self, name: str, *, entity_type="topic", aliases=None, identifiers=None, description=""):
        name=name.strip();
        if not name: raise ValueError("entity name required")
        matches=self.resolve(name,identifiers=identifiers)
        if matches: return {"entity":self.g.get(matches[0]["entity_id"]),"created":False,"match":matches[0]}
        metadata={"canonical_name":name,"entity_type":entity_type,"aliases":sorted(set(aliases or [])),"identifiers":dict(identifiers or {}),"description":description,"resolution_key":self._key(name),"boundary":"Personal knowledge entity index; identity is explicit and auditable."}
        n=self.g.add_node(self.ENTITY_KIND,name,"supported",metadata)
        return {"entity":n,"created":True,"match":None}

    def attach(self, entity_id: str, node_id: str, relation="about"):
        e=self.g.get(entity_id); n=self.g.get(node_id)
        if not e or e.kind!=self.ENTITY_KIND: raise ValueError("invalid entity")
        if not n: raise ValueError("invalid node")
        if relation not in {"about","contains","member_of"}: raise ValueError("unsupported personal-graph relation")
        exists=self.g.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation=? AND target_id=?",(entity_id,relation,node_id)).fetchone()
        if not exists: self.g.link(entity_id,relation,node_id)
        return {"entity_id":entity_id,"node_id":node_id,"relation":relation,"created":not bool(exists)}

    def profile(self, entity_id: str):
        e=self.g.get(entity_id)
        if not e or e.kind!=self.ENTITY_KIND: raise ValueError("invalid entity")
        links=[]
        for r in self.g.db.execute("SELECT source_id,relation,target_id,created_at FROM edges WHERE source_id=? OR target_id=? ORDER BY rowid DESC LIMIT ?",(entity_id,entity_id,self.MAX_LINKS)).fetchall():
            other=r[2] if r[0]==entity_id else r[0]; n=self.g.get(other)
            if n: links.append({"node_id":n.id,"kind":n.kind,"status":n.status,"content":n.content,"relation":r[1],"direction":"out" if r[0]==entity_id else "in","created_at":r[3]})
        claim_ids=sorted({x["node_id"] for x in links if x["kind"]=="Claim"})
        evidence_ids=sorted({x["node_id"] for x in links if x["kind"]=="Evidence"})
        investigations=[x for x in links if x["kind"] in {"InvestigationState","InvestigationPlan","Investigation"}]
        return {"entity":{ "id":e.id,"name":e.content,"status":e.status,"metadata":e.metadata},"claim_ids":claim_ids,"evidence_ids":evidence_ids,"investigations":investigations,"links":links,"counts":{"claims":len(claim_ids),"evidence":len(evidence_ids),"investigations":len(investigations)},"boundary":"Reusable context preserves original node status and provenance; it does not merge claims or assert identity beyond recorded matches."}

    def context(self, name: str, *, identifiers=None):
        matches=self.resolve(name,identifiers=identifiers)
        if not matches: return {"name":name,"matches":[],"suggestion":"Create an explicit entity if this subject should persist across investigations."}
        return {"name":name,"matches":[{"match":m,"profile":self.profile(m["entity_id"])} for m in matches[:5]]}
