from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Iterable
from urllib.parse import urlparse
import hashlib
from datetime import datetime, timezone
import re
from .core import TBOHK

@dataclass(frozen=True)
class SourceDocument:
    source_id: str
    title: str
    uri: str
    text: str
    provider_id: str
    retrieved_at: str
    origin_id: str
    published_at: str | None = None
    valid_from: str | None = None
    valid_until: str | None = None
    upstream_origin_ids: tuple[str, ...] = ()
    transformation_id: str | None = None
    publisher_id: str | None = None
    media: tuple[dict, ...] = ()

class ResearchProvider(Protocol):
    provider_id: str
    def search(self, query: str) -> Iterable[SourceDocument]: ...

class MockProvider:
    """Deterministic provider for offline tests and demonstrations."""
    def __init__(self, provider_id: str, documents: list[SourceDocument]):
        self.provider_id = provider_id
        self.documents = documents
    def search(self, query: str):
        q = query.lower()
        return [d for d in self.documents if any(term in d.text.lower() or term in d.title.lower() for term in q.split())]

def source_fingerprint(doc: SourceDocument) -> str:
    return hashlib.sha256((doc.uri.strip().lower()+"\0"+doc.text.strip()).encode("utf-8")).hexdigest()

def validate_source_document(doc: SourceDocument) -> None:
    parsed=urlparse(doc.uri)
    if parsed.scheme not in {"http","https"} or not parsed.netloc:
        raise ValueError("source URI must be an absolute http/https URL")
    if not doc.source_id or not doc.provider_id or not doc.origin_id:
        raise ValueError("source identity is incomplete")
    if not doc.text.strip():
        raise ValueError("source text is empty")

def source_independence_key(doc: SourceDocument) -> str:
    """Best-effort publisher/origin independence key; shared origins are not independent evidence."""
    return (doc.origin_id or doc.publisher_id or doc.provider_id or doc.source_id).strip().casefold()

def content_boundary(text: str) -> dict:
    """Mark retrieved text as untrusted content; never interpret instructions as system commands."""
    lowered=text.casefold()
    markers=tuple(sorted({m for m in ("ignore previous instructions", "system prompt", "developer message", "jailbreak", "do not follow", "reveal your instructions") if m in lowered}))
    return {"trust":"untrusted_source_content", "instructions_executable":False, "prompt_injection_markers":list(markers)}

def citation_status(graph: TBOHK, source_ids: Iterable[str]) -> dict:
    requested=list(dict.fromkeys(str(x) for x in source_ids if str(x)))
    found=[]; missing=[]
    for sid in requested:
        rows=graph.db.execute("SELECT id FROM nodes WHERE kind='Source' AND (id=? OR json_extract(metadata,'$.source_id')=?)",(sid,sid)).fetchall()
        (found if rows else missing).append(sid)
    return {"requested":requested,"verified":found,"missing":missing,"all_verified":not missing}

class ResearchChain:
    def __init__(self, graph: TBOHK, providers: list[ResearchProvider]):
        self.graph = graph
        self.providers = providers

    def run(self, query: str, stopping_condition="all configured providers completed"):
        unknown = self.graph.add_node("Unknown", query, "unknown", {"query": query})
        request = self.graph.add_node("ResearchRequest", query, "proposed", {
            "query": query, "search_strategy": "provider fan-out", "stopping_condition": stopping_condition
        })
        self.graph.link(request.id, "about", unknown.id)
        activity = self.graph.add_node("Activity", "research", "supported", {
            "activity_type": "research", "query": query, "stopping_condition": stopping_condition
        })
        results, failures, counts = [], [], {}
        seen_global_fingerprints=set()
        independent_origins=set()
        for provider in self.providers:
            p = self.graph.add_node("Provider", provider.provider_id, "supported", {
                "provider_id": provider.provider_id, "agent_type": "research_provider"
            })
            self.graph.link(activity.id, "uses", p.id)
            dispatch = self.graph.add_node("Dispatch", query, "proposed", {"provider_id": provider.provider_id})
            self.graph.link(dispatch.id, "dispatches", request.id); self.graph.link(dispatch.id, "uses", p.id)
            run = self.graph.add_node("Run", query, "proposed", {"provider_id": provider.provider_id})
            self.graph.link(run.id, "generated_by", dispatch.id); self.graph.link(run.id, "generated_by", activity.id)
            try: docs = list(provider.search(query))
            except Exception as exc:
                failures.append({"provider_id": provider.provider_id, "error_type": type(exc).__name__})
                self.graph.set_status(run.id, "failed", f"provider exception: {type(exc).__name__}")
                counts[provider.provider_id] = 0; continue
            counts[provider.provider_id] = len(docs)
            if not docs:
                failures.append({"provider_id": provider.provider_id, "error": "no_results"})
                self.graph.set_status(run.id, "failed", "provider returned no source snapshots")
                continue
            self.graph.set_status(run.id, "supported", f"{len(docs)} source snapshots")
            seen_fingerprints=set()
            for doc in docs:
                if doc.provider_id != provider.provider_id: raise ValueError("document/provider identity mismatch")
                validate_source_document(doc)
                fingerprint=source_fingerprint(doc)
                if fingerprint in seen_fingerprints or fingerprint in seen_global_fingerprints:
                    continue
                seen_fingerprints.add(fingerprint); seen_global_fingerprints.add(fingerprint)
                independent_origins.add(source_independence_key(doc))
                origin = self.graph.add_node("Origin", doc.origin_id, "supported", {
                    "origin_id": doc.origin_id,
                    "upstream_origin_ids": list(doc.upstream_origin_ids),
                    "transformation_id": doc.transformation_id,
                    "publisher_id": doc.publisher_id,
                })
                for parent_id in doc.upstream_origin_ids:
                    parent = self.graph.add_node("Origin", parent_id, "supported", {"origin_id": parent_id})
                    self.graph.link(origin.id, "derived_from_origin", parent.id)
                source = self.graph.add_node("Source", doc.source_id, "supported", {
                    "source_id": doc.source_id, "title": doc.title, "uri": doc.uri, "origin_id": doc.origin_id,
                    "publisher_id": doc.publisher_id, "transformation_id": doc.transformation_id
                })
                self.graph.link(source.id, "attributed_to", p.id)
                self.graph.link(source.id, "originates_from", origin.id)
                snap = self.graph.add_node("SourceSnapshot", doc.text, "supported", {
                    "source_id": doc.source_id, "title": doc.title, "uri": doc.uri,
                    "provider_id": doc.provider_id, "origin_id": doc.origin_id,
                    "upstream_origin_ids": list(doc.upstream_origin_ids),
                    "transformation_id": doc.transformation_id, "publisher_id": doc.publisher_id,
                    "retrieved_at": doc.retrieved_at, "published_at": doc.published_at,
                    "valid_from": doc.valid_from, "valid_until": doc.valid_until,
                    "source_fingerprint": fingerprint,
                    "content_boundary": content_boundary(doc.text),
                })
                self.graph.link(snap.id, "produces", run.id)
                self.graph.link(snap.id, "documents", source.id)
                evidence = self.graph.add_node("Evidence", doc.text, "supported", {
                    "source_id": doc.source_id, "title": doc.title, "uri": doc.uri,
                    "provider_id": doc.provider_id, "origin_id": doc.origin_id,
                    "upstream_origin_ids": list(doc.upstream_origin_ids),
                    "transformation_id": doc.transformation_id, "publisher_id": doc.publisher_id,
                    "locator": {"type": "document", "source_id": doc.source_id},
                    "extraction_method": "provider_returned_document",
                    "source_fingerprint": fingerprint,
                    "content_boundary": content_boundary(doc.text),
                    "observation_time": doc.retrieved_at,
                    "polarity": "supports",
                    "observation_basis": "provider_returned_document", "media": list(doc.media),
                })
                self.graph.link(evidence.id, "derived_from", snap.id)
                self.graph.link(evidence.id, "evidence_for", unknown.id)
                results.append((snap, evidence))
        record = self.graph.add_node("ResearchRecord", query, "supported", {
            "query": query, "providers_consulted": [p.provider_id for p in self.providers],
            "result_counts": counts, "failures": failures, "stopping_condition": stopping_condition,
            "integrity": {"duplicate_policy": "content-addressed source fingerprint; duplicates omitted across providers", "independent_origin_count": len(independent_origins), "source_content_boundary": "retrieved text is untrusted data; embedded instructions are never executable"},
        })
        self.graph.link(record.id, "records", activity.id)
        return {"unknown": unknown, "request": request, "activity": activity, "results": results,
                "research_record": {"query": query, "providers_consulted": [p.provider_id for p in self.providers],
                                    "result_counts": counts, "failures": failures,
                                    "stopping_condition": stopping_condition, "record_id": record.id,
                                    "integrity": {"duplicate_policy": "content-addressed source fingerprint; duplicates omitted across providers", "independent_origin_count": len(independent_origins), "source_content_boundary": "retrieved text is untrusted data; embedded instructions are never executable"}}}
