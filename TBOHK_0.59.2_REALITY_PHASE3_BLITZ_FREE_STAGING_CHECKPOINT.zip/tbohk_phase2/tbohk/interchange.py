from __future__ import annotations
import json

class GraphInterchange:
    """Portable, deterministic JSON interchange for graph snapshots."""
    def __init__(self,graph): self.g=graph
    def export(self, *, kinds=None, limit=5000):
        args=[]; where=''
        if kinds:
            ks=list(dict.fromkeys(kinds)); where=' WHERE kind IN ('+','.join('?'*len(ks))+')'; args.extend(ks)
        rows=self.g.db.execute(f'SELECT * FROM nodes{where} ORDER BY rowid LIMIT ?',args+[max(1,min(int(limit),20000))]).fetchall()
        ids={r['id'] for r in rows}
        edges=[dict(r) for r in self.g.db.execute('SELECT * FROM edges ORDER BY rowid') if r['source_id'] in ids and r['target_id'] in ids]
        return {'format':'tbohk.graph.json','version':1,'nodes':[dict(r) for r in rows],'edges':edges}
    def dumps(self, **kwargs): return json.dumps(self.export(**kwargs),sort_keys=True,separators=(',',':'),ensure_ascii=False)
