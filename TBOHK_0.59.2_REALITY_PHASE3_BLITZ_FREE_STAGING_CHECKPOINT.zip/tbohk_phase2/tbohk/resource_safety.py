from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ComplexityBudget:
    max_reasoning_depth: int = 32
    max_nodes_examined: int = 1000
    max_edges_examined: int = 5000
    max_derivations: int = 500
    max_conflict_members: int = 200
    max_trace_nodes: int = 1000

@dataclass(frozen=True)
class ComplexityReport:
    ok: bool
    exceeded: tuple[str, ...]
    metrics: dict[str, int]

class ReasoningResourceGuard:
    def __init__(self, graph, budget: ComplexityBudget | None = None):
        self.g=graph; self.budget=budget or ComplexityBudget()
    def measure(self, root_id: str) -> ComplexityReport:
        seen=set(); frontier=[root_id]; edges=0; depth=0
        while frontier and len(seen) <= self.budget.max_nodes_examined:
            depth += 1
            nxt=[]
            for nid in frontier:
                if nid in seen: continue
                seen.add(nid)
                for e in self.g.edges(nid):
                    edges += 1
                    other=e['target_id'] if e['source_id']==nid else e['source_id']
                    if other not in seen: nxt.append(other)
                    if edges > self.budget.max_edges_examined: break
                if edges > self.budget.max_edges_examined: break
            if edges > self.budget.max_edges_examined: break
            frontier=nxt
            if depth > self.budget.max_reasoning_depth: break
        exceeded=[]
        if depth > self.budget.max_reasoning_depth: exceeded.append('reasoning_depth')
        if len(seen) > self.budget.max_nodes_examined: exceeded.append('nodes_examined')
        if edges > self.budget.max_edges_examined: exceeded.append('edges_examined')
        return ComplexityReport(not exceeded, tuple(exceeded), {'nodes_examined':len(seen),'edges_examined':edges,'depth':depth})
    def guard(self, root_id: str):
        r=self.measure(root_id)
        if not r.ok: raise RuntimeError('complexity budget exceeded: '+','.join(r.exceeded))
        return r
