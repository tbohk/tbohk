from __future__ import annotations
from dataclasses import dataclass
import hashlib, hmac, json

@dataclass(frozen=True)
class SignatureEnvelope:
    algorithm: str
    key_id: str
    manifest_sha256: str
    signature: str

@dataclass(frozen=True)
class TrustReport:
    passed: bool
    findings: tuple[str, ...]

class ReleaseSigner:
    """Portable authenticated release identity using HMAC-SHA256.

    This provides authenticity to parties that possess the signing key; it is
    deliberately not presented as public-key non-repudiation.
    """
    algorithm = "HMAC-SHA256"

    def __init__(self, key: bytes, key_id: str):
        if not key or not key_id:
            raise ValueError("key and key_id are required")
        self.key = bytes(key)
        self.key_id = key_id

    @staticmethod
    def canonical_manifest(manifest: dict) -> bytes:
        return json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()

    def sign(self, manifest: dict) -> SignatureEnvelope:
        raw = self.canonical_manifest(manifest)
        digest = hashlib.sha256(raw).hexdigest()
        sig = hmac.new(self.key, raw, hashlib.sha256).hexdigest()
        return SignatureEnvelope(self.algorithm, self.key_id, digest, sig)

    def verify(self, manifest: dict, envelope: SignatureEnvelope) -> bool:
        if envelope.algorithm != self.algorithm or envelope.key_id != self.key_id:
            return False
        raw = self.canonical_manifest(manifest)
        digest = hashlib.sha256(raw).hexdigest()
        expected = hmac.new(self.key, raw, hashlib.sha256).hexdigest()
        return hmac.compare_digest(digest, envelope.manifest_sha256) and hmac.compare_digest(expected, envelope.signature)

class TrustAuditor:
    def __init__(self, graph):
        self.g = graph

    def verify_checkpoint(self, checkpoint_id: str, signer: ReleaseSigner) -> TrustReport:
        row = self.g.db.execute("SELECT kind,metadata FROM nodes WHERE id=?", (checkpoint_id,)).fetchone()
        if not row or row['kind'] != 'Checkpoint':
            return TrustReport(False, ('checkpoint_missing',))
        try:
            meta = json.loads(row['metadata'])
            env = SignatureEnvelope(**meta['release_signature'])
            manifest = meta['manifest']
        except (KeyError, TypeError, json.JSONDecodeError):
            return TrustReport(False, ('release_signature_missing_or_malformed',))
        if not signer.verify(manifest, env):
            return TrustReport(False, ('release_signature_invalid',))
        return TrustReport(True, ())
