from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, threading
from typing import Any, Callable

@dataclass(frozen=True)
class DomainEvent:
    id: str
    topic: str
    subject_id: str
    payload: dict[str, Any]
    occurred_at: str

class EventBus:
    """In-process event bus. Delivery is best-effort and never changes truth state."""
    def __init__(self):
        self._lock=threading.RLock(); self._subs: dict[str,list[Callable[[DomainEvent],None]]]={}
    def subscribe(self, topic: str, handler: Callable[[DomainEvent],None]):
        with self._lock: self._subs.setdefault(topic,[]).append(handler)
    def publish(self, topic: str, subject_id: str, payload: dict[str,Any]|None=None):
        event=DomainEvent(hashlib.sha256(f'{topic}|{subject_id}|{datetime.now(timezone.utc).isoformat()}'.encode()).hexdigest()[:24],topic,subject_id,dict(payload or {}),datetime.now(timezone.utc).isoformat())
        with self._lock: handlers=tuple(self._subs.get(topic,()))+tuple(self._subs.get('*',()))
        for handler in handlers:
            try: handler(event)
            except Exception: pass
        return event

class CanonicalJSON:
    @staticmethod
    def dumps(value: Any) -> str:
        return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)
    @staticmethod
    def digest(value: Any) -> str:
        return hashlib.sha256(CanonicalJSON.dumps(value).encode()).hexdigest()

@dataclass(frozen=True)
class Capability:
    id: str
    label: str
    category: str
    description: str
    endpoint: str|None = None
    safe: bool = True

class CapabilityRegistry:
    def __init__(self): self._items: dict[str,Capability]={}
    def register(self, capability: Capability): self._items[capability.id]=capability
    def list(self, category: str|None=None):
        items=list(self._items.values())
        if category: items=[x for x in items if x.category==category]
        return [asdict(x) for x in sorted(items,key=lambda x:(x.category,x.label))]
