from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
import heapq

@dataclass(frozen=True)
class ScheduledJob:
    id:str; kind:str; run_at:str; priority:int; status:str; payload:dict[str,Any]

class Scheduler:
    """Persistent bounded scheduler. Scheduling is declarative; execution is explicit."""
    def __init__(self, graph): self.g=graph
    def schedule(self, kind, payload=None, *, run_at=None, priority=50, dedupe_key=None):
        payload=dict(payload or {})
        if dedupe_key:
            row=self.g.db.execute("SELECT id FROM nodes WHERE kind='ScheduledJob' AND json_extract(metadata,'$.dedupe_key')=? AND status IN ('proposed','proposed','running') LIMIT 1",(dedupe_key,)).fetchone()
            if row: return self.get(row['id'])
        now=run_at or datetime.now(timezone.utc).isoformat()
        n=self.g.add_node('ScheduledJob',kind,'proposed',{'kind':kind,'run_at':now,'priority':int(priority),'payload':payload,'dedupe_key':dedupe_key,'reversible':True})
        return self.get(n.id)
    def get(self, job_id):
        n=self.g.get(job_id)
        if not n or n.kind!='ScheduledJob': raise KeyError(job_id)
        return ScheduledJob(n.id,n.content,n.metadata['run_at'],int(n.metadata.get('priority',50)),n.status,n.metadata.get('payload',{}))
    def due(self, now=None, limit=50):
        now=now or datetime.now(timezone.utc).isoformat()
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='ScheduledJob' AND status='proposed' AND json_extract(metadata,'$.run_at')<=? ORDER BY CAST(json_extract(metadata,'$.priority') AS INTEGER) DESC, rowid LIMIT ?",(now,max(1,min(limit,100)),)).fetchall()
        return [self.get(r['id']) for r in rows]
    def mark(self, job_id, status):
        if status not in {'proposed','supported','rejected','unknown','proposed'}: raise ValueError('invalid job status')
        self.g.update_status(job_id,status,reason='scheduler transition')
        return self.get(job_id)
