from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib, json

@dataclass(frozen=True)
class HorizonSnapshot:
    captured_at: str
    node_hash: str
    edge_hash: str
    event_hash: str
    revision_hash: str
    node_count: int
    edge_count: int
    event_count: int
    revision_count: int
    node_id_hashes: tuple[tuple[str,str], ...] = ()
    edge_hashes: tuple[tuple[str,str], ...] = ()
    event_id_hashes: tuple[tuple[str,str], ...] = ()
    revision_id_hashes: tuple[tuple[str,str], ...] = ()

@dataclass(frozen=True)
class HorizonFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    invariant: str
    blocks_release: bool
    evidence: str

@dataclass(frozen=True)
class HorizonReport:
    passed: bool
    cycles: int
    findings: tuple[HorizonFinding, ...]
    snapshots: tuple[HorizonSnapshot, ...]

class LongHorizonValidator:
    """G17 continuous-integrity validator.

    It validates properties that can fail only after repeated state transitions:
    immutable history, content-hash drift, dangling provenance, checkpoint lineage,
    stale dependency propagation, evaluation-suite drift, and replay accumulation.
    The validator observes state directly and does not call release/gate auditors.
    """
    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _canon(rows):
        return json.dumps([dict(r) for r in rows], sort_keys=True, separators=(",", ":"), default=str).encode()

    def snapshot(self) -> HorizonSnapshot:
        n = self.g.db.execute("SELECT id,kind,status,content,metadata,created_at FROM nodes ORDER BY id").fetchall()
        e = self.g.db.execute("SELECT source_id,relation,target_id,created_at FROM edges ORDER BY source_id,relation,target_id").fetchall()
        ev = self.g.db.execute("SELECT id,event_type,subject_id,payload,created_at FROM events ORDER BY rowid").fetchall()
        rv = self.g.db.execute("SELECT id,node_id,old_status,new_status,old_content,new_content,reason,created_at FROM revisions ORDER BY rowid").fetchall()
        def row_hash(r): return hashlib.sha256(json.dumps(dict(r),sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
        return HorizonSnapshot(datetime.now(timezone.utc).isoformat(),
            hashlib.sha256(self._canon(n)).hexdigest(), hashlib.sha256(self._canon(e)).hexdigest(),
            hashlib.sha256(self._canon(ev)).hexdigest(), hashlib.sha256(self._canon(rv)).hexdigest(),
            len(n),len(e),len(ev),len(rv),
            tuple((r['id'],row_hash(r)) for r in n),
            tuple((f"{r['source_id']}|{r['relation']}|{r['target_id']}",row_hash(r)) for r in e),
            tuple((r['id'],row_hash(r)) for r in ev),
            tuple((r['id'],row_hash(r)) for r in rv))

    def compare(self, baseline: HorizonSnapshot, current: HorizonSnapshot) -> tuple[HorizonFinding, ...]:
        out=[]
        def maps(items): return dict(items)
        for label, old_items, new_items, invariant in (
            ('node',baseline.node_id_hashes,current.node_id_hashes,'I8'),
            ('edge',baseline.edge_hashes,current.edge_hashes,'I8'),
            ('event',baseline.event_id_hashes,current.event_id_hashes,'I3'),
            ('revision',baseline.revision_id_hashes,current.revision_id_hashes,'I3')):
            old,new=maps(old_items),maps(new_items)
            for ident in sorted(set(old)&set(new)):
                if old[ident] != new[ident]:
                    self._find(out,f'{label}_history_mutated','critical',(ident,),invariant,f'{label} record changed after baseline capture')
            if label in ('node','edge','event','revision'):
                missing=sorted(set(old)-set(new))
                if missing:
                    self._find(out,f'{label}_history_deleted','critical',tuple(missing[:8]),'I3',f'{len(missing)} persisted {label} records disappeared')
        return tuple(out)

    def _find(self, out, code, severity, ids, invariant, evidence, blocks=True):
        out.append(HorizonFinding(code,severity,tuple(ids),invariant,blocks,evidence))

    def _content_hashes(self, out):
        rows=self.g.db.execute("SELECT id,content,metadata FROM nodes").fetchall()
        for r in rows:
            try: m=json.loads(r['metadata'])
            except Exception:
                self._find(out,'malformed_node_metadata','critical',[r['id']],'I3','node metadata is not valid JSON'); continue
            expected=hashlib.sha256(r['content'].encode()).hexdigest()
            if m.get('content_sha256') and m['content_sha256'] != expected:
                self._find(out,'content_hash_drift','critical',[r['id']],'I9','stored content hash does not match node content')

    def _history(self, out):
        # Every revision must point to a live node; revision history must never rewrite content.
        for r in self.g.db.execute("SELECT id,node_id,old_content,new_content FROM revisions").fetchall():
            if not self.g.get(r['node_id']):
                self._find(out,'orphan_revision','critical',[r['id']],'I3','revision points to a missing node')
            if r['old_content'] != r['new_content']:
                self._find(out,'content_mutation_without_lineage','critical',[r['id'],r['node_id']],'I3','revision contains content mutation outside the immutable content model')
        for r in self.g.db.execute("SELECT id,subject_id FROM events").fetchall():
            if not self.g.get(r['subject_id']):
                self._find(out,'orphan_event','critical',[r['id']],'I3','event points to a missing subject')

    def _edges(self, out):
        for r in self.g.db.execute("SELECT source_id,relation,target_id FROM edges").fetchall():
            if not self.g.get(r['source_id']) or not self.g.get(r['target_id']):
                self._find(out,'dangling_edge','critical',[r['source_id'],r['target_id']],'I3','edge references missing node')
            if r['source_id']==r['target_id']:
                self._find(out,'self_edge_persistence','critical',[r['source_id']],'I1','self edge survived into persisted state')

    def _dependencies(self, out):
        # A verified object cannot remain verified when a direct epistemic dependency is stale/contradicted.
        rows=self.g.db.execute("""
            SELECT e.target_id AS dependent, e.source_id AS dependency, n.kind AS dep_kind, n.status AS dep_status
            FROM edges e JOIN nodes n ON n.id=e.source_id
            WHERE e.relation IN ('based_on','evidence_for','derived_from','depends_on')
        """).fetchall()
        for r in rows:
            dep=self.g.get(r['dependent'])
            if dep and dep.status=='verified' and r['dep_status'] in ('stale','contradicted','failed'):
                self._find(out,'verified_stale_dependency','critical',[r['dependent'],r['dependency']],'I8',f"verified {dep.kind} depends on {r['dep_status']} node")

    def _evaluations(self, out):
        for r in self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='Evaluation'").fetchall():
            try:m=json.loads(r['metadata'])
            except Exception:
                self._find(out,'evaluation_metadata_corrupt','critical',[r['id']],'I9','evaluation metadata cannot be parsed');continue
            sid=m.get('suite_id'); s=self.g.get(sid) if sid else None
            if not s or s.kind!='EvaluationSuite':
                self._find(out,'evaluation_suite_missing','critical',[r['id']],'I15','evaluation points to missing suite')
            elif m.get('suite_manifest_sha256') != s.metadata.get('manifest_sha256'):
                self._find(out,'evaluation_suite_drift','critical',[r['id'],sid],'I15','evaluation no longer matches the suite manifest used for assessment')

    def _actions(self, out):
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='Action'").fetchall():
            executions=self.g.db.execute("SELECT id FROM events WHERE subject_id=? AND event_type='action.executed' ORDER BY rowid",(r['id'],)).fetchall()
            if len(executions)>1:
                self._find(out,'replay_accumulation','critical',[r['id']],'I7',f'{len(executions)} execution records accumulated for one action')

    def _checkpoints(self, out):
        cps=self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='Checkpoint' ORDER BY created_at,id").fetchall()
        seen={}
        for r in cps:
            try:m=json.loads(r['metadata'])
            except Exception:
                self._find(out,'checkpoint_metadata_corrupt','critical',[r['id']],'I9','checkpoint metadata cannot be parsed');continue
            seq=m.get('checkpoint_sequence'); parent=m.get('parent_checkpoint_id')
            if seq is not None:
                if not isinstance(seq,int) or seq<0:self._find(out,'invalid_checkpoint_sequence','critical',[r['id']],'I9','checkpoint sequence is not a non-negative integer')
                elif seq in seen:self._find(out,'duplicate_checkpoint_sequence','critical',[r['id'],seen[seq]],'I9','two checkpoints share a sequence number')
                else: seen[seq]=r['id']
            if parent:
                p=self.g.get(parent)
                if not p or p.kind!='Checkpoint': self._find(out,'missing_checkpoint_parent','critical',[r['id'],parent],'I9','checkpoint lineage references a missing parent')
                elif seq is not None:
                    try: ps=json.loads(p.metadata and json.dumps(p.metadata)).get('checkpoint_sequence')
                    except Exception: ps=None
                    if ps is not None and seq<=ps:self._find(out,'non_monotonic_checkpoint_lineage','critical',[r['id'],parent],'I9','checkpoint sequence does not advance beyond parent')

    def run(self, *, cycles=12) -> HorizonReport:
        if not isinstance(cycles,int) or cycles<1 or cycles>1000: raise ValueError('cycles must be 1..1000')
        findings=[]; snaps=[]
        previous=self.snapshot(); snaps.append(previous)
        for _ in range(cycles):
            current=self.snapshot(); snaps.append(current)
            # Repeated observation must not create state changes by itself.
            if current.node_hash!=previous.node_hash or current.edge_hash!=previous.edge_hash or current.event_hash!=previous.event_hash or current.revision_hash!=previous.revision_hash:
                self._find(findings,'observer_induced_drift','critical',(),'I8','repeated integrity observation changed persisted state')
            previous=current
        self._content_hashes(findings); self._history(findings); self._edges(findings)
        self._dependencies(findings); self._evaluations(findings); self._actions(findings); self._checkpoints(findings)
        return HorizonReport(not any(f.blocks_release for f in findings),cycles,tuple(findings),tuple(snaps))
