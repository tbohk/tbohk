from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import deque
from typing import Iterable
from .core import TBOHK

# Relations which participate in dependency impact analysis.  Direction matters:
# some graph edges are stored as `dependent -> dependency` (for example
# Decision -> Claim via `based_on`), so the analyzer traverses those edges in
# reverse when starting from the changed dependency.  This prevents the graph's
# storage orientation from hiding the actual downstream blast radius.
DEPENDENCY_RELATIONS = frozenset({
    "evidence_for", "derives", "produces", "depends_on", "predicts",
    "evaluated_by", "evaluates", "premise_of", "applies_rule", "based_on",
    "generated_by", "uses", "invalidates", "documents", "resolves",
    "contains",
})

# Stored as dependent -> dependency; impact travels dependency -> dependent.
REVERSE_DEPENDENCY_RELATIONS = frozenset({
    "based_on", "depends_on", "contains", "resolves", "evaluates",
    "evaluated_by", "uses",
})

@dataclass(frozen=True)
class DependencyPath:
    root_id: str
    node_ids: tuple[str, ...]
    relations: tuple[str, ...]

@dataclass(frozen=True)
class ImpactItem:
    node_id: str
    kind: str
    status: str
    impact: str
    distance: int
    roots: tuple[str, ...]
    paths: tuple[DependencyPath, ...]
    reasons: tuple[str, ...]

@dataclass(frozen=True)
class ImpactReport:
    roots: tuple[str, ...]
    items: tuple[ImpactItem, ...]
    cycle_edges: tuple[tuple[str, str, str], ...]
    excluded_invalid_provenance_roots: tuple[str, ...]
    scoped_run_id: str | None
    counts: dict[str, int]
    boundary: str

class DependencyImpactAnalyzer:
    """Read-only dependency blast-radius analysis.

    A dependency change means "review this downstream object"; it never mutates
    status, rewrites history, or infers that a downstream conclusion is false.
    "disproven" is reserved for an explicit contradictory/invalidating relation
    or a root already carrying an explicit contradicted/failed/rejected state.
    "potentially_invalidated" is used when a foundational dependency is stale or
    otherwise no longer a valid basis for the downstream object.
    "affected" is the default review state.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _valid_evidence(self, node_id: str) -> bool:
        n = self.g.get(node_id)
        if not n or n.kind != "Evidence":
            return True
        origin_id = n.metadata.get("origin_id")
        return bool(origin_id and self.g.get(origin_id))

    def _neighbors(self, node_id: str):
        """Yield deterministic downstream dependency neighbors.

        A single edge may be traversed forward or backward depending on the
        relation's storage semantics.  The yielded relation is always the
        canonical graph relation, while the path direction is encoded by the
        node order.
        """
        rows = []
        for edge in self.g.edges(node_id, direction="out"):
            if edge["relation"] not in DEPENDENCY_RELATIONS:
                continue
            if edge["relation"] in REVERSE_DEPENDENCY_RELATIONS:
                continue
            rows.append((edge["target_id"], edge["relation"]))
        for edge in self.g.edges(node_id, direction="in"):
            if edge["relation"] not in REVERSE_DEPENDENCY_RELATIONS:
                continue
            rows.append((edge["source_id"], edge["relation"]))
        return sorted(rows, key=lambda x: (x[1], x[0]))

    def _scope_nodes(self, run_id: str) -> set[str]:
        run = self.g.get(run_id)
        if not run or run.kind != "AdaptiveResearchRun":
            raise ValueError("run_id must reference an AdaptiveResearchRun")
        seeds = set(run.metadata.get("hypothesis_ids", [])) | {run_id}
        for edge in self.g.edges(run_id, direction="out", relation="contains"):
            cycle = self.g.get(edge["target_id"])
            if cycle:
                seeds.update(cycle.metadata.get("evidence_ids", []))
                seeds.add(cycle.id)
        seen = set(seeds)
        q = deque(sorted(seeds))
        while q:
            cur = q.popleft()
            # Scope membership is an undirected connectivity boundary: it is
            # used only to keep an investigation from leaking into unrelated
            # graph regions. Actual impact traversal below remains direction-
            # aware and therefore preserves dependency semantics.
            for edge in self.g.edges(cur, direction="both"):
                if edge["relation"] not in DEPENDENCY_RELATIONS:
                    continue
                nxt = edge["target_id"] if edge["source_id"] == cur else edge["source_id"]
                if nxt not in seen:
                    seen.add(nxt); q.append(nxt)
        return seen

    def _allowed_for_scope(self, node_id: str, run_id: str | None) -> bool:
        if not run_id:
            return True
        return node_id in self._scope_nodes(run_id)

    def _reachable_from(self, source_id: str, target_id: str, max_nodes: int = 10000) -> bool:
        if source_id == target_id:
            return True
        seen = {source_id}
        q = deque([source_id])
        while q and len(seen) <= max_nodes:
            cur = q.popleft()
            for nxt, _rel in self._neighbors(cur):
                if nxt == target_id:
                    return True
                if nxt not in seen:
                    seen.add(nxt); q.append(nxt)
        return False

    def analyze(self, root_ids: Iterable[str], *, run_id: str | None = None, max_nodes: int = 10000) -> ImpactReport:
        roots = tuple(sorted(dict.fromkeys(root_ids)))
        if not roots:
            raise ValueError("at least one root_id is required")
        if max_nodes < 1:
            raise ValueError("max_nodes must be positive")
        for rid in roots:
            if not self.g.get(rid):
                raise ValueError(f"root node does not exist: {rid}")
        if run_id:
            self._allowed_for_scope(run_id, run_id)

        excluded = tuple(sorted(r for r in roots if not self._valid_evidence(r)))
        active_roots = tuple(r for r in roots if r not in excluded)
        items = {}
        cycle_edges = set()
        q = deque()
        for rid in active_roots:
            if run_id and not self._allowed_for_scope(rid, run_id):
                continue
            q.append((rid, rid, (rid,), ()))

        visited_states = set()
        expanded = 0
        while q:
            root, current, path_nodes, path_relations = q.popleft()
            state = (root, current)
            if state in visited_states:
                # We still retain the first deterministic path only.
                continue
            visited_states.add(state)
            expanded += 1
            if expanded > max_nodes:
                raise ValueError(f"impact traversal exceeded max_nodes={max_nodes}")
            for nxt, rel in self._neighbors(current):
                if rel not in DEPENDENCY_RELATIONS:
                    continue
                if nxt in path_nodes:
                    cycle_edges.add((current, rel, nxt))
                    continue
                if run_id and not self._allowed_for_scope(nxt, run_id):
                    continue
                if not self._valid_evidence(nxt):
                    continue
                n = self.g.get(nxt)
                if not n:
                    continue
                new_path_nodes = path_nodes + (nxt,)
                new_path_relations = path_relations + (rel,)
                path = DependencyPath(root, new_path_nodes, new_path_relations)
                entry = items.setdefault(nxt, {
                    "kind": n.kind, "status": n.status, "distance": len(new_path_relations),
                    "roots": set(), "paths": [], "reasons": set(),
                })
                entry["roots"].add(root)
                if path not in entry["paths"]:
                    entry["paths"].append(path)
                entry["distance"] = min(entry["distance"], len(new_path_relations))
                # The path itself is authoritative; annotate storage reversal
                # where applicable so auditors can see why the edge was crossed.
                if rel in REVERSE_DEPENDENCY_RELATIONS:
                    entry["reasons"].add(f"dependency via {rel} (stored reverse)")
                else:
                    entry["reasons"].add(f"dependency via {rel}")
                q.append((root, nxt, new_path_nodes, new_path_relations))

        out = []
        for nid in sorted(items):
            data = items[nid]
            n = self.g.get(nid)
            impact = self._classify(n, active_roots, data["paths"])
            if nid in active_roots:
                continue
            paths = tuple(sorted(data["paths"], key=lambda p: (len(p.node_ids), p.root_id, p.node_ids, p.relations)))
            out.append(ImpactItem(nid, data["kind"], data["status"], impact,
                                  data["distance"], tuple(sorted(data["roots"])), paths,
                                  tuple(sorted(data["reasons"]))))

        counts = {k: sum(1 for i in out if i.impact == k) for k in ("affected", "potentially_invalidated", "disproven")}
        counts["total_impacted"] = len(out)
        counts["cycle_edges"] = len(cycle_edges)
        return ImpactReport(active_roots, tuple(out), tuple(sorted(cycle_edges)), excluded,
                            run_id, counts,
                            "Dependency impact is a review/blast-radius analysis. It does not mutate history, prove downstream falsehood, assign probabilities, or authorize action.")

    def _classify(self, node, roots, paths) -> str:
        # Explicit invalidation/contradiction has priority over generic dependency.
        for root_id in roots:
            root = self.g.get(root_id)
            if not root:
                continue
            if root.status in {"contradicted", "failed", "rejected", "superseded"}:
                # A changed/failed upstream object removes confidence in its
                # dependents but does not by itself prove them false.
                return "potentially_invalidated"
            if any(e["target_id"] == node.id and e["relation"] in {"invalidates", "contradicts"}
                   for e in self.g.edges(root.id, direction="out")):
                return "disproven"
        # A stale root is a loss of basis, not proof that the dependent object is false.
        if any(self.g.get(p.root_id).status == "stale" for p in paths if self.g.get(p.root_id)):
            return "potentially_invalidated"
        if node.status in {"stale", "contradicted"}:
            return "potentially_invalidated"
        return "affected"

    def analyze_investigation(self, run_id: str, root_ids: Iterable[str], *, max_nodes: int = 10000) -> ImpactReport:
        return self.analyze(root_ids, run_id=run_id, max_nodes=max_nodes)
