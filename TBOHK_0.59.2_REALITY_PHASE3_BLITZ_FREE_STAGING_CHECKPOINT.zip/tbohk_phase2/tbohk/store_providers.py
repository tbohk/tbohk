from __future__ import annotations
import base64, hashlib, json, os, time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.parse import quote
import httpx
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.x509 import Certificate

from .store_billing import PurchaseVerificationError


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


def _b64ud(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))


def decode_jws(jws: str) -> tuple[dict[str, Any], dict[str, Any], bytes]:
    parts = jws.split('.')
    if len(parts) != 3 or not all(parts):
        raise PurchaseVerificationError('invalid JWS compact serialization')
    try:
        header = json.loads(_b64ud(parts[0]))
        payload = json.loads(_b64ud(parts[1]))
        signature = _b64ud(parts[2])
    except Exception as exc:
        raise PurchaseVerificationError('invalid JWS encoding') from exc
    if not isinstance(header, dict) or not isinstance(payload, dict):
        raise PurchaseVerificationError('invalid JWS JSON payload')
    return header, payload, signature


def _verify_cert_chain(leaf: Certificate, chain: list[Certificate], roots: list[Certificate]) -> None:
    certs = [leaf, *chain]
    if not certs or not roots:
        raise PurchaseVerificationError('certificate trust roots are not configured')
    for i, cert in enumerate(certs):
        issuer = certs[i + 1] if i + 1 < len(certs) else next((r for r in roots if r.subject == cert.issuer), None)
        if issuer is None:
            raise PurchaseVerificationError('JWS certificate chain is not trusted')
        try:
            issuer.public_key().verify(cert.signature, cert.tbs_certificate_bytes, padding.PKCS1v15(), cert.signature_hash_algorithm) if isinstance(issuer.public_key(), rsa.RSAPublicKey) else issuer.public_key().verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(cert.signature_hash_algorithm))
        except Exception as exc:
            raise PurchaseVerificationError('JWS certificate signature validation failed') from exc
    if leaf.not_valid_before_utc > datetime.now(timezone.utc) or leaf.not_valid_after_utc < datetime.now(timezone.utc):
        raise PurchaseVerificationError('JWS leaf certificate is outside its validity period')


def verify_apple_jws(jws: str, roots_pem: str) -> tuple[dict[str, Any], dict[str, Any]]:
    header, payload, signature = decode_jws(jws)
    if header.get('alg') != 'ES256':
        raise PurchaseVerificationError('Apple JWS algorithm must be ES256')
    x5c = header.get('x5c')
    if not isinstance(x5c, list) or not x5c:
        raise PurchaseVerificationError('Apple JWS certificate chain is missing')
    try:
        certs = [x509.load_der_x509_certificate(base64.b64decode(v)) for v in x5c]
        roots = []
        for pem in roots_pem.split('-----END CERTIFICATE-----'):
            if '-----BEGIN CERTIFICATE-----' in pem:
                roots.append(x509.load_pem_x509_certificate((pem + '-----END CERTIFICATE-----').encode()))
        _verify_cert_chain(certs[0], certs[1:], roots)
        certs[0].public_key().verify(encode_dss_signature(int.from_bytes(signature[:32],'big'), int.from_bytes(signature[32:],'big')), (jws.split('.')[0] + '.' + jws.split('.')[1]).encode(), ec.ECDSA(hashes.SHA256()))
    except PurchaseVerificationError:
        raise
    except Exception as exc:
        raise PurchaseVerificationError('Apple JWS signature validation failed') from exc
    return header, payload


def _parse_iso_ms(value: Any) -> str | None:
    if value is None: return None
    try:
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(float(value) / 1000, timezone.utc).isoformat()
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).astimezone(timezone.utc).isoformat()
    except Exception:
        return None


def _plan_for_product(product_id: str, mapping: dict[str, str]) -> str:
    plan = mapping.get(product_id)
    if plan not in {'pro', 'unlimited'}:
        raise PurchaseVerificationError('store product is not configured')
    return plan


class AppleStoreServerVerifier:
    """Authoritative Apple verifier using App Store Server API + signed JWS payloads."""
    def __init__(self, env: dict[str, str] | None = None, transport: Callable[..., Any] | None = None):
        e = env or os.environ
        self.issuer_id = e.get('APPLE_ISSUER_ID', '')
        self.key_id = e.get('APPLE_KEY_ID', '')
        self.private_key_pem = e.get('APPLE_PRIVATE_KEY_PEM', '')
        self.root_pem = e.get('APPLE_ROOT_CA_PEM', '')
        self.bundle_id = e.get('APPLE_BUNDLE_ID', '')
        self.environment = e.get('APPLE_ENVIRONMENT', 'production').lower()
        if self.environment not in {'production','sandbox'}:
            raise ValueError('APPLE_ENVIRONMENT must be production or sandbox')
        self.products = {k:v for k,v in {'tbohk.pro':e.get('APPLE_PRODUCT_PRO','tbohk.pro'),'tbohk.unlimited':e.get('APPLE_PRODUCT_UNLIMITED','tbohk.unlimited')}.items()}
        self.product_map = {v:k.split('.')[-1] for k,v in self.products.items()}
        self.transport = transport or httpx.request

    def configured(self) -> bool:
        return all((self.issuer_id,self.key_id,self.private_key_pem,self.root_pem,self.bundle_id))

    def _jwt(self) -> str:
        if not self.configured(): raise PurchaseVerificationError('Apple store verification is not configured')
        now = int(time.time())
        header = {'alg':'ES256','kid':self.key_id,'typ':'JWT'}
        payload = {'iss':self.issuer_id,'iat':now,'exp':now+900,'aud':'appstoreconnect-v1','bid':self.bundle_id}
        signing = _b64u(json.dumps(header,separators=(',',':')).encode())+'.'+_b64u(json.dumps(payload,separators=(',',':')).encode())
        key = serialization.load_pem_private_key(self.private_key_pem.encode(), password=None)
        sig = key.sign(signing.encode(), ec.ECDSA(hashes.SHA256()))
        # Convert DER ECDSA signature to raw R||S as required by JWS.
        r,s = decode_dss_signature(sig)
        return signing+'.'+_b64u(r.to_bytes(32,'big')+s.to_bytes(32,'big'))

    def _get_status(self, transaction_id: str) -> dict[str, Any]:
        base = 'https://api.storekit.apple.com' if self.environment != 'sandbox' else 'https://api.storekit-sandbox.apple.com'
        url = base + '/inApps/v1/subscriptions/' + quote(transaction_id, safe='')
        response = self.transport('GET', url, headers={'Authorization':'Bearer '+self._jwt(),'Accept':'application/json'}, timeout=15)
        if response.status_code != 200:
            raise PurchaseVerificationError(f'Apple App Store Server API rejected request ({response.status_code})')
        data = response.json()
        if not isinstance(data, dict): raise PurchaseVerificationError('Apple API returned invalid JSON')
        return data

    def verify(self, payload: dict[str, Any]) -> dict[str, Any]:
        jws = str(payload.get('signedTransactionInfo') or payload.get('signedPayload') or '').strip()
        if not jws: raise PurchaseVerificationError('Apple signed transaction is required')
        _, tx = verify_apple_jws(jws, self.root_pem)
        if self.bundle_id and tx.get('bundleId') != self.bundle_id: raise PurchaseVerificationError('Apple bundle identifier mismatch')
        if tx.get('environment') and str(tx.get('environment')).lower() != self.environment:
            raise PurchaseVerificationError('Apple transaction environment mismatch')
        transaction_id = str(tx.get('transactionId') or '').strip()
        original_id = str(tx.get('originalTransactionId') or '').strip()
        if not transaction_id or not original_id: raise PurchaseVerificationError('Apple transaction identifiers are missing')
        status_data = self._get_status(transaction_id)
        latest_tx = tx
        latest_renewal: dict[str, Any] = {}
        for group in status_data.get('data') or []:
            for item in group.get('lastTransactions') or []:
                try:
                    _, decoded = verify_apple_jws(item.get('signedTransactionInfo',''), self.root_pem)
                    if decoded.get('originalTransactionId') == original_id:
                        latest_tx = decoded
                        if item.get('signedRenewalInfo'):
                            _, latest_renewal = verify_apple_jws(item['signedRenewalInfo'], self.root_pem)
                except PurchaseVerificationError:
                    continue
        product_id = str(latest_tx.get('productId') or tx.get('productId') or '')
        plan = _plan_for_product(product_id, self.product_map)
        expires = _parse_iso_ms(latest_tx.get('expiresDate'))
        revoked = latest_tx.get('revocationDate') is not None
        now = datetime.now(timezone.utc)
        status = 'revoked' if revoked else ('expired' if expires and datetime.fromisoformat(expires) <= now else 'active')
        if latest_renewal.get('expirationIntent') and status == 'active':
            status = 'canceled'
        return {'purchase_id':original_id,'product_id':product_id,'plan':plan,'status':status,'transaction_id':str(latest_tx.get('transactionId',transaction_id)),'original_transaction_id':original_id,'current_period_end':expires,'cancel_at_period_end':latest_renewal.get('autoRenewStatus') == 0,'raw':{'provider':'apple','transaction':latest_tx,'renewal':latest_renewal,'environment':status_data.get('environment')}}


class GooglePlayVerifier:
    """Authoritative Google Play subscriptionsv2 verifier using a service account."""
    def __init__(self, env: dict[str, str] | None = None, transport: Callable[..., Any] | None = None):
        e = env or os.environ
        self.package = e.get('GOOGLE_PLAY_PACKAGE_NAME','')
        self.client_email = e.get('GOOGLE_SERVICE_ACCOUNT_EMAIL','')
        self.private_key_pem = e.get('GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM','')
        self.products = {e.get('GOOGLE_PRODUCT_PRO','tbohk.pro'):'pro',e.get('GOOGLE_PRODUCT_UNLIMITED','tbohk.unlimited'):'unlimited'}
        self.transport = transport or httpx.request
        self._access_token: tuple[str,float] | None = None

    def configured(self) -> bool:
        return all((self.package,self.client_email,self.private_key_pem))

    def _jwt_assertion(self) -> str:
        if not self.configured(): raise PurchaseVerificationError('Google Play verification is not configured')
        now=int(time.time()); header={'alg':'RS256','typ':'JWT'}; payload={'iss':self.client_email,'scope':'https://www.googleapis.com/auth/androidpublisher','aud':'https://oauth2.googleapis.com/token','iat':now,'exp':now+3600}
        signing=_b64u(json.dumps(header,separators=(',',':')).encode())+'.'+_b64u(json.dumps(payload,separators=(',',':')).encode())
        key=serialization.load_pem_private_key(self.private_key_pem.encode(),password=None)
        sig=key.sign(signing.encode(),padding.PKCS1v15(),hashes.SHA256())
        return signing+'.'+_b64u(sig)

    def _token(self) -> str:
        now=time.time()
        if self._access_token and self._access_token[1] > now+30: return self._access_token[0]
        response=self.transport('POST','https://oauth2.googleapis.com/token',data={'grant_type':'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion':self._jwt_assertion()},timeout=15)
        if response.status_code != 200: raise PurchaseVerificationError('Google OAuth token request failed')
        data=response.json(); token=str(data.get('access_token','')); expires=int(data.get('expires_in',3600))
        if not token: raise PurchaseVerificationError('Google OAuth token response missing access token')
        self._access_token=(token,now+expires); return token

    def _get_subscription(self, purchase_token: str) -> dict[str, Any]:
        url='https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'+quote(self.package,safe='')+'/purchases/subscriptionsv2/tokens/'+quote(purchase_token,safe='')
        response=self.transport('GET',url,headers={'Authorization':'Bearer '+self._token(),'Accept':'application/json'},timeout=15)
        if response.status_code != 200: raise PurchaseVerificationError(f'Google Play subscriptionsv2 rejected request ({response.status_code})')
        data=response.json()
        if not isinstance(data,dict): raise PurchaseVerificationError('Google Play API returned invalid JSON')
        return data

    def verify(self, payload: dict[str, Any]) -> dict[str, Any]:
        token=str(payload.get('purchaseToken') or payload.get('purchase_id') or '').strip()
        if not token: raise PurchaseVerificationError('Google purchase token is required')
        data=self._get_subscription(token)
        if str(data.get('packageName') or self.package) != self.package:
            raise PurchaseVerificationError('Google package identifier mismatch')
        items=data.get('lineItems') or []
        known=[i for i in items if str(i.get('productId') or '').strip() in self.products]
        item=known[-1] if known else (items[-1] if items else {})
        product_id=str(item.get('productId') or '').strip()
        plan=self.products.get(product_id)
        if plan not in {'pro','unlimited'}: raise PurchaseVerificationError('Google product is not configured')
        state=str(data.get('subscriptionState',''))
        mapping={'SUBSCRIPTION_STATE_ACTIVE':'active','SUBSCRIPTION_STATE_IN_GRACE_PERIOD':'grace_period','SUBSCRIPTION_STATE_ON_HOLD':'paused','SUBSCRIPTION_STATE_CANCELED':'canceled','SUBSCRIPTION_STATE_EXPIRED':'expired','SUBSCRIPTION_STATE_PENDING':'pending'}
        status=mapping.get(state)
        if status is None: raise PurchaseVerificationError('Google subscription state is unsupported')
        expiry=item.get('expiryTime')
        return {'purchase_id':token,'product_id':product_id,'plan':plan,'status':status,'transaction_id':item.get('latestSuccessfulOrderId') or data.get('latestOrderId'),'original_transaction_id':token,'current_period_end':_parse_iso_ms(expiry),'cancel_at_period_end':bool((item.get('autoRenewingPlan') or {}).get('autoRenewEnabled') is False),'raw':{'provider':'google','subscription':data}}

class GoogleRTDNVerifier:
    """Validates Pub/Sub push OIDC tokens and decodes Google Play RTDN messages."""
    def __init__(self, audience: str | None = None, transport: Callable[..., Any] | None = None):
        self.audience = audience or os.getenv('GOOGLE_RTDN_AUDIENCE','')
        if not self.audience:
            self.require_audience = True
        else:
            self.require_audience = True
        self.transport = transport or httpx.request
        self._certs: tuple[float, dict[str, Any]] | None = None

    def _google_certs(self) -> dict[str, Any]:
        now=time.time()
        if self._certs and self._certs[0] > now: return self._certs[1]
        r=self.transport('GET','https://www.googleapis.com/oauth2/v1/certs',timeout=10)
        if r.status_code != 200: raise PurchaseVerificationError('Google OIDC certificate retrieval failed')
        data=r.json()
        if not isinstance(data,dict): raise PurchaseVerificationError('Google OIDC certificate response invalid')
        self._certs=(now+300,data); return data

    def verify_oidc(self, authorization: str | None) -> dict[str, Any]:
        if not authorization or not authorization.startswith('Bearer '): raise PurchaseVerificationError('Google RTDN authorization is required')
        header,payload,signature=decode_jws(authorization[7:].strip())
        if header.get('alg') != 'RS256' or not header.get('kid'): raise PurchaseVerificationError('invalid Google OIDC token')
        cert_pem=self._google_certs().get(header['kid'])
        if not cert_pem: raise PurchaseVerificationError('unknown Google OIDC signing key')
        try:
            cert=x509.load_pem_x509_certificate(cert_pem.encode())
            cert.public_key().verify(signature,(authorization[7:].strip().split('.')[0]+'.'+authorization[7:].strip().split('.')[1]).encode(),padding.PKCS1v15(),hashes.SHA256())
        except Exception as exc: raise PurchaseVerificationError('Google OIDC signature validation failed') from exc
        iss=payload.get('iss'); aud=payload.get('aud'); exp=payload.get('exp',0); iat=payload.get('iat',0); nbf=payload.get('nbf',0)
        if iss not in {'https://accounts.google.com','accounts.google.com'}: raise PurchaseVerificationError('Google OIDC issuer mismatch')
        if not self.audience: raise PurchaseVerificationError('Google RTDN audience is not configured')
        if aud != self.audience: raise PurchaseVerificationError('Google OIDC audience mismatch')
        now=time.time()
        if not isinstance(exp,(int,float)) or exp < now: raise PurchaseVerificationError('Google OIDC token expired')
        if iat and (not isinstance(iat,(int,float)) or iat > now+60): raise PurchaseVerificationError('Google OIDC token issued-at is invalid')
        if nbf and (not isinstance(nbf,(int,float)) or nbf > now+60): raise PurchaseVerificationError('Google OIDC token is not yet valid')
        return payload

    @staticmethod
    def decode_pubsub(body: dict[str, Any]) -> dict[str, Any]:
        try:
            data=_b64ud(str(body['message']['data']))
            decoded=json.loads(data)
        except Exception as exc:
            raise PurchaseVerificationError('invalid Google RTDN Pub/Sub message') from exc
        if not isinstance(decoded,dict): raise PurchaseVerificationError('invalid Google RTDN payload')
        return decoded
