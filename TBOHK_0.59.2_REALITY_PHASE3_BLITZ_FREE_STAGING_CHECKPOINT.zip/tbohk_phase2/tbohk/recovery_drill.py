from __future__ import annotations
from dataclasses import dataclass, asdict
import sqlite3, tempfile, shutil
from pathlib import Path
from .selfcare import SelfCareEngine
from .independent_validation import IndependentSystemValidator

@dataclass(frozen=True)
class DrillResult:
    name: str
    detected: bool
    independent_detected: bool
    destructive: bool
    detail: str

class RecoveryDrill:
    """Non-production drill harness: copy a database, damage the copy, and prove detection."""
    def __init__(self, graph): self.g=graph
    def run(self) -> list[DrillResult]:
        source=self.g.db.execute("PRAGMA database_list").fetchone()[2]
        if not source or source == ':memory:':
            return [DrillResult('in_memory_not_drillable',False,False,False,'Use a file-backed database for corruption drills.')]
        source_path=Path(source); work=Path(tempfile.mkdtemp(prefix='tbohk-drill-')); copy=work/'drill.sqlite'
        try:
            self.g.db.commit()
            dst=sqlite3.connect(copy)
            try:
                self.g.db.backup(dst)
            finally:
                dst.close()
            damaged=[]
            db=sqlite3.connect(copy); db.row_factory=sqlite3.Row
            row=db.execute("SELECT id FROM events ORDER BY rowid LIMIT 1").fetchone()
            if row:
                db.execute("DELETE FROM events WHERE id=?",(row['id'],)); db.commit(); damaged.append('event_deleted')
            db.close()
            from .core import TBOHK
            dg=TBOHK(str(copy)); audit=dg.audit(); independent=IndependentSystemValidator(dg).run()
            from .gates_21_30 import G21LedgerAuditor
            ledger=G21LedgerAuditor(dg).audit()
            detected=(not audit.get('ok',False)) or (not ledger.passed); independent_detected=(not independent.passed) or (not ledger.passed)
            return [DrillResult('event_deletion',detected,independent_detected,True,f"core={audit}; ledger={ledger.passed}; independent_findings={len(independent.findings)}")]
        finally:
            shutil.rmtree(work,ignore_errors=True)
    @staticmethod
    def as_dict(results): return [asdict(x) for x in results]
