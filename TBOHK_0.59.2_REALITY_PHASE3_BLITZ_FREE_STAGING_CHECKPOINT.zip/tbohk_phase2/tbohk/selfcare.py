from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import sqlite3
from pathlib import Path
from typing import Any

from .gates_21_30 import run_all

@dataclass(frozen=True)
class CareCheck:
    code: str
    passed: bool
    severity: str
    detail: str

@dataclass(frozen=True)
class SelfCareReport:
    passed: bool
    generated_at: str
    checks: tuple[CareCheck, ...]

class SelfCareEngine:
    """Non-destructive operational self-care for a TBOHK graph.

    Self-care observes, validates, snapshots and reports. It never silently
    rewrites knowledge, repairs provenance, promotes claims, or grants authority.
    Any repair remains an explicit, separately audited operation.
    """
    def __init__(self, graph):
        self.g = graph

    def inspect(self) -> SelfCareReport:
        checks: list[CareCheck] = []
        checks.append(self._sqlite_integrity())
        checks.append(self._foreign_keys())
        checks.append(self._db_configuration())
        try:
            core = self.g.audit()
            checks.append(CareCheck("core_audit", bool(core.get("ok")), "critical", json.dumps(core, sort_keys=True, default=str)))
        except Exception as exc:
            checks.append(CareCheck("core_audit_exception", False, "critical", f"{type(exc).__name__}: {exc}"))
        try:
            reports = run_all(self.g)
            for report in reports:
                blocking = [f for f in report.findings if f.blocks_release]
                checks.append(CareCheck(
                    report.gate,
                    report.passed,
                    "critical" if blocking else ("high" if report.findings else "info"),
                    "clean" if not report.findings else "; ".join(f"{f.code}: {f.evidence}" for f in report.findings),
                ))
        except Exception as exc:
            checks.append(CareCheck("assurance_execution", False, "critical", f"{type(exc).__name__}: {exc}"))
        checks.append(self._migration_integrity())
        checks.append(self._transition_integrity())
        checks.append(self._latest_checkpoint())
        checks.append(self._disk_capacity())
        return SelfCareReport(
            passed=all(c.passed or c.severity not in {"critical", "high"} for c in checks),
            generated_at=datetime.now(timezone.utc).isoformat(),
            checks=tuple(checks),
        )

    def _sqlite_integrity(self) -> CareCheck:
        try:
            rows = self.g.db.execute("PRAGMA integrity_check").fetchall()
            vals = [r[0] for r in rows]
            ok = vals == ["ok"]
            return CareCheck("sqlite_integrity", ok, "critical", "ok" if ok else repr(vals))
        except Exception as exc:
            return CareCheck("sqlite_integrity", False, "critical", f"{type(exc).__name__}: {exc}")

    def _foreign_keys(self) -> CareCheck:
        try:
            rows = self.g.db.execute("PRAGMA foreign_key_check").fetchall()
            return CareCheck("foreign_key_check", not rows, "critical", "clean" if not rows else repr([tuple(r) for r in rows[:20]]))
        except Exception as exc:
            return CareCheck("foreign_key_check", False, "critical", f"{type(exc).__name__}: {exc}")

    def _db_configuration(self) -> CareCheck:
        try:
            fk = self.g.db.execute("PRAGMA foreign_keys").fetchone()[0]
            busy = self.g.db.execute("PRAGMA busy_timeout").fetchone()[0]
            synchronous = self.g.db.execute("PRAGMA synchronous").fetchone()[0]
            journal = self.g.db.execute("PRAGMA journal_mode").fetchone()[0]
            details = f"foreign_keys={fk}, busy_timeout={busy}, synchronous={synchronous}, journal_mode={journal}"
            ok = bool(fk) and int(busy) >= 5000 and int(synchronous) >= 2
            db_path = self.g.db.execute("PRAGMA database_list").fetchone()[2]
            if db_path not in {":memory:", ""}:
                ok = ok and str(journal).lower() == "wal"
            return CareCheck("db_configuration", ok, "high", details)
        except Exception as exc:
            return CareCheck("db_configuration", False, "high", f"{type(exc).__name__}: {exc}")


    def _migration_integrity(self) -> CareCheck:
        try:
            report = self.g.migrations.verify()
            return CareCheck("schema_migrations", bool(report["ok"]), "critical", json.dumps(report, sort_keys=True))
        except Exception as exc:
            return CareCheck("schema_migrations", False, "critical", f"{type(exc).__name__}: {exc}")

    def _transition_integrity(self) -> CareCheck:
        try:
            from .state_machine import StateTransitionEngine
            findings = StateTransitionEngine(self.g).audit()
            return CareCheck("state_transitions", not findings, "critical", "clean" if not findings else json.dumps(findings, sort_keys=True))
        except Exception as exc:
            return CareCheck("state_transitions", False, "critical", f"{type(exc).__name__}: {exc}")

    def _latest_checkpoint(self) -> CareCheck:
        try:
            row = self.g.db.execute("SELECT id FROM nodes WHERE kind='Checkpoint' ORDER BY rowid DESC LIMIT 1").fetchone()
            if not row:
                return CareCheck("latest_checkpoint", True, "info", "no checkpoint present")
            from .checkpoints import CheckpointManager
            ok = CheckpointManager(self.g).verify(row[0])
            return CareCheck("latest_checkpoint", ok, "critical", "verified" if ok else f"checkpoint {row[0]} failed verification")
        except Exception as exc:
            return CareCheck("latest_checkpoint", False, "critical", f"{type(exc).__name__}: {exc}")

    def _disk_capacity(self) -> CareCheck:
        try:
            path = self.g.db.execute("PRAGMA database_list").fetchone()[2]
            if not path or path == ":memory:":
                return CareCheck("disk_capacity", True, "info", "in-memory database")
            free = shutil.disk_usage(path).free
            # Do not make a platform-specific minimum a release invariant; this is an operational warning.
            ok = free >= 100 * 1024 * 1024
            return CareCheck("disk_capacity", ok, "high", f"free_bytes={free}")
        except Exception as exc:
            return CareCheck("disk_capacity", False, "high", f"{type(exc).__name__}: {exc}")

    def backup(self, destination: str | os.PathLike[str]) -> dict[str, Any]:
        """Create and independently integrity-check a SQLite backup."""
        target = Path(destination).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target == Path(self.g.db.execute("PRAGMA database_list").fetchone()[2]).expanduser().resolve():
            raise ValueError("backup destination must differ from live database")
        with self.g._write_lock:
            self.g.db.commit()
            dst = sqlite3.connect(str(target))
            try:
                self.g.db.backup(dst)
                dst.execute("PRAGMA foreign_keys=ON")
                integrity = [r[0] for r in dst.execute("PRAGMA integrity_check").fetchall()]
                fk = [tuple(r) for r in dst.execute("PRAGMA foreign_key_check").fetchall()]
                dst.commit()
            finally:
                dst.close()
        if integrity != ["ok"] or fk:
            raise RuntimeError(f"backup verification failed: integrity={integrity!r}, foreign_keys={fk!r}")
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        return {"path": str(target), "sha256": digest, "integrity": "ok", "foreign_key_check": "clean"}

    @staticmethod
    def as_dict(report: SelfCareReport) -> dict[str, Any]:
        return asdict(report)
