from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass(frozen=True)
class LoopResult:
    run_id: str
    cycles: int
    actions: tuple[str, ...]
    stopped_reason: str

class AutonomousLoop:
    """Bounded orchestration. It may propose work, but cannot grant authority or self-authorize changes."""
    def __init__(self, graph, *, audit=None, planner=None, learner=None):
        self.g = graph; self.audit_engine = audit; self.planner = planner; self.learner = learner

    def start(self, objective, *, max_cycles=1, authority_grant_id=None, researcher=None,
              planner_steps=None, improve_target=None):
        if max_cycles < 1 or max_cycles > 100: raise ValueError('max_cycles must be 1..100')
        run = self.g.add_node('AutonomousRun', objective, 'proposed', {
            'objective': objective, 'max_cycles': max_cycles,
            'authority_grant_id': authority_grant_id,
            'started_at': datetime.now(timezone.utc).isoformat(),
            'state': 'running'})
        actions=[]; stopped='cycle_limit'
        for cycle in range(max_cycles):
            obs = self.g.add_node('LoopCycle', f'{objective} cycle {cycle+1}', 'supported', {
                'run_id':run.id,'cycle':cycle+1,'authority_grant_id':authority_grant_id})
            self.g.link(run.id,'contains',obs.id)
            if researcher:
                result = researcher(cycle+1)
                self.g.add_node('ResearchActivity', f'Research cycle {cycle+1}', 'supported', {'run_id':run.id,'result':result})
                actions.append('research')
            if self.audit_engine:
                findings = self.audit_engine.audit()
                self.g.add_node('LoopAudit', f'Audit cycle {cycle+1}', 'supported', {'run_id':run.id,'finding_count':len(findings)})
                actions.append('audit')
            if planner_steps:
                if not self.planner: raise ValueError('planner required')
                p=self.planner.create(f'{objective} plan cycle {cycle+1}', planner_steps, goal=objective)
                self.g.link(run.id,'creates_branch',p.plan_id); actions.append('plan')
            if improve_target and self.learner:
                # Improvement is only proposed; authorization remains outside the loop.
                prop=self.g.add_node('ChangeProposal', f'Improvement for {improve_target}', 'proposed', {'change_type':'improvement','target_ids':[improve_target],'evaluation_ids':[],'expected_effect':'unspecified','proposer':'autonomous-loop'})
                self.g.link(run.id,'proposes',prop.id); actions.append('improve')
        self.g.set_status(run.id,'supported','bounded autonomous loop completed')
        self.g._event('autonomous.run.completed',run.id,{'cycles':max_cycles,'actions':actions,'stopped_reason':stopped})
        return LoopResult(run.id,max_cycles,tuple(actions),stopped)
