from __future__ import annotations
from dataclasses import dataclass
import hashlib, json

@dataclass(frozen=True)
class IntegrityFinding:
    code: str
    severity: str
    detail: str

@dataclass(frozen=True)
class IntegrityReport:
    passed: bool
    findings: tuple[IntegrityFinding, ...]

class IntegrityAuditor:
    """G13 tamper-evidence audit for checkpointed graph state.

    A checkpoint is valid only when its self-hash and the graph hashes recorded
    in its manifest still match the current graph. This prevents a manifest
    from remaining "valid" after the underlying graph has been modified.
    """
    def __init__(self, graph):
        self.g = graph

    def _graph_hashes(self):
        rows = self.g.db.execute(
            'SELECT id,kind,status,content,metadata FROM nodes '
            'WHERE kind != "Checkpoint" ORDER BY id'
        ).fetchall()
        edges = self.g.db.execute(
            'SELECT source_id,relation,target_id FROM edges '
            'WHERE source_id NOT IN (SELECT id FROM nodes WHERE kind="Checkpoint") '
            'AND target_id NOT IN (SELECT id FROM nodes WHERE kind="Checkpoint") '
            'ORDER BY source_id,relation,target_id'
        ).fetchall()
        nh = hashlib.sha256(json.dumps([dict(r) for r in rows], sort_keys=True).encode()).hexdigest()
        eh = hashlib.sha256(json.dumps([dict(r) for r in edges], sort_keys=True).encode()).hexdigest()
        return nh, eh

    def audit_checkpoint(self, checkpoint_id: str) -> IntegrityReport:
        findings: list[IntegrityFinding] = []
        row = self.g.db.execute(
            'SELECT kind, metadata FROM nodes WHERE id=?', (checkpoint_id,)
        ).fetchone()
        if not row or row['kind'] != 'Checkpoint':
            return IntegrityReport(False, (IntegrityFinding('checkpoint_missing', 'critical', checkpoint_id),))
        try:
            metadata = json.loads(row['metadata'])
            manifest = metadata['manifest']
            stored_digest = metadata['manifest_sha256']
        except (TypeError, KeyError, json.JSONDecodeError):
            return IntegrityReport(False, (IntegrityFinding('malformed_checkpoint_manifest', 'critical', checkpoint_id),))

        actual_digest = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
        if actual_digest != stored_digest:
            findings.append(IntegrityFinding('manifest_hash_mismatch', 'critical', checkpoint_id))

        node_hash, edge_hash = self._graph_hashes()
        if manifest.get('node_hash') != node_hash:
            findings.append(IntegrityFinding('node_hash_mismatch', 'critical', checkpoint_id))
        if manifest.get('edge_hash') != edge_hash:
            findings.append(IntegrityFinding('edge_hash_mismatch', 'critical', checkpoint_id))

        return IntegrityReport(not findings, tuple(findings))
