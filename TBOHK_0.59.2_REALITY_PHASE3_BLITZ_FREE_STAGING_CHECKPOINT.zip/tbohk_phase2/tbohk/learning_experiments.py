from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any
import hashlib
import json
import math
import re


_TOKEN = re.compile(r"[a-z0-9_]+")


@dataclass(frozen=True)
class ExperimentReport:
    experiment_id: str
    dataset_manifest_sha256: str
    training_count: int
    validation_count: int
    baseline_accuracy: float | None
    candidate_accuracy: float | None
    candidate_artifact_sha256: str | None
    status: str
    reasons: tuple[str, ...]


class LearningExperimentEngine:
    """Isolated, deterministic adapter experiment runner.

    This is intentionally a small trainable text adapter, not autonomous model
    replacement. It consumes only a recorded LearningDataset, emits a
    content-addressed artifact, and records evaluation evidence separately from
    production authority.
    """

    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _tokens(text: str) -> list[str]:
        return _TOKEN.findall(text.lower())

    @staticmethod
    def _digest(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()

    @classmethod
    def _features(cls, task: str) -> dict[str, float]:
        tokens = cls._tokens(task)
        features: dict[str, float] = {"__bias__": 1.0}
        for token in tokens:
            features[token] = features.get(token, 0.0) + 1.0
        return features

    @staticmethod
    def _label(example: dict[str, Any]) -> int | None:
        value = example.get("success")
        return 1 if value is True else 0 if value is False else None

    def _dataset(self, dataset_id: str) -> tuple[dict[str, Any], Any]:
        node = self.g.get(dataset_id)
        if not node or node.kind != "LearningDataset":
            raise ValueError("invalid learning dataset")
        return node.metadata, node

    def _baseline(self, validation: list[dict[str, Any]]) -> tuple[float | None, int | None]:
        labels = [self._label(x) for x in validation]
        labels = [x for x in labels if x is not None]
        if not labels:
            return None, None
        zeros = labels.count(0)
        ones = labels.count(1)
        majority = 1 if ones >= zeros else 0
        return sum(y == majority for y in labels) / len(labels), majority

    def run(self, dataset_id: str, *, epochs: int = 8, learning_rate: float = 0.2) -> ExperimentReport:
        if epochs < 1 or epochs > 100:
            raise ValueError("epochs out of range")
        if not 0 < learning_rate <= 2:
            raise ValueError("learning_rate out of range")
        data, dataset_node = self._dataset(dataset_id)
        training = list(data.get("training", []))
        validation = list(data.get("validation", []))
        if not training or not validation:
            raise ValueError("dataset must contain training and validation examples")
        train = [(self._features(x["task"]), self._label(x)) for x in training]
        valid = [(self._features(x["task"]), self._label(x)) for x in validation]
        train = [(x, y) for x, y in train if y is not None]
        valid = [(x, y) for x, y in valid if y is not None]
        if not train or not valid:
            raise ValueError("dataset requires labeled training and validation examples")
        labels = {y for _, y in train}
        if len(labels) < 2:
            raise ValueError("training set requires both success and failure labels")

        weights: dict[str, float] = {}
        for _ in range(epochs):
            for features, label in train:
                score = sum(weights.get(k, 0.0) * v for k, v in features.items())
                probability = 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, score))))
                error = label - probability
                for key, value in features.items():
                    weights[key] = weights.get(key, 0.0) + learning_rate * error * value
        artifact = {
            "format": "tbohk-text-adapter-v1",
            "dataset_manifest_sha256": data.get("manifest_sha256"),
            "epochs": epochs,
            "learning_rate": learning_rate,
            "weights": dict(sorted((k, round(v, 12)) for k, v in weights.items())),
        }
        artifact_sha = self._digest(artifact)

        def predict(features: dict[str, float]) -> int:
            score = sum(weights.get(k, 0.0) * v for k, v in features.items())
            return 1 if score >= 0 else 0

        candidate_accuracy = sum(predict(x) == y for x, y in valid) / len(valid)
        baseline_accuracy, _ = self._baseline(validation)
        reasons: list[str] = []
        if baseline_accuracy is None:
            reasons.append("baseline could not be evaluated")
        if baseline_accuracy is not None and candidate_accuracy < baseline_accuracy:
            reasons.append("candidate accuracy regresses against baseline")
        status = "candidate_ready" if not reasons else "rejected"
        experiment_payload = {
            "dataset_id": dataset_id,
            "dataset_manifest_sha256": data.get("manifest_sha256"),
            "training_count": len(train),
            "validation_count": len(valid),
            "baseline_accuracy": baseline_accuracy,
            "candidate_accuracy": candidate_accuracy,
            "candidate_artifact_sha256": artifact_sha,
            "epochs": epochs,
            "learning_rate": learning_rate,
            "status": status,
            "reasons": reasons,
        }
        exp = self.g.add_node("LearningExperiment", "isolated text adapter experiment", "proposed", experiment_payload)
        artifact_node = self.g.add_node("LearningArtifact", "isolated text adapter artifact", "proposed", {
            **artifact, "experiment_id": exp.id, "artifact_sha256": artifact_sha,
        })
        self.g.link(exp.id, "produces", artifact_node.id)
        evaluation = self.g.add_node("Evaluation", "learning adapter validation", "supported", {
            "suite_manifest_sha256": data.get("manifest_sha256"),
            "metrics": {"score": candidate_accuracy, "accuracy": candidate_accuracy},
            "passed": not reasons,
            "experiment_id": exp.id,
            "artifact_sha256": artifact_sha,
        })
        self.g.link(exp.id, "evaluated_by", evaluation.id)
        return ExperimentReport(exp.id, str(data.get("manifest_sha256")), len(train), len(valid), baseline_accuracy, candidate_accuracy, artifact_sha, status, tuple(reasons))

    def report(self, experiment_id: str) -> dict[str, Any]:
        node = self.g.get(experiment_id)
        if not node or node.kind != "LearningExperiment":
            raise ValueError("invalid learning experiment")
        return {"experiment_id": node.id, **node.metadata, "status": node.status}
