from __future__ import annotations
from dataclasses import dataclass
from .core import TBOHK
from .independence import IndependenceAnalyzer

@dataclass(frozen=True)
class VerificationPolicy:
    policy_id: str
    min_independent_origins: int = 2
    require_locator: bool = True
    allow_automatic: bool = True

class EpistemicEngine:
    def __init__(self, graph: TBOHK, policies=None):
        self.g = graph
        self.policies = policies or {"default": VerificationPolicy("default")}
        self.independence = IndependenceAnalyzer(graph)

    def propose_claim(self, content: str, evidence_ids: list[str], *, subject=None, predicate=None,
                      object_value=None, qualifiers=None, scope=None, time=None, units=None,
                      modality="assertion", uncertainty=None, policy_id="default"):
        if policy_id not in self.policies: raise KeyError(policy_id)
        policy = self.policies[policy_id]
        if modality not in {"assertion", "hypothesis", "conditional", "negation", "question"}:
            raise ValueError(f"unsupported modality: {modality}")
        if uncertainty is not None:
            if not isinstance(uncertainty, dict):
                raise ValueError("uncertainty must be a structured mapping")
            allowed_uncertainty = {"type", "value", "lower", "upper", "unit", "method", "confidence_level", "basis"}
            unknown_keys = set(uncertainty) - allowed_uncertainty
            if unknown_keys:
                raise ValueError(f"unsupported uncertainty fields: {sorted(unknown_keys)}")
            if "confidence_level" in uncertainty and not 0 <= float(uncertainty["confidence_level"]) <= 1:
                raise ValueError("confidence_level must be between 0 and 1")
            if "lower" in uncertainty and "upper" in uncertainty and uncertainty["lower"] > uncertainty["upper"]:
                raise ValueError("uncertainty lower bound exceeds upper bound")
        structured = {
            "subject": subject, "predicate": predicate, "object": object_value,
            "qualifiers": qualifiers or {}, "scope": scope, "time": time, "units": units,
            "modality": modality, "uncertainty": uncertainty,
        }
        claim = self.g.add_node("Claim", content, "proposed", {
            "evidence_count": len(evidence_ids), "structured": structured, "verification_policy": policy_id,
            "verification_min_independent_origins": policy.min_independent_origins,
            "verification_require_locator": policy.require_locator,
            "verification_allow_automatic": policy.allow_automatic,
        })
        for eid in evidence_ids:
            ev = self.g.get(eid)
            if not ev or ev.kind != "Evidence": raise ValueError(f"not evidence: {eid}")
            self.g.link(eid, "evidence_for", claim.id)
        return claim

    def _evidence_origins(self, claim_id):
        """Compatibility helper: return independent lineage groups as origin identifiers."""
        analysis = self.independence.analyze_claim(claim_id)
        return set(group[0] for group in analysis.independent_groups if group), list(self.g._supporting_evidence(claim_id))

    def verify_claim(self, claim_id: str, reviewer="system", policy_id=None):
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim": raise KeyError(claim_id)
        selected = policy_id or claim.metadata.get("verification_policy", "default")
        policy = self.policies.get(selected)
        if not policy: raise KeyError(selected)
        if not policy.allow_automatic: raise PermissionError("selected policy forbids automatic verification")
        analysis = self.independence.analyze_claim(claim_id)
        evidence = list(self.g._supporting_evidence(claim_id))
        if not evidence: raise ValueError("claim has no evidence")
        if policy.require_locator:
            missing = [e.id for e in evidence if not e.metadata.get("locator")]
            if missing: raise ValueError(f"evidence lacks locator: {missing}")
        if analysis.independent_count < policy.min_independent_origins:
            raise ValueError(f"independent origin support required: {analysis.independent_count} < {policy.min_independent_origins}")
        verification = self.g.add_node("Verification", f"Verification of {claim_id}", "supported", {
            "claim_id": claim_id, "reviewer": reviewer, "policy_id": policy.policy_id,
            "independent_origins": [list(g) for g in analysis.independent_groups],
            "independent_group_count": analysis.independent_count,
            "shared_dependency_reasons": list(analysis.reasons),
            "evidence_ids": [e.id for e in evidence],
        })
        self.g.link(verification.id, "evaluates", claim.id)
        self.g.set_status(claim_id, "verified", f"{reviewer}: policy={policy.policy_id}; independent_groups={analysis.independent_count}")
        self.g.link(verification.id, "verified_by", claim.id)
        return self.g.get(claim_id)

    def contradict(self, claim_a: str, claim_b: str, reason=""):
        a, b = self.g.get(claim_a), self.g.get(claim_b)
        if not a or not b or a.kind != "Claim" or b.kind != "Claim": raise ValueError("contradiction requires two claims")
        if claim_a == claim_b: raise ValueError("a claim cannot contradict itself")
        conflict = self.g.add_node("ConflictSet", f"Conflict between {claim_a} and {claim_b}", "proposed", {
            "reason": reason, "resolution": None
        })
        self.g.link(conflict.id, "contains", a.id); self.g.link(conflict.id, "contains", b.id)
        self.g.link(claim_a, "contradicts", claim_b)
        self.g._event("contradiction.recorded", conflict.id, {"claims": [claim_a, claim_b], "reason": reason})
        return conflict

    def resolve_conflict(self, conflict_id: str, disposition: str, *, resolver="system", claim_id=None, rationale="", scope=None):
        """Record an explicit conflict resolution without silently changing claim truth status."""
        allowed = {"accept_claim", "reject_claim", "defer", "scope_split", "supersede"}
        if disposition not in allowed:
            raise ValueError(f"unsupported conflict disposition: {disposition}")
        conflict = self.g.get(conflict_id)
        if not conflict or conflict.kind != "ConflictSet":
            raise KeyError(conflict_id)
        members = {e["target_id"] for e in self.g.edges(conflict_id, direction="out", relation="contains")}
        if len(members) < 2:
            raise ValueError("conflict set requires at least two claims")
        if disposition in {"accept_claim", "reject_claim", "supersede"} and claim_id not in members:
            raise ValueError("claim_id must be a member of the conflict set")
        if disposition == "scope_split" and not scope:
            raise ValueError("scope_split requires scope")
        resolution = self.g.add_node("ConflictResolution", f"{disposition} for {conflict_id}", "resolved" if disposition != "defer" else "proposed", {
            "conflict_id": conflict_id, "disposition": disposition, "resolver": resolver,
            "claim_id": claim_id, "rationale": rationale, "scope": scope,
        })
        self.g.link(resolution.id, "resolves", conflict_id)
        if claim_id:
            self.g.link(resolution.id, "evaluates", claim_id)
        if disposition != "defer":
            self.g.set_status(conflict_id, "resolved", f"{resolver}: {disposition}")
        return resolution

    def promote_knowledge(self, content: str, verified_claim_ids: list[str], *, epistemic_type="assertion", absence_scope=None):
        if epistemic_type not in {"assertion", "negation", "absence_of_evidence", "unknown"}:
            raise ValueError(f"unsupported epistemic_type: {epistemic_type}")
        if epistemic_type == "absence_of_evidence":
            if not absence_scope:
                raise ValueError("absence_of_evidence requires an explicit absence_scope")
            if verified_claim_ids:
                raise ValueError("absence_of_evidence must not masquerade as verified positive support")
            return self.g.add_node("Knowledge", content, "supported", {
                "claim_count": 0, "epistemic_type": epistemic_type, "absence_scope": absence_scope,
            })
        if not verified_claim_ids: raise ValueError("knowledge requires verified claims")
        for cid in verified_claim_ids:
            c = self.g.get(cid)
            if not c or c.kind != "Claim" or c.status != "verified": raise ValueError(f"claim not verified: {cid}")
        k = self.g.add_node("Knowledge", content, "verified", {
            "claim_count": len(verified_claim_ids), "epistemic_type": epistemic_type,
        })
        for cid in verified_claim_ids: self.g.link(cid, "based_on", k.id)
        return k
