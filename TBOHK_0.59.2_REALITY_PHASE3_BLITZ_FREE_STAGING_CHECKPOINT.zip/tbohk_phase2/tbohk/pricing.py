from __future__ import annotations

PLANS = (
    {
        "id": "free",
        "name": "Free",
        "price_monthly": 0,
        "asks_monthly": 25,
        "description": "Start turning questions into inspectable knowledge with the core TBOHK workspace.",
        "features": ("25 asks/month", "Core knowledge workspace", "Core audit trail"),
        "cta": "Start free",
        "available": True,
    },
    {
        "id": "pro",
        "name": "Pro",
        "price_monthly": 10,
        "asks_monthly": 250,
        "description": "For people who use TBOHK regularly as a research and decision workspace.",
        "features": ("250 asks/month", "Full knowledge workspace", "API access", "Verified backups"),
        "cta": "Choose Pro",
        "available": True,
    },
    {
        "id": "unlimited",
        "name": "Unlimited",
        "price_monthly": 20,
        "asks_monthly": 1000,
        "description": "The highest-cap plan for intensive TBOHK use, with up to 1,000 asks each month.",
        "features": ("1,000 asks/month", "Full knowledge workspace", "API access", "Verified backups", "Highest monthly ask cap"),
        "cta": "Choose Unlimited",
        "available": True,
    },
)


def catalog() -> dict:
    return {"currency": "USD", "billing": "monthly", "plans": [dict(p, features=list(p["features"])) for p in PLANS]}
