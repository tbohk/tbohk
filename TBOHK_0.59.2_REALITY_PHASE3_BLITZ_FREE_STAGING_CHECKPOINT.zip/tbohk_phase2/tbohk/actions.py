from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone
import uuid

@dataclass(frozen=True)
class ActionResult:
    action_id:str
    state:str

class ActionLedger:
    """Records consequential actions separately from observation/reasoning."""
    def __init__(self,graph): self.g=graph
    def propose(self,principal,action,target,expected_effect,*,authority_grant_id=None,rollback=None,idempotency_key=None):
        if not str(principal).strip() or not str(action).strip() or not str(target).strip():
            raise ValueError('principal, action, and target are required')
        if not str(expected_effect).strip():
            raise ValueError('expected_effect is required')
        created_at=datetime.now(timezone.utc).isoformat()
        key=idempotency_key or uuid.uuid4().hex
        if not str(key).strip():
            raise ValueError('idempotency_key must not be empty')
        return self.g.add_node('Action',action,'proposed',{'principal':principal,'target':target,'expected_effect':expected_effect,'authority_grant_id':authority_grant_id,'rollback':rollback,'idempotency_key':key,'state':'proposed','created_at':created_at})
    def authorize(self,action_id,grant_id):
        a=self.g.get(action_id); grant=self.g.get(grant_id)
        if not a or a.kind!='Action': raise ValueError('invalid action')
        if a.status not in {'proposed','supported'}: raise PermissionError('action is not in an authorizable state')
        if not grant or grant.kind!='AuthorityGrant' or grant.status!='verified': raise PermissionError('verified authority grant required')
        caps=grant.metadata.get('capabilities',[])
        if 'execute_action' not in caps: raise PermissionError('grant lacks execute_action capability')
        exp=grant.metadata.get('expires_at')
        if exp:
            from datetime import datetime, timezone
            try:
                if datetime.fromisoformat(exp.replace('Z','+00:00')) <= datetime.now(timezone.utc): raise PermissionError('authority grant expired')
            except ValueError: raise PermissionError('authority grant expiry malformed')
        scope=grant.metadata.get('scope')
        if scope and scope not in ('*', a.metadata.get('target')) and a.metadata.get('target') not in (scope if isinstance(scope,list) else [scope]):
            raise PermissionError('authority grant scope does not cover target')
        self.g.link(action_id,'approved_by',grant_id); self.g.set_status(action_id,'supported','authorized'); return self.g.get(action_id)
    def record_execution(self,action_id,actual_effect,*,success,execution_id=None):
        a=self.g.get(action_id)
        if not a or a.kind!='Action': raise ValueError('invalid action')
        if a.status not in {'supported','verified'}: raise ValueError('action must be authorized before execution')
        if not str(actual_effect).strip(): raise ValueError('actual_effect is required')
        execution_id=execution_id or uuid.uuid4().hex
        if not str(execution_id).strip(): raise ValueError('execution_id must not be empty')
        execution=self.g.add_node('Execution',f'Execution {action_id}', 'supported', {
            'action_id':action_id,'execution_id':execution_id,'actual_effect':actual_effect,
            'success':bool(success),'executed_at':datetime.now(timezone.utc).isoformat(),
        })
        self.g.link(execution.id,'records',action_id)
        state='verified' if success else 'failed'
        self.g.set_status(action_id,state,'post-action observation')
        self.g._event('action.executed',action_id,{'actual_effect':actual_effect,'success':success,'execution_id':execution_id,'execution_node_id':execution.id})
        return ActionResult(action_id,state)
