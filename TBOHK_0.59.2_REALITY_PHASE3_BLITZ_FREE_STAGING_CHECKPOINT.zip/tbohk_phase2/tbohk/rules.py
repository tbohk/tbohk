from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from typing import Any

@dataclass(frozen=True)
class RuleResult:
    rule_id: str
    version_id: str

class RuleRegistry:
    def __init__(self, graph): self.g=graph
    def define(self,name,rule_type,spec,*,authority='system',version='1'):
        payload={'name':name,'rule_type':rule_type,'specification':spec,'authority':authority,'version':version}
        digest=self.g._hash(json.dumps(payload,sort_keys=True))
        node=self.g.add_node('Rule',name,'supported',{**payload,'rule_sha256':digest,'created_at':datetime.now(timezone.utc).isoformat()})
        ver=self.g.add_node('RuleVersion',f'{name}@{version}','supported',{'rule_id':node.id,**payload,'rule_sha256':digest})
        self.g.link(ver.id,'based_on',node.id)
        return RuleResult(node.id,ver.id)
    def supersede(self,rule_id,new_spec,*,version,authority='system'):
        rule=self.g.get(rule_id)
        if not rule or rule.kind!='Rule': raise ValueError('invalid rule')
        result=self.define(rule.content,rule.metadata['rule_type'],new_spec,authority=authority,version=version)
        self.g.link(result.version_id,'supersedes',rule_id)
        return result
    def verify_integrity(self,rule_version_id):
        n=self.g.get(rule_version_id)
        if not n or n.kind!='RuleVersion': return False
        m=n.metadata; p={k:m[k] for k in ('name','rule_type','specification','authority','version')}
        return self.g._hash(json.dumps(p,sort_keys=True))==m.get('rule_sha256')

@dataclass(frozen=True)
class ConstraintResult:
    constraint_id:str
    satisfied:bool
    violations:tuple[str,...]

class ConstraintEngine:
    def __init__(self,graph): self.g=graph
    def add(self,name,expression,*,severity='error',scope=None):
        return self.g.add_node('Constraint',name,'supported',{'expression':expression,'severity':severity,'scope':scope})
    def check(self,context:dict[str,Any],constraint_ids=None):
        ids=constraint_ids or [r['id'] for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='Constraint'")]
        out=[]
        for cid in ids:
            n=self.g.get(cid); expr=n.metadata.get('expression',''); ok=True; violation=''
            if expr.startswith('requires:'):
                key=expr.split(':',1)[1].strip(); ok=bool(context.get(key)); violation=f'missing required {key}'
            elif expr.startswith('forbids:'):
                key=expr.split(':',1)[1].strip(); ok=not bool(context.get(key)); violation=f'forbidden {key} present'
            out.append(ConstraintResult(cid,ok,() if ok else (violation,)))
        return tuple(out)
