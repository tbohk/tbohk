from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from typing import Any
from .core import TBOHK

SUPPORTED_RULES = {"identity", "modus_ponens", "conjunction"}

@dataclass(frozen=True)
class ReasoningResult:
    activity_id: str
    conclusion_id: str
    rule_id: str
    premise_ids: tuple[str, ...]
    method: str

    @property
    def derived_claim_id(self):
        return self.conclusion_id

class ReasoningEngine:
    """Conservative G4 reasoning: every inference is an auditable activity.

    Rules are explicit data. Derived claims remain proposed and are never
    automatically verified or promoted to Knowledge.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def _norm(value: Any):
        if isinstance(value, dict):
            return {str(k): ReasoningEngine._norm(v) for k, v in sorted(value.items())}
        if isinstance(value, list):
            return [ReasoningEngine._norm(v) for v in value]
        return value

    @classmethod
    def _matches(cls, actual, expected):
        if not isinstance(actual, dict) or not isinstance(expected, dict):
            return cls._norm(actual) == cls._norm(expected)
        return all(cls._norm(actual.get(k)) == cls._norm(v) for k, v in expected.items())

    def register_rule(self, rule_type: str, *, name=None, schema=None, authority="system"):
        if rule_type not in SUPPORTED_RULES:
            raise ValueError(f"unsupported reasoning rule: {rule_type}")
        payload = {"rule_type": rule_type, "name": name or rule_type,
                   "schema": schema or {}, "authority": authority}
        digest = self.g._hash(json.dumps(payload, sort_keys=True))
        payload["rule_sha256"] = digest
        return self.g.add_node("ReasoningRule", payload["name"], "supported", payload)

    def add_rule(self, name: str, rule_type: str, specification: dict[str, Any], *, authority="system"):
        if rule_type not in SUPPORTED_RULES:
            raise ValueError(f"unsupported reasoning rule: {rule_type}")
        spec = dict(specification)
        schema = {"specification": self._norm(spec)}
        return self.register_rule(rule_type, name=name, schema=schema, authority=authority)

    def _claim(self, cid):
        c = self.g.get(cid)
        if not c or c.kind != "Claim":
            raise ValueError(f"not a claim: {cid}")
        return c

    @staticmethod
    def _structured(claim):
        return claim.metadata.get("structured") or {}

    def _rule_spec(self, rule):
        return rule.metadata.get("schema", {}).get("specification", {})

    def _derive_structured(self, rule, premises):
        typ = rule.metadata.get("rule_type")
        spec = self._rule_spec(rule)
        semantics = [self._structured(p) for p in premises]
        if typ == "identity":
            if len(premises) != 1:
                raise ValueError("identity requires exactly one premise")
            expected = spec.get("consequent")
            if not isinstance(expected, dict) or not self._matches(semantics[0], expected):
                raise ValueError("identity premise does not match rule consequent")
            return dict(expected)
        if typ == "conjunction":
            if len(premises) < 2:
                raise ValueError("conjunction requires at least two premises")
            expected = spec.get("consequent")
            if isinstance(expected, dict):
                required = spec.get("required_semantics", [])
                if required and not all(any(self._matches(s, req) for s in semantics) for req in required):
                    raise ValueError("premises do not satisfy conjunction requirements")
                return dict(expected)
            return {"conjunction": [self._norm(s) for s in semantics]}
        if typ == "modus_ponens":
            if len(premises) != 2:
                raise ValueError("modus_ponens requires exactly two premises")
            explicit = spec.get("consequent")
            antecedent = spec.get("antecedent")
            if isinstance(explicit, dict) and isinstance(antecedent, dict):
                if not any(self._matches(s, antecedent) for s in semantics):
                    raise ValueError("antecedent is not among premises")
                return dict(explicit)
            conditional, antecedent_claim = premises
            implication = self._structured(conditional).get("implication")
            if not isinstance(implication, dict) or not implication.get("consequent"):
                raise ValueError("modus_ponens requires conditional premise with structured implication.consequent")
            if not self._matches(self._structured(antecedent_claim), implication.get("antecedent", {})):
                raise ValueError("modus_ponens antecedent does not match implication antecedent")
            return dict(implication["consequent"])
        raise ValueError(f"unsupported reasoning rule: {typ}")

    def _derive_content(self, rule_type, premises, structured, explicit_content=None):
        if explicit_content is not None:
            return explicit_content
        if rule_type == "conjunction":
            return " AND ".join(p.content for p in premises)
        if rule_type == "modus_ponens":
            return str(structured.get("object") or structured)
        if rule_type == "identity":
            return premises[0].content
        raise ValueError(rule_type)

    def derive(self, rule_id: str, premise_ids: list[str], *, content=None, structured=None,
               method=None, assessor="system", qualifiers=None):
        rule = self.g.get(rule_id)
        if not rule or rule.kind != "ReasoningRule":
            raise KeyError(rule_id)
        rule_type = rule.metadata.get("rule_type")
        if rule_type not in SUPPORTED_RULES:
            raise ValueError("unsupported rule")
        if not premise_ids:
            raise ValueError("reasoning requires at least one premise")
        if len(set(premise_ids)) != len(premise_ids):
            raise ValueError("duplicate premises")
        premises = [self._claim(pid) for pid in premise_ids]
        if rule_type == "modus_ponens" and len(premises) != 2:
            raise ValueError("modus_ponens requires exactly two premises")
        if rule_type == "conjunction" and len(premises) < 2:
            raise ValueError("conjunction requires at least two premises")

        expected = self._derive_structured(rule, premises)
        if structured is None:
            structured = expected
        elif not self._matches(structured, expected) or not self._matches(expected, structured):
            raise ValueError("derived claim semantics does not match the rule result")
        if qualifiers is not None:
            structured = dict(structured)
            structured["qualifiers"] = qualifiers
        unsupported = [p.id for p in premises if p.status not in {"supported", "verified"}]
        if unsupported:
            raise ValueError(f"reasoning premise must be supported or verified: {unsupported}")

        activity = self.g.add_node("ReasoningActivity", f"Derive reasoning result", "supported", {
            "rule_id": rule.id, "premise_ids": premise_ids, "method": method or rule_type,
            "assessor": assessor, "performed_at": datetime.now(timezone.utc).isoformat(),
            "conclusion_id": None,
        })
        for pid in premise_ids:
            self.g.link(pid, "premise_of", activity.id)
            self.g.link(activity.id, "uses", pid)
        self.g.link(activity.id, "applies_rule", rule.id)

        claim_content = self._derive_content(rule_type, premises, structured, content)
        conclusion = self.g.add_node("Claim", claim_content, "proposed", {
            "derived": True, "origin": "reasoning", "reasoning_rule_id": rule.id,
            "reasoning_method": method or rule_type, "premise_ids": premise_ids,
            "structured": structured, "verification_policy": "default",
            "reasoning_activity_id": activity.id,
        })
        self.g.update_metadata(activity.id, {"conclusion_id": conclusion.id}, reason="reasoning conclusion linked")
        self.g.link(activity.id, "derives", conclusion.id)
        self.g.link(activity.id, "produces", conclusion.id)
        self.g.link(conclusion.id, "generated_by", activity.id)
        for pid in premise_ids:
            self.g.link(conclusion.id, "derived_from", pid)
        self.g._event("reasoning.performed", activity.id, {
            "rule_id": rule.id, "premise_ids": premise_ids, "conclusion_id": conclusion.id,
        })
        return ReasoningResult(activity.id, conclusion.id, rule.id, tuple(premise_ids), method or rule_type)
