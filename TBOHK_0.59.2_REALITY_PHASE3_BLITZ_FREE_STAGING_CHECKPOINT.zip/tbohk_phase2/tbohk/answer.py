from __future__ import annotations
from dataclasses import asdict, dataclass
from urllib.parse import urlparse
from datetime import datetime, timezone
from .core import TBOHK

@dataclass(frozen=True)
class AnswerItem:
    claim_id: str
    text: str
    status: str
    evidence: tuple[dict, ...]
    confidence: str

class AnswerPresenter:
    """Build a user-facing answer without promoting unsupported claims to truth."""
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def _confidence(status: str, evidence_count: int, independent: int) -> str:
        if status == "verified" and independent >= 2:
            return "well-supported"
        if status == "verified" and evidence_count:
            return "supported"
        if evidence_count:
            return "evidence available — review required"
        return "unverified"

    def _evidence(self, claim_id: str):
        out=[]; seen=set()
        for e in self.g._supporting_evidence(claim_id):
            if e.id in seen: continue
            seen.add(e.id)
            out.append({
                "id": e.id,
                "title": e.metadata.get("title") or e.metadata.get("source_id") or "Source",
                "url": e.metadata.get("uri"),
                "retrieved_at": e.metadata.get("observation_time") or e.metadata.get("retrieved_at"),
                "publisher": e.metadata.get("publisher_id"),
                "source_id": e.metadata.get("source_id"),
                "media": list(e.metadata.get("media", [])),
            })
        return tuple(x for x in out if self._public_url(x["url"]))

    @staticmethod
    def _public_url(value):
        try:
            u=urlparse(str(value))
            return u.scheme in {"http","https"} and bool(u.netloc)
        except Exception:
            return False

    @staticmethod
    def _evidence_health(source: dict, independent_sources: int) -> dict:
        completeness = sum(bool(source.get(k)) for k in ('url','publisher','source_id','retrieved_at'))
        freshness = 'undated'
        raw = source.get('retrieved_at')
        if raw:
            try:
                dt=datetime.fromisoformat(str(raw).replace('Z','+00:00'))
                age_days=max(0,(datetime.now(timezone.utc)-dt).days)
                freshness = 'recent' if age_days <= 30 else ('aging' if age_days <= 365 else 'old')
            except Exception:
                freshness='unparseable'
        return {
            'provenance_completeness': completeness / 4,
            'freshness': freshness,
            'independent_source_count': independent_sources,
            'needs_provenance_review': completeness < 3,
            'needs_freshness_review': freshness in {'old','undated','unparseable'},
        }

    @staticmethod
    def _citation_quality(source: dict, independent_sources: int) -> dict:
        score=0; reasons=[]
        url=source.get("url") or ""
        if AnswerPresenter._public_url(url): score += 25; reasons.append("absolute_public_url")
        if source.get("publisher"): score += 20; reasons.append("publisher_identified")
        if source.get("source_id"): score += 15; reasons.append("source_identity")
        if source.get("retrieved_at"):
            score += 15; reasons.append("retrieval_time")
            try:
                dt=datetime.fromisoformat(str(source["retrieved_at"]).replace("Z","+00:00"))
                if dt <= datetime.now(timezone.utc): score += 10; reasons.append("retrieval_timestamp_valid")
            except Exception: reasons.append("retrieval_timestamp_unparseable")
        if independent_sources >= 2: score += 15; reasons.append("multiple_independent_sources")
        return {"score":min(100,score),"reasons":reasons,"independent_source_count":independent_sources}

    def _dependency_profile(self, claim_id: str, evidence: tuple[dict, ...]) -> dict:
        # derived_from is encoded as dependent claim -> prerequisite node.
        # Keep this diagnostic bounded: it reports direct and short transitive
        # dependencies without changing status or deciding truth.
        direct = []
        for row in self.g.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='derived_from'", (claim_id,)).fetchall():
            nid=row[0]
            if self.g.get(nid): direct.append(nid)
        seen=set(direct); frontier=list(direct); depth=0
        while frontier and depth < 3:
            nxt=[]
            for nid in frontier:
                for row in self.g.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='derived_from'", (nid,)).fetchall():
                    dep=row[0]
                    if dep not in seen and self.g.get(dep):
                        seen.add(dep); nxt.append(dep)
            frontier=nxt; depth += 1
        source_ids=[e.get('source_id') for e in evidence if e.get('source_id')]
        unique_sources=list(dict.fromkeys(source_ids))
        return {
            'direct_dependency_count': len(direct),
            'dependency_count': len(seen),
            'dependency_ids': list(sorted(seen))[:24],
            'evidence_source_count': len(unique_sources),
            'single_source_support': len(unique_sources) == 1 and bool(evidence),
            'dependency_truncated': bool(frontier),
        }

    @staticmethod
    def _support_impact(items: list[dict]) -> dict:
        source_claims={}
        for item in items:
            for ev in item.get('evidence', ()):
                sid=ev.get('source_id') or ev.get('url')
                if sid: source_claims.setdefault(sid, set()).add(item['claim_id'])
        loads=sorted(((sid,len(cids)) for sid,cids in source_claims.items()), key=lambda x:(-x[1],x[0]))
        total_claims=len(items)
        max_load=loads[0][1] if loads else 0
        return {
            'source_count': len(source_claims),
            'max_claim_load': max_load,
            'single_source_claims': sum(1 for x in items if x.get('dependency_profile',{}).get('single_source_support')),
            'high_impact_sources': [{'source_id':sid,'claim_count':count} for sid,count in loads if count >= 2][:12],
            'concentration_ratio': round(max_load/total_claims,3) if total_claims else 0,
        }

    def _media(self, evidence):
        images=[]; videos=[]
        for e in evidence:
            if isinstance(e, dict):
                metadata=e
                fallback_title=e.get("title")
                source_url=e.get("url")
            else:
                metadata=e.metadata
                fallback_title=metadata.get("title")
                source_url=metadata.get("uri")
            for item in metadata.get("media", []):
                url=item.get("url") if isinstance(item,dict) else None
                if not url: continue
                kind=item.get("type")
                entry={"url":url,"alt":item.get("alt") or fallback_title or "Related media","source_url":source_url}
                if kind == "image": images.append(entry)
                elif kind == "video": videos.append(entry)
        return images[:12], videos[:8]

    def build(self, question: str):
        q=question.strip()
        if not q: raise ValueError("question required")
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='Claim' ORDER BY rowid DESC").fetchall()
        candidates=[]
        terms={x for x in q.casefold().split() if len(x)>2}
        for row in rows:
            c=self.g.get(row[0]); score=sum(1 for t in terms if t in c.content.casefold())
            if score: candidates.append((score,c))
        candidates.sort(key=lambda x:x[0],reverse=True)
        items=[]; all_images=[]; all_videos=[]; source_map={}; unresolved=[]
        for _,c in candidates[:12]:
            ev=self._evidence(c.id)
            indep=len({x.get("source_id") for x in ev if x.get("source_id")})
            item=AnswerItem(c.id,c.content,c.status,ev,self._confidence(c.status,len(ev),indep))
            row=asdict(item)
            row['dependency_profile']=self._dependency_profile(c.id,ev)
            items.append(row)
            if c.status != "verified": unresolved.append(c.id)
            images,videos=self._media(ev); all_images.extend(images); all_videos.extend(videos)
            for source in ev:
                if source["url"]: source_map[source["url"]]=source
        seen_img=set(); images=[]
        for x in all_images:
            if x["url"] not in seen_img: seen_img.add(x["url"]); images.append(x)
        seen_vid=set(); videos=[]
        for x in all_videos:
            if x["url"] not in seen_vid: seen_vid.add(x["url"]); videos.append(x)
        independent_sources=len({s.get("source_id") for s in source_map.values() if s.get("source_id")})
        for source in source_map.values():
            source['evidence_health']=self._evidence_health(source, independent_sources)
            source['citation_quality']=self._citation_quality(source, independent_sources)
        health_values=list(source_map.values())
        provenance_gaps=sum(1 for s in health_values if s['evidence_health']['needs_provenance_review'])
        freshness_gaps=sum(1 for s in health_values if s['evidence_health']['needs_freshness_review'])
        support_impact=self._support_impact(items)
        citation_quality={"score": round(sum(s["citation_quality"]["score"] for s in source_map.values())/len(source_map)) if source_map else 0, "source_count":len(source_map), "independent_source_count":independent_sources, "provenance_gaps":provenance_gaps, "freshness_gaps":freshness_gaps}
        if not items:
            headline="No verified answer is available yet."
            summary="TBOHK does not have matching claims in this account. Research the question using explicit public sources, then review the resulting claims before treating them as knowledge."
        elif any(x["status"] != "verified" for x in items):
            headline="A partial answer is available, but uncertainty remains."
            summary="The statements below are the closest matching claims in the knowledge base. Items marked for review are not presented as established facts."
        else:
            headline="Here is what TBOHK currently supports."
            summary="The answer is assembled only from claims already present in this account. Source links and support status remain attached so you can inspect the basis."
        return {
            "question":q,"headline":headline,"summary":summary,"items":items,
            "sources":list(source_map.values()),"images":images[:12],"videos":videos[:8],
            "unresolved_claim_ids":unresolved,
            "next_actions":[
                "Inspect the cited sources before relying on a consequential claim.",
                "Research unresolved claims when evidence is missing or insufficient." if unresolved else "Re-check the answer when important new evidence appears.",
                "Review conflicts before treating competing claims as resolved."],
            "citation_quality":citation_quality,
            "support_impact":support_impact,
            "truth_boundary":"TBOHK distinguishes evidence, claims and inference. This presentation does not turn a generated or proposed statement into verified truth."
        }
