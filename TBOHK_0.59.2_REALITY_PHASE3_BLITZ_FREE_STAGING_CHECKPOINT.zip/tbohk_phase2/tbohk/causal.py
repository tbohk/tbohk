from __future__ import annotations
from dataclasses import dataclass, asdict
import re
from .core import TBOHK

RELATIONS = {
    'causal': 'causal',
    'correlational': 'correlational',
    'temporal_precedence': 'temporal_precedence',
    'dependency': 'dependency',
    'association': 'association',
    'causal_candidate': 'causal_candidate',
    'indeterminate': 'indeterminate',
}

_CAUSE = re.compile(r'\b(?:causes?|caused|causing|leads? to|led to|results? in|resulted in|drives?|driven by|because of|due to|produces?|produced|prevents?|prevented|inhibits?|inhibited)\b', re.I)
_CORR = re.compile(r'\b(?:correlates? with|correlated with|correlation|associated with|association|linked to|links? to|relationship between)\b', re.I)
_PRECEDES = re.compile(r'\b(?:before|after|preceded|followed|prior to|subsequent to|earlier than|later than)\b', re.I)
_DEPENDS = re.compile(r'\b(?:depends? on|dependent on|requires?|requirement for|contingent on|relies? on|reliant on)\b', re.I)

@dataclass(frozen=True)
class CausalAssessment:
    claim_id: str
    relation: str
    subject: str | None
    object: str | None
    evidence_level: str
    reasons: tuple[str, ...]
    blockers: tuple[str, ...]
    temporal_precedence: bool
    confounder_status: str
    counterfactual_status: str

class CausalReasoner:
    """Conservative causal/relational classifier.

    Language indicating causation is recorded as a claim about causation, but the
    system never upgrades it merely because two variables correlate or because one
    event occurs before another. Strong causal status requires independent support
    for mechanism/design/counterfactual evidence or an explicit evaluated inference.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def parse(text: str):
        t=' '.join(text.strip().split())
        for rx, rel in ((_CAUSE,'causal'),(_CORR,'correlational'),(_DEPENDS,'dependency'),(_PRECEDES,'temporal_precedence')):
            m=rx.search(t)
            if m:
                left=t[:m.start()].strip(' ,;:.')
                right=t[m.end():].strip(' ,;:.')
                if left and right:
                    return rel,left,right,m.group(0)
        return None

    def assess(self, claim_id: str) -> CausalAssessment:
        c=self.g.get(claim_id)
        if not c or c.kind!='Claim': raise ValueError(f'not a Claim: {claim_id}')
        parsed=self.parse(c.content)
        if not parsed:
            return CausalAssessment(claim_id,'indeterminate',None,None,'none',('no explicit causal/relational operator detected',),(),False,'unknown','unknown')
        rel,subject,obj,operator=parsed
        reasons=[f'explicit relational operator: {operator}']
        blockers=[]
        temporal=False
        conf='unknown'
        counter='unknown'
        meta=c.metadata.get('structured') or {}
        if rel=='causal':
            # Causal wording is evidence of what the source asserts, not proof.
            reasons.append('claim explicitly asserts a causal relation')
            blockers.append('causal assertion requires supporting mechanism, intervention, or evaluated causal evidence')
            conf='not_established'
            counter='not_evaluated'
        elif rel=='correlational':
            reasons.append('claim explicitly describes association/correlation')
            blockers.append('correlation does not establish causation')
            conf='association_only'
            counter='not_evaluated'
        elif rel=='temporal_precedence':
            temporal=True
            reasons.append('claim asserts an ordering in time')
            blockers.append('temporal precedence alone does not establish causation')
            conf='temporal_only'
            counter='not_evaluated'
        elif rel=='dependency':
            reasons.append('claim asserts a dependency/requirement relation')
            blockers.append('dependency semantics require definition of necessity and boundary conditions')
            conf='dependency_assertion'
            counter='not_evaluated'
        # Structured metadata can explicitly record evaluated causal support.
        causal_support=meta.get('causal_support') or {}
        if causal_support.get('mechanism') or causal_support.get('intervention') or causal_support.get('counterfactual'):
            reasons.append('structured causal support is explicitly recorded')
            blockers=[]
            conf='supported_candidate'
            counter='supported' if causal_support.get('counterfactual') else 'not_evaluated'
        if meta.get('confounders'):
            conf='confounders_recorded'
            reasons.append('potential confounders are recorded')
        return CausalAssessment(claim_id,rel,subject,obj,conf,tuple(reasons),tuple(blockers),temporal,conf,counter)

    def compare(self, claim_a: str, claim_b: str) -> dict:
        a=self.assess(claim_a); b=self.assess(claim_b)
        if a.relation=='causal' and b.relation=='correlational':
            return {'relationship':'causal_vs_associational_scope','claim_a':claim_a,'claim_b':claim_b,'reason':'one claim asserts causation while the other asserts association; they are not logically equivalent'}
        if a.relation=='temporal_precedence' and b.relation=='causal':
            return {'relationship':'temporal_support_is_not_causal_proof','claim_a':claim_a,'claim_b':claim_b,'reason':'temporal ordering cannot by itself validate a causal claim'}
        return {'relationship':'distinct_or_unresolved','claim_a':claim_a,'claim_b':claim_b,'reason':'no deterministic basis for causal equivalence or contradiction'}

    def record(self, claim_id: str, assessor='causal-review') -> CausalAssessment:
        a=self.assess(claim_id)
        n=self.g.add_node('CausalAssessment',f'Causal assessment of {claim_id}','supported',{
            'claim_id':claim_id,'assessor':assessor,'assessment':asdict(a)})
        self.g.link(n.id,'evaluates',claim_id)
        return a
