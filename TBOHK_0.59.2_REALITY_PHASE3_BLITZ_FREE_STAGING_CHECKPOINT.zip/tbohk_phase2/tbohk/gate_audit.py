from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class GateFinding:
    gate:str; severity:str; code:str; affected:tuple[str,...]; blocks_release:bool
class GateAuditor:
    def __init__(self,graph): self.g=graph
    def audit(self):
        findings=[]
        for r in self.g.db.execute("SELECT id,status FROM nodes WHERE kind='AuthorityGrant'"):
            if r['status']=='verified':
                n=self.g.get(r['id'])
                if not n.metadata.get('capabilities'): findings.append(GateFinding('G6','high','authority_without_capabilities',(r['id'],),True))
        for r in self.g.db.execute("SELECT id,status FROM nodes WHERE kind='RecoveryProposal'"):
            n=self.g.get(r['id'])
            if r['status']=='verified' and not n.metadata.get('reversible'): findings.append(GateFinding('G7','critical','nonreversible_recovery',(r['id'],),True))
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='Evaluation'"):
            n=self.g.get(r['id']); m=n.metadata
            if not m.get('suite_manifest_sha256'): findings.append(GateFinding('G8','high','evaluation_without_fixed_suite_hash',(r['id'],),True))
        return tuple(findings)
