from __future__ import annotations
import hashlib, hmac, os, secrets, sqlite3, threading, smtplib
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json

PLAN_LIMITS = {"free": 25, "pro": 250, "unlimited": 1000}
PLAN_PRICES = {"free": 0, "pro": 10, "unlimited": 20}

@dataclass(frozen=True)
class AccountIdentity:
    account_id: str
    user_id: str
    email: str
    plan: str
    status: str
    ask_limit: int
    ask_used: int
    billing_status: str

class AccountManager:
    def __init__(self, db_path: str, data_dir: str):
        self.db_path = db_path
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS accounts(
          id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'active', plan TEXT NOT NULL DEFAULT 'free',
          billing_status TEXT NOT NULL DEFAULT 'active',
          stripe_customer_id TEXT, stripe_subscription_id TEXT);
        CREATE TABLE IF NOT EXISTS users(
          id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id),
          email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'owner', status TEXT NOT NULL DEFAULT 'active',
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS api_tokens(
          token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
          created_at TEXT NOT NULL, last_used_at TEXT, expires_at TEXT, revoked_at TEXT);
        CREATE TABLE IF NOT EXISTS verification_tokens(
          token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
          purpose TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT);
        CREATE TABLE IF NOT EXISTS auth_throttle(
          key TEXT PRIMARY KEY, failures INTEGER NOT NULL DEFAULT 0, window_started_at TEXT NOT NULL,
          locked_until TEXT);
        CREATE INDEX IF NOT EXISTS idx_verification_user ON verification_tokens(user_id,purpose);
        
        CREATE TABLE IF NOT EXISTS ask_usage(
          account_id TEXT NOT NULL REFERENCES accounts(id), month TEXT NOT NULL,
          used INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
          PRIMARY KEY(account_id, month));
        CREATE TABLE IF NOT EXISTS billing_events(
          provider TEXT NOT NULL, event_id TEXT NOT NULL, event_type TEXT NOT NULL,
          received_at TEXT NOT NULL, payload_json TEXT NOT NULL,
          PRIMARY KEY(provider,event_id));
        CREATE TABLE IF NOT EXISTS entitlements(
          id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id),
          provider TEXT NOT NULL, external_id TEXT NOT NULL, plan TEXT NOT NULL,
          status TEXT NOT NULL, current_period_end TEXT, cancel_at_period_end INTEGER NOT NULL DEFAULT 0,
          raw_json TEXT NOT NULL, updated_at TEXT NOT NULL,
          UNIQUE(provider,external_id));
        CREATE INDEX IF NOT EXISTS idx_users_account ON users(account_id);
        ''')
        for ddl in (
            "ALTER TABLE api_tokens ADD COLUMN expires_at TEXT",
            "ALTER TABLE api_tokens ADD COLUMN revoked_at TEXT",
        ):
            try: self.db.execute(ddl)
            except sqlite3.OperationalError: pass
        self.db.commit()
        self._closed=False

    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _month(): return datetime.now(timezone.utc).strftime('%Y-%m')
    @staticmethod
    def _token_hash(token: str) -> str: return hashlib.sha256(token.encode()).hexdigest()
    @staticmethod
    def _password_hash(password: str, salt: bytes | None = None) -> str:
        salt = salt or secrets.token_bytes(16)
        digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
        return salt.hex() + '$' + digest.hex()
    @classmethod
    def _password_ok(cls, password: str, stored: str) -> bool:
        try:
            salt_hex, digest_hex = stored.split('$', 1)
            got = cls._password_hash(password, bytes.fromhex(salt_hex)).split('$', 1)[1]
            return hmac.compare_digest(got, digest_hex)
        except Exception:
            return False
    @staticmethod
    def _id(prefix): return f'{prefix}_{secrets.token_hex(12)}'

    def _issue_token(self, user_id: str, ttl_days: int = 30) -> str:
        token = 'tbo_' + secrets.token_urlsafe(42)
        now=self._now(); expires=(datetime.now(timezone.utc)+timedelta(days=ttl_days)).isoformat()
        with self.db:
            self.db.execute('INSERT INTO api_tokens(token_hash,user_id,created_at,expires_at) VALUES (?,?,?,?)',(self._token_hash(token),user_id,now,expires))
        return token

    @staticmethod
    def _token(ttl_days: int = 1) -> str:
        return secrets.token_urlsafe(48)

    def _throttle(self, key: str, limit: int = 8, window_seconds: int = 900) -> None:
        now=datetime.now(timezone.utc)
        row=self.db.execute('SELECT * FROM auth_throttle WHERE key=?',(key,)).fetchone()
        if not row: return
        locked=row['locked_until']
        if locked and locked > now.isoformat(): raise PermissionError('too many authentication attempts; try again later')
        started=datetime.fromisoformat(row['window_started_at'])
        if (now-started).total_seconds() > window_seconds:
            with self.db: self.db.execute('DELETE FROM auth_throttle WHERE key=?',(key,))
            return
        if int(row['failures']) >= limit: raise PermissionError('too many authentication attempts; try again later')

    def _failed_auth(self, key: str, limit: int = 8, window_seconds: int = 900) -> None:
        now=datetime.now(timezone.utc); row=self.db.execute('SELECT * FROM auth_throttle WHERE key=?',(key,)).fetchone()
        if not row or (now-datetime.fromisoformat(row['window_started_at'])).total_seconds() > window_seconds:
            with self.db: self.db.execute('INSERT OR REPLACE INTO auth_throttle(key,failures,window_started_at,locked_until) VALUES (?,?,?,?)',(key,1,now.isoformat(),None)); return
        failures=int(row['failures'])+1; locked=(now+timedelta(seconds=window_seconds)).isoformat() if failures >= limit else None
        with self.db: self.db.execute('UPDATE auth_throttle SET failures=?,locked_until=? WHERE key=?',(failures,locked,key))

    def _clear_auth_failures(self, key: str) -> None:
        with self.db: self.db.execute('DELETE FROM auth_throttle WHERE key=?',(key,))

    def _issue_one_time(self, user_id: str, purpose: str, ttl_hours: int = 24) -> str:
        raw=self._token(); now=self._now(); expires=(datetime.now(timezone.utc)+timedelta(hours=ttl_hours)).isoformat()
        with self.db:
            self.db.execute('DELETE FROM verification_tokens WHERE user_id=? AND purpose=? AND used_at IS NULL',(user_id,purpose))
            self.db.execute('INSERT INTO verification_tokens(token_hash,user_id,purpose,created_at,expires_at) VALUES (?,?,?,?,?)',(self._token_hash(raw),user_id,purpose,now,expires))
        return raw

    def create_account(self, email: str, password: str, name: str, plan: str = 'free') -> tuple[AccountIdentity,str]:
        email=email.strip().lower()
        if plan not in PLAN_LIMITS: raise ValueError('invalid plan')
        if plan != 'free': raise ValueError('paid plans require checkout after creating a free account')
        if len(password) < 10: raise ValueError('password must be at least 10 characters')
        if '@' not in email or len(email) > 320: raise ValueError('valid email required')
        aid=self._id('acct'); uid=self._id('usr'); now=self._now()
        with self.lock, self.db:
            if self.db.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone(): raise ValueError('account already exists')
            self.db.execute('INSERT INTO accounts(id,name,created_at,plan) VALUES (?,?,?,?)',(aid,name.strip()[:200] or email,now,plan))
            self.db.execute('INSERT INTO users(id,account_id,email,password_hash,created_at) VALUES (?,?,?,?,?)',(uid,aid,email,self._password_hash(password),now))
        return self.identity(uid), self._issue_token(uid)

    def authenticate_password(self, email: str, password: str) -> tuple[AccountIdentity,str]:
        email=email.strip().lower(); key='login:'+hashlib.sha256(email.encode()).hexdigest()
        self._throttle(key)
        row=self.db.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        if not row or row['status'] != 'active' or not self._password_ok(password,row['password_hash']):
            self._failed_auth(key); raise ValueError('invalid credentials')
        self._clear_auth_failures(key)
        token=self._issue_token(row['id'])
        return self.identity(row['id']), token

    def identity(self, user_id: str) -> AccountIdentity:
        row=self.db.execute('''SELECT u.id user_id,u.email,a.id account_id,a.plan,a.status,a.billing_status,
            COALESCE(x.used,0) used FROM users u JOIN accounts a ON a.id=u.account_id
            LEFT JOIN ask_usage x ON x.account_id=a.id AND x.month=? WHERE u.id=?''',(self._month(),user_id)).fetchone()
        if not row: raise ValueError('account not found')
        return AccountIdentity(row['account_id'],row['user_id'],row['email'],row['plan'],row['status'],PLAN_LIMITS[row['plan']],int(row['used']),row['billing_status'])

    def authenticate_token(self, token: str) -> AccountIdentity | None:
        if not token: return None
        row=self.db.execute('SELECT user_id,expires_at,revoked_at FROM api_tokens WHERE token_hash=?',(self._token_hash(token),)).fetchone()
        if not row or row['revoked_at'] or (row['expires_at'] and row['expires_at'] <= self._now()): return None
        with self.db: self.db.execute('UPDATE api_tokens SET last_used_at=? WHERE token_hash=?',(self._now(),self._token_hash(token)))
        return self.identity(row['user_id'])

    def consume_ask(self, account_id: str, amount: int = 1) -> AccountIdentity:
        if amount < 1: raise ValueError('amount must be positive')
        month=self._month()
        with self.lock, self.db:
            row=self.db.execute('SELECT plan,status,billing_status FROM accounts WHERE id=?',(account_id,)).fetchone()
            if not row: raise ValueError('account not found')
            limit=PLAN_LIMITS[row['plan']]
            current=self.db.execute('SELECT used FROM ask_usage WHERE account_id=? AND month=?',(account_id,month)).fetchone()
            used=int(current['used']) if current else 0
            if used + amount > limit:
                raise QuotaExceeded(limit, used)
            self.db.execute('INSERT INTO ask_usage(account_id,month,used,updated_at) VALUES (?,?,?,?) ON CONFLICT(account_id,month) DO UPDATE SET used=used+excluded.used,updated_at=excluded.updated_at',(account_id,month,amount,self._now()))
        return self.identity(self.db.execute('SELECT id FROM users WHERE account_id=? ORDER BY created_at LIMIT 1',(account_id,)).fetchone()['id'])

    def account_summary(self, identity: AccountIdentity) -> dict:
        return {'account_id':identity.account_id,'email':identity.email,'plan':identity.plan,'status':identity.status,'billing_status':identity.billing_status,'asks':{'used':identity.ask_used,'limit':identity.ask_limit,'remaining':max(0,identity.ask_limit-identity.ask_used),'month':self._month()}}

    def update_plan(self, account_id: str, plan: str, billing_status: str='active', stripe_customer_id: str|None=None, stripe_subscription_id: str|None=None):
        if plan not in PLAN_LIMITS: raise ValueError('invalid plan')
        with self.db:
            self.db.execute('UPDATE accounts SET plan=?,billing_status=?,stripe_customer_id=COALESCE(?,stripe_customer_id),stripe_subscription_id=COALESCE(?,stripe_subscription_id) WHERE id=?',(plan,billing_status,stripe_customer_id,stripe_subscription_id,account_id))

    def record_billing_event(self, provider: str, event_id: str, event_type: str, payload: dict) -> bool:
        """Atomically record a provider event; False means it was already processed."""
        if not provider or not event_id or not event_type: raise ValueError('billing event identity is required')
        with self.lock, self.db:
            cur=self.db.execute('INSERT OR IGNORE INTO billing_events(provider,event_id,event_type,received_at,payload_json) VALUES (?,?,?,?,?)',
                (provider,event_id,event_type,self._now(),json.dumps(payload,separators=(',',':'),sort_keys=True)))
            return cur.rowcount == 1

    def upsert_entitlement(self, account_id: str, provider: str, external_id: str, plan: str, status: str,
                           current_period_end: str|None=None, cancel_at_period_end: bool=False, raw: dict|None=None):
        if plan not in PLAN_LIMITS: raise ValueError('invalid plan')
        if not provider or not external_id: raise ValueError('entitlement identity is required')
        eid=self._id('ent'); now=self._now()
        raw_json=json.dumps(raw or {},separators=(',',':'),sort_keys=True)
        with self.lock, self.db:
            self.db.execute('''INSERT INTO entitlements(id,account_id,provider,external_id,plan,status,current_period_end,cancel_at_period_end,raw_json,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(provider,external_id) DO UPDATE SET account_id=excluded.account_id,plan=excluded.plan,status=excluded.status,
                current_period_end=excluded.current_period_end,cancel_at_period_end=excluded.cancel_at_period_end,raw_json=excluded.raw_json,updated_at=excluded.updated_at''',
                (eid,account_id,provider,external_id,plan,status,current_period_end,int(cancel_at_period_end),raw_json,now))
            row=self.db.execute('SELECT * FROM entitlements WHERE provider=? AND external_id=?',(provider,external_id)).fetchone()
            return dict(row)

    def entitlement_state(self, account_id: str) -> dict:
        rows=self.db.execute('SELECT * FROM entitlements WHERE account_id=? ORDER BY updated_at DESC',(account_id,)).fetchall()
        active=[r for r in rows if r['status'] in {'active','trialing','grace_period'}]
        chosen=active[0] if active else None
        if chosen:
            self.update_plan(account_id,chosen['plan'],chosen['status'])
        elif rows:
            self.update_plan(account_id,'free','canceled')
        return {'account_id':account_id,'plan':chosen['plan'] if chosen else 'free','billing_status':chosen['status'] if chosen else 'canceled','entitlements':[dict(r) for r in rows]}

    def data_path(self, account_id: str) -> str:
        return str(self.data_dir / f'{account_id}.sqlite')

    def revoke_token(self, token: str) -> bool:
        token_hash = self._token_hash(token)
        with self.db:
            cur = self.db.execute('UPDATE api_tokens SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL', (self._now(),token_hash))
        return cur.rowcount == 1

    def revoke_all_tokens(self, user_id: str) -> int:
        with self.db: cur=self.db.execute('UPDATE api_tokens SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL',(self._now(),user_id))
        return cur.rowcount

    def sessions(self, user_id: str) -> list[dict]:
        rows=self.db.execute('SELECT token_hash,created_at,last_used_at,expires_at,revoked_at FROM api_tokens WHERE user_id=? ORDER BY created_at DESC',(user_id,)).fetchall()
        return [{"created_at":r["created_at"],"last_used_at":r["last_used_at"],"expires_at":r["expires_at"],"revoked":bool(r["revoked_at"])} for r in rows]

    def issue_email_verification(self, email: str) -> str:
        row=self.db.execute('SELECT id FROM users WHERE email=?',(email.strip().lower(),)).fetchone()
        if not row: return ''
        return self._issue_one_time(row['id'],'email_verification',24)

    def verify_email(self, token: str) -> bool:
        row=self.db.execute('SELECT * FROM verification_tokens WHERE token_hash=? AND purpose=? AND used_at IS NULL',(self._token_hash(token),'email_verification')).fetchone()
        if not row or row['expires_at'] <= self._now(): return False
        with self.db:
            self.db.execute('UPDATE verification_tokens SET used_at=? WHERE token_hash=?',(self._now(),self._token_hash(token)))
            self.db.execute("UPDATE users SET status='active' WHERE id=?",(row['user_id'],))
        return True

    def request_password_reset(self, email: str) -> str:
        row=self.db.execute('SELECT id FROM users WHERE email=?',(email.strip().lower(),)).fetchone()
        if not row: return ''
        return self._issue_one_time(row['id'],'password_reset',1)

    def reset_password(self, token: str, password: str) -> bool:
        if len(password)<10: raise ValueError('password must be at least 10 characters')
        row=self.db.execute('SELECT * FROM verification_tokens WHERE token_hash=? AND purpose=? AND used_at IS NULL',(self._token_hash(token),'password_reset')).fetchone()
        if not row or row['expires_at'] <= self._now(): return False
        with self.db:
            self.db.execute('UPDATE verification_tokens SET used_at=? WHERE token_hash=?',(self._now(),self._token_hash(token)))
            self.db.execute('UPDATE users SET password_hash=? WHERE id=?',(self._password_hash(password),row['user_id']))
        self.revoke_all_tokens(row['user_id'])
        return True

    def delete_account(self, account_id: str) -> None:
        """Permanently delete tenant data and credentials after billing cancellation."""
        tenant_path = Path(self.data_path(account_id))
        with self.lock, self.db:
            row = self.db.execute('SELECT id FROM accounts WHERE id=?', (account_id,)).fetchone()
            if not row:
                raise ValueError('account not found')
            user_rows = self.db.execute('SELECT id FROM users WHERE account_id=?', (account_id,)).fetchall()
            user_ids = [r['id'] for r in user_rows]
            if user_ids:
                marks = ','.join('?' for _ in user_ids)
                self.db.execute(f'DELETE FROM api_tokens WHERE user_id IN ({marks})', user_ids)
            self.db.execute('DELETE FROM ask_usage WHERE account_id=?', (account_id,))
            self.db.execute('DELETE FROM users WHERE account_id=?', (account_id,))
            self.db.execute('DELETE FROM accounts WHERE id=?', (account_id,))
        try:
            tenant_path.unlink(missing_ok=True)
        except OSError as exc:
            raise RuntimeError(f'account removed but tenant database could not be deleted: {exc}') from exc


    def ensure_bootstrap(self, master_token: str) -> AccountIdentity:
        row=self.db.execute('SELECT id FROM users WHERE email=?',('owner@local.tbohk',)).fetchone()
        if not row:
            aid=self._id('acct'); uid=self._id('usr'); now=self._now()
            with self.db:
                self.db.execute('INSERT INTO accounts(id,name,created_at,plan) VALUES (?,?,?,?)',(aid,'Local deployment',now,'unlimited'))
                self.db.execute('INSERT INTO users(id,account_id,email,password_hash,created_at) VALUES (?,?,?,?,?)',(uid,aid,'owner@local.tbohk',self._password_hash(secrets.token_urlsafe(24)),now))
                self.db.execute('INSERT OR IGNORE INTO api_tokens(token_hash,user_id,created_at) VALUES (?,?,?)',(self._token_hash(master_token),uid,now))
            return self.identity(uid)
        identity=self.identity(row['id'])
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO api_tokens(token_hash,user_id,created_at) VALUES (?,?,?)',(self._token_hash(master_token),identity.user_id,self._now()))
        return identity

    def __enter__(self):
        if self._closed: raise RuntimeError('account manager is closed')
        return self
    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
    def close(self):
        if not self._closed:
            self.db.close(); self._closed=True
    def __del__(self):
        try: self.close()
        except Exception: pass

class QuotaExceeded(Exception):
    def __init__(self, limit, used):
        self.limit=limit; self.used=used
        super().__init__(f'monthly ask limit reached ({used}/{limit})')

class StripeBilling:
    def __init__(self, secret_key: str|None, webhook_secret: str|None, price_ids: dict[str,str] | None = None):
        self.secret_key=secret_key or ''
        self.webhook_secret=webhook_secret or ''
        self.price_ids=price_ids or {}
    def configured(self): return bool(self.secret_key)
    def _request(self, path: str, params: dict):
        if not self.secret_key: raise RuntimeError('billing provider is not configured')
        data=urlencode(params).encode(); req=Request('https://api.stripe.com/v1/'+path,data=data,headers={'Authorization':'Bearer '+self.secret_key,'Content-Type':'application/x-www-form-urlencoded'},method='POST')
        with urlopen(req,timeout=15) as r: return json.loads(r.read().decode())
    def checkout(self, plan: str, account_id: str, success_url: str, cancel_url: str):
        price=self.price_ids.get(plan)
        if plan == 'free': raise ValueError('free plan does not require checkout')
        if not price: raise RuntimeError(f'Stripe price ID missing for {plan}')
        return self._request('checkout/sessions',{'mode':'subscription','line_items[0][price]':price,'line_items[0][quantity]':'1','success_url':success_url,'cancel_url':cancel_url,'client_reference_id':account_id,'metadata[account_id]':account_id,'metadata[plan]':plan,'subscription_data[metadata][account_id]':account_id,'subscription_data[metadata][plan]':plan})
    def portal(self, customer_id: str, return_url: str): return self._request('billing_portal/sessions',{'customer':customer_id,'return_url':return_url})
    def cancel_subscription(self, subscription_id: str):
        return self._request(f'subscriptions/{subscription_id}', {'cancel_at_period_end':'true'})
    def verify_webhook(self, payload: bytes, signature: str) -> dict:
        if not self.webhook_secret: raise ValueError('billing webhook secret is not configured')
        parts=dict(item.split('=',1) for item in signature.split(',') if '=' in item)
        timestamp=parts.get('t'); provided=parts.get('v1')
        if not timestamp or not provided: raise ValueError('invalid Stripe signature')
        try: ts=int(timestamp)
        except (TypeError, ValueError): raise ValueError('invalid Stripe signature timestamp')
        if abs(datetime.now(timezone.utc).timestamp()-ts) > 300: raise ValueError('expired Stripe signature')
        signed=timestamp+'.'+payload.decode()
        expected=hmac.new(self.webhook_secret.encode(),signed.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,provided): raise ValueError('invalid Stripe signature')
        return json.loads(payload.decode())
