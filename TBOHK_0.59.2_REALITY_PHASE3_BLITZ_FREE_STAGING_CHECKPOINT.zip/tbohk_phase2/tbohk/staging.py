from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import os
from typing import Any

from .research import ResearchChain
from .service import DirectURLProvider
from .web_corpus import CommonCrawlProvider
from .answer import AnswerPresenter
from .provider_readiness import readiness
from .observability import metrics


@dataclass(frozen=True)
class StagingRun:
    run_id: str
    question: str
    providers: tuple[str, ...]
    research: dict[str, Any]
    answer: dict[str, Any]
    provider_readiness: dict[str, Any]
    metrics: dict[str, Any]
    started_at: str
    completed_at: str


class StagingOrchestrator:
    """Execute the real question -> research -> evidence -> answer path.

    Network access is intentionally explicit: URLs come from the staging
    environment and are fetched through the existing SSRF-safe provider.
    Common Crawl is optional. No mock provider is used by this orchestrator.
    """
    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _urls() -> list[str]:
        raw = os.environ.get("TBOHK_STAGING_URLS", "")
        return [x.strip() for x in raw.split(",") if x.strip()]

    def run(self, question: str, *, include_common_crawl: bool = False, crawl_id: str | None = None) -> StagingRun:
        question = question.strip()
        if not question:
            raise ValueError("question is required")
        urls = self._urls()
        if not urls and not include_common_crawl:
            raise ValueError("set TBOHK_STAGING_URLS or enable Common Crawl")
        started = datetime.now(timezone.utc).isoformat()
        providers = []
        if urls:
            providers.append(DirectURLProvider(urls))
        if include_common_crawl:
            providers.append(CommonCrawlProvider(crawl_id or CommonCrawlProvider.DEFAULT_CRAWL, max_results=8))
        chain = ResearchChain(self.g, providers)
        out = chain.run(question, "all configured staging providers completed")
        if not out["results"]:
            raise RuntimeError(f"staging research produced no evidence: {out['research_record']['failures']}")
        answer = AnswerPresenter(self.g).build(question)
        completed = datetime.now(timezone.utc).isoformat()
        run_id = out["research_record"]["record_id"]
        return StagingRun(
            run_id=run_id,
            question=question,
            providers=tuple(p.provider_id for p in providers),
            research=out["research_record"],
            answer=answer,
            provider_readiness=readiness(),
            metrics=metrics.snapshot(),
            started_at=started,
            completed_at=completed,
        )

    def run_dict(self, question: str, *, include_common_crawl: bool = False, crawl_id: str | None = None) -> dict[str, Any]:
        return asdict(self.run(question, include_common_crawl=include_common_crawl, crawl_id=crawl_id))
