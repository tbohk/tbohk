from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib
import re
from .core import TBOHK

@dataclass(frozen=True)
class Prediction:
    id: str
    hypothesis_id: str
    statement: str
    status: str
    discriminator: bool

@dataclass(frozen=True)
class ObservationAssessment:
    prediction_id: str
    outcome: str
    reason: str
    evidence_id: str | None
    assessment_id: str

@dataclass(frozen=True)
class ExperimentDesign:
    hypothesis_ids: tuple[str, ...]
    predictions: tuple[str, ...]
    discriminators: tuple[str, ...]
    required_observations: tuple[str, ...]
    controls: tuple[str, ...]
    unresolved: tuple[str, ...]
    boundary: str

class PredictiveReasoner:
    """Conservative prediction and experiment-design layer.

    Predictions are explicit testable requirements. Observations can support,
    fail-to-support, or remain inconclusive, but no observation automatically
    promotes a hypothesis to truth or changes verified knowledge.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _hypothesis(self, hid):
        n=self.g.get(hid)
        if not n or n.kind != 'Hypothesis':
            raise ValueError('not a Hypothesis')
        return n

    def create_prediction(self, hypothesis_id: str, statement: str, *, discriminator: bool = False) -> Prediction:
        self._hypothesis(hypothesis_id)
        s=' '.join(statement.split())
        if not s: raise ValueError('prediction statement required')
        pid='prediction_'+hashlib.sha256((hypothesis_id+'|'+s).encode()).hexdigest()[:24]
        existing=self.g.get(pid)
        if existing:
            return Prediction(existing.id,hypothesis_id,existing.content,existing.status,bool(existing.metadata.get('discriminator')))
        n=self.g.add_node('Prediction',s,'proposed',{
            'prediction_id':pid,'hypothesis_id':hypothesis_id,'discriminator':bool(discriminator),
            'requires_observation':True,
            'truth_boundary':'prediction is a testable consequence, not evidence of itself'})
        self.g.link(hypothesis_id,'predicts',n.id)
        return Prediction(n.id,hypothesis_id,n.content,n.status,bool(discriminator))

    @staticmethod
    def assess_text(prediction: str, observation: str) -> tuple[str,str]:
        p=set(re.findall(r"[a-z0-9]+", prediction.lower()))
        o=set(re.findall(r"[a-z0-9]+", observation.lower()))
        if not p or not o: return 'inconclusive','prediction or observation contains no usable terms'
        stop={'the','a','an','does','is','are','to','of','for','not','never','no','without','fails','fail','decrease','decreased','lower','below'}
        ps=p-stop; os=o-stop
        overlap=len(ps & os)/max(1,len(ps))
        neg_pred=bool(re.search(r'\b(not|never|no|without|fails?|decrease|decreased|lower|below)\b',prediction,re.I))
        neg_obs=bool(re.search(r'\b(not|never|no|without|fails?|decrease|decreased|lower|below)\b',observation,re.I))
        if overlap >= .75 and neg_pred == neg_obs:
            return 'supports','high lexical alignment with matching polarity; semantic review remains required'
        if overlap >= .75 and neg_pred != neg_obs:
            return 'fails_to_support','high lexical alignment with opposing polarity; semantic review remains required'
        return 'inconclusive','observation does not provide sufficient deterministic semantic alignment'

    def assess_observation(self, prediction_id: str, observation: str, evidence_id: str | None = None) -> ObservationAssessment:
        p=self.g.get(prediction_id)
        if not p or p.kind!='Prediction': raise ValueError('not a Prediction')
        outcome,reason=self.assess_text(p.content,observation)
        if evidence_id is not None:
            evidence = self.g.get(evidence_id)
            if evidence is None:
                raise ValueError('evidence_id does not exist')
            if evidence.kind != 'Evidence':
                raise ValueError('evidence_id must reference Evidence')
        aid='assessment_'+hashlib.sha256((prediction_id+'|'+observation+'|'+str(evidence_id)).encode()).hexdigest()[:24]
        existing_row=self.g.db.execute("SELECT id FROM nodes WHERE kind='PredictionAssessment' AND json_extract(metadata, '$.assessment_id')=? LIMIT 1", (aid,)).fetchone()
        if existing_row:
            existing=self.g.get(existing_row[0])
            return ObservationAssessment(prediction_id, existing.metadata.get('outcome','inconclusive'), existing.metadata.get('reason',''), existing.metadata.get('evidence_id'), aid)
        n=self.g.add_node('PredictionAssessment',observation,'proposed',{
            'assessment_id':aid,'prediction_id':prediction_id,'outcome':outcome,
            'reason':reason,'evidence_id':evidence_id,
            'requires_independent_evaluation':True,
            'truth_boundary':'prediction outcome does not by itself establish or falsify a hypothesis'})
        self.g.link(prediction_id,'evaluated_by',n.id)
        if evidence_id: self.g.link(evidence_id,'supports',n.id)
        return ObservationAssessment(prediction_id,outcome,reason,evidence_id,aid)

    def design_experiment(self, hypothesis_ids: list[str]) -> ExperimentDesign:
        hs=[]
        for hid in dict.fromkeys(hypothesis_ids):
            hs.append(self._hypothesis(hid))
        if len(hs)<1: raise ValueError('at least one hypothesis required')
        predictions=[]; discriminators=[]; unresolved=[]
        for h in hs:
            ps=h.metadata.get('predictions',[]) or []
            ds=h.metadata.get('discriminators',[]) or []
            predictions.extend(str(x) for x in ps)
            discriminators.extend(str(x) for x in ds)
            if not ps: unresolved.append(f'{h.id}: no explicit predictions')
            if not ds: unresolved.append(f'{h.id}: no explicit discriminators')
        controls=(
            'measure the outcome with a predefined operational definition',
            'record timing, scope, units, and measurement method',
            'check plausible confounders and selection effects',
            'preserve raw observations and provenance',
        )
        required=tuple(dict.fromkeys(predictions+discriminators))
        return ExperimentDesign(tuple(h.id for h in hs),tuple(predictions),tuple(dict.fromkeys(discriminators)),required,controls,tuple(unresolved),'Experiment design identifies tests and alternatives; it does not select a winning hypothesis.')

    def update_assessment(self, hypothesis_id: str) -> dict:
        h=self._hypothesis(hypothesis_id)
        preds=[self.g.get(e['target_id']) for e in self.g.edges(h.id) if e['relation']=='predicts']
        preds=[p for p in preds if p]
        assessments=[]
        for p in preds:
            seen=set()
            for e in self.g.edges(p.id):
                if e['relation']!='evaluated_by': continue
                a=self.g.get(e['target_id'])
                if a and a.id not in seen:
                    seen.add(a.id); assessments.append(a.metadata.get('outcome','inconclusive'))
        return {'hypothesis_id':h.id,'assessment':'provisional','supporting_predictions':assessments.count('supports'),
                'failed_predictions':assessments.count('fails_to_support'),'inconclusive_predictions':assessments.count('inconclusive'),
                'boundary':'This is an assessment summary only; it does not select a winning hypothesis or promote truth.'}
