"""Bounded self-healing and self-fixing orchestration.

A repair is never applied merely because it was generated.  Repairs are
represented as proposals, evaluated against an explicit baseline, and only
marked ready when the independent checks pass.  Code mutation or privilege
changes are outside this engine by design.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Callable, Any

from .core import TBOHK
from .learning import LearningEngine
from .independent_validation import IndependentSystemValidator
from .deep_assurance import DeepAssurance

@dataclass(frozen=True)
class RepairCandidate:
    repair_id: str
    target_id: str
    description: str
    expected_effect: str
    risk: str

@dataclass(frozen=True)
class RepairValidation:
    repair_id: str
    passed: bool
    checks: tuple[str, ...]
    failures: tuple[str, ...]

class SelfRepairController:
    """Create and validate repairs without silently mutating protected state."""
    def __init__(self, graph: TBOHK):
        self.g=graph
        self.learning=LearningEngine(graph)

    def propose(self, target_id: str, description: str, *, expected_effect: str, risk: str='medium') -> RepairCandidate:
        if not target_id or not description or not expected_effect:
            raise ValueError('target, description, and expected_effect are required')
        if self.g.get(target_id) is None:
            raise KeyError(target_id)
        if risk not in {'low','medium','high','critical'}:
            raise ValueError('invalid repair risk')
        node=self.g.add_node('RepairProposal', description, 'proposed', {
            'target_id':target_id,'description':description,'expected_effect':expected_effect,
            'risk':risk,'state':'proposed','created_at':datetime.now(timezone.utc).isoformat(),
        })
        self.g.link(node.id,'proposes',target_id)
        return RepairCandidate(node.id,target_id,description,expected_effect,risk)

    def validate(self, candidate: RepairCandidate, *, checks: dict[str, Callable[[], Any]]|None=None) -> RepairValidation:
        if self.g.get(candidate.repair_id) is None:
            raise KeyError(candidate.repair_id)
        checks=checks or {}
        passed=[]; failures=[]
        for name, fn in checks.items():
            try:
                result=fn()
                ok=bool(result.passed) if hasattr(result,'passed') else bool(result)
                (passed if ok else failures).append(name)
            except Exception as exc:
                failures.append(f'{name}:{type(exc).__name__}')
        independent=IndependentSystemValidator(self.g).run()
        if independent.passed: passed.append('independent_validation')
        else: failures.append('independent_validation')
        deep=DeepAssurance(self.g).run()
        if deep.passed: passed.append('deep_assurance')
        else: failures.append('deep_assurance')
        ok=not failures and bool(passed)
        self.g.set_status(candidate.repair_id, 'supported' if ok else 'failed', 'repair validation completed')
        self.g.update_metadata(candidate.repair_id, {'state':'validated' if ok else 'rejected','validation_checks':passed,'validation_failures':failures}, reason='repair validation')
        return RepairValidation(candidate.repair_id, ok, tuple(passed), tuple(failures))

    def propose_from_feedback(self, target_id: str, feedback: str, evaluation_ids: list[str], *, expected_effect: str) -> RepairCandidate:
        proposal=self.learning.propose_improvement(target_id, feedback, evaluations=evaluation_ids, expected_effect=expected_effect)
        self.g.update_metadata(proposal.id, {'repair_class':'learning_feedback'}, reason='classify learning improvement as repair candidate')
        return RepairCandidate(proposal.id,target_id,feedback,expected_effect,'medium')

    @staticmethod
    def as_dict(value): return asdict(value)
