from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
import hashlib
import json


@dataclass(frozen=True)
class CanaryDecision:
    canary_id: str
    experiment_id: str
    decision: str
    reasons: tuple[str, ...]
    rollback_required: bool
    decided_at: str


class LearningCanaryEngine:
    """Controlled canary/rollback simulator for learning candidates.

    This records release evidence and makes a deterministic rollback decision. It
    never changes production code, routing, or model authority.
    """

    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _digest(value: Any) -> str:
        raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode()).hexdigest()

    def run(
        self,
        experiment_id: str,
        *,
        observations: int,
        error_rate: float,
        latency_ms: float,
        baseline_latency_ms: float,
        max_error_rate: float = 0.05,
        max_latency_regression_pct: float = 10.0,
    ) -> CanaryDecision:
        exp = self.g.get(experiment_id)
        if not exp or exp.kind != "LearningExperiment":
            raise ValueError("invalid learning experiment")
        if observations < 1:
            raise ValueError("observations must be positive")
        for name, value in (("error_rate", error_rate), ("latency_ms", latency_ms), ("baseline_latency_ms", baseline_latency_ms), ("max_error_rate", max_error_rate), ("max_latency_regression_pct", max_latency_regression_pct)):
            if value < 0:
                raise ValueError(f"{name} must be non-negative")
        if max_error_rate > 1:
            raise ValueError("max_error_rate out of range")
        if exp.metadata.get("status") != "candidate_ready":
            raise ValueError("experiment is not candidate-ready")
        if baseline_latency_ms == 0:
            latency_regression = 0.0 if latency_ms == 0 else float("inf")
        else:
            latency_regression = ((latency_ms - baseline_latency_ms) / baseline_latency_ms) * 100.0
        reasons: list[str] = []
        if error_rate > max_error_rate:
            reasons.append("canary error rate exceeds budget")
        if latency_regression > max_latency_regression_pct:
            reasons.append("canary latency regression exceeds budget")
        decision = "rollback" if reasons else "continue"
        payload = {
            "experiment_id": experiment_id,
            "observations": observations,
            "error_rate": float(error_rate),
            "latency_ms": float(latency_ms),
            "baseline_latency_ms": float(baseline_latency_ms),
            "latency_regression_pct": latency_regression,
            "max_error_rate": float(max_error_rate),
            "max_latency_regression_pct": float(max_latency_regression_pct),
            "decision": decision,
            "reasons": reasons,
            "decided_at": self._now(),
        }
        node = self.g.add_node("LearningCanary", "learning candidate canary", "supported", {**payload, "canary_sha256": self._digest(payload)})
        self.g.link(node.id, "evaluates", experiment_id)
        rollback = decision == "rollback"
        if rollback:
            rollback_node = self.g.add_node("LearningRollback", "learning candidate rollback", "supported", {
                "canary_id": node.id,
                "experiment_id": experiment_id,
                "reason": reasons,
                "created_at": self._now(),
                "rollback_sha256": self._digest({"canary_id": node.id, "reasons": reasons}),
            })
            self.g.link(node.id, "reverses", rollback_node.id)
        return CanaryDecision(node.id, experiment_id, decision, tuple(reasons), rollback, node.created_at)

    def report(self, canary_id: str) -> dict[str, Any]:
        node = self.g.get(canary_id)
        if not node or node.kind != "LearningCanary":
            raise ValueError("invalid learning canary")
        return {"canary_id": node.id, **node.metadata, "status": node.status}
