from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
from datetime import datetime, timezone
import hashlib, re
from urllib.parse import urlparse
from typing import Any


@dataclass(frozen=True)
class ResearchGap:
    kind: str
    priority: int
    description: str
    claim_ids: tuple[str, ...] = ()
    suggested_action: str = ""


class ResearchAgent:
    """Bounded research-planning intelligence over the existing knowledge graph.

    This module plans and diagnoses research. It does not assign truth scores,
    promote claims, or rewrite verification state.
    """
    GAP_PRIORITY = {"critical": 5, "high": 4, "medium": 3, "low": 2}

    def __init__(self, graph):
        self.g = graph

    def _claims_for_question(self, question: str, limit: int = 30):
        terms = {x for x in re.findall(r"[a-z0-9]{3,}", question.casefold()) if x not in {
            "what", "which", "where", "when", "does", "how", "why", "are", "the", "and", "for", "with", "from", "that", "this", "about"
        }}
        rows = self.g.db.execute("SELECT id FROM nodes WHERE kind='Claim' ORDER BY rowid DESC").fetchall()
        scored = []
        for row in rows:
            c = self.g.get(row[0])
            if not c:
                continue
            words = set(re.findall(r"[a-z0-9]{3,}", c.content.casefold()))
            score = len(terms & words)
            if score:
                scored.append((score, c.id, c))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [c for _, _, c in scored[:max(1, min(limit, 100))]]

    def _evidence(self, claim_id: str):
        ids = set()
        for r in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='evidence_for' AND (source_id=? OR target_id=?)", (claim_id, claim_id)):
            ids.add(r[1] if r[0] == claim_id else r[0])
        return [self.g.get(x) for x in sorted(ids) if self.g.get(x) and self.g.get(x).kind == "Evidence"]

    def _origins(self, evidence):
        out = set()
        for e in evidence:
            m = e.metadata or {}
            origin = m.get("origin_id") or m.get("publisher_id") or m.get("source_id")
            if origin:
                out.add(str(origin).casefold())
        return out

    def _source_family(self, evidence):
        """Group evidence by likely upstream origin, without claiming identity."""
        keys = set()
        for e in evidence:
            m = e.metadata or {}
            upstream = m.get("upstream_origin_ids") or m.get("source_family") or []
            if isinstance(upstream, str):
                upstream = [upstream]
            if upstream:
                keys.update(str(x).casefold() for x in upstream if x)
                continue
            uri = m.get("url") or m.get("uri")
            if uri:
                host = urlparse(str(uri)).netloc.casefold().removeprefix("www.")
                if host:
                    keys.add("host:" + host)
            elif m.get("origin_id"):
                keys.add("origin:" + str(m["origin_id"]).casefold())
        return keys

    def claim_leverage(self, claim_id: str, *, max_nodes: int = 100) -> dict[str, Any]:
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim":
            raise ValueError(f"not a Claim: {claim_id}")
        downstream = []
        q = deque([(claim_id, 0)])
        seen = {claim_id}
        while q and len(seen) <= max_nodes:
            current, distance = q.popleft()
            for r in self.g.db.execute("SELECT source_id,target_id,relation FROM edges WHERE relation IN ('derived_from','depends_on','supports','premise_of') AND target_id=?", (current,)):
                nxt = r[0]
                if nxt in seen:
                    continue
                seen.add(nxt)
                n = self.g.get(nxt)
                if n:
                    downstream.append({"id": n.id, "kind": n.kind, "status": n.status, "distance": distance + 1, "relation": r[2]})
                    q.append((nxt, distance + 1))
        downstream.sort(key=lambda x: (x["distance"], x["id"]))
        return {"claim_id": claim_id, "direct_dependents": sum(1 for x in downstream if x["distance"] == 1),
                "bounded_downstream_count": len(downstream), "downstream": downstream[:max_nodes],
                "bounded": len(seen) > max_nodes, "interpretation": "Structural dependency only; not a truth or importance score."}

    def claim_lineage(self, claim_id: str, *, max_nodes: int = 80) -> dict[str, Any]:
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim":
            raise ValueError(f"not a Claim: {claim_id}")
        nodes = {claim.id: {"id": claim.id, "kind": claim.kind, "status": claim.status, "content": claim.content}}
        edges = []
        q = deque([claim.id]); seen = {claim.id}
        while q and len(nodes) < max_nodes:
            current = q.popleft()
            for r in self.g.db.execute("SELECT source_id,target_id,relation FROM edges WHERE relation IN ('derived_from','evidence_for') AND (source_id=? OR target_id=?)", (current, current)):
                other = r[1] if r[0] == current else r[0]
                if other == current:
                    continue
                n = self.g.get(other)
                if not n or n.kind not in {"Claim", "Evidence"}:
                    continue
                edges.append({"source": r[0], "target": r[1], "relation": r[2]})
                if other not in seen:
                    seen.add(other); nodes[other] = {"id": n.id, "kind": n.kind, "status": n.status, "content": n.content}
                    q.append(other)
        # Attach provenance leaves without fetching content or changing state.
        for nid, item in list(nodes.items()):
            n = self.g.get(nid)
            if n and n.kind == "Evidence":
                m = n.metadata or {}
                item["provenance"] = {k: m.get(k) for k in ("url", "uri", "publisher_id", "origin_id", "upstream_origin_ids", "retrieved_at", "published_at") if m.get(k) is not None}
        return {"claim_id": claim_id, "nodes": list(nodes.values()), "edges": edges,
                "bounded": len(nodes) >= max_nodes, "interpretation": "Lineage records relationships and provenance; it does not establish truth."}

    def challenge_claim(self, claim_id: str) -> dict[str, Any]:
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim":
            raise ValueError(f"not a Claim: {claim_id}")
        text = claim.content.strip()
        lower = text.casefold()
        challenges = [
            ("scope", "Does the claim hold across the full population, place, or context it appears to describe?"),
            ("time", "Would the claim still hold for the relevant time period, or could it have changed?"),
            ("measurement", "Could a different definition, measurement method, denominator, or unit explain the result?"),
            ("counterevidence", "What credible evidence would directly contradict this claim?"),
            ("alternative_explanation", "What other explanation could produce the same observation without this claim being true?"),
            ("primary_source", "Can the supporting statement be traced to a primary source, dataset, experiment, filing, or source-of-record?"),
        ]
        if any(x in lower for x in ("cause", "causes", "because", "leads to", "results in")):
            challenges.append(("causality", "Is the relationship causal, or could confounding, selection, reverse causation, or coincidence explain it?"))
        if re.search(r"\b(all|none|always|never|only|every)\b", lower):
            challenges.append(("universality", "Is the absolute wording justified, or are there documented exceptions?"))
        return {"claim_id": claim_id, "claim": text, "challenge_mode": "adversarial_research",
                "tests":[{"kind": k, "question": q} for k, q in challenges],
                "boundary": "These are research prompts, not counterclaims or truth judgments."}

    def gaps(self, question: str, claim_ids: list[str] | None = None) -> dict[str, Any]:
        claims = [self.g.get(x) for x in (claim_ids or [])]
        claims = [c for c in claims if c and c.kind == "Claim"] or self._claims_for_question(question)
        gaps: list[ResearchGap] = []
        if not claims:
            gaps.extend([
                ResearchGap("coverage", 5, "No matching claims are currently represented in the knowledge graph.", (), "Acquire initial evidence from multiple relevant source roles."),
                ResearchGap("definition", 4, "The question has no established scope or terminology in the current graph.", (), "Define the key entities, measures, population, and time period."),
            ])
        for c in claims:
            evidence = self._evidence(c.id); origins = self._origins(evidence); families = self._source_family(evidence)
            if not evidence:
                gaps.append(ResearchGap("coverage", 5, f"Claim lacks direct evidence: {c.content}", (c.id,), "Gather direct evidence."))
            elif len(origins) < 2:
                gaps.append(ResearchGap("independence", 4, f"Claim has evidence but fewer than two distinct origins: {c.content}", (c.id,), "Seek an independent origin rather than another copy."))
            if evidence and len(families) == 1 and len(evidence) > 1:
                gaps.append(ResearchGap("source_family", 4, f"Multiple evidence items may share one upstream source family: {c.content}", (c.id,), "Trace citations upstream to the source-of-record."))
            structured = (c.metadata or {}).get("structured") or {}
            if not structured.get("scope"):
                gaps.append(ResearchGap("scope", 3, f"Claim has no explicit scope: {c.content}", (c.id,), "Clarify population, geography, conditions, or applicability."))
            if not structured.get("time"):
                gaps.append(ResearchGap("time", 3, f"Claim has no explicit time scope: {c.content}", (c.id,), "Check publication, observation, applicable, and expiration dates."))
            if c.status in {"proposed", "unknown", "stale", "contradicted"}:
                gaps.append(ResearchGap("verification", 4, f"Claim remains {c.status}: {c.content}", (c.id,), "Send the claim through the existing verification/review workflow."))
            if not (c.metadata or {}).get("structured"):
                gaps.append(ResearchGap("semantics", 2, f"Claim lacks structured subject/predicate/object fields: {c.content}", (c.id,), "Extract or record structured claim semantics."))
        dedup = {}
        for g in gaps:
            key=(g.kind,g.claim_ids,g.description)
            dedup[key]=g
        ordered=sorted(dedup.values(), key=lambda x:(-x.priority,x.kind,x.description))
        return {"question":question,"claim_ids":[c.id for c in claims],"gaps":[asdict(x) for x in ordered[:100]],
                "counts":{k:sum(1 for x in ordered if x.kind==k) for k in sorted({x.kind for x in ordered})},
                "bounded":True,"not_a_truth_score":True}

    def source_families(self, claim_id: str) -> dict[str, Any]:
        claim=self.g.get(claim_id)
        if not claim or claim.kind!='Claim': raise ValueError(f"not a Claim: {claim_id}")
        evidence=self._evidence(claim_id); groups=defaultdict(list)
        for e in evidence:
            m=e.metadata or {}; upstream=m.get('upstream_origin_ids') or m.get('source_family')
            if isinstance(upstream,str): upstream=[upstream]
            if upstream: key='upstream:' + '|'.join(sorted(str(x).casefold() for x in upstream if x))
            else:
                uri=m.get('url') or m.get('uri'); host=urlparse(str(uri)).netloc.casefold().removeprefix('www.') if uri else ''
                key='host:'+host if host else 'origin:'+str(m.get('origin_id') or e.id).casefold()
            groups[key].append(e.id)
        return {"claim_id":claim_id,"families":[{"family":k,"evidence_ids":sorted(v),"count":len(v)} for k,v in sorted(groups.items())],
                "interpretation":"Likely source-family grouping; shared hosting does not prove common authorship."}

    def plan(self, question: str, claim_ids: list[str] | None = None, *, max_steps: int = 8) -> dict[str, Any]:
        gap_report=self.gaps(question,claim_ids)
        gaps=gap_report['gaps']
        actions=[]; seen=set()
        for g in gaps:
            action=g['suggested_action']
            if action and action not in seen:
                seen.add(action); actions.append({"step":len(actions)+1,"kind":g['kind'],"priority":g['priority'],"action":action,"claim_ids":g['claim_ids']})
            if len(actions)>=max_steps: break
        if not actions:
            actions=[{"step":1,"kind":"recheck","priority":2,"action":"Reassess the evidence after the next material change and record what changed.","claim_ids":gap_report['claim_ids']}]
        now=datetime.now(timezone.utc).isoformat(); q=question.strip()
        plan_id='agentplan_'+hashlib.sha256((q+'|'+now).encode()).hexdigest()[:20]
        return {"plan_id":plan_id,"question":q,"steps":actions,"claim_ids":gap_report['claim_ids'],
                "stopping_rule":"Stop when required evidence gaps are addressed, remaining conflicts are explicit, and no unresolved high-priority gap is silently treated as resolved.",
                "created_at":now,"bounded":True,"truth_boundary":"The plan chooses research actions from structural gaps; it does not choose which claim is true."}

    def run_diagnostics(self, question: str, *, claim_ids: list[str] | None = None) -> dict[str, Any]:
        claims=[self.g.get(x) for x in (claim_ids or [])]; claims=[c for c in claims if c and c.kind=='Claim'] or self._claims_for_question(question)
        leverage=[self.claim_leverage(c.id) for c in claims]
        challenges=[self.challenge_claim(c.id) for c in claims]
        families=[self.source_families(c.id) for c in claims]
        return {"question":question,"gaps":self.gaps(question,[c.id for c in claims]),"plan":self.plan(question,[c.id for c in claims]),
                "leverage":sorted(leverage,key=lambda x:(-x['bounded_downstream_count'],x['claim_id']))[:30],
                "challenges":challenges[:30],"source_families":families[:30],
                "interpretation":"Bounded structural research intelligence. No truth score, confidence score, or automatic promotion is produced."}
