from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Callable, Any
import json

@dataclass(frozen=True)
class ExecutionSpec:
    id: str
    task_id: str
    state: str
    attempt: int
    started_at: str
    finished_at: str|None
    result: dict[str, Any]

class BoundedExecutor:
    """Deterministic execution coordinator with explicit retry and idempotency boundaries."""
    def __init__(self, graph): self.g=graph; self.handlers: dict[str,Callable[[dict],dict]]={}
    def register(self, task_kind: str, handler: Callable[[dict],dict]): self.handlers[task_kind]=handler
    def execute(self, task_id: str, *, max_attempts=1) -> ExecutionSpec:
        task=self.g.get(task_id)
        if not task or task.kind != "MaintenanceTask": raise ValueError("maintenance task required")
        meta=task.metadata
        if meta.get("execution_id"):
            n=self.g.get(meta["execution_id"])
            if n: return self._spec(n)
        max_attempts=max(1,min(int(max_attempts),3)); started=datetime.now(timezone.utc).isoformat()
        handler=self.handlers.get(meta.get("kind") or meta.get("task_kind"))
        last={"state":"queued_for_review","reason":"no registered safe handler"}
        attempt=0
        while attempt < max_attempts:
            attempt += 1
            if not handler: break
            try:
                result=dict(handler(meta)); result.setdefault("state","completed"); last=result; break
            except Exception as exc:
                last={"state":"failed","error":type(exc).__name__,"message":str(exc)}
        finished=datetime.now(timezone.utc).isoformat()
        n=self.g.add_node("MaintenanceExecution",f"Execution {task_id}","supported",{**last,"task_id":task_id,"attempt":attempt,"started_at":started,"finished_at":finished})
        self.g.link(n.id,"records",task_id)
        self.g.update_metadata(task_id,{"execution_id":n.id,"execution_state":last.get("state"),"attempt":attempt},reason="bounded execution recorded")
        return self._spec(n)
    def _spec(self,n):
        m=n.metadata
        return ExecutionSpec(n.id,m["task_id"],m["state"],int(m.get("attempt",1)),m["started_at"],m.get("finished_at"),{k:v for k,v in m.items() if k not in {"task_id","state","attempt","started_at","finished_at"}})
