from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

@dataclass(frozen=True)
class WorkspaceResult:
    decision_id: str
    workspace_id: str

class DecisionWorkspace:
    """Structured decision context without selecting an outcome."""
    def __init__(self, graph): self.g = graph
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    def create(self, title: str, *, objective="", question="", requirements=None, constraints=None, alternatives=None, assumptions=None, unknowns=None, entity_id=None):
        if not str(title).strip(): raise ValueError("decision title required")
        d=self.g.add_node("DecisionWorkspace", title.strip(), "proposed", {
            "objective": str(objective or "").strip(), "question": str(question or "").strip(),
            "requirements": list(requirements or [])[:100], "constraints": list(constraints or [])[:100],
            "created_at": self._now()
        })
        if entity_id:
            if not self.g.get(entity_id): raise ValueError("invalid entity")
            self.g.link(d.id,"about",entity_id)
        for kind, relation, values in (("DecisionAlternative","contains",alternatives), ("DecisionAssumption","assumes",assumptions), ("DecisionUnknown","depends_on",unknowns)):
            for i, value in enumerate(values or []):
                if isinstance(value, dict):
                    content=str(value.get("text") or value.get("name") or "").strip(); meta=dict(value)
                else: content=str(value).strip(); meta={}
                if not content: continue
                meta.update({"decision_id":d.id,"position":i,"created_at":self._now()})
                n=self.g.add_node(kind,content,"proposed",meta); self.g.link(d.id,relation,n.id)
        return WorkspaceResult(d.id,d.id)
    def _children(self, decision_id, relation, kind):
        return [self.g.get(x["target_id"]) for x in self.g.edges(decision_id,"out",relation) if self.g.get(x["target_id"]) and self.g.get(x["target_id"]).kind==kind]
    def _linked(self, node_id, relation): return [self.g.get(x["target_id"]) for x in self.g.edges(node_id,"out",relation) if self.g.get(x["target_id"])]
    def _change_conditions(self, decision_id):
        assumptions=self._children(decision_id,"assumes","DecisionAssumption")
        out=[]
        for a in assumptions:
            evidence=self._linked(a.id,"based_on")
            out.append({"assumption_id":a.id,"assumption":a.content,"strengthen_with":(a.metadata or {}).get("strengthen_with",[]),"weaken_with":(a.metadata or {}).get("weaken_with",[]),"overturn_with":(a.metadata or {}).get("overturn_with",[]),"evidence_ids":[e.id for e in evidence]})
        return out
    def inspect(self, decision_id):
        d=self.g.get(decision_id)
        if not d or d.kind!="DecisionWorkspace": raise ValueError("invalid decision workspace")
        alternatives=self._children(decision_id,"contains","DecisionAlternative")
        assumptions=self._children(decision_id,"assumes","DecisionAssumption")
        unknowns=self._children(decision_id,"depends_on","DecisionUnknown")
        evidence=[]
        for rel in ("based_on","supports","evidence_for"):
            evidence.extend(self._linked(decision_id,rel))
        evidence={x.id:x for x in evidence}
        sensitivity=[]
        for u in unknowns:
            affected=(u.metadata or {}).get("affects") or []
            sensitivity.append({"unknown_id":u.id,"unknown":u.content,"affects":affected,"information_value":"high" if len(affected)>=2 else "local"})
        return {"decision": {"id":d.id,"title":d.content,"status":d.status,"metadata":d.metadata},"alternatives":[{"id":x.id,"text":x.content,"metadata":x.metadata} for x in alternatives],"assumptions":[{"id":x.id,"text":x.content,"metadata":x.metadata,"evidence_ids":[e.id for e in self._linked(x.id,"based_on")]} for x in assumptions],"unknowns":[{"id":x.id,"text":x.content,"metadata":x.metadata} for x in unknowns],"evidence_ids":sorted(evidence),"change_my_mind":self._change_conditions(decision_id),"sensitivity":sensitivity,"boundary":"This workspace organizes evidence, assumptions and unknowns; it does not select an alternative or assign a decision score."}
