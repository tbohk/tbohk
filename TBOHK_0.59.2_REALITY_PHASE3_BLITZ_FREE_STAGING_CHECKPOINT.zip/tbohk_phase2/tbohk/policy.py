from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class PolicyRule:
    name: str
    effect: str
    conditions: dict[str, Any]

@dataclass(frozen=True)
class PolicySpec:
    policy_id: str
    version: str
    rules: tuple[PolicyRule, ...]

class PolicyEngine:
    """Small declarative policy layer; enforcement remains explicit and auditable."""
    def __init__(self, spec: PolicySpec): self.spec=spec
    def evaluate(self, action: str, context: dict[str,Any]) -> dict[str,Any]:
        matches=[]
        for r in self.spec.rules:
            if r.name==action and all(context.get(k)==v for k,v in r.conditions.items()): matches.append(r)
        decision='allow' if any(r.effect=='allow' for r in matches) and not any(r.effect=='deny' for r in matches) else 'deny'
        return {'policy_id':self.spec.policy_id,'version':self.spec.version,'action':action,'decision':decision,'matched_rules':[r.name for r in matches]}
