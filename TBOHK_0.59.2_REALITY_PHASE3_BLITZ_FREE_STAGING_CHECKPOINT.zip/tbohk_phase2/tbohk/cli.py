from __future__ import annotations
import argparse
import json
import os
from .core import TBOHK
from . import __version__


def _graph() -> TBOHK:
    return TBOHK(os.getenv("TBOHK_DB", os.path.expanduser("~/.tbohk/tbohk.sqlite")))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="tbohk", description="The Book of Human Knowledge")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("version", help="print the package version")
    sub.add_parser("stats", help="print graph statistics")
    sub.add_parser("audit", help="run the graph audit")
    sub.add_parser("selfcare", help="run non-destructive operational self-care checks")
    sub.add_parser("invariants", help="print the canonical invariant registry")
    sub.add_parser("migrations", help="show schema migration history and health")
    sub.add_parser("drill", help="run a non-production corruption detection drill against a file-backed DB")
    backup_parser=sub.add_parser("backup", help="create and verify a SQLite backup")
    backup_parser.add_argument("path")
    web_parser=sub.add_parser("web", help="start the TBOHK operator console")
    web_parser.add_argument("--host",default="127.0.0.1")
    web_parser.add_argument("--port",type=int,default=8000)
    args = parser.parse_args(argv)
    if args.command == "version":
        print(__version__)
        return 0
    if args.command == "stats":
        g=_graph()
        print(json.dumps({"nodes":g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],"edges":g.db.execute("SELECT COUNT(*) FROM edges").fetchone()[0],"events":g.db.execute("SELECT COUNT(*) FROM events").fetchone()[0],"revisions":g.db.execute("SELECT COUNT(*) FROM revisions").fetchone()[0]},sort_keys=True))
        return 0
    if args.command == "audit":
        report=_graph().audit()
        print(json.dumps(report,sort_keys=True,default=str))
        return 0 if report.get("ok") else 2
    if args.command == "invariants":
        from .invariants import registry
        print(json.dumps({"invariants":registry()},sort_keys=True))
        return 0
    if args.command == "migrations":
        g=_graph(); print(json.dumps(g.migrations.verify(),sort_keys=True,default=str)); return 0 if g.migrations.verify()["ok"] else 2
    if args.command == "drill":
        from .recovery_drill import RecoveryDrill
        report=RecoveryDrill(_graph()).run(); print(json.dumps(RecoveryDrill.as_dict(report),sort_keys=True)); return 0 if all(x.detected and x.independent_detected for x in report if x.destructive) else 2
    if args.command == "selfcare":
        from .selfcare import SelfCareEngine
        report=SelfCareEngine(_graph()).inspect()
        print(json.dumps(SelfCareEngine.as_dict(report),sort_keys=True,default=str))
        return 0 if report.passed else 2
    if args.command == "backup":
        from .selfcare import SelfCareEngine
        result=SelfCareEngine(_graph()).backup(args.path)
        print(json.dumps(result,sort_keys=True))
        return 0
    if args.command == "web":
        import uvicorn
        import ipaddress
        try:
            addr=ipaddress.ip_address(args.host)
            loopback=addr.is_loopback
        except ValueError:
            loopback=args.host.lower() in {"localhost"}
        if not loopback and not os.getenv("TBOHK_API_TOKEN"):
            print("Refusing non-loopback bind without TBOHK_API_TOKEN", file=__import__("sys").stderr)
            return 2
        uvicorn.run("tbohk.api:app",host=args.host,port=args.port,reload=False)
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
