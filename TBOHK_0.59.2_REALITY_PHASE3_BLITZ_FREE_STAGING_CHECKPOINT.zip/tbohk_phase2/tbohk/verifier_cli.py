from __future__ import annotations
import argparse, json, sqlite3
from .independent_validation import IndependentSystemValidator
from .core import TBOHK

def verify_database(path: str) -> dict:
    g=TBOHK(path)
    report=IndependentSystemValidator(g).run()
    return {"passed":report.passed,"checks_run":report.checks_run,"findings":[f.__dict__ for f in report.findings]}

def main(argv=None):
    p=argparse.ArgumentParser(prog='tbohk-verify'); p.add_argument('database'); args=p.parse_args(argv)
    result=verify_database(args.database); print(json.dumps(result,sort_keys=True,default=str)); return 0 if result['passed'] else 2
if __name__=='__main__': raise SystemExit(main())
