from __future__ import annotations
from dataclasses import dataclass
import json
from collections import deque

INVALIDATING = {"stale", "contradicted", "failed", "rejected", "superseded"}
DEPENDENCY_RELATIONS = {"based_on", "evidence_for", "derived_from", "depends_on", "supports", "premise_of"}

@dataclass(frozen=True)
class LifecycleFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    invariant: str
    blocks_release: bool
    evidence: str

@dataclass(frozen=True)
class InvalidationPlan:
    root_ids: tuple[str, ...]
    affected_ids: tuple[str, ...]
    proposed_statuses: tuple[tuple[str, str], ...]
    reasons: tuple[tuple[str, str], ...]

@dataclass(frozen=True)
class LifecycleReport:
    passed: bool
    findings: tuple[LifecycleFinding, ...]
    plans: tuple[InvalidationPlan, ...]

class KnowledgeLifecycleAuditor:
    """G18 lifecycle auditor: dependency-aware invalidation without self-certifying mutation.

    It computes the transitive blast radius of invalid/stale knowledge and detects
    cases where downstream verified state remains live after a dependency fails.
    The auditor is observational; it never changes graph state.
    """
    def __init__(self, graph):
        self.g = graph

    def _reverse_dependencies(self, node_id):
        q = deque([node_id]); seen=set(); out=[]
        while q:
            cur=q.popleft()
            if cur in seen: continue
            seen.add(cur)
            placeholders=",".join("?" for _ in DEPENDENCY_RELATIONS)
            rows=self.g.db.execute(
                f"SELECT target_id, relation FROM edges WHERE source_id=? AND relation IN ({placeholders})",
                (cur, *DEPENDENCY_RELATIONS)
            ).fetchall()
            # derived_from is encoded as dependent -> dependency, so reverse it.
            rows += self.g.db.execute(
                "SELECT source_id, relation FROM edges WHERE target_id=? AND relation='derived_from'",
                (cur,)
            ).fetchall()
            for r in rows:
                target=r[0]
                if target not in seen:
                    out.append(target); q.append(target)
        return tuple(out)

    def impact(self, root_ids):
        affected=set()
        for rid in root_ids:
            if self.g.get(rid): affected.update(self._reverse_dependencies(rid))
        return tuple(sorted(affected))

    def plan_invalidation(self, root_ids):
        roots=tuple(sorted(set(root_ids)))
        affected=self.impact(roots)
        proposals=[]; reasons=[]
        for nid in affected:
            n=self.g.get(nid)
            if not n: continue
            if n.kind in {"Claim", "Knowledge", "Decision", "Plan"} and n.status == "verified":
                proposals.append((nid, "stale"))
                reasons.append((nid, "transitive dependency invalidated"))
        return InvalidationPlan(roots, affected, tuple(proposals), tuple(reasons))

    def audit(self):
        findings=[]; plans=[]
        roots=[]
        rows=self.g.db.execute("SELECT id,status FROM nodes WHERE status IN ('stale','contradicted','failed','rejected','superseded') ORDER BY id").fetchall()
        roots=[r[0] for r in rows]
        for rid in roots:
            plan=self.plan_invalidation((rid,)); plans.append(plan)
            for nid in plan.affected_ids:
                n=self.g.get(nid)
                if n and n.status == "verified" and n.kind in {"Claim","Knowledge","Decision","Plan"}:
                    findings.append(LifecycleFinding(
                        "verified_state_after_invalid_dependency","critical",(rid,nid),"I18",True,
                        f"{n.kind} remains verified although dependency closure includes invalidated node {rid}"
                    ))
        # A superseding source/claim must not leave its direct successor ambiguous.
        for r in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='supersedes'").fetchall():
            old,new=self.g.get(r[0]),self.g.get(r[1])
            if old and new and old.status not in INVALIDATING:
                findings.append(LifecycleFinding("invalid_supersession_direction","high",(r[0],r[1]),"I18",True,"superseding node is not active while superseded node is linked"))
        # Plans must never be presented as executable verified knowledge merely because a root is stale.
        for r in self.g.db.execute("SELECT id,metadata,status FROM nodes WHERE kind='Plan'").fetchall():
            try: meta=json.loads(r[1])
            except Exception:
                findings.append(LifecycleFinding("malformed_plan_metadata","critical",(r[0],),"I18",True,"plan metadata is not valid JSON")); continue
            deps=meta.get("dependency_ids",[])
            if r[2]=="verified" and any(self.g.get(d) and self.g.get(d).status in INVALIDATING for d in deps):
                findings.append(LifecycleFinding("verified_plan_with_invalid_dependency","critical",(r[0],),"I18",True,"verified plan declares an invalid dependency"))
        return LifecycleReport(not any(f.blocks_release for f in findings), tuple(findings), tuple(plans))
