from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta

@dataclass(frozen=True)
class RealityResult:
    observation_id:str
    fresh:bool

class RealityEngine:
    """Separates external observation from representation and checks freshness explicitly."""
    def __init__(self,graph): self.g=graph
    def observe(self, source, observation, *, observed_at=None, retrieved_at=None, locator=None, polarity='positive', external=True):
        now=datetime.now(timezone.utc)
        oa=observed_at or now.isoformat(); ra=retrieved_at or now.isoformat()
        n=self.g.add_node('Observation',observation,'supported',{
            'source':source,'observed_at':oa,'retrieved_at':ra,'locator':locator,
            'polarity':polarity,'external':external})
        return n
    def freshness(self, observation_id, *, max_age_seconds, now=None):
        n=self.g.get(observation_id)
        if not n or n.kind!='Observation': raise ValueError('invalid observation')
        t=datetime.fromisoformat(n.metadata['retrieved_at'].replace('Z','+00:00'))
        now=now or datetime.now(timezone.utc)
        fresh=(now-t)<=timedelta(seconds=max_age_seconds)
        self.g._event('observation.freshness_checked',observation_id,{'fresh':fresh,'max_age_seconds':max_age_seconds,'checked_at':now.isoformat()})
        return RealityResult(observation_id,fresh)
    def contradict(self, observation_a, observation_b, *, reason):
        a=self.g.get(observation_a); b=self.g.get(observation_b)
        if not a or not b or a.kind!='Observation' or b.kind!='Observation': raise ValueError('observations required')
        c=self.g.add_node('RealityConflict',f'{a.content} vs {b.content}','proposed',{'observation_ids':[a.id,b.id],'reason':reason})
        self.g.link(a.id,'contradicts',b.id); self.g.link(c.id,'records',a.id); self.g.link(c.id,'records',b.id)
        return c
    def verify_action(self, action_id, observation_id, *, expected_effect, actual_effect):
        a=self.g.get(action_id); o=self.g.get(observation_id)
        if not a or a.kind!='Action' or not o or o.kind!='Observation': raise ValueError('action and observation required')
        ok=expected_effect == actual_effect
        v=self.g.add_node('PostActionVerification',f'Verification {action_id}','supported',{'action_id':action_id,'observation_id':observation_id,'expected_effect':expected_effect,'actual_effect':actual_effect,'verified':ok})
        self.g.link(v.id,'evaluates',action_id); self.g.link(v.id,'based_on',observation_id)
        if ok:
            self.g.link(v.id,'verified_by',action_id)
        self.g._event('action.post_verified',action_id,{'verification_id':v.id,'verified':ok})
        return v
