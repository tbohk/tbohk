from __future__ import annotations
from dataclasses import dataclass, asdict
import re
from .core import TBOHK

@dataclass(frozen=True)
class InvestigationTarget:
    prediction_id: str
    hypothesis_ids: tuple[str, ...]
    statement: str
    discriminator: bool
    assessed: bool
    discrimination_potential: str
    priority: int
    rationale: tuple[str, ...]

@dataclass(frozen=True)
class InvestigationPlan:
    hypothesis_ids: tuple[str, ...]
    targets: tuple[InvestigationTarget, ...]
    boundary: str

class AdaptiveInvestigator:
    """Deterministic evidence-selection layer.

    Ranks unresolved predictions by their potential to distinguish explicit
    alternatives. The ranking is a research heuristic, not a probability,
    truth score, or authorization to perform an external experiment.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def _terms(text: str) -> set[str]:
        stop = {'the','a','an','is','are','to','of','for','and','or','in','on','by','with','that','this','will','would','should'}
        return {x for x in re.findall(r'[a-z0-9]+', text.lower()) if x not in stop}

    def _prediction_nodes(self, hypothesis_ids):
        seen = {}
        for hid in dict.fromkeys(hypothesis_ids):
            h = self.g.get(hid)
            if not h or h.kind != 'Hypothesis':
                raise ValueError(f'not a Hypothesis: {hid}')
            for edge in self.g.edges(hid, direction='out', relation='predicts'):
                p = self.g.get(edge['target_id'])
                if p and p.kind == 'Prediction':
                    seen.setdefault(p.id, {'prediction': p, 'hypotheses': []})['hypotheses'].append(hid)
        return seen

    def rank_targets(self, hypothesis_ids: list[str]) -> list[InvestigationTarget]:
        if not hypothesis_ids:
            raise ValueError('at least one hypothesis required')
        data = self._prediction_nodes(hypothesis_ids)
        all_terms = {pid: self._terms(v['prediction'].content) for pid, v in data.items()}
        results=[]
        for pid, item in data.items():
            p=item['prediction']; hs=tuple(dict.fromkeys(item['hypotheses']))
            assessed=any(e['relation']=='evaluated_by' for e in self.g.edges(pid, direction='out'))
            discriminator=bool(p.metadata.get('discriminator', False))
            competing_terms=[]
            for other_id, other in data.items():
                if other_id == pid or set(other['hypotheses']) & set(hs):
                    continue
                competing_terms.extend(all_terms[other_id])
            unique = bool(all_terms[pid] - set(competing_terms))
            if discriminator and unique:
                potential='high'; base=100; rationale=['explicit discriminator','contains terms not shared by competing predictions']
            elif discriminator:
                potential='medium'; base=70; rationale=['explicit discriminator']
            elif unique:
                potential='medium'; base=50; rationale=['prediction differs lexically from competing predictions']
            else:
                potential='low'; base=20; rationale=['prediction is not explicitly discriminating']
            if assessed:
                base -= 40; rationale.append('already has an observation assessment')
            else:
                rationale.append('no observation assessment recorded')
            if len(hs) > 1:
                base -= 10; rationale.append('prediction is shared by multiple hypotheses')
            results.append(InvestigationTarget(pid, hs, p.content, discriminator, assessed, potential, max(0,base), tuple(rationale)))
        return sorted(results, key=lambda x: (-x.priority, x.prediction_id))

    def plan(self, hypothesis_ids: list[str], max_targets: int = 5) -> InvestigationPlan:
        if not 1 <= max_targets <= 20:
            raise ValueError('max_targets must be between 1 and 20')
        targets=tuple(self.rank_targets(hypothesis_ids)[:max_targets])
        return InvestigationPlan(tuple(dict.fromkeys(hypothesis_ids)), targets,
            'Ranking identifies potentially informative observations; it does not establish truth, choose a winning hypothesis, or authorize external action.')
