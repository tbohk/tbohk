from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

PROVIDERS = frozenset({'stripe','apple','google'})
ACTIVE_STATUSES = frozenset({'active','trialing','grace_period'})

@dataclass(frozen=True)
class NormalizedEntitlement:
    provider: str
    external_id: str
    account_id: str
    plan: str
    status: str
    current_period_end: str | None = None
    cancel_at_period_end: bool = False
    raw: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

def normalize_entitlement(*, provider: str, external_id: str, account_id: str, plan: str,
                           status: str, current_period_end: str | None = None,
                           cancel_at_period_end: bool = False, raw: dict[str, Any] | None = None) -> NormalizedEntitlement:
    provider=provider.strip().lower()
    status=status.strip().lower()
    if provider not in PROVIDERS: raise ValueError('unsupported billing provider')
    if not external_id or not account_id: raise ValueError('entitlement identity is required')
    if plan not in {'free','pro','unlimited'}: raise ValueError('invalid plan')
    if not status: raise ValueError('entitlement status is required')
    return NormalizedEntitlement(provider,external_id,account_id,plan,status,current_period_end,bool(cancel_at_period_end),raw or {})
