"""Controlled, reversible fault probes for the self-auditing system."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Any

@dataclass(frozen=True)
class FaultProbe:
    fault_id: str
    expected_detection: str
    reversible: bool = True

class FaultInjectionLab:
    ALLOWED = {"dropped_event", "duplicate_event", "stale_projection", "missing_link", "bad_metadata"}
    def run(self, fault_id: str, *, detect: Callable[[], Any]) -> bool:
        if fault_id not in self.ALLOWED:
            raise ValueError("unsupported fault probe")
        if not callable(detect):
            raise ValueError("detector required")
        return bool(detect())

    def probes(self) -> tuple[FaultProbe, ...]:
        return tuple(FaultProbe(x, f"detector:{x}") for x in sorted(self.ALLOWED))
