from __future__ import annotations
import hashlib, json
from typing import Any

SERIALIZATION_VERSION = "1"

class CanonicalSerializationError(ValueError):
    pass

def canonical_bytes(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise CanonicalSerializationError(str(exc)) from exc

def canonical_json(value: Any) -> str:
    return canonical_bytes(value).decode("utf-8")

def sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()

def envelope(kind: str, payload: Any, *, schema_version: str = SERIALIZATION_VERSION) -> dict[str, Any]:
    if not kind:
        raise ValueError("kind is required")
    return {"serialization_version": schema_version, "kind": kind, "payload": payload}

def verify_envelope(obj: dict[str, Any], kind: str | None = None) -> bool:
    if not isinstance(obj, dict) or obj.get("serialization_version") != SERIALIZATION_VERSION or "payload" not in obj or not obj.get("kind"):
        return False
    return kind is None or obj.get("kind") == kind
