"""Integrated high-assurance preflight for the TBOHK substrate.

This module deliberately composes independent assurance paths without allowing
any one result to certify itself.  It is an orchestration layer, not a new
source of truth: each component remains independently executable.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import hashlib, json, tempfile, os

from .core import TBOHK
from .benchmark import ReasoningBenchmark
from .metamorphic import MetamorphicSuite
from .mutation import MutationSuite
from .independent_validation import IndependentSystemValidator
from .selfcare import SelfCareEngine
from .state_machine import StateTransitionEngine
from .migrations import MigrationManager
from .serialization import canonical_json, sha256

@dataclass(frozen=True)
class AssuranceCheck:
    name: str
    passed: bool
    blocking: bool
    details: str

@dataclass(frozen=True)
class DeepAssuranceReport:
    passed: bool
    checks: tuple[AssuranceCheck, ...]
    manifest_sha256: str

class DeepAssurance:
    """Run the strongest locally reproducible substrate checks as one report."""
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _check(self, name: str, fn, *, blocking=True) -> AssuranceCheck:
        try:
            value = fn()
            if isinstance(value, tuple):
                ok, details = value
            else:
                ok, details = bool(value), "completed"
            return AssuranceCheck(name, bool(ok), blocking, str(details))
        except Exception as exc:
            return AssuranceCheck(name, False, blocking, f"exception: {type(exc).__name__}: {exc}")

    def run(self) -> DeepAssuranceReport:
        checks = []
        checks.append(self._check("core_audit", lambda: (self.g.audit()["ok"], "core audit")))
        checks.append(self._check("selfcare", lambda: (SelfCareEngine(self.g).inspect().passed, "self-care")))
        checks.append(self._check("state_transition_audit", lambda: (not StateTransitionEngine(self.g).audit(), "transition audit")))
        checks.append(self._check("migration_integrity", lambda: (MigrationManager(self.g.db).verify()["ok"], "migration ledger")))
        checks.append(self._check("independent_validator", lambda: (IndependentSystemValidator(self.g).run().passed, "independent validator")))

        benchmark = ReasoningBenchmark().run(as_of="2026-01-01T00:00:00+00:00")
        checks.append(AssuranceCheck("reasoning_benchmark", benchmark.failed == 0, True,
                                     f"{benchmark.passed}/{benchmark.total} cases passed"))
        metamorphic = MetamorphicSuite().run(as_of="2026-01-01T00:00:00+00:00")
        checks.append(AssuranceCheck("metamorphic_suite", metamorphic.failed == 0, True,
                                     f"{metamorphic.passed}/{metamorphic.total} cases passed"))
        mutation = MutationSuite().run(as_of="2026-01-01T00:00:00+00:00")
        checks.append(AssuranceCheck("mutation_suite", mutation.missed == 0, True,
                                     f"{mutation.detected}/{mutation.total} faults detected"))

        # Canonical serialization determinism is tested independently of the DB.
        sample = {"checks": [asdict(c) for c in checks]}
        first = canonical_json(sample)
        second = canonical_json(json.loads(first))
        checks.append(AssuranceCheck("canonical_serialization", first == second and sha256(sample) == sha256(json.loads(first)), True,
                                     "canonical representation is deterministic"))

        # The final report is itself content-addressed, but its hash is not used
        # as a trust root.  It is an audit identifier only.
        blocking_failures = [c for c in checks if c.blocking and not c.passed]
        manifest = {"checks": [asdict(c) for c in checks]}
        manifest_hash = hashlib.sha256(canonical_json(manifest).encode()).hexdigest()
        return DeepAssuranceReport(not blocking_failures, tuple(checks), manifest_hash)
