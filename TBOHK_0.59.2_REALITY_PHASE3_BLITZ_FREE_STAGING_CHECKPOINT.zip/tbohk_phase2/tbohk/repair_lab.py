"""Bounded repair hypothesis laboratory.

Generates, minimizes, and independently evaluates repair hypotheses without
mutating authoritative source. Rejected hypotheses are first-class evidence.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Callable, Iterable, Any

@dataclass(frozen=True)
class RepairHypothesis:
    hypothesis_id: str
    target: str
    strategy: str
    change: str
    risk: str = "medium"

@dataclass(frozen=True)
class RepairOutcome:
    hypothesis_id: str
    reproduced: bool
    effective: bool
    regression_passed: bool
    side_effects: tuple[str, ...]
    accepted: bool
    reason: str
    digest: str

@dataclass(frozen=True)
class RejectedHypothesis:
    hypothesis_id: str
    reason: str
    digest: str

class RepairLab:
    VERSION = "RL1.0-1"
    STRATEGIES = ("recheck", "rebuild_projection", "replay", "quarantine", "refresh")

    @staticmethod
    def _digest(payload: Any) -> str:
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

    def generate(self, *, target: str, failure_type: str, detail: str = "") -> tuple[RepairHypothesis, ...]:
        if not target or not failure_type:
            raise ValueError("target and failure_type are required")
        # Deterministic strategy ordering; detail is evidence, never executable input.
        preferred = {
            "dropped_event": ("replay", "recheck"),
            "duplicate_event": ("replay", "recheck"),
            "stale_projection": ("rebuild_projection", "replay"),
            "missing_link": ("recheck", "replay"),
            "bad_metadata": ("refresh", "quarantine"),
        }.get(failure_type, ("recheck", "quarantine"))
        strategies = tuple(dict.fromkeys(preferred + self.STRATEGIES))[:3]
        return tuple(
            RepairHypothesis(
                hypothesis_id=self._digest({"target": target, "failure_type": failure_type, "strategy": s})[:16],
                target=target, strategy=s, change=f"bounded:{s}:{failure_type}",
                risk="low" if s in {"recheck", "replay"} else "medium",
            ) for s in strategies
        )

    def minimize(self, evidence: Iterable[str], predicate: Callable[[tuple[str, ...]], bool]) -> tuple[str, ...]:
        """Delta-debug evidence while preserving predicate truth."""
        current = tuple(evidence)
        if not predicate(current):
            return current
        changed = True
        while changed and len(current) > 1:
            changed = False
            for i in range(len(current)):
                trial = current[:i] + current[i+1:]
                if trial and predicate(trial):
                    current = trial
                    changed = True
                    break
        return current

    def evaluate(self, hypothesis: RepairHypothesis, *, reproduce: Callable[[], Any], apply: Callable[[RepairHypothesis], Any], regression: Callable[[], Any], side_effects: Callable[[], Iterable[str]] = lambda: ()) -> RepairOutcome:
        failures = []
        try: reproduced = bool(reproduce())
        except Exception as exc: reproduced = False; failures.append(f"reproduce:{type(exc).__name__}")
        if not reproduced: failures.append("original-failure-not-reproduced")
        try: effective = bool(apply(hypothesis))
        except Exception as exc: effective = False; failures.append(f"apply:{type(exc).__name__}")
        if not effective: failures.append("repair-not-effective")
        try: regression_passed = bool(regression())
        except Exception as exc: regression_passed = False; failures.append(f"regression:{type(exc).__name__}")
        if not regression_passed: failures.append("regression-gate-failed")
        try: effects = tuple(sorted(set(str(x) for x in side_effects())))
        except Exception as exc: effects = (f"side_effect_probe:{type(exc).__name__}",)
        if effects: failures.append("side-effects-detected")
        accepted = reproduced and effective and regression_passed and not effects and not failures
        reason = "accepted" if accepted else ";".join(failures)
        payload = {"version":self.VERSION,"hypothesis":hypothesis.__dict__,"reproduced":reproduced,"effective":effective,"regression":regression_passed,"side_effects":effects,"accepted":accepted,"reason":reason}
        return RepairOutcome(hypothesis.hypothesis_id,reproduced,effective,regression_passed,effects,accepted,reason,self._digest(payload))

    def reject_record(self, outcome: RepairOutcome) -> RejectedHypothesis | None:
        if outcome.accepted: return None
        return RejectedHypothesis(outcome.hypothesis_id, outcome.reason, self._digest(outcome.__dict__))
