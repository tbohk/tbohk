from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import re, hashlib
from typing import Any
from .core import TBOHK
from .research import ResearchChain, ResearchProvider
from .epistemic import EpistemicEngine
from .conflict_analysis import ConflictAnalyzer
from .independence import IndependenceAnalyzer
from .synthesis import EvidenceSynthesizer
from .causal import CausalReasoner
from .hypothesis import HypothesisEngine
from .investigation import AdaptiveInvestigator
@dataclass(frozen=True)
class ResearchPlan:
    plan_id: str
    question: str
    subquestions: tuple[str, ...]
    stopping_rule: str
    source_targets: tuple[str, ...]
    created_at: str

@dataclass(frozen=True)
class KnowledgeGap:
    description: str
    related_claim_ids: tuple[str, ...]
    severity: str

@dataclass(frozen=True)
class AutonomousCycle:
    cycle: int
    phase: str
    findings: tuple[str, ...]

class KnowledgeIntelligence:
    """Application-level intelligence orchestration over the G0-G30 substrate.

    This is deliberately deterministic and bounded. It does not silently promote
    retrieved text to truth or grant itself authority to mutate verified knowledge.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.epistemic = EpistemicEngine(graph)
        self.conflict_analyzer = ConflictAnalyzer(graph)
        self.independence = IndependenceAnalyzer(graph)
        self.synthesizer = EvidenceSynthesizer(graph)
        self.causal = CausalReasoner(graph)
        self.hypotheses = HypothesisEngine(graph)
        self.investigator = AdaptiveInvestigator(graph)

    def plan_research(self, question: str, *, max_subquestions: int = 8) -> ResearchPlan:
        if not question.strip(): raise ValueError("question required")
        q = question.strip()
        parts = re.split(r"\s+(?:and|versus|vs\.?|compared with|because|while)\s+", q, flags=re.I)
        subs=[]
        for p in parts:
            p=p.strip(" .?")
            if p and p.lower() not in {x.lower() for x in subs}: subs.append(p+"?")
        if len(subs)==1:
            subs=[q+("?" if not q.endswith("?") else ""),
                  f"What evidence supports or contradicts: {q.rstrip('?')}?",
                  f"What important uncertainty remains about: {q.rstrip('?')}?"]
        subs=subs[:max_subquestions]
        now=datetime.now(timezone.utc).isoformat()
        pid="plan_"+hashlib.sha256((q+now).encode()).hexdigest()[:24]
        self.g.add_node("ResearchPlan", q, "proposed", {"plan_id":pid,"question":q,"subquestions":subs,
            "stopping_rule":"all supplied providers completed; no unresolved critical gap may be silently treated as resolved",
            "created_at":now})
        return ResearchPlan(pid,q,tuple(subs),"all supplied providers completed; unresolved critical gaps remain explicit",(),now)

    def extract_claim_candidates(self, evidence_ids: list[str], *, max_claims: int = 20):
        out=[]
        for eid in evidence_ids:
            e=self.g.get(eid)
            if not e or e.kind!="Evidence": continue
            # Conservative sentence-level extraction: candidates remain proposed.
            sentences=re.split(r"(?<=[.!?])\s+", e.content.strip())
            for s in sentences:
                s=s.strip()
                if len(s)<30 or len(s)>1200: continue
                if s.endswith("?"): continue
                c=self.g.add_node("Claim",s,"proposed",{
                    "candidate_origin":"deterministic_sentence_extractor",
                    "evidence_ids":[eid],"extraction_confidence":"candidate_only",
                    "requires_human_or_independent_evaluation":True})
                self.g.link(c.id,"evidence_for",eid)
                out.append(c.id)
                if len(out)>=max_claims: return out
        return out

    def knowledge_overview(self, query: str = ""):
        q=query.strip().lower()
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='Claim' ORDER BY rowid DESC").fetchall()
        claims=[]
        for r in rows:
            n=self.g.get(r[0])
            if not q or q in n.content.lower():
                claims.append({"id":n.id,"content":n.content,"status":n.status,"metadata":n.metadata})
        return {"query":query,"claims":claims[:200],"count":len(claims)}

    def gaps(self, question: str, claim_ids: list[str] | None = None):
        gaps=[]; ids=claim_ids or []
        if not ids:
            ids=[x["id"] for x in self.knowledge_overview(question)["claims"]]
        if not ids:
            gaps.append(KnowledgeGap("No claims have been established for the question",(),"critical"))
        for cid in ids:
            c=self.g.get(cid)
            if not c or c.kind!="Claim": continue
            evidence=self.g.edges(cid,direction="out",relation="evidence_for")
            if not evidence: gaps.append(KnowledgeGap(f"Claim lacks direct evidence: {cid}",(cid,),"high"))
            if c.status in {"unknown","proposed","stale","contradicted"}:
                gaps.append(KnowledgeGap(f"Claim is not currently verified: {cid}",(cid,),"medium"))
            if c.metadata.get("structured") is None and c.metadata.get("subject") is None:
                gaps.append(KnowledgeGap(f"Claim lacks explicit semantic structure: {cid}",(cid,),"low"))
        return [asdict(g) for g in gaps]

    def conflicts(self, claim_ids: list[str] | None = None):
        ids=set(claim_ids or [])
        rows=self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='contradicts'").fetchall()
        out=[]
        for r in rows:
            if ids and r[0] not in ids and r[1] not in ids: continue
            a,b=self.g.get(r[0]),self.g.get(r[1])
            if a and b: out.append({"claim_a":asdict(a),"claim_b":asdict(b)})
        return out

    def extract_structured_claim_candidates(self, evidence_ids: list[str], *, max_claims: int = 20):
        """Create conservative subject/predicate/object candidates from evidence.

        This is a deterministic parser, not a semantic LLM. It only emits a
        structure when simple linguistic patterns are sufficiently explicit.
        """
        out=[]
        for eid in evidence_ids:
            e=self.g.get(eid)
            if not e or e.kind != "Evidence": continue
            text=e.content.strip()
            sentences=re.split(r"(?<=[.!?])\s+", text)
            for sentence in sentences:
                sentence=sentence.strip(" \t\r\n-•")
                if len(sentence)<25 or sentence.endswith("?"): continue
                subject=predicate=obj=None
                m=re.match(r"^(.{2,100}?)\s+(is|are|was|were|has|have|contains|causes|increases|decreases|reduces|improves|measures|measured)\s+(.{2,500})$", sentence, re.I)
                if m:
                    subject=m.group(1).strip(" ,;:")
                    predicate=m.group(2).lower()
                    obj=m.group(3).strip(" .;:")
                if not (subject and predicate and obj): continue
                c=self.g.add_node("Claim",sentence,"proposed",{
                    "candidate_origin":"deterministic_structured_parser",
                    "structured":{"subject":subject,"predicate":predicate,"object":obj,
                                  "qualifiers":{},"scope":None,"time":None,"units":None,
                                  "modality":"assertion","uncertainty":None},
                    "evidence_ids":[eid],"extraction_confidence":"candidate_only",
                    "requires_human_or_independent_evaluation":True})
                self.g.link(c.id,"evidence_for",eid)
                out.append(c.id)
                if len(out)>=max_claims: return out
        return out

    def evidence_independence(self, claim_id: str):
        """Return an auditable independence view for a claim's direct evidence."""
        claim=self.g.get(claim_id)
        if not claim or claim.kind!='Claim': raise ValueError(f"not a Claim: {claim_id}")
        evidence=[]
        for row in self.g.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='evidence_for'",(claim_id,)):
            n=self.g.get(row[0])
            if n and n.kind=='Evidence': evidence.append(n)
        for row in self.g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='evidence_for'",(claim_id,)):
            n=self.g.get(row[0])
            if n and n.kind=='Evidence' and n.id not in {x.id for x in evidence}: evidence.append(n)
        origins=[]; providers=[]
        for e in evidence:
            if e.metadata.get('origin_id'): origins.append(e.metadata['origin_id'])
            if e.metadata.get('provider_id'): providers.append(e.metadata['provider_id'])
        return {"claim_id":claim_id,"evidence_count":len(evidence),
                "distinct_origins":sorted(set(origins)),"distinct_providers":sorted(set(providers)),
                "independence_sufficient":len(set(origins))>=2,
                "note":"Origin diversity is a structural signal, not proof of truth."}

    def prioritize_gaps(self, question: str):
        gaps=self.gaps(question)
        rank={"critical":4,"high":3,"medium":2,"low":1}
        return sorted(gaps,key=lambda x:(-rank.get(x["severity"],0),x["description"]))

    def synthesize(self, question: str):
        overview=self.knowledge_overview(question)
        ids=[item["id"] for item in overview["claims"]]
        rows=[]
        for item in overview["claims"]:
            ci=self.evidence_independence(item["id"])
            rows.append({"claim":item,"evidence_independence":ci,"normalized":self.synthesizer.normalize_claim(item["id"])})
        structural=self.synthesizer.synthesize(ids)
        causal=[self.causal.assess(cid).__dict__ for cid in ids]
        return {"question":question,"claims":rows,"gaps":self.prioritize_gaps(question),
                "conflicts":self.conflicts(),"structural_comparison":structural,"causal_assessments":causal,
                "boundary":"Synthesis organizes evidence, semantic relationships, and uncertainty; it does not establish truth by itself."}

    def run_bounded(self, question: str, providers: list[ResearchProvider], *, max_cycles=3, urls_description=""):
        max_cycles=max(1,min(max_cycles,10))
        cycles=[]; findings=[]; plan=self.plan_research(question)
        for i in range(1,max_cycles+1):
            phase="research" if i==1 else ("synthesis" if i==2 else "evaluation")
            if phase=="research":
                rr=ResearchChain(self.g,providers).run(question, plan.stopping_rule)
                eids=[e.id for _,e in rr["results"]]
                cids=self.extract_claim_candidates(eids)
                structured=self.extract_structured_claim_candidates(eids)
                findings.append(f"ingested {len(eids)} evidence items and produced {len(cids)} sentence candidates plus {len(structured)} structured candidates")
            elif phase=="synthesis":
                synthesis=self.synthesize(question)
                findings.append(f"reviewed {len(synthesis['claims'])} relevant claims; {len(synthesis['conflicts'])} conflicts and {len(synthesis['gaps'])} gaps remain explicit")
            else:
                gaps=self.prioritize_gaps(question)
                findings.append(f"identified {len(gaps)} explicit knowledge gaps; highest severity={gaps[0]['severity'] if gaps else 'none'}")
            cycles.append(AutonomousCycle(i,phase,(findings[-1],)))
        run=self.g.add_node("AutonomousRun",question,"supported",{
            "bounded":True,"max_cycles":max_cycles,"question":question,
            "cycles":[asdict(c) for c in cycles],"findings":findings,
            "authority_boundary":"research_and_assessment_only; no autonomous authorization"})
        return {"run_id":run.id,"plan":asdict(plan),"cycles":[asdict(c) for c in cycles],"findings":findings,
                "knowledge":self.knowledge_overview(question),"gaps":self.gaps(question),"conflicts":self.conflicts()}
