from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone
import json,hashlib

@dataclass(frozen=True)
class EvaluationResult:
    evaluation_id:str
    score:float|None
    passed:bool

class LearningEngine:
    def __init__(self,graph): self.g=graph
    def create_evaluation_suite(self,name,cases,*,governance='fixed'):
        manifest=json.dumps({'name':name,'cases':cases,'governance':governance},sort_keys=True,separators=(',',':'))
        return self.g.add_node('EvaluationSuite',name,'supported',{'cases':cases,'governance':governance,'manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest()})
    def evaluate(self,target_id,suite_id,*,metrics,assessor='independent'):
        s=self.g.get(suite_id)
        if not s or s.kind!='EvaluationSuite': raise ValueError('invalid suite')
        score=metrics.get('score'); passed=bool(metrics.get('passed',False))
        e=self.g.add_node('Evaluation',f'Evaluation {target_id}','supported',{'target_id':target_id,'suite_id':suite_id,'metrics':metrics,'assessor':assessor,'evaluated_at':datetime.now(timezone.utc).isoformat(),'suite_manifest_sha256':s.metadata.get('manifest_sha256')})
        self.g.link(e.id,'evaluates',target_id); self.g.link(e.id,'based_on',suite_id)
        return EvaluationResult(e.id,score,passed)
    def record_feedback(self,target_id,feedback,*,source='observer',evaluation_id=None):
        n=self.g.add_node('Feedback',f'Feedback for {target_id}','supported',{'target_id':target_id,'feedback':feedback,'source':source,'evaluation_id':evaluation_id,'recorded_at':datetime.now(timezone.utc).isoformat()})
        if evaluation_id: self.g.link(n.id,'based_on',evaluation_id)
        return n
    def propose_improvement(self,target_id,change,*,evaluations,expected_effect,proposer='learning'):
        if not evaluations: raise ValueError('improvement requires evaluation evidence')
        for eid in evaluations:
            e=self.g.get(eid)
            if not e or e.kind!='Evaluation': raise ValueError('invalid evaluation')
        return self.g.add_node('ChangeProposal',f'Improvement for {target_id}','proposed',{'change_type':'improvement','target_ids':[target_id],'change':change,'evaluation_ids':evaluations,'expected_effect':expected_effect,'proposer':proposer,'created_at':datetime.now(timezone.utc).isoformat()})
    def compare(self,baseline_eval_id,candidate_eval_id):
        a=self.g.get(baseline_eval_id); b=self.g.get(candidate_eval_id)
        if not a or not b: raise ValueError('evaluation missing')
        am=a.metadata.get('metrics',{}); bm=b.metadata.get('metrics',{})
        return {'score_delta':(bm.get('score')-am.get('score')) if isinstance(am.get('score'),(int,float)) and isinstance(bm.get('score'),(int,float)) else None,'baseline_passed':bool(am.get('passed')),'candidate_passed':bool(bm.get('passed')),'same_suite':a.metadata.get('suite_manifest_sha256')==b.metadata.get('suite_manifest_sha256')}
