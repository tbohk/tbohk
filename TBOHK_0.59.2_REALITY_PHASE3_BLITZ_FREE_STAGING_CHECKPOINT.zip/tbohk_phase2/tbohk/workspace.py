"""Question-centered knowledge workspace.

The workspace is deliberately conservative: it never turns a generated answer
into verified knowledge.  It assembles evidence, uncertainty, conflicts and
next research actions into a durable, auditable workspace record.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

from .core import TBOHK
from .intelligence import KnowledgeIntelligence
from .evaluation import EvidenceEvaluator, ClaimEvaluator

@dataclass(frozen=True)
class AnswerAssessment:
    claim_ids: tuple[str, ...]
    supported_claims: tuple[str, ...]
    unresolved_claims: tuple[str, ...]
    conflicts: tuple[str, ...]
    evidence_count: int
    independent_evidence_count: int
    limitations: tuple[str, ...]

@dataclass(frozen=True)
class KnowledgeWorkspace:
    workspace_id: str
    question: str
    created_at: str
    assessment: AnswerAssessment
    research_plan: Any
    gaps: tuple[str, ...]
    next_actions: tuple[str, ...]

class QuestionWorkspace:
    """Build an auditable answer workspace from the existing substrate."""
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.intelligence = KnowledgeIntelligence(graph)

    def _claims_for_question(self, question: str):
        q = question.casefold().strip()
        if not q:
            raise ValueError("question must not be empty")
        rows = self.g.db.execute(
            "SELECT * FROM nodes WHERE kind IN ('Claim','Knowledge') ORDER BY rowid DESC"
        ).fetchall()
        tokens = {x for x in q.split() if len(x) > 2}
        ranked=[]
        for row in rows:
            text=f"{row['content']} {row['metadata']}".casefold()
            score=sum(1 for token in tokens if token in text)
            if score:
                ranked.append((score, self.g.get(row['id'])))
        ranked.sort(key=lambda x:(-x[0], x[1].created_at), reverse=False)
        return [n for _,n in ranked[:25]]

    def assess(self, question: str) -> AnswerAssessment:
        candidates=self._claims_for_question(question)
        claim_ids=tuple(n.id for n in candidates if n.kind=='Claim')
        supported=[]; unresolved=[]; conflicts=[]; evidence_count=0; independent=0; limitations=[]
        for claim in candidates:
            if claim.kind!='Claim':
                continue
            try:
                a=ClaimEvaluator(self.g).assess(claim.id)
                evidence_count += len(a.evidence_ids)
                independent=max(independent, int(a.independent_evidence_count))
                if claim.status=='verified':
                    supported.append(claim.id)
                else:
                    unresolved.append(claim.id)
                limitations.extend(a.limitations)
            except Exception as exc:
                unresolved.append(claim.id)
                limitations.append(f"assessment failed for {claim.id}: {type(exc).__name__}")
        for c in self.intelligence.conflicts():
            conflicts.append(str(c.get('id') or c.get('conflict_id') or c))
        if not candidates:
            limitations.append("no matching first-class claims or knowledge records")
        return AnswerAssessment(
            claim_ids=claim_ids,
            supported_claims=tuple(dict.fromkeys(supported)),
            unresolved_claims=tuple(dict.fromkeys(unresolved)),
            conflicts=tuple(dict.fromkeys(conflicts)),
            evidence_count=evidence_count,
            independent_evidence_count=independent,
            limitations=tuple(dict.fromkeys(limitations)),
        )

    def open(self, question: str) -> KnowledgeWorkspace:
        if not question or not question.strip():
            raise ValueError("question must not be empty")
        assessment=self.assess(question)
        plan=self.intelligence.plan_research(question)
        gaps=tuple(self.intelligence.gaps(question))
        actions=[]
        if not assessment.claim_ids or assessment.unresolved_claims:
            actions.append("research unresolved claims")
        if assessment.conflicts:
            actions.append("review conflicting claims")
        if assessment.evidence_count==0:
            actions.append("acquire auditable source evidence")
        if not actions:
            actions.append("re-evaluate the answer against current evidence")
        node=self.g.add_node('KnowledgeWorkspace', question, 'supported', {
            'question':question, 'claim_ids':list(assessment.claim_ids),
            'supported_claims':list(assessment.supported_claims),
            'unresolved_claims':list(assessment.unresolved_claims),
            'conflicts':list(assessment.conflicts), 'evidence_count':assessment.evidence_count,
            'independent_evidence_count':assessment.independent_evidence_count,
            'limitations':list(assessment.limitations), 'gaps':list(gaps),
            'next_actions':actions, 'created_at':datetime.now(timezone.utc).isoformat(),
        })
        return KnowledgeWorkspace(node.id, question, node.created_at, assessment, plan, gaps, tuple(actions))

    @staticmethod
    def as_dict(workspace: KnowledgeWorkspace):
        d=asdict(workspace)
        d['research_plan']=asdict(workspace.research_plan) if hasattr(workspace.research_plan,'__dataclass_fields__') else workspace.research_plan
        return d
