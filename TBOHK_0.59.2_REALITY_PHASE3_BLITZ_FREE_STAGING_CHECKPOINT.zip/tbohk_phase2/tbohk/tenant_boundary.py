from __future__ import annotations
class TenantBoundary:
    """Explicit tenant isolation contract for future multi-user deployments."""
    def __init__(self, tenant_id):
        tenant_id=str(tenant_id).strip()
        if not tenant_id: raise ValueError('tenant_id required')
        self.tenant_id=tenant_id
    def stamp(self, metadata):
        out=dict(metadata); out['tenant_id']=self.tenant_id; return out
    def owns(self, metadata): return metadata.get('tenant_id')==self.tenant_id
    def require(self, metadata):
        if not self.owns(metadata): raise PermissionError('tenant boundary violation')
