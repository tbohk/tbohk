from __future__ import annotations
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class ProviderCheck:
    provider: str
    configured: bool
    missing: tuple[str, ...]

REQUIRED = {
    'stripe': ('STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET','STRIPE_PRICE_PRO','STRIPE_PRICE_UNLIMITED'),
    'apple': ('APPLE_ISSUER_ID','APPLE_KEY_ID','APPLE_PRIVATE_KEY_PEM','APPLE_ROOT_CA_PEM','APPLE_BUNDLE_ID','APPLE_PRODUCT_PRO','APPLE_PRODUCT_UNLIMITED'),
    'google': ('GOOGLE_PLAY_PACKAGE_NAME','GOOGLE_SERVICE_ACCOUNT_EMAIL','GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM','GOOGLE_PRODUCT_PRO','GOOGLE_PRODUCT_UNLIMITED','GOOGLE_RTDN_AUDIENCE'),
}

def check_provider(provider: str, env: dict[str,str] | None = None) -> ProviderCheck:
    e = env or os.environ
    p = provider.strip().lower()
    if p not in REQUIRED:
        raise ValueError('unsupported provider')
    missing = tuple(k for k in REQUIRED[p] if not str(e.get(k,'' )).strip())
    return ProviderCheck(p, not missing, missing)

def readiness(env: dict[str,str] | None = None) -> dict[str,dict]:
    return {p:{'configured': c.configured, 'missing': list(c.missing)} for p in REQUIRED for c in [check_provider(p,env)]}

if __name__ == '__main__':  # pragma: no cover
    import json
    print(json.dumps(readiness(), indent=2, sort_keys=True))
