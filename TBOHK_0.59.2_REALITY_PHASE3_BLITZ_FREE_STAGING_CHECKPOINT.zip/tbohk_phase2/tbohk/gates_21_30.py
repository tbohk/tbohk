from __future__ import annotations
import hashlib, json, re
from dataclasses import dataclass
from datetime import datetime, timezone
from collections import defaultdict

@dataclass(frozen=True)
class AssuranceFinding:
    gate: str; code: str; severity: str; affected: tuple[str,...]; blocks_release: bool; evidence: str

@dataclass(frozen=True)
class AssuranceReport:
    gate: str; passed: bool; findings: tuple[AssuranceFinding,...]

def _finding(g,c,s,a,b,e): return AssuranceFinding(g,c,s,tuple(a),b,e)
def _json(x):
    try: return json.loads(x)
    except Exception: return None

def _rows_digest(rows):
    return hashlib.sha256(json.dumps([dict(r) for r in rows],sort_keys=True,separators=(',',':')).encode()).hexdigest()

class G21LedgerAuditor:
    """Cryptographically chained event/revision history verification."""
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        for table in ("events","revisions"):
            rows=self.g.db.execute(f"SELECT * FROM {table} ORDER BY rowid").fetchall()
            anchor=self.g.db.execute("SELECT row_count,head_row_id,head_hash FROM ledger_anchor WHERE table_name=?",(table,)).fetchone()
            if not anchor:
                fs.append(_finding('G21','ledger_anchor_missing','critical',(table,),True,f'{table} has no immutable-in-graph ledger anchor'))
            else:
                if anchor['row_count'] != len(rows):
                    fs.append(_finding('G21','ledger_anchor_count_mismatch','critical',(table,),True,f'{table} anchor count does not match source row count'))
            chains=self.g.db.execute("SELECT row_id,chain_prev,chain_hash FROM ledger_chain WHERE table_name=? ORDER BY rowid",(table,)).fetchall()
            cmap={r['row_id']:dict(r) for r in chains}
            prev="GENESIS"
            for r in rows:
                d=dict(r); rid=d['id']; stored=cmap.get(rid)
                if not stored:
                    fs.append(_finding('G21','ledger_anchor_missing','critical',(rid,),True,f'{table} row has no chained digest')); continue
                canonical=json.dumps(d,sort_keys=True,separators=(',',':'))
                expected=hashlib.sha256((prev+'|'+canonical).encode()).hexdigest()
                if stored['chain_prev']!=prev or stored['chain_hash']!=expected:
                    fs.append(_finding('G21','ledger_chain_break','critical',(rid,),True,f'{table} history hash chain mismatch'))
                prev=stored['chain_hash']
            if len(chains)!=len(rows):
                fs.append(_finding('G21','ledger_orphan_anchor','critical',tuple(x['row_id'] for x in chains if x['row_id'] not in {r['id'] for r in rows}),True,f'{table} has chain entries without source rows'))
            if anchor and rows:
                last_chain=cmap.get(rows[-1]['id'])
                if not last_chain or anchor['head_row_id'] != rows[-1]['id'] or anchor['head_hash'] != last_chain['chain_hash']:
                    fs.append(_finding('G21','ledger_anchor_head_mismatch','critical',(table,),True,f'{table} anchor head does not match the final chained row'))
            elif anchor and not rows and (anchor['row_count'] != 0 or anchor['head_row_id'] is not None or anchor['head_hash'] != 'GENESIS'):
                fs.append(_finding('G21','ledger_anchor_empty_mismatch','critical',(table,),True,f'{table} is empty but its anchor is not genesis'))
        return AssuranceReport('G21',not any(f.blocks_release for f in fs),tuple(fs))

class G22PortableCheckpointAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        # Use the same canonical portable snapshot definition as CheckpointManager:
        # checkpoint/health nodes are excluded from the payload being attested.
        nodes=self.g.db.execute("SELECT id,kind,status,content,metadata FROM nodes WHERE kind NOT IN ('Checkpoint','HealthSnapshot') ORDER BY id").fetchall()
        edges=self.g.db.execute("SELECT source_id,relation,target_id FROM edges WHERE source_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) AND target_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY source_id,relation,target_id").fetchall()
        events=self.g.db.execute("SELECT id,event_type,subject_id,payload,created_at FROM events WHERE subject_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY rowid").fetchall()
        revs=self.g.db.execute("SELECT id,node_id,old_status,new_status,old_content,new_content,reason,created_at FROM revisions WHERE node_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY rowid").fetchall()
        ledger=self.g.db.execute("SELECT table_name,row_id,chain_prev,chain_hash FROM ledger_chain WHERE NOT (table_name='events' AND row_id IN (SELECT id FROM events WHERE subject_id IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')))) AND NOT (table_name='revisions' AND row_id IN (SELECT id FROM revisions WHERE node_id IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')))) ORDER BY table_name,rowid").fetchall()
        checkpoint_hash=lambda rows: hashlib.sha256(json.dumps([dict(x) for x in rows],sort_keys=True).encode()).hexdigest()
        expected={'node_hash':checkpoint_hash(nodes),'edge_hash':checkpoint_hash(edges),'event_hash':checkpoint_hash(events),'revision_hash':checkpoint_hash(revs),'ledger_hash':checkpoint_hash(ledger)}
        for r in self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='Checkpoint'"):
            m=_json(r['metadata']) or {}; man=m.get('manifest') or {}
            for k,v in expected.items():
                if man.get(k) is None:
                    fs.append(_finding('G22','checkpoint_not_portable','critical',(r['id'],),True,f'manifest missing {k}'))
                elif man.get(k) != v:
                    fs.append(_finding('G22','checkpoint_snapshot_drift','critical',(r['id'],),True,f'checkpoint {k} does not match the current portable snapshot'))
            manifest_digest=m.get('manifest_sha256')
            if manifest_digest:
                canonical=json.dumps(man,sort_keys=True)
                if hashlib.sha256(canonical.encode()).hexdigest()!=manifest_digest:
                    fs.append(_finding('G22','checkpoint_manifest_digest_mismatch','critical',(r['id'],),True,'checkpoint manifest digest does not match its canonical manifest'))
            else:
                fs.append(_finding('G22','checkpoint_manifest_digest_missing','critical',(r['id'],),True,'checkpoint has no manifest_sha256'))
        return AssuranceReport('G22',not any(f.blocks_release for f in fs),tuple(fs))

class G23KeyLifecycleAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]; seen={}
        for r in self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='Checkpoint'"):
            m=_json(r['metadata']) or {}; a=m.get('public_attestation') or m.get('release_signature')
            if not a: continue
            kid=a.get('key_id') or a.get('signing_key_id')
            if not kid: fs.append(_finding('G23','attestation_key_id_missing','critical',(r['id'],),True,'release attestation has no stable key identifier')); continue
            if kid in seen and seen[kid]!=r['id']:
                pass
            seen[kid]=r['id']
        for r in self.g.db.execute("SELECT id,kind,metadata FROM nodes"):
            m=_json(r['metadata']) or {}
            if m.get('secret') is True or any(x in str(m).lower() for x in ('private_key','secret_key','password','api_token','bearer_token')):
                fs.append(_finding('G23','credential_material_in_graph','critical',(r['id'],),True,'credential-like material is present in graph metadata'))
        return AssuranceReport('G23',not any(f.blocks_release for f in fs),tuple(fs))

class G24ReplayConcurrencyAuditor:
    def __init__(self,g): self.g=g
    def digest(self):
        parts=[]
        for t in ('nodes','edges','events','revisions'):
            cols='*'; rows=self.g.db.execute(f'SELECT {cols} FROM {t} ORDER BY rowid').fetchall(); parts.append((t,[dict(r) for r in rows]))
        return hashlib.sha256(json.dumps(parts,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    def audit(self):
        fs=[]; before=self.digest()
        try:
            self.g.audit(); self.g.audit()
        except Exception as e: fs.append(_finding('G24','audit_not_replay_safe','critical',(),True,str(e)))
        after=self.digest()
        if before!=after: fs.append(_finding('G24','observer_replay_mutation','critical',(),True,'repeated observation changed graph state'))
        return AssuranceReport('G24',not any(f.blocks_release for f in fs),tuple(fs))

class G25BoundaryAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        dangerous={'credential','secret','password','private_key','api_key','bearer'}
        for r in self.g.db.execute('SELECT id,kind,metadata,content FROM nodes'):
            m=_json(r['metadata']) or {}; text=(r['content']+' '+json.dumps(m)).lower()
            if any(k in text for k in dangerous) and not m.get('redacted',False):
                fs.append(_finding('G25','sensitive_material_boundary','critical',(r['id'],),True,'possible credential material crosses into persistent knowledge without explicit redaction'))
            if m.get('tool') and not m.get('tool_policy'):
                fs.append(_finding('G25','tool_without_policy','high',(r['id'],),True,'tool declaration lacks explicit capability policy'))
        return AssuranceReport('G25',not any(f.blocks_release for f in fs),tuple(fs))

class G26UncertaintyConflictAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        claims=self.g.db.execute("SELECT id,status,metadata FROM nodes WHERE kind='Claim'").fetchall()
        for r in claims:
            m=_json(r['metadata']) or {}
            if r['status']=='verified' and ('confidence' not in m and 'uncertainty' not in m):
                fs.append(_finding('G26','verified_claim_without_uncertainty_record','high',(r['id'],),False,'verified claim has no explicit uncertainty/confidence metadata'))
        for r in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='contradicts'"):
            a,b=self.g.get(r['source_id']),self.g.get(r['target_id'])
            if a and b and a.status=='verified' and b.status=='verified':
                fs.append(_finding('G26','unresolved_verified_conflict','critical',(a.id,b.id),True,'two mutually contradicting claims remain verified without a conflict-resolution record'))
        return AssuranceReport('G26',not any(f.blocks_release for f in fs),tuple(fs))

class G27ResearchCompletenessAuditor:
    REQUIRED=('question','scope','stopping_rule','source_ids')
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        for r in self.g.db.execute("SELECT id,status,metadata FROM nodes WHERE kind='ResearchTask'"):
            m=_json(r['metadata']) or {}
            for k in self.REQUIRED:
                if k not in m or (isinstance(m[k],(list,dict,str)) and not m[k]):
                    fs.append(_finding('G27','research_contract_incomplete','critical',(r['id'],),True,f'ResearchTask missing {k}'))
            if m.get('complete') and not m.get('coverage_assessment'):
                fs.append(_finding('G27','research_complete_without_coverage','critical',(r['id'],),True,'research marked complete without coverage assessment'))
        return AssuranceReport('G27',not any(f.blocks_release for f in fs),tuple(fs))

class G28VerifierConformanceAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        names=[]
        for r in self.g.db.execute("SELECT id,kind,metadata FROM nodes WHERE kind IN ('EvaluationSuite','Verifier')"):
            m=_json(r['metadata']) or {}; name=m.get('implementation_id') or m.get('verifier_id')
            if name: names.append(name)
        if len(set(names))<2 and any(r[0] for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='EvaluationSuite'")):
            fs.append(_finding('G28','single_verifier_implementation','high',(),False,'conformance has not been demonstrated across independent implementations'))
        return AssuranceReport('G28',not any(f.blocks_release for f in fs),tuple(fs))

class G29ActionDurabilityAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        for r in self.g.db.execute("SELECT id,status,metadata FROM nodes WHERE kind='Action'"):
            m=_json(r['metadata']) or {}
            if r['status']=='verified':
                execution = self.g.db.execute(
                    "SELECT 1 FROM edges e JOIN nodes n ON n.id=e.source_id WHERE e.target_id=? AND e.relation='records' AND n.kind='Execution' LIMIT 1",
                    (r['id'],)).fetchone()
                if not m.get('execution_id') and not m.get('idempotency_key') and not execution:
                    fs.append(_finding('G29','verified_action_without_idempotency','critical',(r['id'],),True,'verified external action lacks durable execution identity'))
                if not m.get('rollback') and not m.get('compensation'):
                    fs.append(_finding('G29','verified_action_without_compensation','critical',(r['id'],),True,'verified external action lacks rollback or compensation semantics'))
                if execution and not m.get('execution_id') and not m.get('idempotency_key'):
                    erow=self.g.db.execute("SELECT metadata FROM nodes WHERE kind='Execution' AND id=(SELECT source_id FROM edges WHERE target_id=? AND relation='records' LIMIT 1)",(r['id'],)).fetchone()
                    em=_json(erow['metadata']) if erow else None
                    if not isinstance(em,dict) or not em.get('execution_id'):
                        fs.append(_finding('G29','execution_record_without_durable_id','critical',(r['id'],),True,'execution record exists but does not carry a durable execution_id'))
        return AssuranceReport('G29',not any(f.blocks_release for f in fs),tuple(fs))

class G30RedTeamAuditor:
    def __init__(self,g): self.g=g
    def audit(self):
        fs=[]
        # Cross-gate invariant matrix: release-critical classes must not silently bypass foundations.
        for r in self.g.db.execute("SELECT id,kind,status FROM nodes WHERE status='verified'"):
            if r['kind'] in {'Decision','Plan','Action'}:
                supports=self.g.db.execute("SELECT 1 FROM edges WHERE ((target_id=? AND relation IN ('verified_by','observes')) OR (source_id=? AND relation IN ('based_on','approved_by','verified_by','observes'))) LIMIT 1",(r['id'],r['id'])).fetchone()
                if not supports: fs.append(_finding('G30','cross_gate_verified_bypass','critical',(r['id'],),True,f'{r["kind"]} is verified without a qualifying assurance relationship'))
        # No graph cycle through authorization itself.
        for r in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='authorizes'"):
            if r['source_id']==r['target_id']: fs.append(_finding('G30','authorization_self_cycle','critical',(r['source_id'],),True,'authorization self-cycle'))
        return AssuranceReport('G30',not any(f.blocks_release for f in fs),tuple(fs))

def run_all(graph):
    return tuple(cls(graph).audit() for cls in (G21LedgerAuditor,G22PortableCheckpointAuditor,G23KeyLifecycleAuditor,G24ReplayConcurrencyAuditor,G25BoundaryAuditor,G26UncertaintyConflictAuditor,G27ResearchCompletenessAuditor,G28VerifierConformanceAuditor,G29ActionDurabilityAuditor,G30RedTeamAuditor))
