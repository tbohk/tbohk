from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from .core import TBOHK
from .independence import IndependenceAnalyzer

DIMENSIONS = (
    "source_integrity", "provenance_completeness", "independence",
    "temporal_fitness", "observation_precision", "polarity",
    "uncertainty", "corroboration", "conflict_exposure"
)

@dataclass(frozen=True)
class EvidenceAssessment:
    evidence_id: str
    dimension_results: dict[str, str]
    limitations: tuple[str, ...]
    assessed_at: str

    @property
    def adequate_dimensions(self) -> int:
        return sum(v == "adequate" for v in self.dimension_results.values())

class EvidenceEvaluator:
    """Assess evidence quality dimensions without converting quality into truth."""
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.independence = IndependenceAnalyzer(graph)

    def assess(self, evidence_id: str, *, as_of=None) -> EvidenceAssessment:
        ev = self.g.get(evidence_id)
        if not ev or ev.kind != "Evidence":
            raise ValueError(f"not evidence: {evidence_id}")
        snap = self.g._snapshot_for_evidence(evidence_id)
        now = as_of or datetime.now(timezone.utc)
        if isinstance(now, str):
            now = self.g._parse_time(now) or datetime.now(timezone.utc)
        results: dict[str, str] = {}
        limitations: list[str] = []

        if snap and snap.metadata.get("content_sha256"):
            results["source_integrity"] = "adequate"
        else:
            results["source_integrity"] = "insufficient"; limitations.append("snapshot integrity hash unavailable")

        required_prov = ("source_id", "provider_id", "origin_id")
        if all(ev.metadata.get(k) for k in required_prov) and snap:
            results["provenance_completeness"] = "adequate"
        else:
            results["provenance_completeness"] = "insufficient"; limitations.append("provenance identifiers incomplete")

        try:
            analysis = self.independence.analyze_evidence([evidence_id])
            results["independence"] = "documented" if analysis.independent_count == 1 else "insufficient"
        except Exception:
            results["independence"] = "unknown"; limitations.append("independence could not be analyzed")

        if snap and self.g._temporal_valid(snap, now):
            results["temporal_fitness"] = "adequate"
        else:
            results["temporal_fitness"] = "stale_or_unknown"; limitations.append("snapshot is not temporally valid at assessment time")

        locator = ev.metadata.get("locator")
        results["observation_precision"] = "adequate" if locator and locator.get("type") != "document" else "coarse"
        if results["observation_precision"] != "adequate": limitations.append("evidence locator is document-level or absent")

        polarity = ev.metadata.get("polarity")
        results["polarity"] = "adequate" if polarity in {"supports", "refutes", "neutral", "unknown"} else "insufficient"
        if results["polarity"] == "insufficient": limitations.append("evidence polarity is missing or invalid")

        results["uncertainty"] = "present" if ev.metadata.get("uncertainty") else "not_stated"
        if results["uncertainty"] == "not_stated": limitations.append("evidence-level uncertainty is not stated")

        # Corroboration is a property of the claim context, not this evidence alone.
        claims = [e["target_id"] for e in self.g.edges(evidence_id, "out", "evidence_for")]
        if claims:
            a = self.independence.analyze_claim(claims[0])
            results["corroboration"] = "present" if len(a.evidence_ids) > 1 else "single_source"
        else:
            results["corroboration"] = "not_applicable"

        conflict = self.g.db.execute(
            "SELECT 1 FROM edges e JOIN nodes c ON c.id=e.source_id WHERE e.target_id=? AND e.relation='contains' AND c.kind='ConflictSet' LIMIT 1",
            (evidence_id,)).fetchone()
        results["conflict_exposure"] = "none_detected" if not conflict else "conflicted_context"

        return EvidenceAssessment(evidence_id, results, tuple(limitations), now.isoformat())

    def record(self, evidence_id: str, *, assessor="system", as_of=None) -> EvidenceAssessment:
        assessment = self.assess(evidence_id, as_of=as_of)
        node = self.g.add_node("EvidenceAssessment", f"Assessment of {evidence_id}", "supported", {
            "evidence_id": evidence_id, "assessor": assessor,
            "assessed_at": assessment.assessed_at,
            "dimensions": assessment.dimension_results,
            "limitations": list(assessment.limitations),
        })
        self.g.link(node.id, "evaluates", evidence_id)
        return assessment


CLAIM_RELATIONS = ("entails", "supports", "correlates", "insufficient", "refutes", "unassessed")

@dataclass(frozen=True)
class ClaimAssessment:
    claim_id: str
    evidence_results: dict[str, str]
    dimensions: dict[str, str]
    limitations: tuple[str, ...]
    assessed_at: str

class ClaimEvaluator:
    """Conservative claim-to-evidence evaluation.

    This evaluator deliberately does not infer truth. It determines whether the
    recorded evidence relationship warrants the claim at the structural level,
    while preserving an explicit distinction between entailment, support,
    correlation, insufficiency and refutation.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.independence = IndependenceAnalyzer(graph)

    @staticmethod
    def _norm(value):
        return " ".join(str(value or "").casefold().split())

    def _relation(self, claim, evidence):
        explicit = evidence.metadata.get("claim_relation")
        if explicit in CLAIM_RELATIONS:
            return explicit
        polarity = evidence.metadata.get("polarity")
        if polarity == "refutes":
            return "refutes"
        if self._norm(evidence.content) == self._norm(claim.content) and polarity in {"supports", None}:
            return "entails"
        if polarity == "supports":
            return "supports"
        return "unassessed"

    def assess(self, claim_id: str, *, as_of=None, evidence_relations=None) -> ClaimAssessment:
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim":
            raise ValueError(f"not a claim: {claim_id}")
        now = as_of or datetime.now(timezone.utc)
        if isinstance(now, str):
            now = self.g._parse_time(now) or datetime.now(timezone.utc)
        evidence = list(self.g._supporting_evidence(claim_id))
        if not evidence:
            return ClaimAssessment(claim_id, {}, {
                "evidence_warrant": "insufficient", "scope_alignment": "unknown",
                "temporal_alignment": "unknown", "uncertainty_propagation": "missing",
                "reproducibility": "insufficient", "conflict_status": "unknown",
            }, ("claim has no evidence",), now.isoformat())
        results = {}
        limitations = []
        for ev in evidence:
            rel = (evidence_relations or {}).get(ev.id) or self._relation(claim, ev)
            if rel not in CLAIM_RELATIONS:
                raise ValueError(f"invalid claim relation for {ev.id}: {rel}")
            results[ev.id] = rel

        relations = set(results.values())
        if "refutes" in relations and not (relations - {"refutes", "unassessed"}):
            warrant = "refuted"
        elif "entails" in relations and "refutes" not in relations:
            warrant = "entailed"
        elif "supports" in relations and "refutes" not in relations:
            warrant = "supported_not_entailed"
        elif "correlates" in relations:
            warrant = "correlation_only"
        else:
            warrant = "insufficient"
        if "unassessed" in relations:
            limitations.append("one or more evidence items lack an explicit claim relationship")

        structured = claim.metadata.get("structured", {})
        scope = structured.get("scope")
        scope_alignment = "stated" if scope is not None else "unstated"
        if scope is None:
            limitations.append("claim scope is not explicitly stated")

        claim_time = structured.get("time")
        temporal_alignment = "not_applicable"
        if claim_time is not None:
            valid = []
            for ev in evidence:
                snap = self.g._snapshot_for_evidence(ev.id)
                valid.append(bool(snap and self.g._temporal_valid(snap, now)))
            temporal_alignment = "aligned" if all(valid) else "misaligned_or_unknown"
            if temporal_alignment != "aligned":
                limitations.append("claim temporal scope is not fully supported by currently valid snapshots")

        uncertainty_present = bool(structured.get("uncertainty")) or any(ev.metadata.get("uncertainty") for ev in evidence)
        uncertainty = "represented" if uncertainty_present else "not_stated"
        if uncertainty == "not_stated":
            limitations.append("neither claim nor supporting evidence states uncertainty")

        reproducible = all(
            ev.metadata.get("source_id") and ev.metadata.get("origin_id") and
            ev.metadata.get("extraction_method") and ev.metadata.get("locator") and
            self.g._snapshot_for_evidence(ev.id) is not None
            for ev in evidence
        )
        if not reproducible:
            limitations.append("provenance chain is incomplete for at least one evidence item")

        try:
            conflict_sets = self.g.db.execute(
                "SELECT DISTINCT source_id FROM edges WHERE target_id=? AND relation='contains'", (claim_id,)
            ).fetchall()
            conflict_status = "participates_in_conflict" if conflict_sets else "no_conflict_recorded"
        except Exception:
            conflict_status = "unknown"

        dimensions = {
            "evidence_warrant": warrant,
            "scope_alignment": scope_alignment,
            "temporal_alignment": temporal_alignment,
            "uncertainty_propagation": uncertainty,
            "reproducibility": "reproducible" if reproducible else "insufficient",
            "conflict_status": conflict_status,
        }
        return ClaimAssessment(claim_id, results, dimensions, tuple(limitations), now.isoformat())

    def record(self, claim_id: str, *, assessor="system", as_of=None, evidence_relations=None):
        assessment = self.assess(claim_id, as_of=as_of, evidence_relations=evidence_relations)
        node = self.g.add_node("ClaimAssessment", f"Assessment of {claim_id}", "supported", {
            "claim_id": claim_id, "assessor": assessor, "assessed_at": assessment.assessed_at,
            "evidence_results": assessment.evidence_results,
            "dimensions": assessment.dimensions, "limitations": list(assessment.limitations),
        })
        self.g.link(node.id, "evaluates", claim_id)
        return assessment

@dataclass(frozen=True)
class ClaimSynthesis:
    claim_id: str
    disposition: str
    uncertainty: dict | None
    supporting_evidence_ids: tuple[str, ...]
    refuting_evidence_ids: tuple[str, ...]
    limitations: tuple[str, ...]
    synthesized_at: str


class ClaimSynthesizer:
    """Produce an explicit, reversible epistemic synthesis without asserting truth.

    Synthesis combines already-recorded claim/evidence assessments. It never
    overwrites evidence or silently changes a claim's truth status.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    @staticmethod
    def _uncertainty_from_evidence(evidence):
        values = []
        intervals = []
        confidences = []
        for ev in evidence:
            u = ev.metadata.get("uncertainty")
            if not isinstance(u, dict):
                continue
            if u.get("lower") is not None and u.get("upper") is not None:
                try:
                    intervals.append((float(u["lower"]), float(u["upper"]), u.get("unit")))
                except (TypeError, ValueError):
                    pass
            if u.get("value") is not None:
                try:
                    values.append(float(u["value"]))
                except (TypeError, ValueError):
                    pass
            if u.get("confidence_level") is not None:
                try:
                    c = float(u["confidence_level"])
                    if 0 <= c <= 1:
                        confidences.append(c)
                except (TypeError, ValueError):
                    pass
        if intervals:
            units = {x[2] for x in intervals}
            if len(units) == 1:
                return {"type": "interval", "lower": min(x[0] for x in intervals),
                        "upper": max(x[1] for x in intervals), "unit": next(iter(units)),
                        "method": "conservative_envelope", "basis": "supporting_evidence"}
        if values:
            return {"type": "observations", "values": values,
                    "method": "unaggregated_observations", "basis": "supporting_evidence"}
        if confidences:
            return {"type": "confidence_observations", "values": confidences,
                    "method": "unaggregated_confidence_levels", "basis": "supporting_evidence"}
        return None

    def synthesize(self, claim_id: str, assessment: ClaimAssessment | None = None, *, as_of=None):
        claim = self.g.get(claim_id)
        if not claim or claim.kind != "Claim":
            raise ValueError(f"not a claim: {claim_id}")
        assessment = assessment or ClaimEvaluator(self.g).assess(claim_id, as_of=as_of)
        supporting = tuple(eid for eid, rel in assessment.evidence_results.items() if rel in {"entails", "supports"})
        refuting = tuple(eid for eid, rel in assessment.evidence_results.items() if rel == "refutes")
        limitations = list(assessment.limitations)
        if not supporting:
            disposition = "unsupported" if not refuting else "refuted"
        elif refuting:
            disposition = "contested"
            limitations.append("supporting and refuting evidence coexist")
        elif assessment.dimensions["evidence_warrant"] == "entailed":
            disposition = "entailed"
        elif assessment.dimensions["evidence_warrant"] == "supported_not_entailed":
            disposition = "supported"
        else:
            disposition = "indeterminate"
        uncertainty = self._uncertainty_from_evidence([self.g.get(eid) for eid in supporting])
        if uncertainty is None and claim.metadata.get("structured", {}).get("uncertainty"):
            uncertainty = claim.metadata["structured"]["uncertainty"]
        if uncertainty is None:
            limitations.append("no structured uncertainty available for synthesis")
        now = as_of or datetime.now(timezone.utc)
        if isinstance(now, str):
            now = self.g._parse_time(now) or datetime.now(timezone.utc)
        return ClaimSynthesis(claim_id, disposition, uncertainty, supporting, refuting,
                              tuple(dict.fromkeys(limitations)), now.isoformat())

    def record(self, claim_id: str, *, assessor="system", as_of=None):
        synthesis = self.synthesize(claim_id, as_of=as_of)
        node = self.g.add_node("ClaimSynthesis", f"Synthesis of {claim_id}", "supported", {
            "claim_id": claim_id, "assessor": assessor, "synthesized_at": synthesis.synthesized_at,
            "disposition": synthesis.disposition, "uncertainty": synthesis.uncertainty,
            "supporting_evidence_ids": list(synthesis.supporting_evidence_ids),
            "refuting_evidence_ids": list(synthesis.refuting_evidence_ids),
            "limitations": list(synthesis.limitations),
        })
        self.g.link(node.id, "evaluates", claim_id)
        self.g._event("claim.synthesized", node.id, {
            "claim_id": claim_id, "disposition": synthesis.disposition,
            "uncertainty": synthesis.uncertainty,
        })
        return synthesis
