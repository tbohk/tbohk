from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from .core import TBOHK

SCENARIOS = {
    'remove_premise', 'substitute_premise', 'fail_assumption', 'activate_defeater',
    'withdraw_evidence', 'invalidate_source', 'advance_time', 'inject_contradiction',
    'change_rule_version', 'break_dependency'
}

@dataclass(frozen=True)
class StressCase:
    scenario: str
    target_id: str
    affected_claim_ids: tuple[str, ...]
    outcome: str
    findings: tuple[str, ...]

@dataclass(frozen=True)
class RobustnessReport:
    root_id: str
    baseline: str
    cases: tuple[StressCase, ...]
    resilience: str
    assessed_at: str

class ReasoningStressTester:
    """G4.6 non-mutating robustness analysis.

    Stress cases model failures against the existing provenance graph. They do
    not alter source claims or silently promote/demote epistemic status.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _node(self, nid):
        return self.g.get(nid)

    def _activities_for_claim(self, claim_id):
        rows = self.g.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation='derives'", (claim_id,)
        ).fetchall()
        return [r[0] for r in rows if self._node(r[0]) and self._node(r[0]).kind == 'ReasoningActivity']

    def _dependent_claims(self, node_id):
        """Downstream claims reachable through derived_from/generated_by provenance."""
        found=set(); queue=[node_id]
        while queue:
            nid=queue.pop(0)
            rows=self.g.db.execute(
                "SELECT source_id FROM edges WHERE target_id=? AND relation='derived_from'", (nid,)
            ).fetchall()
            for r in rows:
                c=self._node(r[0])
                if c and c.kind=='Claim' and c.id not in found:
                    found.add(c.id); queue.append(c.id)
        if self._node(node_id) and self._node(node_id).kind=='Claim': found.discard(node_id)
        return found

    def _root_activity(self, root_id):
        n=self._node(root_id)
        if not n: raise ValueError(root_id)
        if n.kind=='ReasoningActivity': return n
        if n.kind=='Claim':
            acts=self._activities_for_claim(n.id)
            if len(acts)==1: return self._node(acts[0])
            if not acts: raise ValueError('claim has no reasoning activity')
            raise ValueError('claim has multiple derivations; target an activity')
        raise ValueError('target must be Claim or ReasoningActivity')

    def _case(self, scenario, target, affected, outcome, *findings):
        return StressCase(scenario, target, tuple(sorted(set(affected))), outcome, tuple(findings))

    def test(self, root_id: str, scenarios=None, *, assessor='independent-stress-review', as_of=None):
        activity=self._root_activity(root_id)
        m=activity.metadata
        premise_ids=list(m.get('premise_ids') or [])
        assumptions=list(m.get('assumption_ids') or [])
        defeaters=list(m.get('defeater_ids') or [])
        conclusion=m.get('conclusion_id')
        if not conclusion: raise ValueError('reasoning activity has no conclusion')
        selected=list(scenarios or SCENARIOS)
        unknown=set(selected)-SCENARIOS
        if unknown: raise ValueError(f'unsupported scenarios: {sorted(unknown)}')
        cases=[]
        downstream=self._dependent_claims(conclusion)
        all_affected={conclusion,*downstream}

        for s in selected:
            if s=='remove_premise':
                if not premise_ids: cases.append(self._case(s,activity.id,all_affected,'no_effect','no premises recorded'))
                else:
                    for pid in premise_ids:
                        cases.append(self._case(s,pid,all_affected,'fragile',f'removing premise {pid} breaks the recorded premise set'))
            elif s=='substitute_premise':
                cases.append(self._case(s,activity.id,all_affected,'requires_reanalysis','substitution can only be accepted after semantic and rule applicability checks'))
            elif s=='fail_assumption':
                if assumptions: cases.append(self._case(s,assumptions[0],all_affected,'conditionally_fragile','an explicit assumption is load-bearing'))
                else: cases.append(self._case(s,activity.id,all_affected,'no_effect','no explicit assumption is recorded'))
            elif s=='activate_defeater':
                if defeaters: cases.append(self._case(s,defeaters[0],all_affected,'defeated_or_reassess','an explicit defeater can defeat or condition the inference'))
                else: cases.append(self._case(s,activity.id,all_affected,'no_recorded_defeater','no explicit defeater is recorded'))
            elif s=='withdraw_evidence':
                evidence=[]
                for pid in premise_ids:
                    rows=self.g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='evidence_for'",(pid,)).fetchall()
                    evidence += [r[0] for r in rows]
                if evidence: cases.append(self._case(s,evidence[0],all_affected,'requires_reverification','withdrawing supporting evidence invalidates the evidential basis until re-evaluated'))
                else: cases.append(self._case(s,activity.id,all_affected,'no_direct_evidence_found','no direct evidence_for edge was found on premises'))
            elif s=='invalidate_source':
                cases.append(self._case(s,activity.id,all_affected,'requires_reverification','source invalidation must propagate through evidence and dependent claims'))
            elif s=='advance_time':
                cases.append(self._case(s,activity.id,all_affected,'temporal_reassessment','future time may make premises stale or outside their validity interval'))
            elif s=='inject_contradiction':
                cases.append(self._case(s,conclusion,all_affected,'contested','a contradictory claim must be analyzed as a conflict rather than silently selecting a side'))
            elif s=='change_rule_version':
                cases.append(self._case(s,m.get('rule_id') or activity.id,all_affected,'requires_recomputation','changing a rule changes the derivation basis'))
            elif s=='break_dependency':
                cases.append(self._case(s,activity.id,all_affected,'broken','breaking a recorded dependency removes part of the justification chain'))

        fragile={'fragile','defeated_or_reassess','requires_reverification','broken'}
        conditional={'conditionally_fragile','temporal_reassessment','requires_reanalysis','requires_recomputation','contested'}
        outcomes={c.outcome for c in cases}
        if outcomes & fragile: resilience='fragile'
        elif outcomes & conditional: resilience='conditional'
        else: resilience='unaffected_by_recorded_stressors'
        now=as_of or datetime.now(timezone.utc)
        if isinstance(now,str): now=self.g._parse_time(now) or datetime.now(timezone.utc)
        return RobustnessReport(conclusion,'baseline_unchanged',tuple(cases),resilience,now.isoformat())

    def record(self, root_id: str, scenarios=None, *, assessor='independent-stress-review', as_of=None):
        report=self.test(root_id,scenarios,assessor=assessor,as_of=as_of)
        node=self.g.add_node('RobustnessAssessment',f'G4.6 robustness assessment of {root_id}','supported',{
            'root_id':root_id,'assessor':assessor,'assessed_at':report.assessed_at,
            'baseline':report.baseline,'resilience':report.resilience,
            'cases':[{'scenario':c.scenario,'target_id':c.target_id,'affected_claim_ids':list(c.affected_claim_ids),'outcome':c.outcome,'findings':list(c.findings)} for c in report.cases]
        })
        self.g.link(node.id,'evaluates',root_id)
        return report
