"""Cross-layer release assurance gates for TBOHK.

This module is intentionally conservative. It checks that the release is not
advancing one layer while another layer remains stale or syntactically broken.
It does not mutate source, data, truth state, or deployment authority.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import ast, json, re
from hashlib import sha256

VERSION = "0.59.2"

@dataclass(frozen=True)
class GuardCheck:
    check_id: str
    layer: str
    passed: bool
    detail: str

@dataclass(frozen=True)
class GuardReport:
    version: str
    checks: tuple[GuardCheck, ...]
    digest: str
    passed: bool


def _digest(value) -> str:
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

class ReleaseGuard:
    """Run cheap deterministic cross-layer checks before expensive suites."""
    VERSION = "RG1.0-1"

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.package = self.root / "tbohk"
        self.tests = self.root / "tests"

    def run(self) -> GuardReport:
        checks = [
            self._python_syntax(),
            self._version_consistency(),
            self._ui_contracts(),
            self._test_inventory(),
            self._architecture_self_edge_scan(),
            self._artifact_hygiene(),
        ]
        payload = [asdict(x) for x in checks]
        return GuardReport(VERSION, tuple(checks), _digest(payload), all(x.passed for x in checks))

    def _python_syntax(self) -> GuardCheck:
        failures=[]
        for p in sorted(self.package.rglob("*.py")):
            if "__pycache__" in p.parts: continue
            try: ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
            except (SyntaxError, UnicodeDecodeError) as e: failures.append(f"{p.name}: {e}")
        return GuardCheck("python.syntax", "backend", not failures, "; ".join(failures) if failures else "all package Python files parse")

    def _version_consistency(self) -> GuardCheck:
        init=(self.package/"__init__.py").read_text(encoding="utf-8")
        py=(self.root/"pyproject.toml").read_text(encoding="utf-8")
        init_v=re.search(r'__version__\s*=\s*[\"\']([^\"\']+)', init)
        py_v=re.search(r'^version\s*=\s*[\"\']([^\"\']+)', py, re.M)
        ok=bool(init_v and py_v and init_v.group(1)==py_v.group(1)==VERSION)
        return GuardCheck("release.version", "release", ok, f"package={init_v.group(1) if init_v else 'missing'} pyproject={py_v.group(1) if py_v else 'missing'} expected={VERSION}")

    def _ui_contracts(self) -> GuardCheck:
        ui=self.package/"ui.html"
        text=ui.read_text(encoding="utf-8")
        required_ids=("answerOut","investigationHealthOut","globalSearch","commandOverlay","toast","health","graphExplorerOut")
        missing=[x for x in required_ids if f'id="{x}"' not in text]
        required_functions=("renderAnswer","runInvestigationHealth","runGlobalSearch","showView","runUiSelfCheck","exploreGraphNode","loadKnowledgeMap","selectMapNode","loadMapImpact","loadMapAttention")
        missing += [x for x in required_functions if not re.search(rf"function\s+{re.escape(x)}\s*\(", text)]
        return GuardCheck("ui.contract", "frontend", not missing, "all required UI contracts present" if not missing else "missing: "+", ".join(missing))

    def _test_inventory(self) -> GuardCheck:
        tests=list(self.tests.glob("test_*.py")) if self.tests.exists() else []
        backend_modules=[p for p in self.package.glob("*.py") if p.name not in {"__init__.py"}]
        names=" ".join(p.stem for p in tests)
        critical=("evaluation","selftest","repair","assurance","ui","release")
        covered=[k for k in critical if k in names.lower()]
        ok=bool(tests) and len(covered)>=5
        return GuardCheck("test.inventory", "testing", ok, f"{len(tests)} test modules; critical coverage families={','.join(covered)}")

    def _architecture_self_edge_scan(self) -> GuardCheck:
        modules={p.relative_to(self.package).with_suffix("").as_posix().replace("/",".") for p in self.package.rglob("*.py") if "__pycache__" not in p.parts}
        self_edges=[]
        for p in self.package.rglob("*.py"):
            if "__pycache__" in p.parts: continue
            name=p.relative_to(self.package).with_suffix("").as_posix().replace("/",".")
            try: tree=ast.parse(p.read_text(encoding="utf-8"))
            except SyntaxError: continue
            for x in ast.walk(tree):
                targets=[]
                if isinstance(x, ast.Import): targets=[a.name for a in x.names]
                elif isinstance(x, ast.ImportFrom) and x.module: targets=[x.module]
                for t in targets:
                    if t==name: self_edges.append(name)
        return GuardCheck("architecture.no_self_edges", "architecture", not self_edges, "no module imports itself" if not self_edges else "self-imports: "+", ".join(sorted(set(self_edges))))

    def _artifact_hygiene(self) -> GuardCheck:
        # Test runners legitimately create caches in the working tree. The release
        # gate checks dedicated output directories instead, where cache leakage is
        # actually a shipping defect.
        outputs=[self.root/"dist", self.root/"release", self.root/"artifacts"]
        bad=[]
        for base in outputs:
            if not base.exists(): continue
            bad.extend(str(p.relative_to(self.root)) for p in base.rglob("*") if p.is_file() and (p.suffix in {".pyc", ".pyo"} or "__pycache__" in p.parts))
        return GuardCheck("artifact.hygiene", "packaging", not bad, "release output directories are cache-free" if not bad else "cache/bytecode present: "+", ".join(bad[:8]))
