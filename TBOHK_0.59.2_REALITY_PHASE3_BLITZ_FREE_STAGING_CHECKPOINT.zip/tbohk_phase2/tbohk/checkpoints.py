from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from dataclasses import dataclass

@dataclass(frozen=True)
class Checkpoint:
    checkpoint_id: str
    manifest_sha256: str
    manifest: dict

class CheckpointManager:
    def __init__(self, graph): self.g = graph

    def _snapshot(self):
        rows = self.g.db.execute("SELECT id,kind,status,content,metadata FROM nodes WHERE kind NOT IN ('Checkpoint','HealthSnapshot') ORDER BY id").fetchall()
        edges = self.g.db.execute("SELECT source_id,relation,target_id FROM edges WHERE source_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) AND target_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY source_id,relation,target_id").fetchall()
        events = self.g.db.execute("SELECT id,event_type,subject_id,payload,created_at FROM events WHERE subject_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY rowid").fetchall()
        revisions = self.g.db.execute("SELECT id,node_id,old_status,new_status,old_content,new_content,reason,created_at FROM revisions WHERE node_id NOT IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')) ORDER BY rowid").fetchall()
        ledger = self.g.db.execute("SELECT table_name,row_id,chain_prev,chain_hash FROM ledger_chain WHERE NOT (table_name='events' AND row_id IN (SELECT id FROM events WHERE subject_id IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')))) AND NOT (table_name='revisions' AND row_id IN (SELECT id FROM revisions WHERE node_id IN (SELECT id FROM nodes WHERE kind IN ('Checkpoint','HealthSnapshot')))) ORDER BY table_name,rowid").fetchall()
        return rows, edges, events, revisions, ledger

    @staticmethod
    def _hash_rows(rows):
        return hashlib.sha256(json.dumps([dict(r) for r in rows], sort_keys=True).encode()).hexdigest()

    def create(self, *, code_version, schema_version, invariant_version, test_summary,
               dependency_versions=None, signer=None, parent_checkpoint_id=None, checkpoint_sequence=None,
               require_clean=True):
        if require_clean:
            audit = self.g.audit()
            structural = {
                "audit_exception", "content_hash_mismatch", "metadata_hash_mismatch",
                "snapshot_hash_mismatch", "snapshot_without_source_id",
                "snapshot_without_provider_id", "snapshot_without_origin_id",
                "snapshot_without_retrieval_time", "invalid_retrieval_time",
                "invalid_publication_time", "invalid_valid_from", "invalid_valid_until",
                "invalid_validity_interval", "evidence_without_source_snapshot",
                "evidence_invalid_locator", "evidence_without_extraction_method",
                "invalid_observation_time", "research_record_without_query",
            }
            blocking = [p for p in audit.get("problems", []) if len(p) > 1 and p[1] in structural]
            if blocking:
                raise ValueError(f"cannot checkpoint structurally compromised graph: {blocking!r}")
        rows, edges, events, revisions, ledger = self._snapshot()
        manifest = {
            'code_version': code_version, 'schema_version': schema_version,
            'invariant_version': invariant_version, 'test_summary': test_summary,
            'dependency_versions': dependency_versions or {},
            'node_hash': self._hash_rows(rows), 'edge_hash': self._hash_rows(edges),
            'event_hash': self._hash_rows(events), 'revision_hash': self._hash_rows(revisions),
            'ledger_hash': self._hash_rows(ledger),
            'created_at': datetime.now(timezone.utc).isoformat(),
        }
        digest = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
        metadata = {'manifest': manifest, 'manifest_sha256': digest}
        if parent_checkpoint_id is not None:
            parent = self.g.get(parent_checkpoint_id)
            if not parent or parent.kind != 'Checkpoint': raise ValueError('invalid parent checkpoint')
            metadata['parent_checkpoint_id'] = parent_checkpoint_id
        if checkpoint_sequence is not None:
            if not isinstance(checkpoint_sequence, int) or checkpoint_sequence < 0:
                raise ValueError('checkpoint_sequence must be a non-negative integer')
            metadata['checkpoint_sequence'] = checkpoint_sequence
        if signer is not None: metadata['release_signature'] = signer.sign(manifest).__dict__
        n = self.g.add_node('Checkpoint', f'checkpoint-{digest[:12]}', 'supported', metadata)
        return Checkpoint(n.id, digest, manifest)

    def external_anchor(self, checkpoint_id, anchor_store):
        """Append the checkpoint manifest identity to an external trust domain."""
        n = self.g.get(checkpoint_id)
        if not n or n.kind != "Checkpoint":
            raise KeyError(checkpoint_id)
        if not self.verify(checkpoint_id):
            raise ValueError("cannot externally anchor an unverifiable checkpoint")
        return anchor_store.append(checkpoint_id, n.metadata["manifest"], n.metadata["manifest_sha256"])

    def verify(self, checkpoint_id):
        n = self.g.get(checkpoint_id)
        if not n or n.kind != 'Checkpoint': return False
        m, d = n.metadata.get('manifest'), n.metadata.get('manifest_sha256')
        if not isinstance(m, dict) or hashlib.sha256(json.dumps(m, sort_keys=True).encode()).hexdigest() != d:
            return False
        rows, edges, events, revisions, ledger = self._snapshot()
        hashes = {
            'node_hash': self._hash_rows(rows), 'edge_hash': self._hash_rows(edges),
            'event_hash': self._hash_rows(events), 'revision_hash': self._hash_rows(revisions),
            'ledger_hash': self._hash_rows(ledger),
        }
        return all(m.get(k) == v for k, v in hashes.items())
