from __future__ import annotations
from dataclasses import dataclass
from collections import deque

FORWARD_DEPENDENCY = {"evidence_for", "supports", "premise_of", "invalidates"}
REVERSE_DEPENDENCY = {"based_on", "derived_from", "assumes", "uses", "evaluates_against", "depends_on"}
PROMOTABLE = {"proposed", "supported", "verified", "recovered", "resolved"}

@dataclass(frozen=True)
class ContaminationFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    invariant: str
    blocks_release: bool
    evidence: str

@dataclass(frozen=True)
class QuarantinePlan:
    root_ids: tuple[str, ...]
    quarantined_ids: tuple[str, ...]
    promotion_blocked_ids: tuple[str, ...]
    unaffected_ids: tuple[str, ...]
    reasons: tuple[tuple[str, str], ...]

@dataclass(frozen=True)
class ContaminationReport:
    passed: bool
    findings: tuple[ContaminationFinding, ...]
    plans: tuple[QuarantinePlan, ...]

class ContaminationValidator:
    """G19: contamination propagation and quarantine-boundary validator."""
    def __init__(self, graph):
        self.g = graph

    def _neighbors(self, node_id):
        out = []
        ph = ",".join("?" for _ in FORWARD_DEPENDENCY)
        rows = self.g.db.execute(
            f"SELECT target_id FROM edges WHERE source_id=? AND relation IN ({ph})",
            (node_id, *sorted(FORWARD_DEPENDENCY))).fetchall()
        out.extend(r[0] for r in rows)
        ph = ",".join("?" for _ in REVERSE_DEPENDENCY)
        rows = self.g.db.execute(
            f"SELECT source_id FROM edges WHERE target_id=? AND relation IN ({ph})",
            (node_id, *sorted(REVERSE_DEPENDENCY))).fetchall()
        out.extend(r[0] for r in rows)
        # Metadata dependencies are encoded as dependent -> dependency, so find
        # nodes that explicitly declare this node as a prerequisite.
        for row in self.g.db.execute("SELECT id, metadata FROM nodes").fetchall():
            try:
                deps = __import__("json").loads(row["metadata"]).get("dependency_ids", [])
            except Exception:
                deps = []
            if node_id in deps:
                out.append(row["id"])
        return tuple(dict.fromkeys(out))

    def closure(self, root_ids):
        affected, q = set(), deque(sorted(set(root_ids)))
        while q:
            cur = q.popleft()
            if cur in affected or not self.g.get(cur):
                continue
            affected.add(cur)
            q.extend(n for n in self._neighbors(cur) if n not in affected)
        return tuple(sorted(affected))

    def plan_quarantine(self, root_ids):
        roots = tuple(sorted(set(root_ids)))
        contaminated = set(self.closure(roots))
        blocked, reasons = [], []
        for nid in sorted(contaminated):
            n = self.g.get(nid)
            if n and n.status in PROMOTABLE:
                blocked.append(nid)
                reasons.append((nid, "contamination closure blocks promotion or continued verification"))
        all_ids = {r[0] for r in self.g.db.execute("SELECT id FROM nodes").fetchall()}
        return QuarantinePlan(roots, tuple(sorted(contaminated)), tuple(blocked),
                              tuple(sorted(all_ids - contaminated)), tuple(reasons))

    def audit(self, root_ids=()):
        findings, plans = [], []
        for rid in tuple(sorted(set(root_ids))):
            if not self.g.get(rid):
                findings.append(ContaminationFinding("contamination_root_missing", "critical", (rid,), "I19", True, "declared contamination root does not exist"))
                continue
            p = self.plan_quarantine((rid,)); plans.append(p)
            root = self.g.get(rid)
            if root.status == "verified":
                findings.append(ContaminationFinding("contaminated_root_verified", "critical", (rid,), "I19", True, "contamination declaration conflicts with verified root status"))
            for nid in p.promotion_blocked_ids:
                n = self.g.get(nid)
                if n and n.status == "verified":
                    findings.append(ContaminationFinding("verified_contaminated_derivative", "critical", (rid, nid), "I19", True, f"verified {n.kind} lies inside contamination closure"))
                elif n:
                    findings.append(ContaminationFinding("promotion_blocked_contaminated_derivative", "high", (rid, nid), "I19", True, f"{n.kind} is {n.status} and must not be promoted while contaminated"))
            for nid in p.quarantined_ids:
                n = self.g.get(nid)
                if not n or nid == rid:
                    continue
                try:
                    declared = n.metadata.get("dependency_ids", [])
                except Exception:
                    declared = []
                for dep in declared:
                    if dep == rid and nid not in p.quarantined_ids:
                        findings.append(ContaminationFinding("contamination_path_hole", "critical", (rid, nid), "I19", True, "declared contaminated dependency is outside quarantine closure"))
        return ContaminationReport(not any(f.blocks_release for f in findings), tuple(findings), tuple(plans))
