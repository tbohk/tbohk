from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from .core import TBOHK
from .semantics import METHODS

VERDICTS = {"warranted", "conditionally_warranted", "insufficient", "invalid", "contested"}

@dataclass(frozen=True)
class InferenceAssessment:
    activity_id: str
    conclusion_id: str
    verdict: str
    dimensions: dict[str, str]
    findings: tuple[str, ...]
    competing_activity_ids: tuple[str, ...]
    assessed_at: str

class InferenceEvaluator:
    """G4.3 independent evaluation of a reasoning activity.

    This layer evaluates the reasoning record; it never changes the conclusion's
    truth/status and never certifies its own evaluation as a verification event.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _node(self, nid, kind=None):
        n = self.g.get(nid)
        if not n or (kind and n.kind != kind):
            return None
        return n

    def _ancestors(self, claim_id):
        seen, stack = set(), [claim_id]
        while stack:
            cid = stack.pop()
            if cid in seen: continue
            seen.add(cid)
            for row in self.g.db.execute(
                "SELECT source_id FROM edges WHERE target_id=? AND relation IN ('derived_from','generated_by')", (cid,)):
                n = self.g.get(row[0])
                if n and n.kind == "Claim": stack.append(n.id)
            for row in self.g.db.execute(
                "SELECT target_id FROM edges WHERE source_id=? AND relation='uses'", (cid,)):
                n = self.g.get(row[0])
                if n and n.kind == "Claim": stack.append(n.id)
        return seen

    def _cycle(self, activity_id, conclusion_id):
        # Follow premise -> generating reasoning activity dependencies. The
        # normal conclusion -> premise provenance edge is not itself a cycle.
        seen, stack = set(), []
        for row in self.g.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='uses'", (activity_id,)):
            stack.append(row[0])
        while stack:
            claim_id = stack.pop()
            if claim_id == conclusion_id: return True
            if claim_id in seen: continue
            seen.add(claim_id)
            for row in self.g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='generated_by'", (claim_id,)):
                parent_activity = row[0]
                if parent_activity == activity_id: return True
                for p in self.g.db.execute("SELECT target_id FROM edges WHERE source_id=? AND relation='uses'", (parent_activity,)):
                    stack.append(p[0])
        return False

    def _competing(self, conclusion_id, activity_id):
        rows = self.g.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation IN ('derives','produces')", (conclusion_id,)
        ).fetchall()
        return tuple(sorted({r[0] for r in rows if r[0] != activity_id and self.g.get(r[0]) and self.g.get(r[0]).kind == 'ReasoningActivity'}))

    def assess(self, activity_id: str, *, assessor="independent-review", as_of=None) -> InferenceAssessment:
        a = self._node(activity_id, "ReasoningActivity")
        if not a: raise ValueError(f"not a reasoning activity: {activity_id}")
        m = a.metadata
        method = m.get("method")
        # G4 executable rules are deductive by semantics; G4.2 semantic
        # activities already carry their explicit method names.
        effective_method = method if method in METHODS else ("deductive" if method in {"identity","conjunction","modus_ponens"} else method)
        conclusion_id = m.get("conclusion_id")
        conclusion = self._node(conclusion_id, "Claim") if conclusion_id else None
        findings=[]
        d={}

        d["method_validity"] = "valid" if effective_method in METHODS else "invalid"
        if d["method_validity"] == "invalid": findings.append("reasoning method is unknown")

        premise_ids = m.get("premise_ids") or []
        premises=[]
        for pid in premise_ids:
            p=self._node(pid,"Claim")
            if p: premises.append(p)
            else: findings.append(f"missing premise: {pid}")
        d["premise_completeness"] = "complete" if len(premises)==len(premise_ids) and premise_ids else "insufficient"
        if d["premise_completeness"] != "complete": findings.append("one or more recorded premises are unavailable")

        d["premise_status"] = "adequate" if premises and all(p.status in {"supported","verified"} for p in premises) else "insufficient"
        if d["premise_status"] != "adequate": findings.append("premise status is not sufficient for this reasoning layer")

        roles=m.get("premise_roles") or {}
        if method in {"deductive","defeasible"} and not roles:
            d["premise_role_completeness"]="insufficient"; findings.append("deductive/defeasible reasoning lacks explicit premise roles")
        else: d["premise_role_completeness"]="stated"

        rule_id=m.get("rule_id")
        rule=self._node(rule_id,"ReasoningRule") if rule_id else None
        d["rule_integrity"]="valid" if rule and rule.metadata.get("rule_sha256") == self.g._hash(json.dumps({k:v for k,v in rule.metadata.items() if k not in {"rule_sha256","content_sha256","metadata_sha256"}}, sort_keys=True)) else ("not_applicable" if not rule_id else "invalid")
        if d["rule_integrity"] == "invalid": findings.append("reasoning rule is missing or has an invalid integrity hash")

        d["assumption_exposure"] = "present" if m.get("assumption_ids") else "none_recorded"
        for aid in m.get("assumption_ids") or []:
            if not self._node(aid,"Assumption"): findings.append(f"missing assumption: {aid}")
        if m.get("assumption_ids"): findings.append("conclusion is conditional on explicit assumptions")

        d["defeater_exposure"] = "present" if m.get("defeater_ids") else "none_recorded"
        for did in m.get("defeater_ids") or []:
            if not self._node(did,"Defeater"): findings.append(f"missing defeater: {did}")
        if m.get("defeater_ids"): findings.append("one or more defeaters may defeat the inference")

        d["scope"] = "stated" if conclusion and conclusion.metadata.get("structured",{}).get("scope") is not None else "unstated"
        if d["scope"] == "unstated": findings.append("conclusion scope is not explicit")

        d["uncertainty"] = "represented" if conclusion and conclusion.metadata.get("structured",{}).get("uncertainty") is not None else "not_stated"
        if d["uncertainty"] == "not_stated": findings.append("conclusion uncertainty is not explicitly represented")

        d["circularity"] = "detected" if conclusion and self._cycle(activity_id, conclusion.id) else "none_detected"
        if d["circularity"] == "detected": findings.append("reasoning chain is circular or self-supporting")

        competing=self._competing(conclusion_id, activity_id) if conclusion else ()
        d["competing_derivations"] = "present" if competing else "none_recorded"
        if competing: findings.append("conclusion has competing derivation path(s)")

        if method == "counterfactual":
            d["hypothetical_isolation"] = "isolated" if m.get("counterfactual") and m.get("counterfactual").get("intervention") else "invalid"
        else: d["hypothetical_isolation"]="not_applicable"
        if d["hypothetical_isolation"] == "invalid": findings.append("counterfactual intervention is missing")

        invalid = any(v == "invalid" for v in d.values()) or d["circularity"] == "detected"
        insufficient = d["premise_completeness"] != "complete" or d["premise_status"] != "adequate"
        conditional = bool(m.get("assumption_ids") or m.get("defeater_ids"))
        if invalid: verdict="invalid"
        elif insufficient: verdict="insufficient"
        elif competing: verdict="contested"
        elif conditional: verdict="conditionally_warranted"
        else: verdict="warranted"
        now=as_of or datetime.now(timezone.utc)
        if isinstance(now,str): now=self.g._parse_time(now) or datetime.now(timezone.utc)
        return InferenceAssessment(activity_id, conclusion_id, verdict, d, tuple(findings), competing, now.isoformat())

    def record(self, activity_id: str, *, assessor="independent-review", as_of=None):
        assessment=self.assess(activity_id, assessor=assessor, as_of=as_of)
        node=self.g.add_node("InferenceAssessment", f"Independent assessment of {activity_id}", "supported", {
            "activity_id":activity_id, "conclusion_id":assessment.conclusion_id,
            "assessor":assessor, "assessed_at":assessment.assessed_at,
            "verdict":assessment.verdict, "dimensions":assessment.dimensions,
            "findings":list(assessment.findings), "competing_activity_ids":list(assessment.competing_activity_ids),
        })
        self.g.link(node.id,"evaluates",activity_id)
        return assessment
