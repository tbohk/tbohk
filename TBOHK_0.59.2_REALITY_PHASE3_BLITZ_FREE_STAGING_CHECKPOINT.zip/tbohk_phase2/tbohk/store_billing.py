from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable
import hashlib, json

STORE_PROVIDERS = frozenset({'apple','google'})
VALID_STATES = frozenset({'active','trialing','grace_period','paused','canceled','expired','revoked','pending','recovered'})

@dataclass(frozen=True)
class VerifiedPurchase:
    provider: str
    purchase_id: str
    account_id: str
    product_id: str
    plan: str
    status: str
    transaction_id: str | None = None
    original_transaction_id: str | None = None
    current_period_end: str | None = None
    cancel_at_period_end: bool = False
    raw: dict[str, Any] | None = None

    def entitlement_id(self) -> str:
        return self.original_transaction_id or self.transaction_id or self.purchase_id

class PurchaseVerificationError(ValueError):
    pass

class StorePurchaseVerifier:
    """Provider-neutral authority boundary. Real Apple/Google verification is injected.

    The verifier never trusts a client-supplied plan or status. Provider adapters must
    return a normalized payload after validating provider signatures/tokens with the
    official store authority.
    """
    def __init__(self, adapters: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] | None = None):
        self.adapters = adapters or {}

    def verify(self, provider: str, payload: dict[str, Any], account_id: str) -> VerifiedPurchase:
        provider = provider.strip().lower()
        if provider not in STORE_PROVIDERS:
            raise PurchaseVerificationError('unsupported store provider')
        if not account_id:
            raise PurchaseVerificationError('account identity is required')
        adapter = self.adapters.get(provider)
        if adapter is None:
            raise PurchaseVerificationError(f'{provider} store verification is not configured')
        try:
            data = adapter(dict(payload))
        except PurchaseVerificationError:
            raise
        except Exception as exc:
            raise PurchaseVerificationError(f'{provider} purchase verification failed') from exc
        if not isinstance(data, dict):
            raise PurchaseVerificationError('store verifier returned invalid data')
        required = ('purchase_id','product_id','plan','status')
        if any(not str(data.get(k,'' )).strip() for k in required):
            raise PurchaseVerificationError('verified purchase is missing required fields')
        plan = str(data['plan']).strip().lower()
        if plan not in {'free','pro','unlimited'}:
            raise PurchaseVerificationError('verified purchase has invalid plan')
        status = str(data['status']).strip().lower()
        if status not in VALID_STATES:
            raise PurchaseVerificationError('verified purchase has invalid status')
        return VerifiedPurchase(provider=provider,purchase_id=str(data['purchase_id']),account_id=account_id,
            product_id=str(data['product_id']),plan=plan,status=status,
            transaction_id=data.get('transaction_id'),original_transaction_id=data.get('original_transaction_id'),
            current_period_end=data.get('current_period_end'),cancel_at_period_end=bool(data.get('cancel_at_period_end',False)),raw=data.get('raw') or {})

def deterministic_event_id(provider: str, payload: dict[str, Any]) -> str:
    return provider + '_' + hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def validate_event_timestamp(value: str | None, max_age_seconds: int = 86400) -> None:
    if not value:
        return
    try:
        dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError as exc:
        raise PurchaseVerificationError('invalid event timestamp') from exc
    if abs((datetime.now(timezone.utc)-dt).total_seconds()) > max_age_seconds:
        raise PurchaseVerificationError('stale store event')
