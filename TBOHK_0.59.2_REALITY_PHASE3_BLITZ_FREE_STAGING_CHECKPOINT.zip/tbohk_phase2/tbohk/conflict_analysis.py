from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from .core import TBOHK

VERDICTS = {"unresolved", "balanced", "supports_a", "supports_b", "scope_separated", "insufficient"}

@dataclass(frozen=True)
class ConflictAssessment:
    conflict_id: str
    member_claim_ids: tuple[str, ...]
    verdict: str
    dimensions: dict[str, str]
    objections: tuple[str, ...]
    defeaters: tuple[str, ...]
    derivation_activity_ids: tuple[str, ...]
    assessed_at: str

class ConflictAnalyzer:
    """G4.4 analysis of competing claims without selecting truth by default.

    A conflict is analyzed through provenance, scope, time, derivation,
    objections and defeaters. Analysis records an explicit verdict only when
    the graph contains an explicit resolution or a structural scope split.
    It never changes claim status and never silently resolves a ConflictSet.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _claims(self, conflict_id):
        return [self.g.get(r[0]) for r in self.g.db.execute(
            "SELECT target_id FROM edges WHERE source_id=? AND relation='contains'", (conflict_id,))
            if self.g.get(r[0]) and self.g.get(r[0]).kind == "Claim"]

    def _resolutions(self, conflict_id):
        return [self.g.get(r[0]) for r in self.g.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation='resolves'", (conflict_id,))
            if self.g.get(r[0])]

    def _activities(self, claim_id):
        return [r[0] for r in self.g.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation IN ('derives','produces')", (claim_id,))
            if self.g.get(r[0]) and self.g.get(r[0]).kind == 'ReasoningActivity']

    def _scope(self, claim):
        return claim.metadata.get("structured", {}).get("scope")

    def _time(self, claim):
        return claim.metadata.get("structured", {}).get("time")

    def _explicit_defeaters(self, claim_id):
        ids=[]
        for aid in self._activities(claim_id):
            for r in self.g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='defeats'", (aid,)):
                n=self.g.get(r[0])
                if n and n.kind == 'Defeater': ids.append(n.id)
        return sorted(set(ids))

    def assess(self, conflict_id: str, *, assessor="independent-conflict-review", as_of=None):
        conflict=self.g.get(conflict_id)
        if not conflict or conflict.kind != 'ConflictSet': raise ValueError(f"not a ConflictSet: {conflict_id}")
        claims=self._claims(conflict_id)
        if len(claims)<2: raise ValueError("conflict requires at least two claims")
        findings=[]; d={}
        scopes=[self._scope(c) for c in claims]
        times=[self._time(c) for c in claims]
        d['member_count']=str(len(claims))
        d['status_distribution']=';'.join(sorted(c.status for c in claims))
        d['scope_analysis']='explicit' if all(s is not None for s in scopes) else 'incomplete'
        if d['scope_analysis']=='incomplete': findings.append('one or more conflicting claims lack explicit scope')
        d['temporal_analysis']='explicit' if all(t is not None for t in times) else 'incomplete'
        if d['temporal_analysis']=='incomplete': findings.append('one or more conflicting claims lack explicit time')
        activities=tuple(sorted({a for c in claims for a in self._activities(c.id)}))
        d['derivation_analysis']='present' if activities else 'none'
        d['defeater_analysis']='present' if any(self._explicit_defeaters(c.id) for c in claims) else 'none_recorded'
        objections=[]
        for c in claims:
            for r in self.g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation IN ('contradicts','refutes')", (c.id,)):
                n=self.g.get(r[0])
                if n and n.kind=='Claim' and n.id not in [x.id for x in claims]: objections.append(n.id)
        d['external_objections']='present' if objections else 'none_recorded'
        resolutions=self._resolutions(conflict_id)
        dispositions=[r.metadata.get('disposition') for r in resolutions]
        d['explicit_resolution']='present' if resolutions else 'none'
        verdict='unresolved'
        if 'scope_split' in dispositions:
            verdict='scope_separated'
        elif any(x in {'accept_claim','reject_claim','supersede'} for x in dispositions):
            verdict='unresolved'  # analyzer reports the record; it does not adopt its choice.
            findings.append('an explicit resolution exists; analyzer does not independently endorse its disposition')
        elif not claims or len(claims)<2:
            verdict='insufficient'
        elif d['scope_analysis']=='explicit' and len(set(map(str,scopes))) > 1:
            verdict='scope_separated'
            findings.append('claims have materially different declared scopes')
        else:
            verdict='balanced'
            findings.append('no structural basis was found to select a winning claim')
        now=as_of or datetime.now(timezone.utc)
        if isinstance(now,str): now=self.g._parse_time(now) or datetime.now(timezone.utc)
        return ConflictAssessment(conflict_id, tuple(c.id for c in claims), verdict, d,
                                  tuple(sorted(set(objections))), tuple(sorted({d for c in claims for d in self._explicit_defeaters(c.id)})), activities, now.isoformat())

    def record(self, conflict_id: str, *, assessor="independent-conflict-review", as_of=None):
        a=self.assess(conflict_id, assessor=assessor, as_of=as_of)
        node=self.g.add_node('ConflictAssessment', f'Independent analysis of {conflict_id}', 'supported', {
            'conflict_id':conflict_id,'member_claim_ids':list(a.member_claim_ids),'assessor':assessor,
            'assessed_at':a.assessed_at,'verdict':a.verdict,'dimensions':a.dimensions,
            'objections':list(a.objections),'defeaters':list(a.defeaters),'derivation_activity_ids':list(a.derivation_activity_ids)
        })
        self.g.link(node.id,'evaluates',conflict_id)
        return a
