from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class AdversarialFinding:
    code:str; severity:str; affected:tuple[str,...]; blocks_release:bool

class AdversarialValidator:
    """Structural attacks against self-reference, authority escalation, compound failure and drift."""
    def __init__(self, graph): self.g=graph
    def run(self):
        out=[]
        # Self-reference: an evaluation cannot evaluate its own suite/target.
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='Evaluation'"):
            n=self.g.get(r['id']); m=n.metadata
            if m.get('target_id') == r['id'] or m.get('suite_id') == r['id']:
                out.append(AdversarialFinding('self_evaluating_evaluation','critical',(r['id'],),True))
        # Evaluation isolation: fixed suites must not be evaluated by themselves.
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='EvaluationSuite'"):
            sid=r['id']
            if self.g.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='evaluates' AND target_id=?",(sid,sid)).fetchone():
                out.append(AdversarialFinding('suite_self_reference','critical',(sid,),True))
        # Authority escalation: a proposal/change must never itself authorize.
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind IN ('ChangeProposal','AutonomousRun','Evaluation')"):
            if self.g.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='authorizes'",(r['id'],)).fetchone():
                out.append(AdversarialFinding('autonomy_authority_escalation','critical',(r['id'],),True))
        # Compound failure: verified action without verified authority or post-action observation.
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='Action' AND status='verified'"):
            aid=r['id']; a=self.g.get(aid); gid=a.metadata.get('authority_grant_id')
            grant=self.g.get(gid) if gid else None
            if not grant or grant.status!='verified': out.append(AdversarialFinding('action_without_verified_authority','critical',(aid,),True))
            if not any(e['relation']=='verified_by' for e in self.g.edges(aid,'in')) and not any(e['relation']=='records' for e in self.g.edges(aid,'in')):
                out.append(AdversarialFinding('action_without_post_observation','high',(aid,),True))
        # Drift: expired authority remains verified.
        for r in self.g.db.execute("SELECT id FROM nodes WHERE kind='AuthorityGrant' AND status='verified'"):
            n=self.g.get(r['id']); exp=n.metadata.get('expires_at')
            if exp:
                from datetime import datetime, timezone
                try:
                    if datetime.fromisoformat(exp.replace('Z','+00:00')) <= datetime.now(timezone.utc):
                        out.append(AdversarialFinding('expired_authority_grant','critical',(r['id'],),True))
                except ValueError: out.append(AdversarialFinding('malformed_authority_expiry','high',(r['id'],),True))
        return tuple(out)
