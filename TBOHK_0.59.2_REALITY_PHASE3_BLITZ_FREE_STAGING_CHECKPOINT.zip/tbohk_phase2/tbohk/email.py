from __future__ import annotations

import os
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage
from urllib.parse import quote


@dataclass(frozen=True)
class EmailConfig:
    host: str = os.getenv("TBOHK_SMTP_HOST", "")
    port: int = int(os.getenv("TBOHK_SMTP_PORT", "587"))
    username: str = os.getenv("TBOHK_SMTP_USERNAME", "")
    password: str = os.getenv("TBOHK_SMTP_PASSWORD", "")
    sender: str = os.getenv("TBOHK_EMAIL_FROM", "")
    use_tls: bool = os.getenv("TBOHK_SMTP_TLS", "1").lower() not in {"0", "false", "no"}
    public_base_url: str = os.getenv("TBOHK_PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")

    @property
    def configured(self) -> bool:
        return bool(self.host and self.sender)


class TransactionalEmail:
    """Small provider-neutral SMTP adapter for transactional account mail."""

    def __init__(self, config: EmailConfig | None = None):
        self.config = config or EmailConfig()

    def _send(self, recipient: str, subject: str, text: str) -> bool:
        if not self.config.configured:
            return False
        msg = EmailMessage()
        msg["From"] = self.config.sender
        msg["To"] = recipient
        msg["Subject"] = subject
        msg.set_content(text)
        with smtplib.SMTP(self.config.host, self.config.port, timeout=15) as server:
            if self.config.use_tls:
                server.starttls()
            if self.config.username:
                server.login(self.config.username, self.config.password)
            server.send_message(msg)
        return True

    def verification(self, recipient: str, token: str) -> bool:
        link = f"{self.config.public_base_url}/account/verify-email?token={quote(token, safe='')}"
        return self._send(recipient, "Verify your TBOHK email", f"Verify your TBOHK account:\n\n{link}\n\nThis link expires in 24 hours.")

    def password_reset(self, recipient: str, token: str) -> bool:
        link = f"{self.config.public_base_url}/account/password-reset?token={quote(token, safe='')}"
        return self._send(recipient, "Reset your TBOHK password", f"Reset your TBOHK password:\n\n{link}\n\nThis link expires in 1 hour. If you did not request this, you can ignore this message.")
