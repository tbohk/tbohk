from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, os, tempfile

@dataclass(frozen=True)
class ArtifactRef:
    digest: str
    size: int
    path: str

class ContentAddressedArtifactStore:
    """Local object-store contract: immutable SHA-256 addressed artifacts."""
    def __init__(self, root: str):
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
    def put(self, data: bytes) -> ArtifactRef:
        blob = bytes(data); digest = hashlib.sha256(blob).hexdigest()
        target = self.root / digest[:2] / digest
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if target.read_bytes() != blob: raise RuntimeError('artifact digest collision')
        else:
            fd, tmp = tempfile.mkstemp(prefix='.artifact-', dir=target.parent)
            try:
                with os.fdopen(fd, 'wb') as f: f.write(blob); f.flush(); os.fsync(f.fileno())
                os.replace(tmp, target); os.chmod(target, 0o640)
            finally:
                if os.path.exists(tmp): os.unlink(tmp)
        return ArtifactRef(digest, len(blob), str(target))
    def get(self, digest: str) -> bytes:
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest.lower()): raise ValueError('invalid artifact digest')
        p=self.root/digest[:2]/digest
        data=p.read_bytes()
        if hashlib.sha256(data).hexdigest()!=digest: raise RuntimeError('artifact integrity failure')
        return data
    def exists(self, digest: str) -> bool:
        try: self.get(digest); return True
        except (FileNotFoundError, ValueError, RuntimeError): return False
