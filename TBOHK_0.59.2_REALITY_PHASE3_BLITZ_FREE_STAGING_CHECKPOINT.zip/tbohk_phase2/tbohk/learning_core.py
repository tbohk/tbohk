from __future__ import annotations

"""Continual-learning control plane for TBOHK.

This module deliberately separates learning from authority. It records experience,
maintains an auditable self-model, plans learning work, and evaluates improvement
candidates. It never mutates production code/models and never promotes a candidate
without explicit, reproducible evaluation evidence.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import json
from typing import Any, Iterable

from .benchmark import ReasoningBenchmark


_ALLOWED_KINDS = {
    "interaction", "research", "prediction", "outcome", "feedback",
    "failure", "correction", "benchmark", "system_event"
}


@dataclass(frozen=True)
class Experience:
    experience_id: str
    kind: str
    task: str
    outcome: str
    success: bool | None
    value: float | None
    source: str
    recorded_at: str


@dataclass(frozen=True)
class LearningPlan:
    plan_id: str
    priorities: tuple[dict[str, Any], ...]
    generated_at: str
    basis_count: int


@dataclass(frozen=True)
class PromotionDecision:
    candidate_id: str
    decision: str
    reasons: tuple[str, ...]
    decided_at: str


class LearningCore:
    """Auditable continual-learning coordinator.

    The core treats observations and user feedback as learning signals, never as
    automatic truth. Candidate improvements remain isolated records until they
    satisfy a promotion gate against the same immutable evaluation suite.
    """

    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _digest(value: Any) -> str:
        text = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def record_experience(
        self,
        kind: str,
        task: str,
        outcome: str,
        *,
        success: bool | None = None,
        value: float | None = None,
        source: str = "system",
        metadata: dict[str, Any] | None = None,
    ) -> Experience:
        if kind not in _ALLOWED_KINDS:
            raise ValueError("invalid experience kind")
        if not task.strip() or not outcome.strip():
            raise ValueError("task and outcome are required")
        if value is not None and not isinstance(value, (int, float)):
            raise ValueError("value must be numeric")
        payload = {
            "experience_kind": kind,
            "task": task,
            "outcome": outcome,
            "success": success,
            "value": value,
            "source": source,
            "recorded_at": self._now(),
            "metadata": dict(metadata or {}),
        }
        node = self.g.add_node(
            "LearningExperience",
            f"{kind}: {task[:160]}",
            "supported",
            {**payload, "experience_sha256": self._digest(payload)},
        )
        return Experience(node.id, kind, task, outcome, success, value, source, node.created_at)

    def record_failure(self, task: str, failure_class: str, detail: str, *, source: str = "system") -> Experience:
        return self.record_experience(
            "failure", task, detail, success=False, source=source,
            metadata={"failure_class": failure_class},
        )

    def record_correction(self, task: str, correction: str, *, source: str = "user") -> Experience:
        return self.record_experience("correction", task, correction, success=True, source=source)

    def self_model(self, *, limit: int = 500, persist: bool = True) -> dict[str, Any]:
        if limit < 1 or limit > 5000:
            raise ValueError("limit out of range")
        rows = self.g.db.execute(
            "SELECT id, metadata, created_at FROM nodes WHERE kind='LearningExperience' ORDER BY rowid DESC LIMIT ?",
            (limit,),
        ).fetchall()
        total = len(rows)
        successful = 0
        failed = 0
        unknown = 0
        values: list[float] = []
        failure_classes: dict[str, int] = {}
        sources: dict[str, int] = {}
        for row in rows:
            meta = json.loads(row["metadata"])
            flag = meta.get("success")
            if flag is True:
                successful += 1
            elif flag is False:
                failed += 1
            else:
                unknown += 1
            if isinstance(meta.get("value"), (int, float)):
                values.append(float(meta["value"]))
            cls = meta.get("metadata", {}).get("failure_class") if isinstance(meta.get("metadata"), dict) else None
            if cls:
                failure_classes[cls] = failure_classes.get(cls, 0) + 1
            src = str(meta.get("source", "unknown"))
            sources[src] = sources.get(src, 0) + 1
        observed = successful + failed
        success_rate = successful / observed if observed else None
        mean_value = sum(values) / len(values) if values else None
        model = {
            "sample_size": total,
            "observed_outcomes": observed,
            "success_rate": success_rate,
            "mean_value": mean_value,
            "failure_classes": dict(sorted(failure_classes.items(), key=lambda x: (-x[1], x[0]))),
            "experience_sources": dict(sorted(sources.items(), key=lambda x: (-x[1], x[0]))),
            "truth_boundary": "self-model metrics describe recorded system experience; they are not a general intelligence score",
            "generated_at": self._now(),
        }
        if persist:
            node = self.g.add_node("LearningSelfModel", "TBOHK self-model snapshot", "supported", model)
            return {**model, "self_model_id": node.id}
        return model

    def plan(self, *, limit: int = 500, persist: bool = True) -> LearningPlan:
        if limit < 1:
            raise ValueError("limit must be positive")
        rows = self.g.db.execute(
            "SELECT metadata FROM nodes WHERE kind='LearningExperience' ORDER BY rowid DESC LIMIT ?",
            (limit,),
        ).fetchall()
        failures: dict[str, int] = {}
        corrections: dict[str, int] = {}
        for row in rows:
            meta = json.loads(row["metadata"])
            task = str(meta.get("task", "unknown"))
            if meta.get("success") is False:
                failures[task] = failures.get(task, 0) + 1
            if meta.get("experience_kind") == "correction":
                corrections[task] = corrections.get(task, 0) + 1
        tasks = set(failures) | set(corrections)
        priorities = []
        for task in tasks:
            score = failures.get(task, 0) * 2 + corrections.get(task, 0)
            priorities.append({
                "task": task,
                "priority": score,
                "failure_count": failures.get(task, 0),
                "correction_count": corrections.get(task, 0),
                "recommended_action": "investigate_failure_pattern",
            })
        priorities.sort(key=lambda x: (-x["priority"], x["task"]))
        payload = {"priorities": priorities, "basis_count": len(rows)}
        if persist:
            node = self.g.add_node("LearningPlan", "TBOHK learning plan", "proposed", {**payload, "plan_sha256": self._digest(payload)})
            return LearningPlan(node.id, tuple(priorities), node.created_at, len(rows))
        return LearningPlan("transient", tuple(priorities), self._now(), len(rows))

    def propose_candidate(
        self,
        name: str,
        target: str,
        change: dict[str, Any],
        *,
        baseline_evaluation_id: str,
        candidate_evaluation_id: str,
        adversarial_passed: bool,
        security_passed: bool,
        latency_regression_pct: float = 0.0,
    ) -> str:
        if not name.strip() or not target.strip():
            raise ValueError("name and target are required")
        base = self.g.get(baseline_evaluation_id)
        candidate = self.g.get(candidate_evaluation_id)
        if not base or base.kind != "Evaluation" or not candidate or candidate.kind != "Evaluation":
            raise ValueError("baseline and candidate evaluations are required")
        bm = base.metadata.get("metrics", {})
        cm = candidate.metadata.get("metrics", {})
        payload = {
            "name": name,
            "target": target,
            "change": dict(change),
            "baseline_evaluation_id": baseline_evaluation_id,
            "candidate_evaluation_id": candidate_evaluation_id,
            "baseline_suite_manifest_sha256": base.metadata.get("suite_manifest_sha256"),
            "candidate_suite_manifest_sha256": candidate.metadata.get("suite_manifest_sha256"),
            "adversarial_passed": bool(adversarial_passed),
            "security_passed": bool(security_passed),
            "latency_regression_pct": float(latency_regression_pct),
            "baseline_score": bm.get("score"),
            "candidate_score": cm.get("score"),
            "created_at": self._now(),
        }
        node = self.g.add_node("LearningCandidate", name, "proposed", {**payload, "candidate_sha256": self._digest(payload)})
        self.g.link(node.id, "evaluates_against", baseline_evaluation_id)
        self.g.link(node.id, "based_on", candidate_evaluation_id)
        return node.id

    def promotion_gate(self, candidate_id: str, *, max_latency_regression_pct: float = 10.0) -> PromotionDecision:
        candidate = self.g.get(candidate_id)
        if not candidate or candidate.kind != "LearningCandidate":
            raise ValueError("invalid learning candidate")
        m = candidate.metadata
        reasons: list[str] = []
        if m.get("baseline_suite_manifest_sha256") != m.get("candidate_suite_manifest_sha256"):
            reasons.append("baseline and candidate use different evaluation suites")
        if not bool(m.get("adversarial_passed")):
            reasons.append("adversarial evaluation failed")
        if not bool(m.get("security_passed")):
            reasons.append("security evaluation failed")
        latency = float(m.get("latency_regression_pct", 0.0))
        if latency > max_latency_regression_pct:
            reasons.append("latency regression exceeds promotion budget")
        baseline_score = m.get("baseline_score")
        candidate_score = m.get("candidate_score")
        if not isinstance(baseline_score, (int, float)) or not isinstance(candidate_score, (int, float)):
            reasons.append("both baseline and candidate scores are required")
        elif candidate_score < baseline_score:
            reasons.append("candidate score regresses against baseline")
        base_node = self.g.get(m.get("baseline_evaluation_id", ""))
        cand_node = self.g.get(m.get("candidate_evaluation_id", ""))
        if not base_node or not cand_node or not base_node.metadata.get("metrics", {}).get("passed") or not cand_node.metadata.get("metrics", {}).get("passed"):
            reasons.append("baseline and candidate evaluations must both pass")
        decision = "approved" if not reasons else "rejected"
        status = "verified" if decision == "approved" else "rejected"
        result = PromotionDecision(candidate_id, decision, tuple(reasons or ["all promotion gates passed"]), self._now())
        self.g.update_metadata(candidate_id, {
            "promotion_decision": decision,
            "promotion_reasons": list(result.reasons),
            "promotion_decided_at": result.decided_at,
            "promotion_gate_version": "1",
        }, reason="learning promotion gate")
        self.g.set_status(candidate_id, status, f"promotion gate: {decision}")
        return result

    def replay(self, *, limit: int = 100, kinds: set[str] | None = None) -> dict[str, Any]:
        """Return a deterministic replay batch from recorded experience.

        Replay is observational: it does not mutate the graph and does not treat
        user feedback as ground truth. The batch digest makes an evaluation input
        reproducible and auditable.
        """
        if limit < 1 or limit > 5000:
            raise ValueError("limit out of range")
        rows = self.g.db.execute(
            "SELECT id, metadata, created_at FROM nodes WHERE kind='LearningExperience' ORDER BY rowid ASC LIMIT ?",
            (limit,),
        ).fetchall()
        experiences = []
        for row in rows:
            meta = json.loads(row["metadata"])
            if kinds and meta.get("experience_kind") not in kinds:
                continue
            experiences.append({
                "experience_id": row["id"],
                "kind": meta.get("experience_kind"),
                "task": meta.get("task"),
                "outcome": meta.get("outcome"),
                "success": meta.get("success"),
                "value": meta.get("value"),
                "source": meta.get("source"),
                "recorded_at": row["created_at"],
            })
        return {
            "count": len(experiences),
            "experiences": experiences,
            "batch_sha256": self._digest(experiences),
            "truth_boundary": "replay data is training/evaluation input, not verified truth",
        }

    def run_benchmark(self, *, record: bool = True, assessor: str = "independent-regression-suite") -> dict[str, Any]:
        """Run the fixed reasoning corpus and optionally record the result."""
        report = ReasoningBenchmark().run()
        payload = {
            "corpus_version": report.corpus_version,
            "corpus_sha256": report.corpus_sha256,
            "total": report.total,
            "passed": report.passed,
            "failed": report.failed,
            "results": [{"case_id": r.case_id, "passed": r.passed, "findings": list(r.findings)} for r in report.results],
            "assessor": assessor,
            "recorded": bool(record),
        }
        if record:
            _, node = ReasoningBenchmark().record(self.g, assessor=assessor, as_of=report.assessed_at)
            payload["benchmark_run_id"] = node.id
        return payload

    def build_dataset(self, *, limit: int = 500, validation_fraction: float = 0.2, record: bool = True) -> dict[str, Any]:
        """Build a deterministic, provenance-preserving learning dataset.

        Recorded experience is a learning signal, not verified truth. The builder
        therefore preserves source experience IDs, uses a content-addressed split,
        and refuses invalid validation fractions. It never mutates source experiences.
        """
        if limit < 1 or limit > 5000:
            raise ValueError("limit out of range")
        if not 0.05 <= validation_fraction <= 0.5:
            raise ValueError("validation_fraction out of range")
        rows = self.g.db.execute(
            "SELECT id, metadata, created_at FROM nodes WHERE kind='LearningExperience' ORDER BY rowid ASC LIMIT ?",
            (limit,),
        ).fetchall()
        examples = []
        for row in rows:
            meta = json.loads(row["metadata"])
            task = str(meta.get("task", "")).strip()
            outcome = str(meta.get("outcome", "")).strip()
            if not task or not outcome:
                continue
            example = {
                "experience_id": row["id"],
                "kind": meta.get("experience_kind"),
                "task": task,
                "outcome": outcome,
                "success": meta.get("success"),
                "value": meta.get("value"),
                "source": meta.get("source", "unknown"),
                "recorded_at": row["created_at"],
            }
            example["example_sha256"] = self._digest(example)
            examples.append(example)

        validation = []
        training = []
        for example in examples:
            bucket = int(example["example_sha256"][:8], 16) / 0x100000000
            (validation if bucket < validation_fraction else training).append(example)
        training.sort(key=lambda x: x["example_sha256"])
        validation.sort(key=lambda x: x["example_sha256"])
        training_ids = {x["experience_id"] for x in training}
        validation_ids = {x["experience_id"] for x in validation}
        overlap = training_ids & validation_ids
        if overlap:
            raise RuntimeError("dataset split contamination detected")
        manifest = {
            "version": "1",
            "training": [x["example_sha256"] for x in training],
            "validation": [x["example_sha256"] for x in validation],
            "validation_fraction": validation_fraction,
        }
        payload = {
            "dataset_version": "1",
            "source_count": len(examples),
            "training_count": len(training),
            "validation_count": len(validation),
            "training": training,
            "validation": validation,
            "manifest_sha256": self._digest(manifest),
            "truth_boundary": "experience-derived examples are learning signals and retain source provenance; they are not verified truth",
            "contamination_check": "passed",
            "generated_at": max((x["recorded_at"] for x in examples), default=""),
        }
        if record:
            node = self.g.add_node("LearningDataset", "TBOHK learning dataset", "proposed", payload)
            payload["dataset_id"] = node.id
        return payload

    def attention_feedback(self, node_id: str, action: str, *, success: bool, note: str = "", source: str = "user", baseline: dict[str, Any] | None = None, current: dict[str, Any] | None = None) -> Experience:
        """Record an explicit outcome for an attention recommendation.

        This is preference/experience learning only: it never changes the
        selected knowledge object or its epistemic status.
        """
        allowed={"research","conflict","impact","lineage","monitor"}
        if action not in allowed:
            raise ValueError("invalid attention action")
        node=self.g.get(node_id)
        if node is None:
            raise ValueError("node not found")
        outcome=("resolved" if success else "not_resolved") + (f": {note.strip()}" if note.strip() else "")
        baseline=dict(baseline or {})
        current=dict(current or {})
        def _num(x, key):
            try: return float(x.get(key, 0) or 0)
            except (TypeError,ValueError): return 0.0
        delta={
            "gap_count": _num(current,"gap_count")-_num(baseline,"gap_count"),
            "conflict_count": _num(current,"conflict_count")-_num(baseline,"conflict_count"),
            "impact_count": _num(current,"impact_count")-_num(baseline,"impact_count"),
        }
        metadata={"attention_action":action,"node_id":node_id,"feedback_note":note.strip()[:2000],
                  "baseline_state":{k:baseline.get(k) for k in ("gap_count","conflict_count","impact_count")},
                  "current_state":{k:current.get(k) for k in ("gap_count","conflict_count","impact_count")},
                  "state_delta":delta,
                  "resolution_signal": "improved" if any(v < 0 for v in delta.values()) else ("unchanged" if all(v == 0 for v in delta.values()) else "expanded")}
        return self.record_experience("outcome", f"attention:{action}:{node_id}", outcome, success=bool(success), source=source, metadata=metadata)

    def attention_profile(self, actions: Iterable[str], *, limit: int = 500) -> dict[str, dict[str, Any]]:
        """Return bounded historical outcome signals for attention actions.

        Rates use a conservative Beta(1,1) prior so tiny samples cannot dominate.
        """
        allowed={"research","conflict","impact","lineage","monitor"}
        actions=[a for a in actions if a in allowed]
        if not actions: return {}
        rows=self.g.db.execute(
            "SELECT metadata FROM nodes WHERE kind='LearningExperience' ORDER BY rowid DESC LIMIT ?",
            (max(1,min(int(limit),5000)),),
        ).fetchall()
        stats={a:{"observations":0,"successes":0,"success_rate":0.5,"confidence":"prior_only"} for a in actions}
        for row in rows:
            meta=json.loads(row["metadata"])
            nested=meta.get("metadata") if isinstance(meta.get("metadata"),dict) else {}
            action=nested.get("attention_action")
            if action not in stats or meta.get("experience_kind")!="outcome": continue
            stats[action]["observations"]+=1
            if meta.get("success") is True: stats[action]["successes"]+=1
        for value in stats.values():
            n=value["observations"]; s=value["successes"]
            value["success_rate"]=(s+1)/(n+2)
            value["confidence"]="observed" if n>=5 else ("early_signal" if n else "prior_only")
        return stats

    def dashboard(self) -> dict[str, Any]:
        model = self.self_model(limit=500, persist=False)
        plan = self.plan(limit=500, persist=False)
        candidates = self.g.db.execute(
            "SELECT status, COUNT(*) AS count FROM nodes WHERE kind='LearningCandidate' GROUP BY status ORDER BY status"
        ).fetchall()
        return {
            "self_model": model,
            "learning_plan": asdict(plan),
            "candidate_status": {r["status"]: r["count"] for r in candidates},
            "promotion_boundary": "approved candidates are records only; deployment/model replacement remains an explicit release operation",
        }
