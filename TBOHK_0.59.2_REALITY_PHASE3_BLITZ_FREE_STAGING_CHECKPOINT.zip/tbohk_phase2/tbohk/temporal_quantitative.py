from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional
import re

_YEAR = re.compile(r'\b(19\d{2}|20\d{2}|21\d{2})\b')
_QUARTER = re.compile(r'\bQ([1-4])\s*(19\d{2}|20\d{2}|21\d{2})\b', re.I)
_MONTH = re.compile(r'\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(19\d{2}|20\d{2}|21\d{2})\b', re.I)
_DATE = re.compile(r'\b(19\d{2}|20\d{2}|21\d{2})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b')
_NUMBER = re.compile(r'(?<![A-Za-z])[-+]?\d+(?:\.\d+)?(?:\s*(?:%|percent|percentage|USD|EUR|GBP|kg|km|m|seconds?|minutes?|hours?|days?|weeks?|months?|years?))?(?![A-Za-z])', re.I)

@dataclass(frozen=True)
class TimeScope:
    kind: str
    start: str | None
    end: str | None
    label: str

@dataclass(frozen=True)
class Quantity:
    value: float
    unit: str | None
    raw: str

@dataclass(frozen=True)
class TemporalQuantitativeComparison:
    relationship: str
    reason: str
    time_a: dict | None
    time_b: dict | None
    quantity_a: dict | None
    quantity_b: dict | None

class TemporalQuantitativeAnalyzer:
    """Conservative temporal/quantitative interpretation.

    It distinguishes disagreement across different periods from contradiction in
    the same measurement scope. It never decides which numerical observation is true.
    """
    MONTHS = {m.lower(): i for i,m in enumerate(('January','February','March','April','May','June','July','August','September','October','November','December'),1)}

    @classmethod
    def parse_time(cls, text: str) -> TimeScope | None:
        q = _QUARTER.search(text)
        if q:
            year=int(q.group(2)); quarter=int(q.group(1)); start_month=(quarter-1)*3+1
            return TimeScope('quarter', f'{year:04d}-{start_month:02d}-01', f'{year:04d}-{start_month+2:02d}-31', q.group(0))
        d = _DATE.search(text)
        if d:
            label=d.group(0); return TimeScope('date', label, label, label)
        m = _MONTH.search(text)
        if m:
            year=int(m.group(1)); name=m.group(0).rsplit(' ',1)[0].lower(); month=cls.MONTHS.get(name, cls.MONTHS.get(name[:3]))
            return TimeScope('month', f'{year:04d}-{month:02d}-01', f'{year:04d}-{month:02d}-31', m.group(0))
        y = _YEAR.search(text)
        if y:
            year=int(y.group(1)); return TimeScope('year', f'{year:04d}-01-01', f'{year:04d}-12-31', y.group(0))
        # Relative durations are retained as labels rather than fabricated dates.
        rel=re.search(r'\b(?:after|over|during|within|for)\s+(?:the\s+)?(?:\d+(?:\.\d+)?|one|two|three|four|five|six|twelve)\s+(?:days?|weeks?|months?|years?)\b', text, re.I)
        if rel: return TimeScope('relative_duration', None, None, rel.group(0))
        return None

    @staticmethod
    def parse_quantity(text: str) -> Quantity | None:
        m=_NUMBER.search(text)
        if not m: return None
        raw=m.group(0).strip()
        num=re.match(r'[-+]?\d+(?:\.\d+)?', raw)
        if not num: return None
        value=float(num.group(0)); unit=raw[num.end():].strip().lower() or None
        if unit=='percent': unit='%'
        return Quantity(value,unit,raw)

    @classmethod
    def analyze(cls, object_a: str, object_b: str, *, same_subject: bool, same_predicate: bool) -> TemporalQuantitativeComparison:
        ta=cls.parse_time(object_a); tb=cls.parse_time(object_b)
        qa=cls.parse_quantity(object_a); qb=cls.parse_quantity(object_b)
        td=asdict(ta) if ta else None; te=asdict(tb) if tb else None
        qd=asdict(qa) if qa else None; qe=asdict(qb) if qb else None
        if not (same_subject and same_predicate):
            return TemporalQuantitativeComparison('indeterminate','subject or predicate differs',td,te,qd,qe)
        if ta and tb and ta.start != tb.start:
            return TemporalQuantitativeComparison('temporal_scope_difference','measurements refer to different explicit periods; change across time is not itself a contradiction',td,te,qd,qe)
        if qa and qb and qa.unit == qb.unit and qa.value != qb.value:
            return TemporalQuantitativeComparison('quantitative_disagreement','same semantic scope contains different quantified values; requires source/method review',td,te,qd,qe)
        if (ta is None) != (tb is None):
            return TemporalQuantitativeComparison('temporal_scope_incomplete','only one claim declares a detectable time scope',td,te,qd,qe)
        return TemporalQuantitativeComparison('compatible_or_unresolved','no temporal or quantitative contradiction established',td,te,qd,qe)
