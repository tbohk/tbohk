from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from .core import TBOHK

@dataclass(frozen=True)
class ExplanationTrace:
    root_id: str
    node_ids: tuple[str, ...]
    edge_count: int
    missing_links: tuple[str, ...]
    cycles: tuple[str, ...]
    conditional_nodes: tuple[str, ...]
    conflict_nodes: tuple[str, ...]
    complete: bool
    traced_at: str

class ExplanationReconstructor:
    """G4.5 reconstructs an auditable explanation from graph provenance.

    It reports what the graph can reconstruct; it never invents missing
    provenance and never changes epistemic status.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _node(self, nid):
        return self.g.get(nid)

    def _out(self, nid, relations=None):
        rels = set(relations or [])
        rows = self.g.db.execute("SELECT * FROM edges WHERE source_id=?", (nid,)).fetchall()
        return [dict(r) for r in rows if not rels or r["relation"] in rels]

    def _in(self, nid, relations=None):
        rels = set(relations or [])
        rows = self.g.db.execute("SELECT * FROM edges WHERE target_id=?", (nid,)).fetchall()
        return [dict(r) for r in rows if not rels or r["relation"] in rels]

    def trace(self, root_id: str, *, max_nodes=500, as_of=None) -> ExplanationTrace:
        root = self._node(root_id)
        if not root:
            raise ValueError(f"unknown root: {root_id}")
        seen=set(); stack=[root_id]; edge_keys=set(); missing=[]; cycles=[]
        conditional=set(); conflicts=set()
        provenance_relations={
            "Claim": {"generated_by","derived_from","contradicts","refutes"},
            "ReasoningActivity": {"uses","applies_rule","assumes","creates_branch","derives","produces"},
            "ReasoningRule": set(), "Assumption": set(), "Defeater": set(),
            "CounterfactualBranch": set(), "InferenceAssessment": {"evaluates"},
            "ConflictSet": set(), "ConflictAssessment": {"evaluates"},
            "Evidence": {"evidence_for","derived_from"},
            "SourceSnapshot": {"documents"}, "Source": set(), "Origin": {"derived_from"},
            "Verification": {"verified_by"}, "Knowledge": {"derived_from"},
        }
        while stack and len(seen) < max_nodes:
            nid=stack.pop()
            if nid in seen:
                continue
            n=self._node(nid)
            if not n:
                missing.append(f"missing node: {nid}"); continue
            seen.add(nid)
            m=n.metadata
            if n.kind in {"Assumption","Defeater"} or m.get("assumption_ids") or m.get("defeater_ids"):
                conditional.add(nid)
            if n.kind in {"ConflictSet","ConflictAssessment"}:
                conflicts.add(nid)
            for e in self._out(nid):
                edge_keys.add((e["source_id"],e["relation"],e["target_id"]))
                target=e["target_id"]
                if target in seen:
                    cycles.append(f"{nid} -[{e['relation']}]-> {target}")
                elif e["relation"] in provenance_relations.get(n.kind, set()):
                    stack.append(target)
            # Conflict membership is a parallel provenance path: a claim can be
            # contained in a ConflictSet without the ConflictSet being a derivation.
            for e in self._in(nid):
                if e["relation"] == "contains":
                    src=self._node(e["source_id"])
                    if src and src.kind == "ConflictSet":
                        conflicts.add(src.id)
                        if src.id not in seen: stack.append(src.id)
            # Backward provenance is essential for evidence/source reconstruction.
            for e in self._in(nid):
                edge_keys.add((e["source_id"],e["relation"],e["target_id"]))
                source=e["source_id"]
                if e["relation"] in {"generated_by","derived_from","evidence_for","verified_by","documents","evaluates","assumes","defeats"}:
                    if source not in seen: stack.append(source)
            if n.kind == "Claim":
                if not any(e["relation"] == "generated_by" for e in self._in(nid)) and not m.get("reasoning_activity_id") and not m.get("evidence_ids"):
                    # A proposed assertion can legitimately be an externally supplied claim.
                    if m.get("derived"):
                        missing.append(f"claim {nid} is marked derived but has no generating activity")
                if m.get("derived") and not any(e["relation"] == "derived_from" for e in self._out(nid)):
                    missing.append(f"derived claim {nid} has no derived_from provenance")
            if n.kind == "ReasoningActivity":
                if not any(e["relation"] == "applies_rule" for e in self._out(nid)) and n.metadata.get("rule_id"):
                    missing.append(f"reasoning activity {nid} lacks applies_rule edge")
                if n.metadata.get("assumption_ids"):
                    for aid in n.metadata["assumption_ids"]:
                        if not any(e["relation"] == "assumes" and e["target_id"] == aid for e in self._out(nid)):
                            missing.append(f"reasoning activity {nid} lacks assumes edge to {aid}")
        if stack:
            missing.append(f"trace truncated at max_nodes={max_nodes}")
        # Verify referenced metadata IDs are actually present in the reconstructed graph.
        for nid in list(seen):
            n=self._node(nid); m=n.metadata
            refs=[]
            for key in ("premise_ids","assumption_ids","defeater_ids","evidence_ids"):
                v=m.get(key,[]); refs.extend(v if isinstance(v,list) else [])
            if m.get("rule_id"): refs.append(m["rule_id"])
            for rid in refs:
                if self._node(rid) is None: missing.append(f"{nid} references missing {rid}")
        now=as_of or datetime.now(timezone.utc)
        if isinstance(now,str): now=self.g._parse_time(now) or datetime.now(timezone.utc)
        return ExplanationTrace(root_id,tuple(sorted(seen)),len(edge_keys),tuple(sorted(set(missing))),tuple(sorted(set(cycles))),tuple(sorted(conditional)),tuple(sorted(conflicts)),not missing,now.isoformat())

    def record(self, root_id: str, *, assessor="explanation-reconstructor", max_nodes=500, as_of=None):
        t=self.trace(root_id,max_nodes=max_nodes,as_of=as_of)
        node=self.g.add_node("ExplanationTrace", f"Reconstructed explanation for {root_id}", "supported", {
            "root_id":t.root_id,"node_ids":list(t.node_ids),"edge_count":t.edge_count,
            "missing_links":list(t.missing_links),"cycles":list(t.cycles),
            "conditional_nodes":list(t.conditional_nodes),"conflict_nodes":list(t.conflict_nodes),
            "complete":t.complete,"assessor":assessor,"traced_at":t.traced_at,
        })
        self.g.link(node.id,"evaluates",root_id)
        return t
