from __future__ import annotations
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse, urljoin
import hashlib
import ipaddress
import socket
import urllib.request
import io
import os
from bs4 import BeautifulSoup

from .core import TBOHK
from .research import ResearchChain, SourceDocument
from .epistemic import EpistemicEngine
from .explanation import ExplanationReconstructor
from .query_engine import QueryEngine

class TBOHKService:
    """Application service: HTTP/UI orchestration around the audited substrate."""
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.epistemic = EpistemicEngine(graph)
        self.explain = ExplanationReconstructor(graph)

    def stats(self):
        return {
            "nodes": self.g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
            "edges": self.g.db.execute("SELECT COUNT(*) FROM edges").fetchone()[0],
            "events": self.g.db.execute("SELECT COUNT(*) FROM events").fetchone()[0],
            "revisions": self.g.db.execute("SELECT COUNT(*) FROM revisions").fetchone()[0],
        }

    def search_nodes(self, q: str, limit: int = 50):
        q = q.strip().lower()
        if not q: return []
        if not isinstance(limit, int) or limit < 1: raise ValueError("limit must be a positive integer")
        limit=min(limit,200)
        result=QueryEngine(self.g).search(q,limit)
        return [self._node_dict(self.g.get(r['id'])) for r in result.items]

    @staticmethod
    def _node_dict(n):
        if not n: return None
        return {"id":n.id,"kind":n.kind,"status":n.status,"content":n.content,"created_at":n.created_at,"metadata":n.metadata}

    def node(self, node_id):
        n=self.g.get(node_id)
        if not n: raise KeyError(node_id)
        return {**self._node_dict(n), "edges":self.g.edges(node_id), "events":self.g.events(node_id), "revisions":self.g.revisions(node_id)}

    def create_claim(self, content, evidence_ids, **structured):
        return self._node_dict(self.epistemic.propose_claim(content, evidence_ids, **structured))

    def explain_node(self, node_id):
        t=self.explain.trace(node_id)
        return asdict(t)

class _SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, validator, max_redirects=5):
        self.validator=validator; self.max_redirects=max_redirects; self.count=0
        super().__init__()

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if self.count >= self.max_redirects:
            raise ValueError(f"too many redirects (>{self.max_redirects})")
        target=urljoin(req.full_url, newurl)
        parsed=urlparse(target)
        if parsed.scheme not in {"http","https"}:
            raise ValueError("redirect target must use http/https")
        self.validator(parsed.hostname)
        self.count += 1
        return super().redirect_request(req, fp, code, msg, headers, target)

class DirectURLProvider:
    provider_id = "direct-url"
    def __init__(self, urls: list[str], timeout=12, max_bytes=2_000_000, proxy: str | None = None):
        self.urls=urls; self.timeout=timeout; self.max_bytes=max_bytes
        # Production staging may require an explicit egress proxy. Never inherit
        # ambient proxy variables; an operator must opt in deliberately.
        self.proxy = proxy if proxy is not None else os.environ.get("TBOHK_STAGING_HTTP_PROXY", "").strip()
    @staticmethod
    def _safe_host(host):
        if not host: raise ValueError("URL host required")
        infos=socket.getaddrinfo(host, None)
        if not infos: raise ValueError("URL host did not resolve")
        for info in infos:
            addr=ipaddress.ip_address(info[4][0])
            if not addr.is_global:
                raise ValueError("URL resolves to a non-public address")
    def _opener(self):
        # Never inherit ambient HTTP(S)_PROXY settings; only the explicit staging proxy is used.
        proxy_map = {"http": self.proxy, "https": self.proxy} if self.proxy else {}
        return urllib.request.build_opener(
            urllib.request.ProxyHandler(proxy_map),
            _SafeRedirectHandler(self._safe_host),
        )
    def search(self, query: str):
        docs=[]
        for url in self.urls:
            p=urlparse(url)
            if p.scheme not in {"http","https"}: raise ValueError("only http/https URLs are allowed")
            self._safe_host(p.hostname)
            req=urllib.request.Request(url,headers={"User-Agent":"TBOHK/0.2 research-fetcher"})
            with self._opener().open(req, timeout=self.timeout) as r:
                data=r.read(self.max_bytes+1)
                if len(data)>self.max_bytes: raise ValueError("document exceeds size limit")
                raw_ctype=r.headers.get("content-type","")
                ctype=raw_ctype.split(";",1)[0].strip().lower()
                charset="utf-8"
                if "charset=" in raw_ctype.lower(): charset=raw_ctype.lower().split("charset=",1)[1].split(";",1)[0].strip()
                if ctype == "application/pdf" or url.lower().split("?",1)[0].endswith(".pdf"):
                    try:
                        from pypdf import PdfReader
                        reader=PdfReader(io.BytesIO(data))
                        if len(reader.pages) > 50: raise ValueError("PDF exceeds 50-page extraction limit")
                        text="\n".join((page.extract_text() or "") for page in reader.pages)
                        title=url
                    except ImportError as exc:
                        raise ValueError("PDF extraction support is unavailable") from exc
                    except ValueError:
                        raise
                    except Exception as exc:
                        raise ValueError("PDF extraction failed safely") from exc
                    media=[]
                else:
                    text=data.decode(charset,errors="replace")
                    media=[]
                if "html" in ctype or "<html" in text.lower():
                    soup=BeautifulSoup(text,"html.parser")
                    title=(soup.title.get_text(" ",strip=True) if soup.title else url)
                    for tag in soup.find_all("img"):
                        src=tag.get("src") or tag.get("data-src")
                        if src:
                            try: media.append({"type":"image","url":urljoin(url,src),"alt":tag.get("alt") or title})
                            except ValueError: pass
                    for tag in soup.find_all(["video","source"]):
                        src=tag.get("src")
                        if src:
                            try: media.append({"type":"video","url":urljoin(url,src),"alt":tag.get("title") or title})
                            except ValueError: pass
                    for tag in soup.find_all("iframe"):
                        src=tag.get("src") or ""
                        if any(host in src.lower() for host in ("youtube.com","youtu.be","vimeo.com")):
                            try: media.append({"type":"video","url":urljoin(url,src),"alt":title})
                            except ValueError: pass
                    media=media[:20]
                    for x in soup(["script","style","noscript"]): x.decompose()
                    text=soup.get_text(" ",strip=True)
                else: title=url
            now=datetime.now(timezone.utc).isoformat()
            sid="url_"+hashlib.sha256(url.encode()).hexdigest()[:24]
            oid="origin_"+hashlib.sha256((url+title).encode()).hexdigest()[:24]
            docs.append(SourceDocument(sid,title,url,text,self.provider_id,now,oid,published_at=None,media=tuple(media)))
        return docs
