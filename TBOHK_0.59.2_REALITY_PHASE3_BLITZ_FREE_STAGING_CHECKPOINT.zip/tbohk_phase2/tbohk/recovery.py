from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone

@dataclass(frozen=True)
class RecoveryResult:
    proposal_id:str
    validated:bool
    reversible:bool
    validation_id:str|None=None

class RecoveryEngine:
    def __init__(self,graph): self.g=graph
    def detect(self,issue_type,affected_ids,*,severity='high',evidence=None):
        return self.g.add_node('RecoveryIncident',issue_type,'proposed',{'issue_type':issue_type,'affected_ids':affected_ids,'severity':severity,'evidence':evidence or [],'detected_at':datetime.now(timezone.utc).isoformat()})
    def propose(self,incident_id,action,*,rollback,diagnosis,proposer='recovery'):
        i=self.g.get(incident_id)
        if not i or i.kind!='RecoveryIncident': raise ValueError('invalid incident')
        return self.g.add_node('RecoveryProposal',action,'proposed',{'incident_id':incident_id,'action':action,'rollback':rollback,'diagnosis':diagnosis,'proposer':proposer,'reversible':bool(rollback)})
    def validate(self,proposal_id,*,independent=True,regression_passed=True,assessor='independent_reviewer'):
        p=self.g.get(proposal_id); ok=bool(p and p.metadata.get('reversible') and independent and regression_passed and str(assessor).strip())
        if p and assessor == p.metadata.get('proposer'):
            ok=False; independent=False
        v=self.g.add_node('RecoveryValidation',f'Validation {proposal_id}','supported',{'proposal_id':proposal_id,'validated':ok,'independent':independent,'regression_passed':regression_passed,'assessor':assessor,'assessed_at':datetime.now(timezone.utc).isoformat()})
        self.g.link(v.id,'evaluates',proposal_id)
        return RecoveryResult(proposal_id,ok,bool(p and p.metadata.get('reversible')),v.id)
    def apply(self,proposal_id,*,validation_id):
        p=self.g.get(proposal_id); v=self.g.get(validation_id)
        if not p or p.kind!='RecoveryProposal' or not v or v.kind!='RecoveryValidation' or not v.metadata.get('validated'):
            raise PermissionError('independent validated recovery required')
        if v.metadata.get('proposal_id') != proposal_id or not self.g.edges(validation_id,'out','evaluates') or not any(e['target_id']==proposal_id for e in self.g.edges(validation_id,'out','evaluates')):
            raise PermissionError('validation does not evaluate this recovery proposal')
        self.g.set_status(proposal_id,'verified','validated recovery applied'); self.g._event('recovery.applied',proposal_id,{'validation_id':validation_id}); return self.g.get(proposal_id)
