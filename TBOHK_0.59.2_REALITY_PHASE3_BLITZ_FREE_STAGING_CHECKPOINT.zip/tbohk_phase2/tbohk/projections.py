from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ProjectionResult:
    name: str
    rows: tuple[dict[str,Any], ...]
    generated_at: str

class GraphProjection:
    """Fast, disposable read projections; authoritative nodes remain untouched."""
    def __init__(self, graph): self.g=graph
    def overview(self):
        rows=self.g.db.execute('SELECT kind,status,COUNT(*) n FROM nodes GROUP BY kind,status ORDER BY kind,status').fetchall()
        return {'rows':[dict(r) for r in rows], 'node_count':self.g.db.execute('SELECT COUNT(*) FROM nodes').fetchone()[0], 'edge_count':self.g.db.execute('SELECT COUNT(*) FROM edges').fetchone()[0]}
    def neighborhood(self,node_id,limit=100):
        rows=self.g.db.execute('''SELECT e.relation,e.source_id,e.target_id,n.kind,n.status,n.content FROM edges e JOIN nodes n ON n.id=CASE WHEN e.source_id=? THEN e.target_id ELSE e.source_id END WHERE e.source_id=? OR e.target_id=? ORDER BY e.rowid DESC LIMIT ?''',(node_id,node_id,node_id,max(1,min(int(limit),500)))).fetchall()
        return [dict(r) for r in rows]
    def rebuildable(self): return True
