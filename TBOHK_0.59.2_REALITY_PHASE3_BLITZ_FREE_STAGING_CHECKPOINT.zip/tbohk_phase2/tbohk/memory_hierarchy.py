from __future__ import annotations
from dataclasses import dataclass
from collections import OrderedDict
from typing import Any
import time

@dataclass(frozen=True)
class MemoryEntry:
    key:str; value:Any; tier:str; created_at:float; expires_at:float|None

class MemoryHierarchy:
    """Explicit volatile/session/persistent-like tiers without pretending memory is truth."""
    def __init__(self, max_entries=256): self.max_entries=max(1,min(int(max_entries),5000)); self._tiers={k:OrderedDict() for k in ('volatile','session','derived')}
    def put(self,key,value,*,tier='volatile',ttl=None):
        if tier not in self._tiers: raise ValueError('invalid memory tier')
        now=time.monotonic(); self._tiers[tier][key]=MemoryEntry(key,value,tier,now,None if ttl is None else now+max(0,float(ttl)))
        self._tiers[tier].move_to_end(key)
        while len(self._tiers[tier])>self.max_entries: self._tiers[tier].popitem(last=False)
    def get(self,key,*,tier=None):
        tiers=[tier] if tier else list(self._tiers)
        for t in tiers:
            e=self._tiers[t].get(key)
            if e and (e.expires_at is None or time.monotonic()<e.expires_at): return e.value
            if e: self._tiers[t].pop(key,None)
        return None
    def forget(self,key):
        for tier in self._tiers.values(): tier.pop(key,None)
    def stats(self): return {k:len(v) for k,v in self._tiers.items()}
