"""One-command assurance pipeline and durable checkpoint manifest."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json
from pathlib import Path

from .core import TBOHK
from .deep_assurance import DeepAssurance
from .release import ReleaseAuditor
from .selfcare import SelfCareEngine
from .independent_validation import IndependentSystemValidator
from .serialization import canonical_json

@dataclass(frozen=True)
class AssuranceSnapshot:
    generated_at: str
    tests_note: str
    core_audit: bool
    independent_validation: bool
    deep_assurance: bool
    selfcare: bool
    release_audit: bool
    manifest_sha256: str

class AssurancePipeline:
    def __init__(self, graph: TBOHK): self.g=graph

    def run(self, *, checkpoint_id=None) -> AssuranceSnapshot:
        core=bool(self.g.audit().get('ok'))
        independent=IndependentSystemValidator(self.g).run()
        deep=DeepAssurance(self.g).run()
        care=SelfCareEngine(self.g).inspect()
        release=ReleaseAuditor(self.g).audit(checkpoint_id=checkpoint_id)
        data={
            'generated_at':datetime.now(timezone.utc).isoformat(),
            'core_audit':core,'independent_validation':independent.passed,
            'deep_assurance':deep.passed,'selfcare':care.passed,'release_audit':release.passed,
        }
        digest=hashlib.sha256(canonical_json(data).encode()).hexdigest()
        return AssuranceSnapshot(**data, tests_note='run pytest and coverage externally for source-level metrics', manifest_sha256=digest)

    def write_manifest(self, path: str|Path, snapshot: AssuranceSnapshot, *, artifact_hashes: dict[str,str]|None=None):
        payload={'snapshot':asdict(snapshot),'artifact_hashes':dict(sorted((artifact_hashes or {}).items()))}
        payload['manifest_sha256']=hashlib.sha256(canonical_json(payload).encode()).hexdigest()
        Path(path).write_text(json.dumps(payload,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        return payload
