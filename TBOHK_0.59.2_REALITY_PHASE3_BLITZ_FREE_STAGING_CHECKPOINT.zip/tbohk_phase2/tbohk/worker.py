from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
import json, uuid

@dataclass(frozen=True)
class WorkItem:
    id: str; kind: str; payload: dict; status: str; attempts: int; lease_until: str|None

class DurableWorkQueue:
    """SQLite-backed at-least-once queue with leases and idempotency keys."""
    def __init__(self, graph): self.g=graph
    def enqueue(self, kind, payload=None, *, idempotency_key=None):
        if idempotency_key:
            row=self.g.db.execute("SELECT id FROM nodes WHERE kind='WorkItem' AND json_extract(metadata,'$.idempotency_key')=? AND status IN ('proposed','supported') LIMIT 1",(idempotency_key,)).fetchone()
            if row: return self.get(row['id'])
        n=self.g.add_node('WorkItem',kind,'proposed',{'kind':kind,'payload':dict(payload or {}),'attempts':0,'lease_until':None,'idempotency_key':idempotency_key,'worker_id':None})
        return self.get(n.id)
    def get(self, item_id):
        n=self.g.get(item_id)
        if not n or n.kind!='WorkItem': raise KeyError(item_id)
        return WorkItem(n.id,n.content,n.metadata.get('payload',{}),n.status,int(n.metadata.get('attempts',0)),n.metadata.get('lease_until'))
    def lease(self, worker_id, *, now=None, lease_seconds=60, limit=1):
        now_dt=now or datetime.now(timezone.utc); now_iso=now_dt.isoformat(); until=(now_dt+timedelta(seconds=max(1,lease_seconds))).isoformat()
        rows=self.g.db.execute("SELECT id FROM nodes WHERE kind='WorkItem' AND (status='proposed' OR (status='supported' AND json_extract(metadata,'$.lease_until')<?)) ORDER BY rowid LIMIT ?",(now_iso,max(1,min(limit,20)))).fetchall()
        out=[]
        for r in rows:
            n=self.g.get(r['id']); m=dict(n.metadata); m.update({'lease_until':until,'worker_id':str(worker_id),'attempts':int(m.get('attempts',0))+1}); self.g.update_metadata(n.id,m,reason='work lease'); self.g.set_status(n.id,'supported',reason='work leased'); out.append(self.get(n.id))
        return out
    def complete(self, item_id):
        self.g.update_metadata(item_id,{'lease_until':None},reason='work completion'); self.g.set_status(item_id,'supported',reason='work completed'); return self.get(item_id)
    def fail(self, item_id, reason='worker failure'):
        self.g.update_metadata(item_id,{'lease_until':None},reason='work failure'); self.g.set_status(item_id,'rejected',reason=reason); return self.get(item_id)
