from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Iterable

from .investigation_health import InvestigationHealthAnalyzer


@dataclass(frozen=True)
class HealthSnapshot:
    snapshot_id: str
    created_at: str
    roots: tuple[str, ...]
    digest: str
    previous_snapshot_id: str | None
    comparison: dict
    recheck_triggers: tuple[dict, ...]


class InvestigationHealthHistory:
    """Persist and compare bounded investigation-health observations.

    Health snapshots are observational records. They never change claim status,
    resolve conflicts, select decisions, or mutate evidence. Recheck triggers
    are deterministic maintenance signals derived from differences between
    consecutive snapshots.
    """

    def __init__(self, graph):
        self.g = graph
        self.analyzer = InvestigationHealthAnalyzer(graph)

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @classmethod
    def _digest(cls, health):
        payload = asdict(health)
        return hashlib.sha256(cls._canonical(payload).encode()).hexdigest()

    @staticmethod
    def _set(values):
        return {str(v) for v in (values or [])}

    @classmethod
    def _compare(cls, previous: dict | None, current: dict) -> dict:
        if not previous:
            return {
                "baseline": True,
                "changed": False,
                "changes": [],
                "summary": "Baseline health snapshot created; future runs can now detect longitudinal change.",
            }

        pc = previous.get("coverage", {})
        cc = current.get("coverage", {})
        changes = []
        if pc.get("covered_claims") != cc.get("covered_claims"):
            changes.append({"code": "coverage_changed", "before": pc.get("covered_claims", 0), "after": cc.get("covered_claims", 0)})
        if pc.get("uncovered_claims") != cc.get("uncovered_claims"):
            changes.append({"code": "coverage_gap_changed", "before": pc.get("uncovered_claims", 0), "after": cc.get("uncovered_claims", 0)})

        pr = previous.get("redundancy", {})
        cr = current.get("redundancy", {})
        if pr.get("independent_count") != cr.get("independent_count"):
            changes.append({"code": "independence_changed", "before": pr.get("independent_count", 0), "after": cr.get("independent_count", 0)})

        pm = cls._set(x.get("node_id") for x in previous.get("maintenance", []))
        cm = cls._set(x.get("node_id") for x in current.get("maintenance", []))
        added = sorted(cm - pm)
        removed = sorted(pm - cm)
        if added or removed:
            changes.append({"code": "maintenance_queue_changed", "added": added[:100], "removed": removed[:100]})

        pt = {cls._canonical({k: x.get(k) for k in ("claim_a", "claim_b", "relationship")}) for x in previous.get("temporal", [])}
        ct = {cls._canonical({k: x.get(k) for k in ("claim_a", "claim_b", "relationship")}) for x in current.get("temporal", [])}
        if pt != ct:
            changes.append({"code": "temporal_or_quantitative_conflicts_changed", "added": sorted(ct - pt)[:50], "removed": sorted(pt - ct)[:50]})

        pi = {x.get("evidence_id"): x.get("affected_count", 0) for x in previous.get("counterfactuals", [])}
        ci = {x.get("evidence_id"): x.get("affected_count", 0) for x in current.get("counterfactuals", [])}
        changed_impact = sorted(k for k in set(pi) | set(ci) if pi.get(k) != ci.get(k))
        if changed_impact:
            changes.append({"code": "counterfactual_impact_changed", "evidence_ids": changed_impact[:100]})

        pcid = (previous.get("checkpoint") or {}).get("checkpoint_id")
        ccid = (current.get("checkpoint") or {}).get("checkpoint_id")
        pver = (previous.get("checkpoint") or {}).get("verified")
        cver = (current.get("checkpoint") or {}).get("verified")
        if pcid != ccid or pver != cver:
            changes.append({"code": "checkpoint_state_changed", "before": {"id": pcid, "verified": pver}, "after": {"id": ccid, "verified": cver}})

        pa = {x.get("code") for x in previous.get("adversarial", [])}
        ca = {x.get("code") for x in current.get("adversarial", [])}
        if pa != ca:
            changes.append({"code": "adversarial_findings_changed", "added": sorted(ca - pa), "removed": sorted(pa - ca)})

        return {"baseline": False, "changed": bool(changes), "changes": changes,
                "summary": f"{len(changes)} longitudinal health change(s) detected." if changes else "No tracked longitudinal health change detected."}

    @staticmethod
    def _triggers(current: dict, comparison: dict) -> tuple[dict, ...]:
        triggers = []
        for change in comparison.get("changes", []):
            code = change.get("code")
            if code in {"coverage_gap_changed", "coverage_changed"} and change.get("after", 0) > change.get("before", 0):
                triggers.append({"code": "recheck_coverage", "priority": "high", "reason": "Coverage weakened since the previous health snapshot."})
            elif code == "independence_changed" and change.get("after", 0) < change.get("before", 0):
                triggers.append({"code": "recheck_independence", "priority": "high", "reason": "Fewer independent provenance groups are available than before."})
            elif code == "maintenance_queue_changed" and change.get("added"):
                triggers.append({"code": "maintenance_review", "priority": "high", "reason": "New maintenance items appeared since the previous snapshot."})
            elif code == "temporal_or_quantitative_conflicts_changed" and change.get("added"):
                triggers.append({"code": "recheck_conflicts", "priority": "high", "reason": "New temporal or quantitative disagreement was detected."})
            elif code == "counterfactual_impact_changed":
                triggers.append({"code": "recheck_fragile_support", "priority": "medium", "reason": "The downstream impact of one or more evidence items changed."})
            elif code == "checkpoint_state_changed" and current.get("checkpoint", {}).get("present") and not current.get("checkpoint", {}).get("verified"):
                triggers.append({"code": "checkpoint_recheck", "priority": "critical", "reason": "The latest checkpoint no longer verifies against the current graph."})
            elif code == "adversarial_findings_changed" and change.get("added"):
                triggers.append({"code": "adversarial_review", "priority": "high", "reason": "New structural adversarial findings appeared."})
        return tuple(triggers)

    def _latest(self, roots: tuple[str, ...]):
        rows = self.g.db.execute(
            "SELECT id FROM nodes WHERE kind='HealthSnapshot' ORDER BY rowid DESC"
        ).fetchall()
        root_key = list(roots)
        for row in rows:
            n = self.g.get(row[0])
            if n and list(n.metadata.get("roots", [])) == root_key:
                return n
        return None

    @staticmethod
    def _normalize_roots(root_ids: Iterable[str]) -> tuple[str, ...]:
        if isinstance(root_ids, (str, bytes)):
            raise ValueError("root_ids must be an iterable of node IDs, not a single string")
        roots = tuple(sorted({str(x).strip() for x in root_ids if str(x).strip()}))
        if not roots:
            raise ValueError("at least one root_id is required")
        return roots

    @staticmethod
    def _normalize_limit(limit: int) -> int:
        try:
            value = int(limit)
        except (TypeError, ValueError) as exc:
            raise ValueError("limit must be an integer") from exc
        if value < 1 or value > 100:
            raise ValueError("limit must be between 1 and 100")
        return value

    def snapshot(self, root_ids: Iterable[str], *, health: dict | None = None) -> HealthSnapshot:
        roots = self._normalize_roots(root_ids)
        for rid in roots:
            if not self.g.get(rid):
                raise ValueError(f"root node does not exist: {rid}")
        if health is None:
            health = asdict(self.analyzer.analyze(roots))
        digest = hashlib.sha256(self._canonical(health).encode()).hexdigest()
        previous = self._latest(roots)
        previous_health = previous.metadata.get("health") if previous else None
        comparison = self._compare(previous_health, health)
        triggers = self._triggers(health, comparison)
        now = datetime.now(timezone.utc).isoformat()
        metadata = {
            "roots": list(roots), "health": health, "digest": digest,
            "previous_snapshot_id": previous.id if previous else None,
            "comparison": comparison, "recheck_triggers": list(triggers), "created_at": now,
        }
        node = self.g.add_node("HealthSnapshot", f"health-{digest[:12]}", "supported", metadata)
        return HealthSnapshot(node.id, now, roots, digest, previous.id if previous else None, comparison, triggers)

    def history(self, root_ids: Iterable[str], limit: int = 20) -> tuple[dict, ...]:
        roots = self._normalize_roots(root_ids)
        limit = self._normalize_limit(limit)
        rows = self.g.db.execute("SELECT id FROM nodes WHERE kind='HealthSnapshot' ORDER BY rowid DESC LIMIT ?", (limit * 10,)).fetchall()
        out = []
        for row in rows:
            n = self.g.get(row[0])
            if n and tuple(sorted(n.metadata.get("roots", []))) == roots:
                out.append({"id": n.id, **n.metadata})
                if len(out) >= limit:
                    break
        return tuple(out)
