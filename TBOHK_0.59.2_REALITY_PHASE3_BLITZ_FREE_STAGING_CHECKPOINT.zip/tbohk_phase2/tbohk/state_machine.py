from __future__ import annotations
from dataclasses import dataclass
from .core import STATUSES
from .invariants import transition_rule

@dataclass(frozen=True)
class TransitionAssessment:
    allowed: bool
    requires_workflow: bool
    reason: str

class StateTransitionEngine:
    """Canonical status transition policy.

    Low-level legacy mutations remain available for forensic fixtures, but production
    workflows should use transition(), and audits can flag transitions outside policy.
    """
    def __init__(self, graph): self.g = graph
    def assess(self, node_id: str, target: str) -> TransitionAssessment:
        node=self.g.get(node_id)
        if not node: raise KeyError(node_id)
        if target not in STATUSES: raise ValueError(f"invalid status: {target}")
        r=transition_rule(node.status,target)
        return TransitionAssessment(r.allowed,r.requires_workflow,r.rationale)
    def transition(self, node_id: str, target: str, *, reason: str, workflow: str | None = None):
        a=self.assess(node_id,target)
        if not a.allowed: raise ValueError(f"invalid status transition {self.g.get(node_id).status}->{target}")
        if a.requires_workflow and not workflow:
            raise PermissionError(f"transition to {target} requires a governing workflow")
        self.g.set_status(node_id,target,reason)
        self.g._event("status.transition",node_id,{"workflow":workflow,"target":target})
        return self.g.get(node_id)
    def audit(self):
        findings=[]
        for r in self.g.db.execute("SELECT node_id,old_status,new_status,id FROM revisions ORDER BY rowid"):
            rule=transition_rule(r['old_status'],r['new_status'])
            if not rule.allowed:
                findings.append({"code":"invalid_status_transition","revision_id":r['id'],"node_id":r['node_id'],"from":r['old_status'],"to":r['new_status']})
            if rule.requires_workflow:
                # Workflow provenance is recorded in a companion status.transition event.
                row=self.g.db.execute("SELECT 1 FROM events WHERE subject_id=? AND event_type='status.transition' AND json_extract(payload,'$.target')=? LIMIT 1",(r['node_id'],r['new_status'])).fetchone()
                if not row:
                    findings.append({"code":"sensitive_transition_without_workflow_event","revision_id":r['id'],"node_id":r['node_id'],"to":r['new_status']})
        return findings
