"""System Assurance and Recursive Improvement control plane.

The control plane is deliberately descriptive and bounded: it inventories the
architecture, records subsystem contracts and invariants, simulates change
impact, captures experiments, synthesizes regression probes, and composes the
existing self-test/repair/evaluation layers. It never edits source code or
promotes knowledge truth automatically.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from hashlib import sha256
import ast, json, re
from typing import Any, Iterable, Callable

VERSION = "0.58.1"

@dataclass(frozen=True)
class Constitution:
    version: str
    principles: tuple[str, ...]
    forbidden_automatic_actions: tuple[str, ...]
    release_gates: tuple[str, ...]
    improvement_budget: dict[str, int]
    blind_spot_states: tuple[str, ...]
    digest: str

@dataclass(frozen=True)
class SubsystemContract:
    name: str
    purpose: str
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    dependencies: tuple[str, ...]
    invariants: tuple[str, ...]
    failure_modes: tuple[str, ...]
    security_controls: tuple[str, ...]
    resource_limits: tuple[str, ...]
    tests: tuple[str, ...]
    blind_spots: tuple[str, ...]
    repair_strategies: tuple[str, ...]

@dataclass(frozen=True)
class ArchitectureNode:
    name: str
    kind: str
    path: str = ""

@dataclass(frozen=True)
class ArchitectureEdge:
    source: str
    relation: str
    target: str

@dataclass(frozen=True)
class ArchitectureGraph:
    nodes: tuple[ArchitectureNode, ...]
    edges: tuple[ArchitectureEdge, ...]
    digest: str

@dataclass(frozen=True)
class InvariantCandidate:
    invariant_id: str
    statement: str
    source: str
    evidence: tuple[str, ...]
    status: str
    digest: str

@dataclass(frozen=True)
class ChangeSimulation:
    change_id: str
    target: str
    impacted: tuple[str, ...]
    affected_contracts: tuple[str, ...]
    affected_invariants: tuple[str, ...]
    required_tests: tuple[str, ...]
    risks: tuple[str, ...]
    budget_ok: bool
    digest: str

@dataclass(frozen=True)
class Experiment:
    experiment_id: str
    hypothesis: str
    prediction: str
    change: str
    observed: str
    unexpected: tuple[str, ...]
    tests: tuple[str, ...]
    conclusion: str
    digest: str

@dataclass(frozen=True)
class RegressionProbe:
    probe_id: str
    source: str
    target: str
    predicate: str
    reason: str
    digest: str

@dataclass(frozen=True)
class AssuranceSnapshot:
    constitution: Constitution
    architecture: ArchitectureGraph
    contracts: tuple[SubsystemContract, ...]
    invariants: tuple[InvariantCandidate, ...]
    blind_spots: dict[str, tuple[str, ...]]
    digest: str


def _digest(value: Any) -> str:
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

class SystemConstitution:
    VERSION = "C1.0-1"
    PRINCIPLES = (
        "authoritative knowledge is never silently mutated by assurance",
        "every capability must be observable and auditable",
        "every repair is bounded, reversible, and independently verified",
        "tests must test the mechanisms that test the system",
        "unknowns remain explicit rather than being converted to confidence",
        "improvement consumes a finite budget and leaves durable evidence",
    )
    FORBIDDEN = ("automatic_source_mutation", "automatic_authority_escalation", "automatic_truth_promotion", "unbounded_recursion")
    GATES = ("compile", "regression", "evaluation", "meta_evaluation", "determinism", "artifact_integrity")
    BLIND_SPOTS = ("KNOWN", "KNOWN_UNKNOWN", "UNKNOWN", "CONTESTED", "DEGRADED", "UNTESTED")

    def build(self) -> Constitution:
        budget = {"steps": 50, "candidates": 25, "tests": 100, "mutations": 25, "recursion": 3, "seconds": 120}
        payload = {"version": self.VERSION, "principles": self.PRINCIPLES, "forbidden": self.FORBIDDEN, "gates": self.GATES, "budget": budget, "blind": self.BLIND_SPOTS}
        return Constitution(self.VERSION, self.PRINCIPLES, self.FORBIDDEN, self.GATES, budget, self.BLIND_SPOTS, _digest(payload))

    def record(self, graph: Any) -> Constitution:
        c = self.build()
        graph.add_node("SystemConstitution", f"System Constitution {c.version}", "verified", asdict(c))
        return c

class ArchitectureInspector:
    """Build a deterministic dependency graph from Python imports and symbols."""
    VERSION = "ADG1.0-1"
    def scan(self, root: str | Path) -> ArchitectureGraph:
        root = Path(root)
        modules: dict[str, Path] = {}
        for p in sorted(root.rglob("*.py")):
            if any(part.startswith(".") or part == "__pycache__" for part in p.parts): continue
            rel = p.relative_to(root).with_suffix("")
            name = ".".join(rel.parts)
            modules[name] = p
        nodes = [ArchitectureNode(n, "module", str(p.relative_to(root))) for n,p in modules.items()]
        edges: set[tuple[str,str,str]] = set()
        for name,p in modules.items():
            try: tree=ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
            except (SyntaxError,UnicodeDecodeError): continue
            for x in ast.walk(tree):
                target = None
                if isinstance(x, ast.Import):
                    for a in x.names:
                        target = a.name
                        base = target if target in modules else target.split('.')[0]
                        if base in modules and base != name: edges.add((name,"imports",base))
                elif isinstance(x, ast.ImportFrom) and x.module:
                    target=x.module
                    candidates=[target, target.rsplit('.',1)[0] if '.' in target else target]
                    for base in candidates:
                        if base in modules and base != name: edges.add((name,"imports",base)); break
        es=tuple(ArchitectureEdge(*e) for e in sorted(edges))
        return ArchitectureGraph(tuple(nodes), es, _digest({"nodes":[asdict(x) for x in nodes],"edges":[asdict(x) for x in es]}))

class ContractRegistry:
    VERSION="SC1.0-1"
    def __init__(self): self._contracts: dict[str,SubsystemContract] = {}
    def register(self, contract: SubsystemContract) -> SubsystemContract:
        if not contract.name.strip(): raise ValueError("contract name required")
        self._contracts[contract.name]=contract; return contract
    def discover(self, architecture: ArchitectureGraph, tests: Iterable[str] = ()) -> tuple[SubsystemContract,...]:
        test_names=tuple(sorted(set(tests)))
        for n in architecture.nodes:
            if n.kind != "module": continue
            deps=tuple(sorted(e.target for e in architecture.edges if e.source==n.name and e.relation=="imports"))
            related_tests=tuple(t for t in test_names if n.name.split('.')[-1] in t or n.name in t)
            self.register(SubsystemContract(n.name, f"Provide {n.name}", ("validated inputs",), ("observable outputs",), deps, ("deterministic logical results", "bounded resource use"), ("invalid input", "dependency failure", "unexpected state"), ("input validation", "authority boundary"), ("bounded execution",), related_tests, ("external behavior",), ("recheck", "isolate", "rebuild")))
        return tuple(self._contracts[n] for n in sorted(self._contracts))
    def all(self): return tuple(self._contracts[n] for n in sorted(self._contracts))

class InvariantDiscovery:
    VERSION="ID1.0-1"
    def discover(self, architecture: ArchitectureGraph, contracts: Iterable[SubsystemContract]) -> tuple[InvariantCandidate,...]:
        out=[]
        for c in contracts:
            for statement in c.invariants:
                iid=_digest({"name":c.name,"statement":statement})[:16]
                out.append(InvariantCandidate(iid,statement,c.name,("contract",),"candidate",_digest({"id":iid,"statement":statement})))
        # Structural invariant: every imported target must exist in the graph.
        names={n.name for n in architecture.nodes}
        missing=sorted({e.target for e in architecture.edges if e.target not in names})
        out.append(InvariantCandidate(_digest({"struct":"imports"})[:16],"every recorded import target exists in the scanned architecture","architecture",tuple(missing),"candidate" if missing else "promotable",_digest({"missing":missing})))
        return tuple(out)
    def validate(self, candidates: Iterable[InvariantCandidate], architecture: ArchitectureGraph) -> tuple[InvariantCandidate,...]:
        names={n.name for n in architecture.nodes}
        return tuple(InvariantCandidate(x.invariant_id,x.statement,x.source,x.evidence,"promotable" if not (x.source=="architecture" and x.evidence) else "rejected",x.digest) for x in candidates)

class AdversarialLaboratory:
    VERSION="AL1.0-1"
    FAULTS=("missing_dependency","duplicate_event","stale_projection","resource_exhaustion","malformed_metadata","unauthorized_transition")
    def run(self, detector: Callable[[str], bool]) -> dict[str,Any]:
        results={f:bool(detector(f)) for f in self.FAULTS}
        return {"version":self.VERSION,"faults":results,"detected":sum(results.values()),"total":len(results),"all_detected":all(results.values())}

class CounterfactualSimulator:
    VERSION="CS1.0-1"
    def simulate(self, target: str, architecture: ArchitectureGraph, contracts: Iterable[SubsystemContract], invariants: Iterable[InvariantCandidate], tests: Iterable[str], *, max_nodes=50) -> ChangeSimulation:
        reverse: dict[str,set[str]]={}
        for e in architecture.edges: reverse.setdefault(e.target,set()).add(e.source)
        impacted=set([target]); frontier=[target]
        while frontier and len(impacted)<max_nodes:
            cur=frontier.pop(0)
            for dep in sorted(reverse.get(cur,set())):
                if dep not in impacted: impacted.add(dep); frontier.append(dep)
        cs={c.name:c for c in contracts}; affected_contracts=tuple(sorted(x for x in impacted if x in cs))
        affected_invariants=tuple(sorted(i.invariant_id for i in invariants if i.source in impacted or i.source=="architecture"))
        req=tuple(sorted(set(tests)))[:100]
        risks=[]
        if len(impacted)>10: risks.append("large_dependency_fanout")
        if not req: risks.append("no_matching_regression_tests")
        if affected_invariants: risks.append("invariant_revalidation_required")
        cid=_digest({"target":target,"impacted":sorted(impacted)})[:16]
        payload={"id":cid,"target":target,"impacted":sorted(impacted),"contracts":affected_contracts,"invariants":affected_invariants,"tests":req,"risks":risks}
        return ChangeSimulation(cid,target,tuple(sorted(impacted)),affected_contracts,affected_invariants,req,tuple(risks),len(impacted)<=max_nodes,_digest(payload))

class ExperimentalLearningLoop:
    VERSION="EL1.0-1"
    def run(self, hypothesis: str, prediction: str, change: str, observed: str, *, unexpected=(), tests=(), conclusion="") -> Experiment:
        eid=_digest({"h":hypothesis,"p":prediction,"c":change})[:16]
        payload={"id":eid,"h":hypothesis,"p":prediction,"c":change,"o":observed,"u":list(unexpected),"t":list(tests),"conclusion":conclusion}
        return Experiment(eid,hypothesis,prediction,change,observed,tuple(unexpected),tuple(tests),conclusion or ("confirmed" if prediction==observed else "diverged"),_digest(payload))
    def record(self, graph: Any, experiment: Experiment):
        return graph.add_node("EngineeringExperiment", f"Experiment {experiment.experiment_id}", "supported", asdict(experiment))

class RegressionGenerator:
    VERSION="RG1.0-1"
    def from_failures(self, failures: Iterable[Any], gaps: Iterable[str]=()) -> tuple[RegressionProbe,...]:
        out=[]
        for f in failures:
            fid=getattr(f,"case_id",None) or getattr(f,"failure_type",None) or str(f)
            reason=getattr(f,"detail","") or getattr(f,"reason","") or "historical failure"
            pid=_digest({"f":fid,"r":reason})[:16]
            out.append(RegressionProbe(pid,"failure",str(fid),"reproduces prior failure predicate",reason,_digest({"id":pid,"reason":reason})))
        for gap in gaps:
            pid=_digest({"gap":gap})[:16]
            out.append(RegressionProbe(pid,"coverage_gap",gap,"detects uncovered architectural behavior",f"gap:{gap}",_digest({"id":pid,"gap":gap})))
        return tuple(out)

class SystemAssuranceEngine:
    VERSION=VERSION
    def __init__(self, graph: Any, source_root: str | Path):
        self.g=graph; self.root=Path(source_root)
    def snapshot(self, tests: Iterable[str]=()) -> AssuranceSnapshot:
        constitution=SystemConstitution().build()
        architecture=ArchitectureInspector().scan(self.root)
        registry=ContractRegistry(); contracts=registry.discover(architecture,tests)
        candidates=InvariantDiscovery().discover(architecture,contracts)
        invariants=InvariantDiscovery().validate(candidates,architecture)
        blind={c.name:c.blind_spots for c in contracts}
        digest=_digest({"constitution":asdict(constitution),"architecture":architecture.digest,"contracts":[asdict(x) for x in contracts],"invariants":[asdict(x) for x in invariants]})
        return AssuranceSnapshot(constitution,architecture,contracts,invariants,blind,digest)
    def record(self, snapshot: AssuranceSnapshot):
        c=self.g.add_node("AssuranceSnapshot",f"System assurance {self.VERSION}","supported",asdict(snapshot))
        for contract in snapshot.contracts:
            n=self.g.add_node("SubsystemContract",contract.name,"supported",asdict(contract))
            for dep in contract.dependencies:
                try:
                    target=next(x for x in snapshot.contracts if x.name==dep)
                    trows=self.g.db.execute("SELECT id FROM nodes WHERE kind='SubsystemContract' AND content=? ORDER BY created_at DESC LIMIT 1",(target.name,)).fetchone()
                    if trows: self.g.link(n.id,"depends_on",trows[0])
                except StopIteration: pass
        return c
    def health(self, snapshot: AssuranceSnapshot) -> dict[str,Any]:
        return {"version":self.VERSION,"architecture_nodes":len(snapshot.architecture.nodes),"architecture_edges":len(snapshot.architecture.edges),"contracts":len(snapshot.contracts),"invariants":len(snapshot.invariants),"blind_spots":sum(len(v) for v in snapshot.blind_spots.values()),"digest":snapshot.digest}

class ImmuneSystem:
    """Composes existing assurance mechanisms into one bounded health cycle."""
    VERSION="IS1.0-1"
    def run(self, *, evaluation: Any, selftest: Any, meta: Any, simulation: ChangeSimulation | None = None) -> dict[str,Any]:
        gates={"evaluation":bool(getattr(evaluation,"passed_all",False)),"selftest":bool(getattr(selftest,"passed_all",False)),"meta":bool(getattr(meta,"passed_all",False))}
        if simulation is not None: gates["counterfactual_budget"] = simulation.budget_ok
        return {"version":self.VERSION,"gates":gates,"healthy":all(gates.values()),"required_actions":tuple(k for k,v in gates.items() if not v),"digest":_digest(gates)}

class RecursiveImprovementEngine:
    """Bounded three-level evaluation: product, engineering, improvement system."""
    VERSION="RI1.0-1"
    def assess(self, snapshot: AssuranceSnapshot, *, product_ok: bool, engineering_ok: bool, improvement_ok: bool, depth: int = 0) -> dict[str,Any]:
        budget=snapshot.constitution.improvement_budget
        bounded=depth < budget["recursion"]
        levels={"product":product_ok,"engineering":engineering_ok,"improvement":improvement_ok}
        return {"version":self.VERSION,"depth":depth,"budget_depth":budget["recursion"],"bounded":bounded,"levels":levels,"healthy":bounded and all(levels.values()),"next":("deeper_meta_evaluation" if bounded and not all(levels.values()) else "hold") ,"digest":_digest({"levels":levels,"depth":depth})}
