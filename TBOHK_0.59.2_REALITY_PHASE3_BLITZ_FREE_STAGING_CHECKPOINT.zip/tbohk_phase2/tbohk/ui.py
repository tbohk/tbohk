from __future__ import annotations

from pathlib import Path


def page(version: str) -> str:
    html = (Path(__file__).with_name("ui.html")).read_text(encoding="utf-8")
    return html.replace("__VERSION__", version)
