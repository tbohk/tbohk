from __future__ import annotations
from dataclasses import dataclass, asdict
from .core import TBOHK
from .research import ResearchChain, ResearchProvider
from .investigation import AdaptiveInvestigator
from .intelligence import KnowledgeIntelligence
from .adaptive_learning import AdaptiveLearningEngine
from .investigation_state import InvestigationStateEngine

@dataclass(frozen=True)
class AdaptiveCycle:
    cycle: int
    target_prediction_id: str | None
    query: str | None
    evidence_count: int
    status: str
    rationale: tuple[str, ...]

@dataclass(frozen=True)
class AdaptiveResearchResult:
    run_id: str
    cycles: tuple[AdaptiveCycle, ...]
    stop_reason: str
    authority_boundary: str

class AdaptiveResearchController:
    """Bounded controller for evidence acquisition.

    The controller may dispatch only to providers explicitly supplied by the
    caller. It selects unresolved research targets, records every cycle, and
    stops on exhaustion, repetition, provider failure, or the caller's bound.
    It never authorizes external experiments or promotes a hypothesis.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.investigator = AdaptiveInvestigator(graph)
        self.intelligence = KnowledgeIntelligence(graph)
        self.learning = AdaptiveLearningEngine(graph)
        self.state = InvestigationStateEngine(graph)

    def run(self, question: str, hypothesis_ids: list[str], providers: list[ResearchProvider], *, max_cycles: int = 3, max_targets: int = 1) -> AdaptiveResearchResult:
        q = ' '.join(question.split())
        if not q:
            raise ValueError('question required')
        if not providers:
            raise ValueError('at least one explicit research provider required')
        if not 1 <= max_cycles <= 10:
            raise ValueError('max_cycles must be between 1 and 10')
        if not 1 <= max_targets <= 5:
            raise ValueError('max_targets must be between 1 and 5')
        # Validate all hypotheses before creating the run so bad IDs cannot leave partial runs.
        plan = self.investigator.plan(hypothesis_ids, max_targets=max_targets)
        run = self.g.add_node('AdaptiveResearchRun', q, 'proposed', {
            'question': q, 'hypothesis_ids': list(plan.hypothesis_ids),
            'max_cycles': max_cycles, 'max_targets': max_targets,
            'providers': [p.provider_id for p in providers],
            'authority_boundary': 'research_and_assessment_only; no autonomous authorization or external experiment execution',
        })
        cycles = []
        attempted = set()
        stop_reason = 'cycle_bound_reached'
        last_learning = None
        previous_state_id = None
        for cycle_no in range(1, max_cycles + 1):
            targets = self.investigator.rank_targets(list(plan.hypothesis_ids))
            target = next((t for t in targets if not t.assessed and t.prediction_id not in attempted and t.priority > 0), None)
            if target is None:
                stop_reason = 'no_unresolved_informative_target'
                break
            attempted.add(target.prediction_id)
            query = target.statement
            try:
                rr = ResearchChain(self.g, providers).run(query, f'adaptive cycle {cycle_no}: target prediction {target.prediction_id}')
                evidence_nodes = [e for _, e in rr['results']]
                evidence_count = len(evidence_nodes)
                status = 'completed' if evidence_count else 'no_evidence'
                rationale = tuple(target.rationale) + (f'queried {len(providers)} explicit provider(s)',)
            except Exception as exc:
                evidence_count = 0
                status = 'failed'
                rationale = tuple(target.rationale) + (f'controller caught {type(exc).__name__}',)
            cnode = self.g.add_node('AdaptiveResearchCycle', query, 'supported' if status == 'completed' else 'failed', {
                'run_id': run.id, 'cycle': cycle_no, 'target_prediction_id': target.prediction_id,
                'query': query, 'evidence_count': evidence_count, 'status': status,
                'rationale': list(rationale), 'providers': [p.provider_id for p in providers],
                'evidence_ids': [e.id for _, e in rr['results']] if status != 'failed' else [],
            })
            self.g.link(run.id, 'contains', cnode.id)
            cycles.append(AdaptiveCycle(cycle_no, target.prediction_id, query, evidence_count, status, rationale))
            if status != 'failed':
                remaining = sum(1 for t in self.investigator.rank_targets(list(plan.hypothesis_ids)) if not t.assessed and t.prediction_id not in attempted and t.priority > 0)
                evidence_nodes = [e for _, e in rr['results']]
                last_learning = self.learning.update(run.id, cycle_no, evidence_nodes, remaining)
                learning_id = self.learning.record(run.id, last_learning, [e.id for e in evidence_nodes])
                self.g.link(cnode.id, 'evaluates', learning_id)
            # Record a historical state after every cycle. Each snapshot is immutable;
            # later evidence supersedes the snapshot rather than rewriting it.
            state = self.state.build(run.id, list(plan.hypothesis_ids), through_cycle=cycle_no)
            current_state_id = self.state.record(run.id, state, previous_state_id=previous_state_id)
            delta = self.state.delta(run.id, previous_state_id, current_state_id)
            self.state.record_delta(run.id, delta)
            previous_state_id = current_state_id
            if last_learning and last_learning.stop_recommended and remaining == 0:
                stop_reason = 'no_unresolved_informative_target'
                break
            if last_learning and last_learning.stop_recommended and last_learning.marginal_value == 0:
                stop_reason = 'diminishing_information_value'
                break
            if status == 'failed':
                stop_reason = 'research_cycle_failed'
                break
        self.g.set_status(run.id, 'supported', f'adaptive research completed: {len(cycles)} cycle(s); {stop_reason}')
        return AdaptiveResearchResult(run.id, tuple(cycles), stop_reason,
            'Research is bounded to explicitly supplied providers and evidence acquisition; it does not authorize experiments, external actions, or truth promotion.')
