from __future__ import annotations
from dataclasses import dataclass
import json

@dataclass(frozen=True)
class ProvenanceFinding:
    code: str
    severity: str
    detail: str

@dataclass(frozen=True)
class ProvenanceReport:
    passed: bool
    findings: tuple[ProvenanceFinding, ...]

class ProvenanceEngine:
    """G14 first-class provenance: agents, activities, responsibility and derivation."""
    def __init__(self, graph):
        self.g = graph

    def agent(self, name: str, *, role: str = "unknown", metadata=None):
        return self.g.add_node("Agent", name, "supported", {"role": role, **(metadata or {})})

    def activity(self, name: str, *, activity_type: str = "unknown", agent_id=None, metadata=None):
        n = self.g.add_node("Activity", name, "supported", {"activity_type": activity_type, **(metadata or {})})
        if agent_id is not None:
            self.g.link(n.id, "attributed_to", agent_id)
        return n

    def derive(self, entity_id: str, source_id: str, *, activity_id=None):
        self.g.link(entity_id, "derived_from", source_id)
        if activity_id is not None:
            self.g.link(entity_id, "generated_by", activity_id)

    def responsibility(self, activity_id: str, agent_id: str):
        self.g.link(activity_id, "attributed_to", agent_id)

    def audit(self) -> ProvenanceReport:
        findings = []
        for row in self.g.db.execute("SELECT id,kind,metadata FROM nodes WHERE kind IN ('Activity','Agent')"):
            meta = json.loads(row['metadata'])
            if row['kind'] == 'Activity':
                typ = meta.get('activity_type')
                if not typ:
                    findings.append(ProvenanceFinding('activity_missing_type','error',row['id']))
                if not self.g.db.execute("SELECT 1 FROM edges WHERE source_id=? AND relation='attributed_to'", (row['id'],)).fetchone():
                    findings.append(ProvenanceFinding('activity_missing_agent','error',row['id']))
            elif not meta.get('role'):
                findings.append(ProvenanceFinding('agent_missing_role','warning',row['id']))
        for row in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='generated_by'"):
            a = self.g.db.execute("SELECT kind FROM nodes WHERE id=?", (row['target_id'],)).fetchone()
            if not a or a['kind'] != 'Activity':
                findings.append(ProvenanceFinding('generated_by_non_activity','error',row['target_id']))
        return ProvenanceReport(not any(f.severity == 'error' for f in findings), tuple(findings))
