from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json
from typing import Iterable

from .impact import DependencyImpactAnalyzer, ImpactReport

REVIEW_KINDS = {
    "Claim", "Hypothesis", "Conclusion", "Knowledge", "Decision", "Plan",
    "ConflictSet", "ConflictAssessment", "Verification", "ReasoningActivity",
    "InferenceAssessment", "PredictionAssessment", "InvestigationState",
}

@dataclass(frozen=True)
class ReEvaluationItem:
    node_id: str
    kind: str
    current_status: str
    impact: str
    priority: str
    reasons: tuple[str, ...]
    root_ids: tuple[str, ...]

@dataclass(frozen=True)
class ReEvaluationQueue:
    queue_id: str
    fingerprint: str
    roots: tuple[str, ...]
    run_id: str | None
    item_ids: tuple[str, ...]
    items: tuple[ReEvaluationItem, ...]
    counts: dict[str, int]
    authority_boundary: str
    idempotent: bool = False

class ReEvaluationController:
    """Turn dependency impact into an explicit, auditable review queue.

    Queue creation never changes the status/content of the affected object. A
    review item is a request for independent re-evaluation, not a truth update,
    authorization, or automatic invalidation.
    """
    def __init__(self, graph):
        self.g = graph
        self.impact = DependencyImpactAnalyzer(graph)

    @staticmethod
    def _priority(impact: str, kind: str) -> str:
        if impact == "disproven":
            return "critical"
        if impact == "potentially_invalidated":
            return "high"
        if kind in {"Decision", "Plan"}:
            return "high"
        return "normal"

    def _fingerprint(self, report: ImpactReport) -> str:
        payload = {
            "roots": report.roots,
            "run_id": report.scoped_run_id,
            "items": [
                {
                    "node_id": i.node_id,
                    "kind": i.kind,
                    "status": i.status,
                    "impact": i.impact,
                    "roots": i.roots,
                    "paths": [
                        {"nodes": p.node_ids, "relations": p.relations}
                        for p in i.paths
                    ],
                    "reasons": i.reasons,
                }
                for i in report.items
                if i.kind in REVIEW_KINDS
            ],
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode()).hexdigest()

    def _existing(self, fingerprint: str):
        rows = self.g.db.execute(
            "SELECT id, metadata, status FROM nodes WHERE kind='ReEvaluationQueue' ORDER BY id"
        ).fetchall()
        for row in rows:
            try:
                meta = json.loads(row[1])
            except Exception:
                continue
            if meta.get("fingerprint") == fingerprint:
                return self.g.get(row[0])
        return None

    def create(self, root_ids: Iterable[str], *, run_id: str | None = None,
               max_nodes: int = 10000, reuse_existing: bool = True) -> ReEvaluationQueue:
        report = (self.impact.analyze_investigation(run_id, root_ids, max_nodes=max_nodes)
                  if run_id else self.impact.analyze(root_ids, max_nodes=max_nodes))
        fingerprint = self._fingerprint(report)
        if reuse_existing:
            existing = self._existing(fingerprint)
            if existing:
                return self._load(existing.id, idempotent=True)

        now = datetime.now(timezone.utc).isoformat()
        items = []
        for item in report.items:
            if item.kind not in REVIEW_KINDS:
                continue
            items.append(ReEvaluationItem(
                item.node_id, item.kind, item.status, item.impact,
                self._priority(item.impact, item.kind), item.reasons, item.roots
            ))
        items.sort(key=lambda x: (
            {"critical": 0, "high": 1, "normal": 2}[x.priority],
            {"disproven": 0, "potentially_invalidated": 1, "affected": 2}[x.impact],
            x.kind, x.node_id,
        ))

        queue = self.g.add_node("ReEvaluationQueue", f"Re-evaluation queue {fingerprint[:12]}", "proposed", {
            "fingerprint": fingerprint,
            "root_ids": list(report.roots),
            "run_id": run_id,
            "created_at": now,
            "authority_boundary": "review_only; no automatic truth update; no authorization",
            "source_counts": report.counts,
        })
        item_ids = []
        for position, item in enumerate(items):
            node = self.g.add_node("ReEvaluationItem", f"Review {item.node_id}", "proposed", {
                "queue_id": queue.id,
                "target_id": item.node_id,
                "target_kind": item.kind,
                "current_status": item.current_status,
                "impact": item.impact,
                "priority": item.priority,
                "root_ids": list(item.root_ids),
                "reasons": list(item.reasons),
                "position": position,
                "created_at": now,
                "requires_independent_evaluation": True,
                "automatic_status_change": False,
            })
            self.g.link(queue.id, "contains", node.id)
            self.g.link(node.id, "evaluates", self.g.get(item.node_id).id)
            item_ids.append(node.id)

        return ReEvaluationQueue(
            queue.id, fingerprint, report.roots, run_id, tuple(item_ids), tuple(items),
            {
                "total": len(items),
                "critical": sum(i.priority == "critical" for i in items),
                "high": sum(i.priority == "high" for i in items),
                "normal": sum(i.priority == "normal" for i in items),
                "affected": sum(i.impact == "affected" for i in items),
                "potentially_invalidated": sum(i.impact == "potentially_invalidated" for i in items),
                "disproven": sum(i.impact == "disproven" for i in items),
            },
            "Review queue only. Independent evaluation is required before any status change or action authorization.",
            False,
        )

    def _load(self, queue_id: str, *, idempotent=False) -> ReEvaluationQueue:
        q = self.g.get(queue_id)
        if not q or q.kind != "ReEvaluationQueue":
            raise ValueError(f"not a ReEvaluationQueue: {queue_id}")
        meta = q.metadata
        items = []
        item_ids = []
        for edge in self.g.edges(queue_id, direction="out", relation="contains"):
            n = self.g.get(edge["target_id"])
            if not n or n.kind != "ReEvaluationItem":
                continue
            item_ids.append(n.id)
            m = n.metadata
            items.append(ReEvaluationItem(
                m["target_id"], m["target_kind"], m["current_status"], m["impact"],
                m["priority"], tuple(m.get("reasons", [])), tuple(m.get("root_ids", []))
            ))
        items.sort(key=lambda x: ({"critical":0,"high":1,"normal":2}[x.priority], x.kind, x.node_id))
        return ReEvaluationQueue(
            q.id, meta["fingerprint"], tuple(meta.get("root_ids", [])), meta.get("run_id"),
            tuple(sorted(item_ids)), tuple(items),
            {
                "total": len(items),
                "critical": sum(i.priority == "critical" for i in items),
                "high": sum(i.priority == "high" for i in items),
                "normal": sum(i.priority == "normal" for i in items),
                "affected": sum(i.impact == "affected" for i in items),
                "potentially_invalidated": sum(i.impact == "potentially_invalidated" for i in items),
                "disproven": sum(i.impact == "disproven" for i in items),
            },
            meta.get("authority_boundary", "review only"), idempotent
        )

    def get(self, queue_id: str) -> ReEvaluationQueue:
        return self._load(queue_id)

@dataclass(frozen=True)
class EvaluationPolicy:
    item_id: str
    target_id: str
    required_evidence: tuple[str, ...]
    required_observations: tuple[str, ...]
    minimum_independent_assessments: int
    authority_boundary: str

@dataclass(frozen=True)
class ReEvaluationAssessment:
    assessment_id: str
    item_id: str
    target_id: str
    assessor_id: str
    outcome: str
    evidence_ids: tuple[str, ...]
    observation_ids: tuple[str, ...]
    rationale: str
    proposed_status: str | None

@dataclass(frozen=True)
class ProposedTransition:
    transition_id: str
    target_id: str
    from_status: str
    proposed_status: str
    assessment_ids: tuple[str, ...]
    authorized: bool
    authority_boundary: str

ALLOWED_OUTCOMES = {"supports", "contradicts", "inconclusive", "insufficient_evidence"}

class ReEvaluationWorkflow:
    """Execute review mechanics without executing epistemic or authority changes.

    Policy creation records what must be reviewed. Assessment submission records
    independent findings. Comparison creates a proposed transition only; it never
    changes the target's status and never grants authority.
    """
    def __init__(self, graph):
        self.g = graph

    def policy(self, item_id: str) -> EvaluationPolicy:
        item = self.g.get(item_id)
        if not item or item.kind != "ReEvaluationItem":
            raise ValueError(f"invalid re-evaluation item: {item_id}")
        target = self.g.get(item.metadata["target_id"])
        if not target:
            raise KeyError(item.metadata["target_id"])
        impact = item.metadata.get("impact")
        required_evidence = ()
        required_observations = ()
        if impact in {"potentially_invalidated", "disproven"}:
            required_evidence = tuple(sorted({
                e["source_id"] for e in self.g.edges(target.id, direction="in", relation="evidence_for")
                if self.g.get(e["source_id"]) and self.g.get(e["source_id"]).kind == "Evidence"
            }))
        if target.kind in {"Hypothesis", "Conclusion", "Decision", "Plan"}:
            required_observations = tuple(sorted({
                e["source_id"] for e in self.g.edges(target.id, direction="in", relation="observes")
                if self.g.get(e["source_id"])
            }))
        minimum = 2 if impact in {"potentially_invalidated", "disproven"} else 1
        return EvaluationPolicy(
            item_id, target.id, required_evidence, required_observations, minimum,
            "assessment_only; no automatic status change; no authorization",
        )

    def submit(self, item_id: str, *, assessor_id: str, outcome: str,
               evidence_ids: Iterable[str] = (), observation_ids: Iterable[str] = (),
               rationale: str = "") -> ReEvaluationAssessment:
        if outcome not in ALLOWED_OUTCOMES:
            raise ValueError(f"invalid assessment outcome: {outcome}")
        if not assessor_id.strip():
            raise ValueError("assessor_id required")
        item = self.g.get(item_id)
        if not item or item.kind != "ReEvaluationItem":
            raise ValueError(f"invalid re-evaluation item: {item_id}")
        target_id = item.metadata["target_id"]
        target = self.g.get(target_id)
        if not target: raise KeyError(target_id)
        evidence_ids = tuple(sorted(set(evidence_ids)))
        observation_ids = tuple(sorted(set(observation_ids)))
        policy = self.policy(item_id)
        for nid in evidence_ids:
            n = self.g.get(nid)
            if not n: raise KeyError(nid)
            if n.kind != "Evidence": raise ValueError(f"evidence_ids must reference Evidence nodes: {nid}")
            if not self._valid_evidence(n): raise ValueError(f"evidence lacks valid origin provenance: {nid}")
            if nid == target_id: raise ValueError("assessment cannot cite target as its own evidence")
        for nid in observation_ids:
            n = self.g.get(nid)
            if not n: raise KeyError(nid)
            if n.kind != "Observation": raise ValueError(f"observation_ids must reference Observation nodes: {nid}")
            if nid == target_id: raise ValueError("assessment cannot cite target as its own observation")
        if outcome in {"supports", "contradicts"} and not (evidence_ids or observation_ids):
            raise ValueError("supporting or contradictory assessment requires evidence or observation basis")
        if not rationale.strip():
            raise ValueError("assessment rationale required")
        # A stable content fingerprint makes duplicate submissions idempotent.
        fp = hashlib.sha256(json.dumps({
            "item": item_id, "target": target_id, "assessor": assessor_id,
            "outcome": outcome, "evidence": evidence_ids,
            "observations": observation_ids, "rationale": rationale,
        }, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        for n in self.g.db.execute("SELECT id, metadata FROM nodes WHERE kind='ReEvaluationAssessment' ORDER BY id").fetchall():
            meta = json.loads(n[1])
            if meta.get("fingerprint") == fp:
                return self._assessment(n[0])
        node = self.g.add_node("ReEvaluationAssessment", f"Assessment {target_id}", "proposed", {
            "item_id": item_id, "target_id": target_id, "assessor_id": assessor_id,
            "outcome": outcome, "evidence_ids": list(evidence_ids),
            "observation_ids": list(observation_ids), "rationale": rationale,
            "fingerprint": fp, "independent": True,
            "automatic_status_change": False,
        })
        self.g.link(item_id, "evaluated_by", node.id)
        for nid in evidence_ids + observation_ids: self.g.link(node.id, "based_on", nid)
        proposed = self._proposed_status(target.status, outcome)
        return ReEvaluationAssessment(node.id, item_id, target_id, assessor_id, outcome,
                                      evidence_ids, observation_ids, rationale, proposed)

    @staticmethod
    def _proposed_status(current: str, outcome: str) -> str | None:
        if outcome == "contradicts":
            return "contradicted" if current in {"verified", "supported", "proposed"} else None
        if outcome == "supports":
            return "verified" if current in {"proposed", "supported", "contradicted", "stale"} else None
        return None

    def _valid_evidence(self, node) -> bool:
        origin_id = node.metadata.get("origin_id")
        return bool(origin_id and self.g.get(origin_id))

    def _assessment(self, assessment_id: str) -> ReEvaluationAssessment:
        n = self.g.get(assessment_id)
        m = n.metadata
        return ReEvaluationAssessment(n.id, m["item_id"], m["target_id"], m["assessor_id"],
                                      m["outcome"], tuple(m.get("evidence_ids", [])),
                                      tuple(m.get("observation_ids", [])), m.get("rationale", ""),
                                      self._proposed_status(self.g.get(m["target_id"]).status, m["outcome"]))

    def propose_transition(self, item_id: str) -> ProposedTransition:
        item = self.g.get(item_id)
        if not item or item.kind != "ReEvaluationItem": raise ValueError("invalid re-evaluation item")
        target = self.g.get(item.metadata["target_id"])
        assessments = []
        for e in self.g.edges(item_id, direction="out", relation="evaluated_by"):
            a = self.g.get(e["target_id"])
            if a and a.kind == "ReEvaluationAssessment": assessments.append(a)
        assessments.sort(key=lambda n: n.id)
        if not assessments:
            raise ValueError("independent assessment required")
        policy = self.policy(item_id)
        if target.status != item.metadata.get("current_status"):
            raise ValueError("target status changed since review item creation; create a fresh re-evaluation queue")
        assessor_ids = {a.metadata.get("assessor_id") for a in assessments if a.metadata.get("assessor_id")}
        if len(assessor_ids) < policy.minimum_independent_assessments:
            raise ValueError(f"{policy.minimum_independent_assessments} distinct assessor(s) required; received {len(assessor_ids)}")
        outcomes = {a.metadata.get("outcome") for a in assessments}
        if len(outcomes) != 1:
            proposed = None
        else:
            proposed = self._proposed_status(target.status, next(iter(outcomes)))
        transition_fingerprint = hashlib.sha256(json.dumps({
            "item_id": item_id, "target_id": target.id, "from_status": target.status,
            "proposed_status": proposed, "assessment_ids": [a.id for a in assessments],
        }, sort_keys=True, separators=(",",":")).encode()).hexdigest()
        for row in self.g.db.execute("SELECT id, metadata FROM nodes WHERE kind='ProposedTransition' ORDER BY id").fetchall():
            meta=json.loads(row[1])
            if meta.get("fingerprint") == transition_fingerprint:
                return ProposedTransition(row[0], target.id, target.status, meta.get("proposed_status"),
                                          tuple(meta.get("assessment_ids", [])), False,
                                          meta.get("authority_boundary", "proposal_only; separate authorization required"))
        node = self.g.add_node("ProposedTransition", f"Proposed transition {target.id}", "proposed", {
            "target_id": target.id, "from_status": target.status,
            "proposed_status": proposed, "assessment_ids": [a.id for a in assessments],
            "authorized": False,
            "fingerprint": transition_fingerprint,
            "authority_boundary": "proposal_only; separate authorization required",
        })
        for a in assessments: self.g.link(node.id, "evaluates_against", a.id)
        return ProposedTransition(node.id, target.id, target.status, proposed,
                                  tuple(a.id for a in assessments), False,
                                  "proposal_only; separate authorization required")
