from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone

@dataclass(frozen=True)
class PlanResult:
    plan_id:str
    step_ids:tuple[str,...]

class PlanEngine:
    def __init__(self,graph): self.g=graph
    def create(self,title,steps,*,decision_id=None,goal=None):
        p=self.g.add_node('Plan',title,'proposed',{'goal':goal,'decision_id':decision_id,'created_at':datetime.now(timezone.utc).isoformat()})
        ids=[]
        for i,step in enumerate(steps):
            s=self.g.add_node('PlanStep',str(step),'proposed',{'plan_id':p.id,'position':i})
            self.g.link(p.id,'contains',s.id); ids.append(s.id)
            if i: self.g.link(s.id,'depends_on',ids[i-1])
        if decision_id: self.g.link(p.id,'based_on',decision_id)
        return PlanResult(p.id,tuple(ids))
    def validate(self,plan_id):
        p=self.g.get(plan_id); problems=[]
        if not p or p.kind!='Plan': return (False,('invalid_plan',))
        steps=[self.g.get(e['target_id']) for e in self.g.edges(plan_id,'out','contains')]
        if not steps: problems.append('plan_without_steps')
        if p.status=='verified' and not self.g.edges(plan_id,'in','approved_by'): problems.append('plan_without_approval')
        return (not problems,tuple(problems))
