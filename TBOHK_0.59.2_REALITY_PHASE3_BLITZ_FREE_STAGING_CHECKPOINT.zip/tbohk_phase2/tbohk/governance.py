from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timezone
import hashlib,json

@dataclass(frozen=True)
class GovernanceDecision:
    proposal_id:str
    allowed:bool
    reasons:tuple[str,...]

class GovernanceEngine:
    def __init__(self,graph): self.g=graph
    def grant(self,principal,capabilities,*,scope=None,expires_at=None,approver='governance'):
        payload={'principal':principal,'capabilities':sorted(set(capabilities)),'scope':scope,'expires_at':expires_at,'approver':approver,'issued_at':datetime.now(timezone.utc).isoformat()}
        return self.g.add_node('AuthorityGrant',principal,'proposed',payload)
    def approve_grant(self,grant_id,*,approver,reason=''):
        n=self.g.get(grant_id)
        if not n or n.kind!='AuthorityGrant': raise ValueError('invalid grant')
        if approver != n.metadata.get('approver'): raise PermissionError('wrong approver')
        if approver == n.metadata.get('principal'): raise PermissionError('grant principal cannot approve its own authority grant')
        self.g.set_status(grant_id,'verified',reason); return self.g.get(grant_id)
    def propose_change(self,title,change_type,target_ids,*,proposer,impact=None):
        return self.g.add_node('ChangeProposal',title,'proposed',{'change_type':change_type,'target_ids':target_ids,'proposer':proposer,'impact':impact or {},'created_at':datetime.now(timezone.utc).isoformat()})
    def evaluate_change(self,proposal_id,*,benchmark_passed=True,metamorphic_passed=True,mutation_passed=True,approver='independent'):
        p=self.g.get(proposal_id); reasons=[]
        if not p or p.kind!='ChangeProposal': return GovernanceDecision(proposal_id,False,('invalid proposal',))
        for ok,label in ((benchmark_passed,'benchmark'),(metamorphic_passed,'metamorphic'),(mutation_passed,'mutation')):
            if not ok: reasons.append(f'{label} regression failed')
        allowed=not reasons
        a=self.g.add_node('GovernanceAssessment',f'Assessment {proposal_id}','supported',{'proposal_id':proposal_id,'allowed':allowed,'reasons':reasons,'assessor':approver,'assessed_at':datetime.now(timezone.utc).isoformat()})
        self.g.link(a.id,'evaluates',proposal_id)
        return GovernanceDecision(proposal_id,allowed,tuple(reasons))
    def authorize(self,proposal_id,*,assessment_id):
        a=self.g.get(assessment_id); p=self.g.get(proposal_id)
        if not a or a.kind!='GovernanceAssessment' or not a.metadata.get('allowed'): raise PermissionError('change not approved')
        if not p or p.kind!='ChangeProposal': raise ValueError('proposal missing')
        if a.metadata.get('proposal_id') != proposal_id or not self.g.edges(assessment_id,'out','evaluates') or not any(e['target_id']==proposal_id for e in self.g.edges(assessment_id,'out','evaluates')):
            raise PermissionError('assessment does not evaluate this proposal')
        if a.metadata.get('assessor') == p.metadata.get('proposer'):
            raise PermissionError('proposer cannot independently authorize own change')
        self.g.set_status(proposal_id,'verified','governance authorization'); self.g.link(proposal_id,'approved_by',assessment_id); return self.g.get(proposal_id)
