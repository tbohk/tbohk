from __future__ import annotations
from dataclasses import dataclass, asdict
import re
from .core import TBOHK

@dataclass(frozen=True)
class Hypothesis:
    id: str
    statement: str
    status: str
    evidence_ids: tuple[str, ...]
    predictions: tuple[str, ...]
    discriminators: tuple[str, ...]
    alternatives: tuple[str, ...]
    blockers: tuple[str, ...]

@dataclass(frozen=True)
class HypothesisComparison:
    hypotheses: tuple[str, ...]
    shared_evidence: tuple[str, ...]
    discriminating_evidence: tuple[str, ...]
    unresolved: tuple[str, ...]
    boundary: str

class HypothesisEngine:
    """Conservative hypothesis and competing-explanation engine.

    It constructs explicit alternatives and identifies evidence that could
    discriminate them. It never converts explanatory fit into truth or selects
    a winner without an independently evaluated basis.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def create(self, statement: str, evidence_ids=(), predictions=(), discriminators=(), alternatives=()):
        if not statement.strip(): raise ValueError('hypothesis statement required')
        ids=tuple(dict.fromkeys(evidence_ids)); alts=tuple(dict.fromkeys(alternatives))
        n=self.g.add_node('Hypothesis', statement.strip(), 'proposed', {
            'evidence_ids':list(ids), 'predictions':list(predictions),
            'discriminators':list(discriminators), 'alternatives':list(alts),
            'requires_independent_evaluation':True,
            'truth_boundary':'explanatory hypothesis; not established by creation or evidence count'})
        for eid in ids:
            if self.g.get(eid): self.g.link(n.id,'evidence_for',eid)
        return Hypothesis(n.id,n.content,n.status,ids,tuple(predictions),tuple(discriminators),alts,('requires independent evaluation',))

    def generate_alternatives(self, question: str, observations=(), max_hypotheses=4):
        """Generate deterministic explanation templates from explicit observations.
        This is scaffolding for future semantic generation, not an LLM claim generator.
        """
        q=' '.join(question.split()); obs=tuple(o.strip() for o in observations if o.strip())
        candidates=[
            f"The primary proposed mechanism explains the observed result for: {q}",
            f"A competing mechanism, rather than the proposed mechanism, explains the observed result for: {q}",
            f"A common external factor or confounder explains the observed result for: {q}",
            f"The observed result is partly attributable to measurement, selection, or sampling effects for: {q}",
        ][:max(1,min(max_hypotheses,4))]
        return [self.create(c, evidence_ids=(), predictions=obs, discriminators=(
            'independent evidence testing the proposed mechanism',
            'evidence targeting plausible confounders',
            'measurement or sampling validation',
        )) for c in candidates]

    def compare(self, hypothesis_ids):
        hs=[]
        for hid in hypothesis_ids:
            n=self.g.get(hid)
            if n and n.kind=='Hypothesis': hs.append(n)
        if len(hs)<2: raise ValueError('at least two hypotheses required')
        sets=[set(n.metadata.get('evidence_ids',[])) for n in hs]
        shared=set.intersection(*sets) if sets else set()
        all_e=set.union(*sets) if sets else set()
        discriminating=all_e-shared
        unresolved=[]
        for n in hs:
            if not n.metadata.get('predictions'): unresolved.append(f'{n.id}: no explicit predictions')
            if not n.metadata.get('discriminators'): unresolved.append(f'{n.id}: no explicit discriminators')
        return HypothesisComparison(tuple(h.id for h in hs),tuple(sorted(shared)),tuple(sorted(discriminating)),tuple(unresolved),
            'Comparison identifies explanatory alternatives and evidence requirements; it does not select a winning hypothesis.')

    def assess(self, hypothesis_id):
        n=self.g.get(hypothesis_id)
        if not n or n.kind!='Hypothesis': raise ValueError('not a Hypothesis')
        ev=list(n.metadata.get('evidence_ids',[]))
        return {'hypothesis_id':n.id,'statement':n.content,'status':n.status,
                'evidence_count':len(ev),'predictions':n.metadata.get('predictions',[]),
                'discriminators':n.metadata.get('discriminators',[]),
                'alternatives':n.metadata.get('alternatives',[]),
                'evaluation_boundary':'Evidence association is not equivalent to explanatory confirmation.'}
