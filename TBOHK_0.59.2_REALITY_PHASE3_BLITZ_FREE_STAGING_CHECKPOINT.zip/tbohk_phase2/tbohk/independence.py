from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from .core import TBOHK, Node

@dataclass(frozen=True)
class IndependenceAnalysis:
    evidence_ids: tuple[str, ...]
    independent_groups: tuple[tuple[str, ...], ...]
    shared_dependencies: tuple[tuple[str, ...], ...]
    reasons: tuple[str, ...]

    @property
    def independent_count(self) -> int:
        return len(self.independent_groups)

class IndependenceAnalyzer:
    """Analyze independence from documented origin lineage, not provider count.

    A provider is an agent/transport. An origin is the upstream provenance of the
    information. Two pieces of evidence are not independent when their origin
    lineages intersect. An explicitly shared transformation is also treated as a
    dependency.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph

    def _roots(self, origin_id: str, seen=None) -> set[str]:
        seen = set() if seen is None else set(seen)
        if origin_id in seen:
            return set()
        seen.add(origin_id)
        parents: set[str] = set()
        for row in self.g.db.execute("SELECT metadata FROM nodes WHERE kind='Origin'"):
            import json
            meta = json.loads(row[0])
            if meta.get("origin_id") != origin_id:
                continue
            parents.update(meta.get("upstream_origin_ids") or [])
        if not parents:
            return {origin_id}
        roots: set[str] = set()
        for parent in parents:
            roots.update(self._roots(parent, seen))
        return roots or {origin_id}

    def analyze_evidence(self, evidence_ids: Iterable[str]) -> IndependenceAnalysis:
        records = []
        for eid in evidence_ids:
            ev = self.g.get(eid)
            if not ev or ev.kind != "Evidence":
                raise ValueError(f"not evidence: {eid}")
            snap = self.g._snapshot_for_evidence(eid)
            if not snap:
                records.append((eid, frozenset({f"missing-snapshot:{eid}"}), None))
                continue
            meta = snap.metadata
            origin = meta.get("origin_id")
            roots = frozenset(self._roots(origin)) if origin else frozenset({f"missing-origin:{eid}"})
            records.append((eid, roots, meta.get("transformation_id")))

        # Build connected components of evidence whose documented provenance intersects.
        parent = list(range(len(records)))
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb: parent[rb] = ra

        reasons = []
        for i in range(len(records)):
            for j in range(i + 1, len(records)):
                _, roots_i, transform_i = records[i]
                _, roots_j, transform_j = records[j]
                if roots_i & roots_j:
                    union(i, j)
                    reasons.append(f"{records[i][0]} shares upstream origin lineage with {records[j][0]}")
                elif transform_i and transform_i == transform_j:
                    union(i, j)
                    reasons.append(f"{records[i][0]} shares transformation lineage with {records[j][0]}")

        components: dict[int, list[int]] = {}
        for i in range(len(records)):
            components.setdefault(find(i), []).append(i)
        groups = [tuple(records[i][0] for i in idxs) for idxs in components.values()]
        dependencies = []
        for idxs in components.values():
            dep = set()
            for i in idxs:
                dep.update(records[i][1])
                if records[i][2]: dep.add(f"transformation:{records[i][2]}")
            dependencies.append(tuple(sorted(dep)))

        return IndependenceAnalysis(
            evidence_ids=tuple(eid for eid, _, _ in records),
            independent_groups=tuple(groups),
            shared_dependencies=tuple(dependencies),
            reasons=tuple(reasons),
        )

    def analyze_claim(self, claim_id: str) -> IndependenceAnalysis:
        evidence = self.g._supporting_evidence(claim_id)
        return self.analyze_evidence(ev.id for ev in evidence)
