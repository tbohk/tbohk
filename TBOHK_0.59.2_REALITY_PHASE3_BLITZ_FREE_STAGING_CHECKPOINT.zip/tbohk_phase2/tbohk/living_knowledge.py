from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import re
from typing import Any


@dataclass(frozen=True)
class ReviewTrigger:
    kind: str
    priority: int
    subject: str
    claim_ids: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()
    reason: str = ""
    suggested_action: str = ""


class LivingKnowledge:
    """Time-aware subject views over the existing knowledge graph.

    A living view records what is currently represented, what changed, and what
    should be rechecked. It never turns freshness, age, source count, or change
    detection into a truth/confidence score and never silently changes claim state.
    """
    DEFAULT_REVIEW_DAYS = 30
    AGING_DAYS = 90
    MAX_CLAIMS = 100
    MAX_EVIDENCE = 200

    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _now():
        return datetime.now(timezone.utc)

    @staticmethod
    def _parse(value):
        if not value:
            return None
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _norm(text):
        return re.sub(r"\s+", " ", str(text or "").strip().casefold())

    def _claims(self, subject: str):
        key = self._norm(subject)
        rows = self.g.db.execute("SELECT id FROM nodes WHERE kind='Claim' ORDER BY rowid DESC").fetchall()
        out = []
        for row in rows:
            claim = self.g.get(row[0])
            if not claim:
                continue
            structured = (claim.metadata or {}).get("structured") or {}
            claim_subject = self._norm(structured.get("subject"))
            text = self._norm(claim.content)
            if (claim_subject and (claim_subject == key or key in claim_subject or claim_subject in key)) or key in text:
                out.append(claim)
            if len(out) >= self.MAX_CLAIMS:
                break
        return out

    def _evidence(self, claim):
        rows = self.g.db.execute(
            "SELECT source_id FROM edges WHERE target_id=? AND relation='evidence_for'", (claim.id,)
        ).fetchall()
        return [self.g.get(r[0]) for r in rows if self.g.get(r[0]) and self.g.get(r[0]).kind == "Evidence"]

    def _latest_retrieval(self, evidence):
        dates = [(self._parse((e.metadata or {}).get("retrieved_at")), e) for e in evidence]
        dates = [(d, e) for d, e in dates if d]
        return max(dates, key=lambda x: x[0])[0] if dates else None

    def _origins(self, evidence):
        return sorted({str((e.metadata or {}).get("origin_id")).casefold() for e in evidence if (e.metadata or {}).get("origin_id")})

    def _last_snapshot(self, subject):
        rows = self.g.db.execute(
            "SELECT id FROM nodes WHERE kind='KnowledgeSnapshot' ORDER BY rowid DESC"
        ).fetchall()
        key = self._norm(subject)
        for row in rows:
            n = self.g.get(row[0])
            if n and self._norm((n.metadata or {}).get("subject")) == key:
                return n
        return None

    def _trigger(self, kind, priority, subject, claim_ids=(), evidence_ids=(), reason="", action=""):
        return ReviewTrigger(kind, priority, subject, tuple(sorted(set(claim_ids))), tuple(sorted(set(evidence_ids))), reason, action)

    def review_triggers(self, subject: str, *, as_of=None):
        now = self._parse(as_of) if as_of else self._now()
        claims = self._claims(subject)
        triggers = []
        for claim in claims:
            evidence = self._evidence(claim)
            if claim.status in {"stale", "contradicted", "rejected", "superseded"}:
                triggers.append(self._trigger("invalidated_claim", 5, subject, (claim.id,), reason=f"Claim is {claim.status}.", action="Review the claim and its downstream dependencies."))
            if not evidence:
                triggers.append(self._trigger("missing_evidence", 5, subject, (claim.id,), reason="No direct evidence is currently linked.", action="Acquire direct evidence."))
                continue
            origins = self._origins(evidence)
            if len(origins) < 2:
                triggers.append(self._trigger("independence", 4, subject, (claim.id,), tuple(e.id for e in evidence), reason="Fewer than two distinct evidence origins are recorded.", action="Seek an independent origin or source-of-record."))
            latest = self._latest_retrieval(evidence)
            if latest:
                age = (now - latest).days
                if age >= self.AGING_DAYS:
                    triggers.append(self._trigger("aging_evidence", 3, subject, (claim.id,), tuple(e.id for e in evidence), reason=f"Newest recorded evidence is {age} days old.", action="Recheck current evidence and record the retrieval date."))
            else:
                triggers.append(self._trigger("undated_evidence", 3, subject, (claim.id,), tuple(e.id for e in evidence), reason="Evidence has no parseable retrieval timestamp.", action="Restore or record provenance timestamps."))
            valid_until = []
            for e in evidence:
                snap = next((self.g.get(x["target_id"]) for x in self.g.edges(e.id, "out", "derived_from") if self.g.get(x["target_id"]) and self.g.get(x["target_id"]).kind == "SourceSnapshot"), None)
                if snap and self._parse((snap.metadata or {}).get("valid_until")):
                    valid_until.append((self._parse(snap.metadata.get("valid_until")), e.id))
            expired = [eid for dt, eid in valid_until if dt and dt < now]
            if expired:
                triggers.append(self._trigger("expired_evidence", 5, subject, (claim.id,), expired, reason="One or more supporting source snapshots are past their recorded validity end.", action="Reverify the claim against current or applicable sources."))

        # Explicit supersession and contradiction relationships are surfaced even
        # when the affected node is not itself stale.
        ids = {c.id for c in claims}
        for row in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='supersedes'").fetchall():
            new_id, old_id = row
            if new_id in ids or old_id in ids:
                triggers.append(self._trigger("supersession", 4, subject, tuple(x for x in (new_id, old_id) if x in ids), reason="A claim has an explicit supersession relationship.", action="Review the newer claim and preserve the historical lineage."))
        for row in self.g.db.execute("SELECT source_id,target_id FROM edges WHERE relation='contradicts'").fetchall():
            a, b = row
            if a in ids or b in ids:
                triggers.append(self._trigger("conflict", 4, subject, tuple(x for x in (a, b) if x in ids), reason="A contradiction edge touches this subject.", action="Compare scope, time, measurement, and source provenance."))

        dedup = {}
        for t in triggers:
            dedup[(t.kind, t.claim_ids, t.evidence_ids)] = t
        return [asdict(x) for x in sorted(dedup.values(), key=lambda x: (-x.priority, x.kind, x.claim_ids))]

    def snapshot(self, subject: str, *, as_of=None):
        now = self._parse(as_of) if as_of else self._now()
        claims = self._claims(subject)
        evidence = []
        verified = stale = proposed = contradicted = 0
        for c in claims:
            if c.status == "verified": verified += 1
            elif c.status == "stale": stale += 1
            elif c.status in {"proposed", "unknown"}: proposed += 1
            elif c.status == "contradicted": contradicted += 1
            evidence.extend(self._evidence(c))
        evidence = {e.id: e for e in evidence}
        origins = self._origins(list(evidence.values()))
        latest = self._latest_retrieval(list(evidence.values()))
        review_days = self.DEFAULT_REVIEW_DAYS
        next_review = (latest + timedelta(days=review_days)) if latest else now
        triggers = self.review_triggers(subject, as_of=now)
        digest_payload = {
            "subject": subject, "claim_ids": sorted(c.id for c in claims),
            "statuses": {"verified": verified, "stale": stale, "proposed": proposed, "contradicted": contradicted},
            "evidence_ids": sorted(evidence), "origins": origins,
            "latest_retrieved_at": latest.isoformat() if latest else None,
            "triggers": [(x["kind"], tuple(x["claim_ids"])) for x in triggers],
        }
        digest = hashlib.sha256(str(digest_payload).encode()).hexdigest()
        return {
            "subject": subject,
            "as_of": now.isoformat(),
            "claim_ids": sorted(c.id for c in claims),
            "claim_count": len(claims),
            "status_counts": {"verified": verified, "stale": stale, "proposed": proposed, "contradicted": contradicted},
            "evidence_ids": sorted(evidence)[: self.MAX_EVIDENCE],
            "evidence_count": len(evidence),
            "distinct_origins": origins,
            "latest_retrieved_at": latest.isoformat() if latest else None,
            "last_verified_claims": sorted(c.id for c in claims if c.status == "verified"),
            "next_review": next_review.isoformat(),
            "review_due": now >= next_review or bool(triggers),
            "review_triggers": triggers[:100],
            "snapshot_digest": digest,
            "boundary": "Living knowledge is a time-aware record of graph state and maintenance needs; it is not a truth or confidence score.",
        }

    def history(self, subject: str, limit: int = 20):
        limit = max(1, min(int(limit), 100))
        key = self._norm(subject)
        rows = self.g.db.execute("SELECT id FROM nodes WHERE kind='KnowledgeSnapshot' ORDER BY rowid DESC LIMIT 1000").fetchall()
        out = []
        for row in rows:
            n = self.g.get(row[0])
            if n and self._norm((n.metadata or {}).get("subject")) == key:
                out.append({"id": n.id, "created_at": n.created_at, **n.metadata})
                if len(out) >= limit:
                    break
        return {"subject": subject, "snapshots": out, "count": len(out), "bounded": True}

    def record_snapshot(self, subject: str, *, as_of=None):
        report = self.snapshot(subject, as_of=as_of)
        previous = self._last_snapshot(subject)
        changes = self.compare(report, previous.metadata if previous else None)
        node = self.g.add_node("KnowledgeSnapshot", subject, "supported", report)
        profile = self._profile(subject)
        self.g.link(node.id, "records", profile.id)
        for cid in report["claim_ids"]:
            if self.g.get(cid):
                self.g.link(node.id, "observes", cid)
        self.g.update_metadata(node.id, {"changes": changes}, reason="living knowledge snapshot comparison")
        return {"snapshot": self.g.get(node.id).metadata, "snapshot_id": node.id, "changes": changes, "profile_id": profile.id}

    def _profile(self, subject):
        key = self._norm(subject)
        rows = self.g.db.execute("SELECT id FROM nodes WHERE kind='KnowledgeProfile' ORDER BY rowid").fetchall()
        for row in rows:
            n = self.g.get(row[0])
            if n and self._norm(n.metadata.get("subject")) == key:
                return n
        return self.g.add_node("KnowledgeProfile", subject, "supported", {"subject": subject, "created_by": "living_knowledge", "boundary": "subject index, not a truth assertion"})

    @staticmethod
    def compare(current: dict, previous: dict | None):
        if not previous:
            return {"changed": True, "reason": "first recorded snapshot", "deltas": {}}
        fields = ("claim_count", "evidence_count", "distinct_origins", "status_counts", "latest_retrieved_at", "review_due")
        deltas = {}
        for f in fields:
            if current.get(f) != previous.get(f):
                deltas[f] = {"before": previous.get(f), "after": current.get(f)}
        return {"changed": bool(deltas), "reason": "graph state changed" if deltas else "no tracked change", "deltas": deltas}
