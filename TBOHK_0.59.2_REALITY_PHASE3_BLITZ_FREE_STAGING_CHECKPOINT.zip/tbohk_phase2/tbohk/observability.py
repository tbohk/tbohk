from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import threading, time
from collections import Counter

@dataclass(frozen=True)
class RequestMetric:
    route: str
    method: str
    status: int
    latency_ms: float
    request_id: str
    tenant_id: str | None

class Metrics:
    def __init__(self):
        self._lock=threading.RLock(); self._requests=[]; self._counts=Counter(); self._errors=Counter()
    def record(self, route, method, status, latency_ms, request_id, tenant_id=None):
        if not route or not method or not request_id: raise ValueError('route, method and request_id are required')
        m=RequestMetric(route,method,int(status),max(0.0,float(latency_ms)),request_id,tenant_id)
        with self._lock:
            self._requests.append(m); self._requests=self._requests[-5000:]; self._counts[(route,method)]+=1
            if status >= 500: self._errors[(route,method)]+=1
        return m
    def snapshot(self):
        with self._lock:
            rows=list(self._requests); counts=dict(self._counts); errors=dict(self._errors)
        lat=[x.latency_ms for x in rows]
        lat_sorted=sorted(lat)
        def pct(p):
            if not lat_sorted: return 0.0
            idx=min(len(lat_sorted)-1,max(0,int(round((len(lat_sorted)-1)*p))))
            return lat_sorted[idx]
        return {'requests':len(rows),'routes':{f'{k[0]} {k[1]}':v for k,v in counts.items()},'server_errors':{f'{k[0]} {k[1]}':v for k,v in errors.items()},'latency_ms':{'p50':pct(.5),'p95':pct(.95),'p99':pct(.99)}}
    def recent(self, limit=100):
        if not isinstance(limit,int) or limit<1: raise ValueError('limit must be positive')
        with self._lock: return [asdict(x) for x in self._requests[-min(limit,500):]]

metrics=Metrics()

def request_timer():
    return time.perf_counter()

def elapsed_ms(start):
    if not isinstance(start,(int,float)): raise ValueError('start must be numeric')
    return max(0.0,(time.perf_counter()-start)*1000.0)
