"""Replayable regression intelligence.

This layer records *how* a test failed without changing product truth. Failure
capsules are deterministic and can be used to reprioritize future regression
runs. It is advisory: prioritization never removes mandatory gates.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Iterable


@dataclass(frozen=True)
class FailureCapsule:
    case_id: str
    suite: str
    seed: int
    failure_type: str
    detail: str
    reproduction: str
    source_version: str

    @property
    def digest(self) -> str:
        payload = {
            "case_id": self.case_id,
            "suite": self.suite,
            "seed": self.seed,
            "failure_type": self.failure_type,
            "detail": self.detail,
            "reproduction": self.reproduction,
            "source_version": self.source_version,
        }
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class RegressionPriority:
    case_id: str
    score: int
    reasons: tuple[str, ...]


class RegressionIntelligence:
    """Turn historical failures into deterministic test ordering signals."""

    def __init__(self, failures: Iterable[FailureCapsule] = ()):
        self.failures = tuple(failures)

    def prioritize(self, case_ids: Iterable[str], *, mandatory: Iterable[str] = ()) -> tuple[RegressionPriority, ...]:
        mandatory_set = set(mandatory)
        history: dict[str, int] = {}
        for failure in self.failures:
            history[failure.case_id] = history.get(failure.case_id, 0) + 1
        out = []
        for case_id in case_ids:
            count = history.get(case_id, 0)
            score = count * 10 + (100 if case_id in mandatory_set else 0)
            reasons = []
            if count:
                reasons.append(f"failed:{count}")
            if case_id in mandatory_set:
                reasons.append("mandatory")
            out.append(RegressionPriority(case_id, score, tuple(reasons)))
        return tuple(sorted(out, key=lambda x: (-x.score, x.case_id)))

    @staticmethod
    def make_failure(case_id: str, suite: str, *, seed: int, failure_type: str,
                     detail: str, reproduction: str, source_version: str) -> FailureCapsule:
        if not case_id or not suite or not reproduction or not source_version:
            raise ValueError("failure capsule requires identity, reproduction, and source version")
        return FailureCapsule(case_id, suite, int(seed), failure_type, detail, reproduction, source_version)
