from __future__ import annotations
from dataclasses import dataclass
import time

@dataclass(frozen=True)
class ResourceBudget:
    max_steps:int=100
    max_seconds:float=10.0
    max_items:int=500

class BudgetExceeded(RuntimeError): pass

class Budget:
    def __init__(self,spec:ResourceBudget): self.spec=spec; self.started=time.monotonic(); self.steps=0; self.items=0
    def step(self,count=1):
        self.steps += int(count); self.check()
    def consume(self,count=1):
        self.items += int(count); self.check()
    def check(self):
        if self.steps>self.spec.max_steps: raise BudgetExceeded('step budget exceeded')
        if self.items>self.spec.max_items: raise BudgetExceeded('item budget exceeded')
        if time.monotonic()-self.started>self.spec.max_seconds: raise BudgetExceeded('time budget exceeded')
    def snapshot(self): return {'steps':self.steps,'items':self.items,'elapsed_ms':round((time.monotonic()-self.started)*1000,3),'limits':self.spec.__dict__}
