from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
import json

@dataclass(frozen=True)
class EventEnvelope:
    id: str
    event_type: str
    subject_id: str
    payload: dict[str, Any]
    created_at: str

class EventStore:
    """Read/replay boundary over the authoritative append-only event ledger."""
    def __init__(self, graph): self.g=graph
    def append(self, event_type: str, subject_id: str, payload: dict[str,Any]):
        if not str(event_type).strip() or not str(subject_id).strip(): raise ValueError('event type and subject required')
        with self.g._write_lock:
            self.g._event(event_type,subject_id,payload); self.g.db.commit()
        row=self.g.db.execute('SELECT * FROM events WHERE subject_id=? ORDER BY rowid DESC LIMIT 1',(subject_id,)).fetchone()
        return EventEnvelope(row['id'],row['event_type'],row['subject_id'],json.loads(row['payload']),row['created_at'])
    def stream(self, subject_id=None, event_type=None, limit=500):
        clauses=[]; args=[]
        if subject_id: clauses.append('subject_id=?'); args.append(subject_id)
        if event_type: clauses.append('event_type=?'); args.append(event_type)
        where=(' WHERE '+' AND '.join(clauses)) if clauses else ''
        rows=self.g.db.execute(f'SELECT * FROM events{where} ORDER BY rowid LIMIT ?',args+[max(1,min(int(limit),5000))]).fetchall()
        return [EventEnvelope(r['id'],r['event_type'],r['subject_id'],json.loads(r['payload']),r['created_at']) for r in rows]
    def replay(self, reducer: Callable[[Any,EventEnvelope],Any], initial=None, **filters):
        state=initial
        for event in self.stream(**filters): state=reducer(state,event)
        return state
