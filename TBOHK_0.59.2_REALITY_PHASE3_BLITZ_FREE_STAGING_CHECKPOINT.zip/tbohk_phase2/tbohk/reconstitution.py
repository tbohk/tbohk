from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib, json
from .contamination import ContaminationValidator

@dataclass(frozen=True)
class ReconstitutionFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    blocks_recovery: bool
    evidence: str

@dataclass(frozen=True)
class RecoverySnapshot:
    checkpoint_id: str
    source_digest: str
    nodes: tuple[dict, ...]
    edges: tuple[dict, ...]
    exported_at: str

@dataclass(frozen=True)
class ReconstitutionPlan:
    checkpoint_id: str
    included_nodes: tuple[str, ...]
    excluded_nodes: tuple[str, ...]
    included_edges: tuple[tuple[str, str, str], ...]
    findings: tuple[ReconstitutionFinding, ...]
    source_digest: str

@dataclass(frozen=True)
class ReconstitutionReport:
    passed: bool
    plan: ReconstitutionPlan
    restored_node_ids: tuple[str, ...] = ()

class ReconstitutionEngine:
    """G20: provenance-preserving reconstruction from a validated immutable snapshot.

    Recovery is deliberately separated into export, validation, planning and apply.
    A snapshot can be inspected without changing graph state. Apply is permitted only
    into an empty target graph after source integrity and exclusion checks pass.
    """
    def __init__(self, graph):
        self.g = graph

    @staticmethod
    def _digest(nodes, edges):
        payload = {
            'nodes': sorted(nodes, key=lambda x: x['id']),
            'edges': sorted(edges, key=lambda x: (x['source_id'], x['relation'], x['target_id']))
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

    def export_snapshot(self, checkpoint_id: str) -> RecoverySnapshot:
        cp = self.g.get(checkpoint_id)
        if not cp or cp.kind != 'Checkpoint':
            raise ValueError('invalid checkpoint')
        from .checkpoints import CheckpointManager
        if not CheckpointManager(self.g).verify(checkpoint_id):
            raise ValueError('checkpoint integrity verification failed')
        nodes = [dict(r) for r in self.g.db.execute(
            "SELECT id,kind,status,content,metadata,created_at FROM nodes WHERE kind != 'Checkpoint' ORDER BY id"
        ).fetchall()]
        edges = [dict(r) for r in self.g.db.execute(
            "SELECT source_id,relation,target_id,created_at FROM edges WHERE source_id NOT IN (SELECT id FROM nodes WHERE kind='Checkpoint') AND target_id NOT IN (SELECT id FROM nodes WHERE kind='Checkpoint') ORDER BY source_id,relation,target_id"
        ).fetchall()]
        digest = self._digest(nodes, edges)
        return RecoverySnapshot(checkpoint_id, digest, tuple(nodes), tuple(edges), datetime.now(timezone.utc).isoformat())

    def plan(self, snapshot: RecoverySnapshot, *, exclude_ids=(), contamination_roots=()) -> ReconstitutionPlan:
        findings = []
        actual_digest = self._digest(list(snapshot.nodes), list(snapshot.edges))
        if actual_digest != snapshot.source_digest:
            findings.append(ReconstitutionFinding('snapshot_digest_mismatch', 'critical', (snapshot.checkpoint_id,), True, 'snapshot records do not match their declared source digest'))
        node_map = {n['id']: n for n in snapshot.nodes}
        excluded = set(exclude_ids) | set(contamination_roots)
        if contamination_roots:
            temp = self._temporary_graph(snapshot)
            excluded.update(ContaminationValidator(temp).closure(tuple(contamination_roots)))
        included = set(node_map) - excluded
        for eid in sorted(excluded):
            if eid not in node_map:
                findings.append(ReconstitutionFinding('excluded_node_missing_from_snapshot', 'high', (eid,), False, 'requested exclusion is absent from source snapshot'))
        for n in snapshot.nodes:
            try:
                meta = json.loads(n['metadata'])
            except Exception:
                findings.append(ReconstitutionFinding('malformed_node_metadata', 'critical', (n['id'],), True, 'snapshot node metadata is not valid JSON'))
                continue
            expected = hashlib.sha256(n['content'].encode()).hexdigest()
            if meta.get('content_sha256') != expected:
                findings.append(ReconstitutionFinding('node_content_hash_mismatch', 'critical', (n['id'],), True, 'snapshot content does not match its recorded content hash'))
            if n['id'] in excluded:
                continue
            deps = meta.get('dependency_ids', [])
            missing = [d for d in deps if d not in node_map or d in excluded]
            if missing:
                findings.append(ReconstitutionFinding('recovered_node_has_missing_dependency', 'critical', (n['id'], *missing), True, 'reconstruction would restore a node without all declared dependencies'))
        edge_rows=[]
        for e in snapshot.edges:
            s,t=e['source_id'],e['target_id']
            if s in excluded or t in excluded: continue
            if s not in included or t not in included:
                findings.append(ReconstitutionFinding('edge_targets_missing_node', 'critical', (s,t), True, 'included edge has a missing endpoint'))
                continue
            edge_rows.append((s,e['relation'],t))
        if contamination_roots:
            # The contamination closure is added to `excluded` before `included`
            # is computed, so contaminated descendants cannot enter the restore set.
            temp = self._temporary_graph(snapshot)
            excluded.update(ContaminationValidator(temp).closure(tuple(contamination_roots)))
            included = set(node_map) - excluded
        return ReconstitutionPlan(snapshot.checkpoint_id, tuple(sorted(included)), tuple(sorted(excluded)), tuple(sorted(edge_rows)), tuple(findings), snapshot.source_digest)

    def _temporary_graph(self, snapshot):
        from .core import TBOHK
        g=TBOHK()
        for n in snapshot.nodes:
            meta=json.loads(n['metadata'])
            g.db.execute('INSERT INTO nodes VALUES (?,?,?,?,?,?)',(n['id'],n['kind'],n['status'],n['content'],json.dumps(meta,sort_keys=True),n['created_at']))
        for e in snapshot.edges:
            g.db.execute('INSERT INTO edges VALUES (?,?,?,?)',(e['source_id'],e['relation'],e['target_id'],e['created_at']))
        g.db.commit(); return g

    def apply(self, plan: ReconstitutionPlan, snapshot: RecoverySnapshot, *, target_graph, validation_id: str | None = None):
        if plan.findings or plan.source_digest != snapshot.source_digest:
            raise PermissionError('validated clean reconstitution plan required')
        count = target_graph.db.execute('SELECT COUNT(*) FROM nodes').fetchone()[0]
        if count:
            raise PermissionError('reconstitution target must be empty')
        target_graph.db.execute('BEGIN')
        try:
            for n in snapshot.nodes:
                if n['id'] not in plan.included_nodes: continue
                target_graph.db.execute('INSERT INTO nodes VALUES (?,?,?,?,?,?)', (n['id'],n['kind'],n['status'],n['content'],n['metadata'],n['created_at']))
            for s,r,t in plan.included_edges:
                target_graph.db.execute('INSERT INTO edges VALUES (?,?,?,?)',(s,r,t,datetime.now(timezone.utc).isoformat()))
            target_graph.db.execute('COMMIT')
        except Exception:
            target_graph.db.execute('ROLLBACK'); raise
        restored=tuple(plan.included_nodes)
        # Provenance is added after the atomic restore, so the restored state can be independently audited.
        target_graph._event('reconstitution.applied', restored[0] if restored else 'system', {'checkpoint_id':plan.checkpoint_id,'source_digest':plan.source_digest,'validation_id':validation_id,'restored_count':len(restored)})
        target_graph.db.commit()
        return ReconstitutionReport(True, plan, restored)

@dataclass(frozen=True)
class RecoveryAuditFinding:
    code: str
    severity: str
    affected: tuple[str, ...]
    blocks_release: bool
    evidence: str

class RecoveryLifecycleAuditor:
    """G20 release checks for recovery records and validation provenance."""
    def __init__(self, graph): self.g = graph

    def audit(self):
        findings=[]
        for row in self.g.db.execute("SELECT id,status,metadata FROM nodes WHERE kind='RecoveryProposal'").fetchall():
            try: meta=json.loads(row['metadata'])
            except Exception:
                findings.append(RecoveryAuditFinding('malformed_recovery_proposal','critical',(row['id'],),True,'recovery proposal metadata is malformed')); continue
            vals=self.g.db.execute("SELECT id,metadata FROM nodes WHERE kind='RecoveryValidation'").fetchall()
            matching=[]
            for v in vals:
                try: vm=json.loads(v['metadata'])
                except Exception: continue
                if vm.get('proposal_id')==row['id']: matching.append((v['id'],vm))
            if row['status']=='verified' and not any(vm.get('validated') and vm.get('independent') and vm.get('regression_passed') for _,vm in matching):
                findings.append(RecoveryAuditFinding('recovery_without_independent_validation','critical',(row['id'],),True,'verified recovery proposal lacks independent validated recovery evidence'))
            if row['status']=='verified' and not meta.get('rollback'):
                findings.append(RecoveryAuditFinding('verified_recovery_without_rollback','critical',(row['id'],),True,'verified recovery is not demonstrably reversible'))
        return tuple(findings)
