from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from typing import Callable, Any
import json
import time
@dataclass(frozen=True)
class CheckResult:
    check_id: str; category: str; passed: bool; duration_ms: float; detail: str=""; reproducible: bool=True
@dataclass(frozen=True)
class RepairSignal:
    check_id: str; category: str; action: str; severity: str; evidence: str
@dataclass(frozen=True)
class SelfTestReport:
    version: str; checks: tuple[CheckResult,...]; repairs: tuple[RepairSignal,...]; run_digest: str
    @property
    def total(self): return len(self.checks)
    @property
    def passed(self): return sum(c.passed for c in self.checks)
    @property
    def failed(self): return self.total-self.passed
    @property
    def passed_all(self): return bool(self.checks) and self.failed==0
class SelfTestEngine:
    VERSION="S2.0-1"
    def __init__(self, graph=None): self.g=graph; self._checks=[]
    def register(self, check_id:str, category:str, fn:Callable[[],Any]):
        if not check_id or not category or not callable(fn): raise ValueError("invalid self-test registration")
        self._checks.append((check_id,category,fn))
    def run(self):
        results=[]; repairs=[]
        for check_id,category,fn in self._checks:
            start=time.perf_counter()
            try:
                passed=bool(fn()); detail="ok" if passed else "check returned false"
            except Exception as exc:
                passed=False; detail=f"{type(exc).__name__}: {exc}"
            results.append(CheckResult(check_id,category,passed,(time.perf_counter()-start)*1000,detail))
            if not passed:
                severity="critical" if category in {"integrity","security"} else "maintenance"
                repairs.append(RepairSignal(check_id,category,f"recheck:{check_id}",severity,detail))
        payload=[{"check_id":r.check_id,"category":r.category,"passed":r.passed,"detail":r.detail,"reproducible":r.reproducible} for r in results]
        digest=sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()
        return SelfTestReport(self.VERSION,tuple(results),tuple(repairs),digest)
    def record(self, report):
        if self.g is None: return None
        return self.g.add_node("SelfTestRun",f"Self-test {report.version}","supported",{"version":report.version,"total":report.total,"passed":report.passed,"failed":report.failed,"passed_all":report.passed_all,"run_digest":report.run_digest,"repairs":[r.__dict__ for r in report.repairs]})
