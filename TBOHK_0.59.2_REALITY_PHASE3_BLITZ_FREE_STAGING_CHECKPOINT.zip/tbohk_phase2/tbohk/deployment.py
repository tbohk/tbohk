from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, os, subprocess, tempfile, threading
from pathlib import Path
from typing import Protocol


class DeploymentError(ValueError):
    pass


@dataclass(frozen=True)
class DeploymentResult:
    release_id: str
    adapter: str
    state: str
    artifact_sha256: str
    verified: bool
    rollback_available: bool
    detail: str
    completed_at: str


class DeploymentAdapter(Protocol):
    name: str
    def deploy(self, release_id: str, artifact_path: str, artifact_sha256: str) -> DeploymentResult: ...
    def rollback(self, release_id: str) -> DeploymentResult: ...
    def health(self) -> dict: ...


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


class LocalSystemdAdapter:
    """Fixed-command Linux/systemd deployment adapter.

    It intentionally accepts no shell command from callers. The only mutable
    input is the verified artifact path; service/unit names are configuration
    values validated as safe identifiers. Deployment is serialized by a lock.
    """
    name = "systemd"
    _name_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.@-")

    def __init__(self, service: str = "tbohk", install_root: str = "/opt/tbohk/releases", runner=None):
        if not service or any(c not in self._name_chars for c in service):
            raise DeploymentError("invalid systemd service name")
        self.service = service
        self.install_root = Path(install_root)
        self.runner = runner or subprocess.run
        self._lock = threading.RLock()
        self._previous: Path | None = None
        self._active: Path | None = None

    def _run(self, *args: str) -> subprocess.CompletedProcess:
        return self.runner(list(args), check=True, capture_output=True, text=True, timeout=120)

    def health(self) -> dict:
        try:
            p = self._run("systemctl", "is-active", "--quiet", self.service)
            return {"healthy": p.returncode == 0, "service": self.service}
        except Exception as exc:
            return {"healthy": False, "service": self.service, "error": type(exc).__name__}

    def deploy(self, release_id: str, artifact_path: str, artifact_sha256: str) -> DeploymentResult:
        with self._lock:
            src = Path(artifact_path).resolve()
            if not src.is_file():
                raise DeploymentError("release artifact does not exist")
            if not artifact_sha256 or len(artifact_sha256) != 64:
                raise DeploymentError("artifact SHA-256 is required")
            actual = sha256_file(str(src))
            if actual != artifact_sha256.lower():
                raise DeploymentError("release artifact SHA-256 mismatch")
            if release_id in {"", ".", ".."} or any(c not in self._name_chars for c in release_id):
                raise DeploymentError("invalid release identifier")
            self.install_root.mkdir(parents=True, exist_ok=True)
            target = self.install_root / release_id
            previous = self._active
            if target.exists():
                raise DeploymentError("release target already exists")
            target.mkdir(mode=0o750)
            copied = target / src.name
            # copy bytes without accepting a destination outside install_root
            data = src.read_bytes()
            copied.write_bytes(data)
            os.chmod(copied, 0o640)
            if sha256_file(str(copied)) != actual:
                raise DeploymentError("installed artifact verification failed")
            self._run("systemctl", "restart", self.service)
            self._previous = previous
            self._active = target
            return DeploymentResult(release_id, self.name, "deployed", actual, True, previous is not None, "systemd service restarted", datetime.now(timezone.utc).isoformat())

    def rollback(self, release_id: str) -> DeploymentResult:
        with self._lock:
            if self._previous is None or not self._previous.exists():
                raise DeploymentError("no verified previous release is available for rollback")
            previous = self._previous
            self._run("systemctl", "restart", self.service)
            self._active = previous
            self._previous = None
            return DeploymentResult(release_id, self.name, "rolled_back", "", True, False, "systemd service restarted on previous verified release", datetime.now(timezone.utc).isoformat())


class DeploymentManager:
    """Allowlisted deployment adapters behind the release-control authority."""
    def __init__(self, adapters: dict[str, DeploymentAdapter] | None = None):
        self.adapters = adapters or {}

    def deploy(self, adapter: str, release_id: str, artifact_path: str, artifact_sha256: str) -> DeploymentResult:
        impl = self.adapters.get(adapter)
        if impl is None:
            raise DeploymentError("deployment adapter is not configured")
        return impl.deploy(release_id, artifact_path, artifact_sha256)

    def rollback(self, adapter: str, release_id: str) -> DeploymentResult:
        impl = self.adapters.get(adapter)
        if impl is None:
            raise DeploymentError("deployment adapter is not configured")
        return impl.rollback(release_id)

    def health(self, adapter: str) -> dict:
        impl = self.adapters.get(adapter)
        if impl is None:
            raise DeploymentError("deployment adapter is not configured")
        return impl.health()
