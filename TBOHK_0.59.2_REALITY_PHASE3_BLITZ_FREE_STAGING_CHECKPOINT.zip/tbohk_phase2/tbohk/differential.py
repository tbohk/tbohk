"""Deterministic differential comparison for state/query observations."""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any

@dataclass(frozen=True)
class DifferentialMismatch:
    path: str
    expected: Any
    actual: Any

@dataclass(frozen=True)
class DifferentialReport:
    equal: bool
    mismatches: tuple[DifferentialMismatch, ...]
    digest: str

class DifferentialComparator:
    VERSION = "DC1.0-1"
    def compare(self, expected: Any, actual: Any) -> DifferentialReport:
        mismatches = tuple(self._diff(expected, actual, ""))
        payload = {"version":self.VERSION,"mismatches":[m.__dict__ for m in mismatches]}
        digest = sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
        return DifferentialReport(not mismatches, mismatches, digest)
    def _diff(self, a: Any, b: Any, path: str):
        if type(a) is not type(b):
            yield DifferentialMismatch(path, a, b); return
        if isinstance(a, dict):
            for key in sorted(set(a) | set(b), key=str):
                if key not in a or key not in b: yield DifferentialMismatch(f"{path}/{key}", a.get(key), b.get(key))
                else: yield from self._diff(a[key], b[key], f"{path}/{key}")
        elif isinstance(a, (list, tuple)):
            if len(a) != len(b): yield DifferentialMismatch(path, a, b); return
            for i,(x,y) in enumerate(zip(a,b)): yield from self._diff(x,y,f"{path}/{i}")
        elif a != b: yield DifferentialMismatch(path, a, b)
