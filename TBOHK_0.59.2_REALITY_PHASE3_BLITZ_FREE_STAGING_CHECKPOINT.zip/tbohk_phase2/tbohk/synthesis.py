from __future__ import annotations
from dataclasses import dataclass, asdict
import re
from typing import Iterable
from .core import TBOHK
from .independence import IndependenceAnalyzer
from .temporal_quantitative import TemporalQuantitativeAnalyzer
from .causal import CausalReasoner

_NEG = re.compile(r"\b(?:not|no|never|without|cannot|can't|doesn't|does not|isn't|is not|aren't|are not)\b", re.I)
_LINK = re.compile(r"\b(is|are|was|were|has|have|causes|increases|decreases|reduces|improves|contains|measures|measured)\b", re.I)
_NUM = re.compile(r"\b\d+(?:\.\d+)?\s*(?:%|percent|years?|months?|days?|hours?|kg|km|m|seconds?)?\b", re.I)

@dataclass(frozen=True)
class ClaimStructure:
    subject: str
    predicate: str
    object: str
    negated: bool = False

@dataclass(frozen=True)
class Comparison:
    claim_a: str
    claim_b: str
    relationship: str
    reason: str

class EvidenceSynthesizer:
    """Deterministic semantic comparison layer.

    It normalizes simple declarative claims and detects high-confidence structural
    opposition. It never changes claim status and never decides which claim is true.
    """
    def __init__(self, graph: TBOHK):
        self.g = graph
        self.independence = IndependenceAnalyzer(graph)
        self.causal = CausalReasoner(graph)

    @staticmethod
    def parse(text: str) -> ClaimStructure | None:
        text = re.sub(r"\s+", " ", text.strip().strip(". "))
        m = _LINK.search(text)
        if not m: return None
        subject = text[:m.start()].strip(" ,;:")
        predicate = m.group(1).lower()
        obj = text[m.end():].strip(" ,;:")
        negated = bool(_NEG.search(obj))
        obj = re.sub(r"^(?:not|no|never)\s+", "", obj, flags=re.I).strip()
        if not subject or not obj or len(subject) > 160 or len(obj) > 700: return None
        return ClaimStructure(subject, predicate, obj, negated)

    def normalize_claim(self, claim_id: str) -> dict:
        c = self.g.get(claim_id)
        if not c or c.kind != "Claim": raise ValueError(f"not a Claim: {claim_id}")
        existing = c.metadata.get("structured")
        if existing and existing.get("subject") and existing.get("predicate") and existing.get("object"):
            s = ClaimStructure(existing["subject"], existing["predicate"], existing["object"], bool(existing.get("negated")))
        else:
            parsed = self.parse(c.content)
            if not parsed: return {"claim_id": claim_id, "structured": None, "status": "unparseable"}
            s = parsed
        return {"claim_id": claim_id, "structured": asdict(s), "status": "candidate"}

    def compare(self, claim_a: str, claim_b: str) -> Comparison:
        a = self.normalize_claim(claim_a)["structured"]
        b = self.normalize_claim(claim_b)["structured"]
        if not a or not b: return Comparison(claim_a, claim_b, "indeterminate", "one or both claims are not structurally parseable")
        same_subject = a["subject"].casefold() == b["subject"].casefold()
        same_pred = a["predicate"].casefold() == b["predicate"].casefold()
        if not (same_subject and same_pred):
            return Comparison(claim_a, claim_b, "different_scope_or_relation", "subject or predicate differs")
        ao, bo = a["object"], b["object"]
        if ao.casefold() == bo.casefold() and a["negated"] != b["negated"]:
            return Comparison(claim_a, claim_b, "contradictory", "same subject, predicate, and object with opposite polarity")
        if a["negated"] != b["negated"] and ao.casefold() != bo.casefold():
            return Comparison(claim_a, claim_b, "potentially_contradictory", "same subject/predicate with opposite polarity; temporal and quantitative scope requires review")
        tq = TemporalQuantitativeAnalyzer.analyze(ao, bo, same_subject=True, same_predicate=True)
        if tq.relationship in {"temporal_scope_difference", "quantitative_disagreement", "temporal_scope_incomplete"}:
            return Comparison(claim_a, claim_b, tq.relationship, tq.reason)
        return Comparison(claim_a, claim_b, "compatible_or_unresolved", "no high-confidence structural contradiction detected")

    def compare_claim_set(self, claim_ids: Iterable[str]) -> list[dict]:
        ids = list(dict.fromkeys(claim_ids)); out=[]
        for i in range(len(ids)):
            for j in range(i+1, len(ids)):
                out.append(asdict(self.compare(ids[i], ids[j])))
        return out

    def evidence_profile(self, claim_id: str) -> dict:
        evidence = self.g._supporting_evidence(claim_id)
        if not evidence:
            return {"claim_id": claim_id, "evidence_ids": [], "independent_groups": [], "independent_count": 0}
        a = self.independence.analyze_evidence(e.id for e in evidence)
        return {"claim_id": claim_id, "evidence_ids": list(a.evidence_ids),
                "independent_groups": [list(x) for x in a.independent_groups],
                "independent_count": a.independent_count,
                "shared_dependencies": [list(x) for x in a.shared_dependencies],
                "reasons": list(a.reasons)}

    def synthesize(self, claim_ids: Iterable[str]) -> dict:
        ids=list(dict.fromkeys(claim_ids))
        comparisons=self.compare_claim_set(ids)
        causal_assessments=[asdict(self.causal.assess(cid)) for cid in ids]
        causal_comparisons=[]
        for i in range(len(ids)):
            for j in range(i+1,len(ids)):
                causal_comparisons.append(self.causal.compare(ids[i],ids[j]))
        contradictions=[x for x in comparisons if x["relationship"] in {"contradictory","potentially_contradictory"}]
        profiles=[self.evidence_profile(cid) for cid in ids]
        return {"claims": ids, "comparisons": comparisons, "contradictions": contradictions,
                "causal_assessments": causal_assessments, "causal_comparisons": causal_comparisons,
                "evidence_profiles": profiles,
                "boundary": "Structural comparison is not a truth determination; unresolved contradictions remain unresolved."}
