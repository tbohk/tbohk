# TBOHK 0.29.28 — Web Learning Loop

## Implemented

The public-web corpus feature now has an operational bounded learning cycle:

1. ingest timestamped Common Crawl observations
2. extract conservative sentence-level candidate claims
3. extract structured subject/predicate/object candidates
4. merge exact normalized duplicate candidates and retain all evidence links
5. measure independent-origin support
6. create explicit VerificationTask records
7. detect structured disagreements and create ConflictSet records
8. retain candidates as `proposed`; never auto-promote corpus observations to verified knowledge
9. record a WebLearningCycle tying evidence, candidates, verification tasks, conflicts, and continuation cursor together

## Boundary

The system does not and cannot literally consume the entire Internet in one operation. It uses Common Crawl's public archive as a scalable corpus source and processes it through bounded, resumable cycles. Current Common Crawl documentation exposes both CDXJ and bulk URL indexes and WARC/WET archive data.

## Verification

- Full regression: 705 passed
- Python compilation: pass
- JavaScript syntax: pass
- New web-learning tests: pass
- Version synchronized: 0.29.28

## Safety/epistemic boundary

Corpus text is untrusted evidence. Embedded instructions are not executable authority. Candidate extraction, source agreement, and conflict detection are structural signals; they do not establish truth. Promotion remains governed by TBOHK's existing epistemic verification workflow.
