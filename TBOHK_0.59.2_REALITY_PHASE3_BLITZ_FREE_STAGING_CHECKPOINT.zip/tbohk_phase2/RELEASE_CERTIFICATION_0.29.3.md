# TBOHK 0.29.3 Release Certification

## Automated certification record

- Test suite: 676 passed.
- Production coverage: 8,313 statements / 8,313 covered / 100%.
- Python compileall: PASS.
- Production verifier: PASS using isolated certification databases.
- Local assurance: PASS.
- Chromium: PASS, 10 application views × 6 viewport widths (320, 360, 390, 412, 768, 1440).
- Swift package build: PASS on Linux. This verifies the source shell; it is not a substitute for Xcode/iOS signing.
- Live HTTP: `/health` 200; `/pricing` 200; invalid protected token 401.
- Provider readiness remains credential-gated by design.

## Product behavior covered

- Multi-account tenant isolation and monthly usage metering.
- 30-day sessions, revocation, recovery-token hashing, reset invalidation, login throttling.
- Stripe/Apple/Google server-side entitlement authority and idempotency.
- Account deletion and tenant-data deletion.
- Release authorization, staged rollout, health gating and rollback evidence.
- Learning/experiment/canary controls cannot self-deploy.
- Research URL validation, SSRF protection, bounded retrieval, PDF/HTML/text extraction, provenance, duplicate suppression, independent-origin analysis, citation verification, and untrusted-source content boundaries.
- Grounded answer presentation, uncertainty/truth boundary, citation-quality metadata, and deterministic SSE transport.
- Responsive web UI acceptance and native client source contracts.
- Backup/restore and assurance infrastructure already present in the baseline and retained.

## Remaining activation gates

These cannot honestly be marked complete from this build environment:

1. Production Stripe account configuration and live webhook activation.
2. Apple App Store Connect products, server credentials, Xcode signing, TestFlight and store review.
3. Google Play Console products, service account, RTDN, Play signing, closed testing and store review.
4. Production SMTP credentials/sender identity.
5. Production infrastructure/DNS/TLS/WAF/observability provisioning.
6. Legal/operator completion of store privacy/data-safety declarations and final commercial disclosures.

No production secret is included in the artifact.
