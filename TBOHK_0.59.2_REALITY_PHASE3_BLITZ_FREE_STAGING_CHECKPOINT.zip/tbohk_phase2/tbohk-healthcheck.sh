#!/bin/sh
set -eu
URL=${TBOHK_HEALTH_URL:-http://127.0.0.1:8000/health}
TIMEOUT=${TBOHK_HEALTH_TIMEOUT:-5}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$ROOT/.venv/bin/python" - "$URL" "$TIMEOUT" <<'PY'
import json, sys, urllib.request
url, timeout = sys.argv[1], float(sys.argv[2])
try:
    with urllib.request.urlopen(url, timeout=timeout) as r:
        if r.status != 200:
            raise SystemExit(f'health HTTP {r.status}')
        payload = json.load(r)
except Exception as exc:
    raise SystemExit(f'health check failed: {exc}')
if payload.get('ok') is not True:
    raise SystemExit(f'health payload not ok: {payload!r}')
print('health=ok')
PY
