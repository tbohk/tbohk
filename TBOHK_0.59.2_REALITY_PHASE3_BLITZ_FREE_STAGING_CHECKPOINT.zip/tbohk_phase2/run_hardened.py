from __future__ import annotations
import ipaddress, os, stat, sys
from pathlib import Path


def _truthy(name: str) -> bool:
    return os.getenv(name, '').strip().lower() in {'1','true','yes','on'}


def _read_secret_file() -> None:
    path = os.getenv('TBOHK_API_TOKEN_FILE', '').strip()
    if not path or os.getenv('TBOHK_API_TOKEN'):
        return
    p = Path(path).expanduser()
    st = p.stat()
    if st.st_mode & 0o077:
        raise SystemExit(f'refusing insecure token file permissions: {p} mode={stat.S_IMODE(st.st_mode):04o}')
    token = p.read_text(encoding='utf-8').strip()
    if len(token) < 32:
        raise SystemExit('refusing API token shorter than 32 characters')
    os.environ['TBOHK_API_TOKEN'] = token


def _validate_bind() -> None:
    host = os.getenv('TBOHK_HOST', '127.0.0.1')
    try:
        loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = host.lower() == 'localhost'
    token = os.getenv('TBOHK_API_TOKEN', '')
    if token and len(token) < 32:
        raise SystemExit('refusing API token shorter than 32 characters')
    if not loopback and not token:
        raise SystemExit('refusing non-loopback bind without TBOHK_API_TOKEN or TBOHK_API_TOKEN_FILE')
    if not loopback and _truthy('TBOHK_REQUIRE_TLS'):
        cert = Path(os.environ.get('TBOHK_TLS_CERT', '')).expanduser()
        key = Path(os.environ.get('TBOHK_TLS_KEY', '')).expanduser()
        if not cert.is_file() or not key.is_file():
            raise SystemExit('TLS is required for non-loopback deployment but certificate/key are missing')
        if key.stat().st_mode & 0o077:
            raise SystemExit(f'refusing insecure TLS key permissions: {key} mode={stat.S_IMODE(key.stat().st_mode):04o}')


def main() -> int:
    _read_secret_file()
    _validate_bind()
    import uvicorn
    kwargs = dict(
        host=os.getenv('TBOHK_HOST', '127.0.0.1'),
        port=int(os.getenv('TBOHK_PORT', '8000')),
        workers=1,
        loop='uvloop',
        http='httptools',
        access_log=_truthy('TBOHK_ACCESS_LOG'),
        log_level=os.getenv('TBOHK_LOG_LEVEL', 'info'),
        server_header=False,
        date_header=False,
        reload=False,
    )
    if _truthy('TBOHK_REQUIRE_TLS'):
        kwargs['ssl_certfile'] = os.environ['TBOHK_TLS_CERT']
        kwargs['ssl_keyfile'] = os.environ['TBOHK_TLS_KEY']
    uvicorn.run('tbohk.api:app', **kwargs)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
