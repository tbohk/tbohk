# TBOHK Reality Phase 2 — Networked Staging Run

## Result

The Phase 2 application path was exercised with a real public HTTPS target (`https://example.com/`).
The application reached the network boundary and failed at DNS resolution in the current execution environment:
`gaierror` / `Temporary failure in name resolution`.

This is an environment/network egress limitation, not a successful provider result. TBOHK therefore correctly refuses to manufacture an evidence record or answer from unavailable external data.

The public target itself is independently reachable from the web retrieval layer and returns the expected Example Domain document.

## Hardening completed during the run

- Added explicit `TBOHK_STAGING_HTTP_PROXY` support for staging environments that require controlled egress.
- Ambient `HTTP_PROXY`/`HTTPS_PROXY` settings remain ignored unless the explicit TBOHK staging proxy is configured.
- Added regression coverage for the explicit proxy boundary.
- Existing SSRF/public-address/redirect protections remain enforced.

## Verification

- Full pytest: 821 passed
- Python compileall: PASS
- Chromium UI acceptance: 10 views × 6 viewport widths PASS
- Staging without configured source: fail-closed PASS
- Real public-source attempt: blocked by runtime DNS/network isolation; not counted as a provider success

## Staging requirement

Run the same checkpoint in a networked staging environment with DNS/HTTPS egress enabled, or set `TBOHK_STAGING_HTTP_PROXY` to an approved egress proxy. The staging smoke then becomes a genuine external retrieval test rather than a mocked or synthetic one.
