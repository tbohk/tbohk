# TBOHK G2/G3 Hardened Prototype — Repair 2

This checkpoint hardens the earlier G2/G3 vertical slice and repairs two architectural defects found during regression testing.

## Implemented

- explicit `Source`, `Activity`, `Provider`, `ResearchRecord` and verification lineage;
- provider-vs-origin distinction for independence analysis;
- immutable content hash audit for source snapshots;
- retrieval/publication/validity timestamps and validity-interval checks;
- precise evidence locator, extraction method and observation time;
- structured claim semantics alongside human-readable claim text;
- policy-driven verification thresholds captured on each Claim;
- first-class `Verification` nodes with corrected provenance direction;
- explicit `ConflictSet` objects for contradictions;
- research completeness records with query, strategy, providers, result counts, failures and stopping condition;
- adversarial regression tests for shared-source corroboration, missing evidence metadata, tampered snapshots, temporal errors, verification provenance and policy/audit consistency.

## G2/G3 flow

G2: `Unknown -> ResearchRequest -> Activity -> Provider -> Dispatch -> Run -> Source -> SourceSnapshot -> Evidence -> ResearchRecord`

G3: `Evidence -> Claim -> ConflictSet / Verification -> Knowledge`

## Repaired defects

1. **Verification edge direction:** verification is now represented as `Verification --verified_by--> Claim`, preserving the meaning that a verification activity/node attests to the claim.
2. **Policy/audit mismatch:** audit derives the required number of independent origins from the Claim's recorded verification policy rather than imposing a universal two-origin rule.

## Test

```bash
pytest -q
```

Expected: **10 passing tests**.

## Deliberate non-goals

No live web retrieval, autonomous tool execution, authority escalation, self-healing, self-modification, probabilistic truth model, or final release claim is introduced here. Those belong to later gates and must be constrained by this provenance/epistemic foundation.

## G3 continuation — current checkpoint

This checkpoint extends the hardened G2/G3 substrate with three explicit mechanisms:

1. **Independence analysis** — provider identity is not treated as independence. Evidence is grouped by documented upstream-origin lineage and shared transformation identifiers. First-class `Origin` nodes make the dependency path auditable.
2. **Contradiction resolution** — contradictions remain explicit `ConflictSet` nodes. Resolution is a separate `ConflictResolution` node with a declared disposition and rationale; resolving a conflict does not silently rewrite claim status.
3. **Temporal invalidation** — source snapshots may carry `valid_from` / `valid_until`. `audit(as_of=...)` detects verified claims whose complete evidence set is temporally invalid, while `temporal_invalidation(as_of=...)` explicitly marks those claims and dependent verified Knowledge as `stale`.

### Current G2/G3 flow

G2: `Unknown -> ResearchRequest -> Activity -> Provider -> Dispatch -> Run -> Origin -> Source -> SourceSnapshot -> Evidence -> ResearchRecord`

G3: `Evidence -> Claim -> ConflictSet / Verification -> Knowledge`

Contradiction handling adds:
`ConflictSet -> ConflictResolution`

### Important limitation
The system does **not** independently discover real-world source lineage. Independence remains only as strong as the provenance supplied by a research adapter. Temporal validity is currently interval-based; claim-specific temporal semantics, automated re-research, and live retrieval remain later work.

## Current G3 epistemic hardening

The current checkpoint also distinguishes four epistemic knowledge types: `assertion`, `negation`, `absence_of_evidence`, and `unknown`. Absence of evidence is never promoted to a verified positive fact; it remains `supported` and requires an explicit search/corpus scope.

Evidence now records a locator type, observation time, extraction method, observation basis, and polarity. Locator types include document, text quote, text position, fragment, XPath, CSS, and data position. This is designed around the same general principle as the W3C Web Annotation model: evidence should identify a particular segment/state of a resource rather than merely naming a whole document.

Claims may carry structured uncertainty, including interval bounds, units, method, basis, and confidence level. The system validates the structure but does not interpret a confidence number as truth probability.

## G4 — Provenance-Preserving Reasoning

The current checkpoint adds a constrained reasoning substrate. `ReasoningRule` and `ReasoningActivity` are first-class nodes. A reasoning activity explicitly applies a declared rule to supported or verified Claim premises and produces a new Claim with preserved derivation links.

Supported rule forms in this checkpoint are deliberately narrow:
- `identity` — preserves a structured proposition;
- `conjunction` — derives a declared consequence from multiple declared premises;
- `modus_ponens` — derives a declared consequent from a matching antecedent plus an explicit implication premise or a rule that explicitly asserts the implication.

Reasoning does not automatically verify a derived Claim. The result remains `proposed` until a separate verification policy and process establish support. This preserves the distinction between evidence, claims, and inference.

The implementation is aligned conceptually with W3C PROV's model of Activities using Entities and generating derived Entities; the TBOHK implementation uses its own graph vocabulary rather than claiming PROV compliance. See https://www.w3.org/TR/prov-o/.

### G4 boundary

This is not yet a general-purpose natural-language theorem prover. Semantic matching is explicit and structured. No hidden LLM inference is treated as an auditable proof step. Later reasoning layers must add rule registration, rule versioning, conflict-aware inference, uncertainty propagation through derivations, dependency invalidation, and authorization boundaries before autonomous reasoning is considered.

Current validation: **41 tests passing**, compilation passing, demo audit passing, and release ZIP integrity passing.

## G9–G11 continuation

G9 adds bounded autonomous orchestration. G10 adds adversarial structural validation. G11 adds explicit reality correspondence through external observations, freshness checks, preserved conflicts, and post-action verification. These gates deliberately preserve the distinctions `capability != authority`, `representation != reality`, and `observation != truth`.

Current validation: **115 tests passing**.

## G12 — Release Gate

G12 adds a final release auditor that aggregates prior structural gate findings, adversarial findings, core graph-audit findings, and checkpoint-manifest integrity. Any blocking finding prevents a release report from passing.

Post-action reality verification is also tied explicitly to the Action with a `verified_by` edge only when expected and observed effects match. A failed verification remains evidence of mismatch rather than an authorization or success signal.

### G12 release validation

- **119 tests passing**
- `python -m compileall -q tbohk` passing
- Existing demo execution and audit passing
- Checkpoint integrity regression passing, including tamper detection
- G12 release audit passing on a clean graph

The release artifact is a reproducible ZIP checkpoint of the tested source tree. A release pass means the implemented invariants and supplied tests pass; it is not a claim that the system has unrestricted real-world autonomy or universal factual correctness.


## G13 — Integrity & Tamper-Evident Checkpointing

G13 strengthens the G12 release boundary by binding a checkpoint to the graph state it describes. `IntegrityAuditor` verifies the checkpoint manifest self-hash plus independent node and edge hashes. The release auditor treats any mismatch as a blocking finding. Adversarial tests cover manifest mutation, node mutation, and edge deletion after checkpoint creation.

This is **tamper evidence**, not external cryptographic signing or non-repudiation. A future distribution layer can add trusted signatures without changing the underlying invariant.

Current validation: **123 tests passing**.

## G14 — Trusted Provenance & Release Identity

G14 adds explicit `Agent` and `Activity` provenance entities, responsibility/derivation links, provenance auditing, and authenticated checkpoint release identity using canonical HMAC-SHA256 signatures. Signed checkpoints can be verified by `TrustAuditor`, and `ReleaseAuditor` can enforce the signature as a release-blocking condition. The HMAC mechanism authenticates releases to holders of the signing key; it is not public-key non-repudiation.

## G16 — Independent System Validation
The G16 layer independently challenges graph invariants, provenance, authority, consequential actions, autonomy boundaries, reality correspondence, checkpoint records, and untrusted source content. It is intentionally separate from the earlier gate auditors and is integrated into the release audit as a blocking validation layer.

## G17: Continuous Integrity & Long-Horizon Validation

G17 validates properties that may fail only after repeated operation or accumulated state transitions. It fingerprints graph state, preserves baseline comparisons, detects content and history mutation, checks dependency invalidation, binds evaluations to fixed suite manifests, detects replay accumulation, and validates checkpoint lineage. The release auditor executes a bounded G17 horizon check; longer campaigns are available through `LongHorizonValidator`.


## G18 — Knowledge Lifecycle & Dependency-Aware Invalidation
G18 adds an observational lifecycle auditor that computes transitive dependency blast radius, detects verified claims/knowledge/decisions/plans surviving invalid dependencies, and produces reversible invalidation proposals without mutating graph state. Release validation treats G18 findings as blocking.

### G19 — Epistemic Contamination & Cascade Containment
TBOHK can calculate the downstream quarantine boundary of an explicitly declared contaminated epistemic root without mutating the graph. Verified or promotable derivatives inside that closure are surfaced as blocking findings, while unrelated knowledge remains outside the quarantine boundary.

## G21–G30 Assurance Layer
TBOHK now includes G21–G30 hardening for immutable history, portable checkpoints, key/credential boundaries, replay safety, tool isolation, uncertainty/conflict handling, research completeness, verifier conformance, durable external actions, and final cross-gate red-team validation. The release auditor aggregates these gates with G0–G20.

## Reality Build 0.3 — Full Phase A-G Slice

The application now exposes a bounded end-to-end intelligence workflow. Key endpoints include `/research/plan`, `/research`, `/knowledge`, `/gaps`, `/conflicts`, `/explain/{node_id}`, and `/autonomous-run`.

Autonomy is deliberately bounded: supplied public URLs are the research boundary, claim extraction produces only `proposed` candidates, and the autonomous run cannot create authority grants or authorize external actions.

### Intelligence Deepening (Build 0.4)
- deterministic structured claim candidates (subject/predicate/object)
- evidence-origin/provider independence inspection
- prioritized research-gap queue
- auditable synthesis surface preserving conflicts and uncertainty
- bounded autonomy remains non-authorizing

### Reality Build 0.5 — Semantic Evidence Synthesis

The intelligence layer now includes deterministic semantic claim normalization and cross-claim comparison. Simple declarative claims can be represented as subject/predicate/object plus polarity, and high-confidence structural contradictions can be surfaced without promoting either side to truth. Evidence independence is assessed from provenance lineage rather than simply counting providers. The `/synthesis` API exposes these results while preserving the system's epistemic boundary.


## Reality Build 0.8 — Causal & Relational Reasoning

TBOHK now has a conservative causal/relational reasoning layer. Claims can be classified as causal, correlational, temporal-precedence, dependency, association, or indeterminate. Causal wording is recorded as an assertion, not treated as proof. Correlation and temporal precedence explicitly remain insufficient to establish causation.

The layer records blockers such as missing mechanism, intervention, counterfactual evaluation, and unresolved confounding. Explicit structured causal support may elevate an assessment to `supported_candidate`, but the claim itself remains subject to the existing verification and epistemic controls. The `/causal/{node_id}` API exposes the auditable assessment, while `/synthesis` now includes causal assessments and pairwise causal comparisons.

Validation: **223 tests passing**. Application version: **0.5.0**.

## Reality Build 0.8 — Hypothesis & Competing-Explanation Reasoning

Adds explicit proposed hypotheses, alternative explanations, predictions, discriminating evidence, shared-vs-distinct evidence comparison, and evaluation boundaries. Hypotheses remain proposed and are never promoted to truth by generation or evidence count.


## Reality Build 0.13

The adaptive research controller closes the loop between explicit hypothesis discrimination and bounded evidence acquisition. It chooses unresolved informative predictions, queries only caller-supplied research providers, records auditable adaptive cycles, and stops deterministically at explicit bounds or target exhaustion. It does not execute experiments, grant authority, promote hypotheses, or convert research results directly into truth.

Validation: **242 tests passing**; compilation, fresh-database audit, release-audit, and API smoke checks passing.


## Reality Build 0.13 — Evolving Investigation State

Adaptive research now produces an explicit investigation state separating supporting and contradicting evidence, independent and dependent origins, unresolved conflicts, stale evidence, unresolved targets, and stopping rationale. This state is auditable and never acts as a truth probability or changes hypothesis status.
