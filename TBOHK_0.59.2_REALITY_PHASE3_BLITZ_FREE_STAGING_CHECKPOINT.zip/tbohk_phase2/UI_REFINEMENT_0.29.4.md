# TBOHK UI Refinement 0.29.4

## Purpose
This release is a user-interface refinement pass focused on reducing friction, improving visual hierarchy, strengthening touch/mobile behavior, and making the primary question workflow obvious.

## Changes
- Added a direct question composer to Home.
- Added keyboard shortcut `/` and Ctrl/Cmd+K to focus the question composer when not typing in another control.
- Added Escape-to-close behavior for the pricing modal.
- Reworked mobile navigation into compact grouped controls instead of a tall sidebar.
- Added clearer Workspace/System navigation grouping.
- Improved sticky header/navigation behavior.
- Increased touch-target sizes and focus-visible affordances.
- Improved form-control sizing and mobile text-entry behavior.
- Improved panel/card hierarchy, spacing, typography, and answer/source readability.
- Improved pricing-card layout so actions remain anchored consistently.
- Added graceful storage wrappers so restricted sessionStorage cannot abort UI initialization.
- Preserved existing API contracts and server-authoritative billing/security behavior.

## Verification
- Full regression suite: 676 passed.
- Chromium UI acceptance: 10 views × 6 viewport widths passed.
- Interaction acceptance: Home quick-start, keyboard focus, and Escape-to-close passed.
- Production UI remains account/API driven; no client-side entitlement authority was introduced.
