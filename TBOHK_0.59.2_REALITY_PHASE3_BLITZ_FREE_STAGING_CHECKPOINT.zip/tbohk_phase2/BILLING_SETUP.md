# TBOHK account and billing setup

TBOHK supports three account plans:

- Free — $0/month — 25 asks/month
- Pro — $10/month — 250 asks/month
- Unlimited — $20/month — 1,000 asks/month cap

## Stripe setup

Create two recurring monthly Stripe Prices matching the TBOHK catalog:

- Pro: USD 10.00/month
- Unlimited: USD 20.00/month

Then configure the deployment environment:

```text
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_UNLIMITED=price_...
```

Configure the Stripe webhook endpoint to:

```text
POST https://YOUR-TBOHK-HOST/billing/webhook
```

The webhook signing secret must be the endpoint's Stripe signing secret, not the API secret.

## Billing lifecycle

1. A user creates a Free account.
2. The user selects Pro or Unlimited in TBOHK.
3. TBOHK creates a Stripe Checkout subscription session.
4. Stripe completes payment/subscription creation.
5. Stripe sends the signed webhook.
6. TBOHK verifies the signature and activates the account's paid plan.
7. Subscription updates change billing state; cancellation returns the account to Free.
8. The Billing Portal can be opened from the account once a Stripe customer is attached.

TBOHK never accepts a client-supplied request as proof of payment. Paid entitlement comes from the verified billing event.

## Ask metering

Ask usage is stored by account and UTC calendar month. A successful accepted `/workspace` question consumes one ask. When the limit is reached, the API returns HTTP 429 and the UI displays the remaining allowance.

The counter does not require a scheduled monthly reset. The current `YYYY-MM` key changes automatically when the calendar month changes.

## Storage

The account registry is stored in `TBOHK_ACCOUNTS_DB`. Each account's knowledge graph is stored as its own SQLite database below `TBOHK_ACCOUNT_DATA_DIR`. This prevents one account's knowledge graph from being queried through another account's runtime context.

Production backups include all of these databases in the same retained snapshot set.


## Provider-neutral entitlement layer
TBOHK stores normalized entitlements separately from account plan fields. Providers are `stripe`, `apple`, and `google`; provider events are deduplicated by `(provider,event_id)`.

The `/billing/entitlement` endpoint is the reconciliation contract for a server-verified provider transaction. Native Apple/Google clients must not assert entitlement locally; the server must verify the provider transaction first, then submit the normalized result.

Production provider verification remains a deployment gate: configure Stripe credentials/Price IDs, Apple App Store Server API credentials and Server Notifications V2, and Google Play purchase-token verification plus RTDN before enabling live store billing.

## Production provider gate

`GET /billing/provider-readiness` exposes only configured/missing field names; it never returns secret values. Production startup/CI should require all three providers to report `configured=true` before enabling paid mobile billing.

Stripe requires the live secret, webhook signing secret, and the two live recurring Price IDs. Apple requires the App Store Connect In-App Purchase API key material, Apple root certificates, bundle identifier, environment, and product identifiers. Google requires the Play package, service-account credentials, product identifiers, and a Pub/Sub push audience.

Apple Server Notifications V2 must be configured; V1 is deprecated. Apple server verification should use the App Store Server API as the current-state authority. Google RTDN is a state-change signal; TBOHK calls `subscriptionsv2` to obtain the complete current state before changing entitlement. Google Play's older `purchases.subscriptions` subscription-state endpoint is not used for new integrations.

## Provider readiness and launch invariant

`GET /billing/provider-readiness` reports only whether required production configuration is present and which variable names are missing. It never returns secret values. Paid production billing must remain disabled until Stripe, Apple, and Google each report `configured=true` in the deployment environment.

The server remains the entitlement authority. A mobile client may report a purchase token/transaction to the server, but it cannot grant itself Pro or Unlimited. Apple notifications use App Store Server Notifications V2 and signed JWS payloads; Google RTDN is treated as a state-change signal and the backend queries `subscriptionsv2` for the complete subscription state. Stripe entitlement changes are accepted only from verified webhook events.
