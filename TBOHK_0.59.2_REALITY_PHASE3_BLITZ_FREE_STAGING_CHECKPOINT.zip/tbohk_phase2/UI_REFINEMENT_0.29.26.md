# TBOHK 0.29.26 — Hardening and Longitudinal Reliability

## Implemented

- Persistent investigation-health snapshots and longitudinal comparisons.
- Deterministic recheck triggers for coverage, provenance independence, maintenance, conflicts, fragile support, checkpoint integrity, and adversarial findings.
- Unified investigation-health UI with current state, changes, history, triggers, dependency graph, and decision context.
- Health snapshots excluded from release checkpoint hashes.
- Root-ID and history-limit validation hardened.
- Longitudinal tests recompute health after graph changes rather than reusing stale observations.
- Canonical runtime/package version aligned to `0.29.26`.

## Verification

- `pytest -q`: 700 passed.
- Python compilation: PASS.
- JavaScript syntax: PASS.
- Chromium UI acceptance: 10 views × 6 viewport widths PASS.
- CLI version reports `0.29.26`.

## Boundary

Health diagnostics are observational. They do not independently decide truth, resolve conflicts, select decisions, change claim status, or authorize deployment.
