#!/bin/sh
set -eu
umask 077
BACKUP=${1:?usage: restore_verify.sh BACKUP_DB RESTORE_DB}
DEST=${2:?usage: restore_verify.sh BACKUP_DB RESTORE_DB}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$ROOT/.venv/bin/python" "$ROOT/tbohk_restore_verify.py" "$BACKUP" "$DEST"
