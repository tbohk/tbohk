# TBOHK 0.29.3 Launch Closure

This increment closes executable portions of the remaining product gaps without treating external credentials or store review as completed from source alone.

## Completed in this artifact
- Native Android entrypoint with Compose UI, secure session storage, account registration/login/logout, ask, research, entitlement refresh, accessibility semantics, and `tbohk://ask` deep-link routing.
- Native iOS SwiftUI application surface with question workflow, server-authoritative answer boundary, degraded-network behavior, accessibility labels, and URL routing. Linux Swift build passes; Apple platform signing/build remains Xcode-dependent.
- Research ingestion supports bounded PDF extraction, HTML/text extraction, media capture, public-IP SSRF protection, redirect validation, cross-provider duplicate suppression, independent-origin tracking, and explicit untrusted-source content boundaries.
- Answer responses expose bounded citation-quality metadata and a deterministic SSE transport stream over the same server-authoritative answer structure.
- New regression coverage exercises the launch-closure paths and preserves 100% production-code coverage.
- Version bumped to 0.29.3.

## Verified here
- 676 tests passing.
- 8,313 production statements, 100% coverage.
- Python compileall PASS.
- Production verifier PASS with isolated databases.
- Local assurance PASS.
- Chromium acceptance PASS: 10 views × 6 viewport widths.
- Swift package build PASS on Linux.
- Live HTTP smoke: `/health` 200, `/pricing` 200, invalid protected token 401.

## Explicitly external
- Apple App Store Connect credentials, Xcode signing, TestFlight submission/review.
- Google Play Console credentials, Play signing, closed-track/production review.
- Stripe production keys, Price IDs, and webhook endpoint activation.
- Production SMTP sender credentials.
- Production infrastructure provisioning, DNS/TLS/WAF/monitoring ownership.

Those items remain activation/operations gates, not source-code claims.
