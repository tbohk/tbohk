# TBOHK 0.27 — Full Readiness Roadmap

## Mission

Make the underlying TBOHK substrate extremely difficult to corrupt silently, then make the application useful without weakening its epistemic, provenance, reality, governance, or recovery boundaries.

## 0.27 foundation-hardening result

**Validated:** 317 tests pass; Python compilation passes; a clean graph passes ReleaseAuditor and SelfCareEngine; coverage is approximately 92% statement coverage.

### Hardened now

- SQLite foreign-key enforcement.
- 5-second database busy timeout.
- WAL mode for file-backed databases.
- `synchronous=FULL` for file-backed databases.
- recursive triggers enabled.
- trusted SQLite schema disabled where supported.
- missing ledger entries are no longer silently rebuilt at database open.
- core audit fails closed on unexpected persistent-state parsing errors.
- structurally compromised graphs cannot create normal checkpoints.
- verified SQLite backup creation and post-backup integrity checking.
- non-destructive self-care checks.
- public-bind refusal in the CLI unless an API token is configured.
- updated architecture GIF showing the hardened foundation and transition to the application.

## Full subsystem readiness matrix

| Subsystem | Current state | Forward requirement |
|---|---|---|
| Core graph | implemented | formal schema migration/versioning |
| Node identity | implemented | stable external identifiers where appropriate |
| Typed relations | implemented | relation ontology + validation registry |
| Event history | implemented | independent external anchoring |
| Revision history | implemented | immutable archival/export contract |
| Content integrity | implemented | independent hash verification service |
| Metadata integrity | implemented | schema validation + canonical serialization version |
| Provenance | implemented | explicit Entity/Activity/Agent model |
| Source lineage | implemented | shared-origin and copy detection at scale |
| Evidence locators | implemented | exact document-span UI and extractor provenance |
| Claims | implemented | full semantic claim schema and normalization |
| Temporal validity | implemented | policy-driven freshness by claim class |
| Contradictions | implemented | conflict-set reconciliation UI and policies |
| Uncertainty | implemented | multidimensional evidence strength without fake certainty |
| Research | implemented prototype | provider ecosystem + measurable coverage |
| Search | URL-oriented | production retrieval abstraction |
| Documents | missing | PDF/HTML/text/CSV/structured ingestion |
| Knowledge admission | backend primitives | human review workflow |
| Reasoning | implemented | broader independently evaluated rule/model adapters |
| Hypotheses | implemented | richer discriminating-evidence workflow |
| Predictions | implemented | longitudinal outcome collection |
| Investigation | implemented | background job orchestration |
| Re-evaluation | implemented | scheduled triggers + reviewer queues |
| Lifecycle | implemented | automatic detection with governed transition proposals |
| Recovery | implemented | regular disaster-recovery drills |
| Security boundary | prototype hardened | external threat model + adversarial document testing |
| Tool boundary | implemented prototype | production isolation/sandboxing |
| Authority | implemented prototype | identity-backed authority grants |
| Actions | implemented prototype | production execution adapters + durable receipts |
| Self-care | implemented | scheduler/alerts/incident workflow |
| Checkpoints | implemented | signed external trust anchors |
| Replay | implemented prototype | cross-runtime deterministic replay |
| Independent verification | implemented prototype | separate implementation/verifier service |
| Multi-user identity | missing | authentication, roles, workspaces, tenancy |
| Persistence | SQLite prototype | PostgreSQL/equivalent + migrations |
| Artifact storage | missing | object storage + retention policy |
| Background workers | missing | queue, retries, idempotency and leases |
| Observability | partial | metrics, traces, structured audit export |
| UI | operator console | knowledge workspace + graph + review queues |
| LLM adapters | missing | auditable model/provider/prompt/tool provenance |
| Deployment | prototype | hardened production profile |

## Order of work

### Phase 1 — Structural hardening (0.27.x)

1. Formal invariant registry.
2. Status/state transition matrix.
3. Canonical serialization/versioning.
4. External ledger anchoring.
5. Independent verifier executable outside the main runtime.
6. Database migration framework.
7. Disaster-recovery rehearsal harness.
8. Security threat model for ingestion, tools, documents and credentials.

### Phase 2 — Knowledge workspace (0.28)

1. Question workspace.
2. Evidence/source viewer.
3. Claim admission queue.
4. Conflict workspace.
5. Temporal timeline.
6. Explanation/reasoning trace.
7. Knowledge graph explorer.
8. Human approval/rejection/re-evaluation workflows.

### Phase 3 — Real ingestion (0.29–0.30)

1. File ingestion.
2. Content-addressed artifacts.
3. Extractor provenance.
4. Search providers.
5. Deduplication/shared-origin analysis.
6. Incremental re-research.
7. Background research jobs.

### Phase 4 — Intelligence (0.31+)

1. Auditable LLM adapters.
2. Structured extraction.
3. Claim normalization.
4. Contradiction candidate generation.
5. Model evaluation isolation.
6. Retrieval/indexing/embedding acceleration while keeping provenance authoritative.

### Phase 5 — Production

1. Identity/workspaces.
2. PostgreSQL and migrations.
3. Object storage.
4. Worker infrastructure.
5. Secret/key custody.
6. Monitoring and incident response.
7. Backup/restore drills.
8. Independent security review.

## Non-negotiable invariants

- Evidence is not truth.
- Representation is not reality.
- Inference is not observation.
- Confidence is not probability of truth.
- Absence of evidence is not evidence of absence.
- Provider identity is not source independence.
- Capability is not authority.
- Autonomy is not self-authorization.
- Self-correction is not self-perfection.
- A clean structural audit is not proof of factual correctness.
- A model output is untrusted until it passes the appropriate admission/evaluation path.
- A recovery operation cannot certify itself.
- A repair cannot erase the evidence that a repair occurred.

## Definition of “ready to move forward”

The next application phase begins when:

- the invariant registry is explicit;
- invalid state transitions are rejected or quarantined;
- the ledger has an external trust anchor;
- independent verification does not depend on the same implementation path;
- recovery is exercised against intentionally damaged checkpoints;
- ingestion is isolated from authority and execution;
- every durable mutation is attributable and replay/audit visible;
- self-care can detect structural degradation without silently rewriting the graph.

The objective is not literally “never breaks.” The objective is **failure that is observable, attributable, bounded, reversible where possible, and incapable of silently becoming false knowledge.**
