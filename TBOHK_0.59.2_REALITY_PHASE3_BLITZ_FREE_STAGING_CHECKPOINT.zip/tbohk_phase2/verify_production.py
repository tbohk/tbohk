from __future__ import annotations
import os
from pathlib import Path
from tbohk.core import TBOHK
from tbohk.release import ReleaseAuditor
from tbohk.selfcare import SelfCareEngine
from tbohk.accounts import AccountManager, PLAN_LIMITS

db = os.environ['TBOHK_DB']
accounts_db = os.getenv('TBOHK_ACCOUNTS_DB', str(Path(db).with_name('accounts.sqlite')))
account_data_dir = os.getenv('TBOHK_ACCOUNT_DATA_DIR', str(Path(db).with_name('accounts')))
with TBOHK(db) as g:
    checks = {
        'audit': bool(g.audit().get('ok')),
        'release_audit': bool(ReleaseAuditor(g).audit().passed),
        'selfcare': bool(SelfCareEngine(g).inspect().passed),
        'migrations': bool(g.migrations.verify().get('ok')),
    }
with AccountManager(accounts_db, account_data_dir) as accounts:
    required={'accounts','users','api_tokens','ask_usage'}
    tables={r[0] for r in accounts.db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    checks['account_registry']=required <= tables
    checks['plan_limits']=PLAN_LIMITS == {'free':25,'pro':250,'unlimited':1000}
print(checks)
raise SystemExit(0 if all(checks.values()) else 2)
