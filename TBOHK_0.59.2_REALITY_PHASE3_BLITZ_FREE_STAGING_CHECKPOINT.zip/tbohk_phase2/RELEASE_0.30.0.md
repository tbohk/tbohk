# TBOHK 0.30.0 — Research Intelligence

## Added
- Bounded ResearchAgent over the existing knowledge graph.
- Research gap map for coverage, independence, source-family, scope, time, verification, and semantic gaps.
- Structural claim-leverage analysis for downstream dependencies.
- Claim lineage view from claims through evidence and provenance metadata.
- Adversarial challenge prompts including scope, time, measurement, counterevidence, alternative explanations, primary-source escalation, and causal checks.
- Source-family grouping to expose possible shared upstream origins without treating host/domain similarity as proof of common authorship.
- Research-agent API endpoints and a Research workspace intelligence panel.
- New deterministic test coverage.

## Boundaries
- No truth score or hidden confidence score is generated.
- No claim status is promoted, rejected, or rewritten by this layer.
- Research recommendations are bounded by structural gaps and existing graph relationships.
- Source-family detection is explicitly heuristic and does not establish provenance identity by itself.

## Verification
- Full test suite: 715 passed.
- UI acceptance + new research-agent tests: 14 passed.
- Python bytecode compilation: passed.
- CLI version: 0.30.0.
