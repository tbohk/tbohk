# TBOHK 0.29 — Knowledge Workspace + Closed-Loop Assurance Architecture

## System objective

TBOHK is an auditable knowledge system: a question is converted into a structured workspace containing claims, evidence, provenance, uncertainty, conflicts, research gaps, reasoning traces, and explicit next actions.

The system does **not** treat generated text as verified truth. Verification remains a governed state transition supported by evidence and independent checks.

## Closed loop

```text
Question
  -> Workspace
  -> Evidence / Claims / Conflicts / Gaps
  -> Research
  -> Reasoning / Hypotheses / Predictions
  -> Evaluation
  -> Re-evaluation
  -> Learning candidate
  -> Repair candidate
  -> Independent validation
  -> Deep assurance
  -> Release gate
  -> Checkpoint + manifest + hashes
```

## Self-learning boundary

Learning records are first-class objects. Feedback and evaluations can create improvement proposals. They do not silently alter protected knowledge or grant authority.

## Self-healing boundary

Self-care detects integrity/configuration failures. Self-repair creates an explicit `RepairProposal`, validates it through independent validation and Deep Assurance, and records the result. The repair engine does not execute arbitrary code, rewrite provenance, promote claims, or grant authority.

## Evidence boundary

- observation != interpretation
- evidence != truth
- inference != observation
- confidence != truth probability
- capability != authority
- absence of evidence != positive evidence
- historical state is preserved when knowledge is revised

## Recovery boundary

Every durable checkpoint is content-addressed. Release manifests can include dependency, schema, invariant, test and artifact identities. The intended operational pattern is:

`detect -> contain -> diagnose -> propose -> replay -> independently validate -> apply -> verify -> checkpoint`

## Application surface

0.29 adds:

- `POST /workspace` — open a question-centered knowledge workspace
- `POST /assurance/pipeline` — compose core audit, independent validation, Deep Assurance, self-care and release audit
- `POST /repairs` — create a bounded repair proposal

Existing research, claims, explanation, hypothesis, prediction, investigation, reevaluation, causal, synthesis, assurance and release surfaces remain intact.

## Security statement

This is defense-in-depth engineering, not a mathematical proof of security or literal unbreakability. Production deployment still requires environment-specific threat modeling, secret/key custody, dependency scanning, external penetration testing and operational controls.
