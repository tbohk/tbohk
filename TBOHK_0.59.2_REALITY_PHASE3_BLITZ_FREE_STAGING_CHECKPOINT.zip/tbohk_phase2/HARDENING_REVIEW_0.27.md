# TBOHK 0.27 Foundation Hardening Review

## Principle

TBOHK should be extremely difficult to corrupt silently. It should fail closed, preserve evidence of failure, and require explicit governed recovery rather than silently repairing itself.

## Changes in 0.27

- SQLite `foreign_keys=ON`, `busy_timeout>=5000`, `WAL`, `synchronous=FULL`, recursive triggers and trusted-schema hardening for file databases.
- Ledger opening no longer reconstructs missing ledger entries automatically. A missing chain entry is a forensic finding, not a repair opportunity.
- Core graph audit now fails closed if malformed persistent metadata causes an unexpected audit exception.
- Checkpoints refuse to be created from a graph that already fails the core audit unless the caller explicitly opts out with `require_clean=False` for controlled forensic work.
- Added non-destructive `SelfCareEngine` checks for SQLite integrity, foreign keys, DB configuration, core audit, G21-G30 assurance, latest checkpoint, and disk capacity.
- Added verified SQLite backup creation with integrity and foreign-key validation.
- Added CLI commands `selfcare` and `backup`.

## Remaining structural hardening

1. Formal invariant registry with release-blocking severity and dependency scope.
2. Explicit state-transition matrix so invalid status transitions cannot occur through low-level APIs.
3. External/independent ledger anchoring; the local database alone cannot be its own immutable trust root.
4. Independent verifier implementation outside the main Python runtime.
5. Threat-model and adversarial testing of the network/document ingestion boundary.
6. Production identity, key custody, isolation, backups and disaster-recovery exercises.
7. Human review and admission workflows before knowledge is promoted into durable application state.

## Non-goal

The system must never equate a passing self-care cycle with universal truth. Self-care establishes structural and operational health; epistemic correctness still depends on evidence, provenance, uncertainty, conflict, time and independent verification.
