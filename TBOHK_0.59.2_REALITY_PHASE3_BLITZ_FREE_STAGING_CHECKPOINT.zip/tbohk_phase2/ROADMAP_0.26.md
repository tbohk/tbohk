# TBOHK Roadmap — 0.26 Reality-to-App Plan

## Baseline

**Recovered baseline:** TBOHK Reality Build 0.25  
**Current validation:** 310 tests passing; compileall passing.  
**Purpose of this roadmap:** turn the hardened knowledge substrate into the usable application envisioned by the original BHK/TBOHK concept, without weakening the epistemic and governance boundaries already implemented.

## What is already real

### Knowledge substrate
- Nodes, typed relations, event/revision history, immutable-ish ledger chain.
- Evidence, claims, structured claims, verification, conflict sets, provenance and temporal validity.
- Research records with completeness metadata.
- Independence/origin analysis.
- Reasoning, inference, causal assessment, hypotheses, predictions and investigation state.
- Dependency impact analysis and re-evaluation workflows.
- Knowledge lifecycle, contamination/quarantine and recovery/reconstitution.

### Assurance substrate
- G0–G20 assurance layers.
- G21 immutable event/revision ledger.
- G22 portable checkpoints and migration proof.
- G23 key lifecycle/trust recovery.
- G24 deterministic replay/concurrency validation.
- G25 tool/supply-chain/credential boundaries.
- G26 uncertainty and temporal conflict handling.
- G27 research completeness/open-world coverage.
- G28 independent verifier/conformance boundary.
- G29 durable external actions and compensation boundary.
- G30 integrated red-team gate.
- Release aggregation and checkpoint integrity.

### Existing application surface
- FastAPI service.
- CLI for version/stats/audit.
- Basic browser home page.
- Explicit-URL research ingestion.
- Research planning, bounded autonomous research, knowledge overview, gaps, conflicts, synthesis, hypotheses, predictions, investigations, impact and re-evaluation APIs.

## The major gap

TBOHK is currently a **strong backend prototype with a thin operator interface**, not yet the full application.

The next phase is therefore not another arbitrary assurance gate. It is the **Reality-to-App layer**: make the existing architecture understandable and useful to a human while preserving its distinctions.

## Build sequence

### Phase A — App shell (0.26) — NOW
- Replace the proof-of-concept home page with a real operator console.
- Dashboard: health, graph size, evidence/claim/knowledge counts, open conflicts, gaps, assurance status.
- Research workspace: question, source URLs, plan, bounded research run, result trace.
- Knowledge workspace: search claims, inspect evidence, provenance, temporal state and explanations.
- Conflict/gap workspace: explicit unresolved items and drill-down.
- Investigation workspace: hypotheses, predictions, observations, state history and impact.
- Assurance workspace: audit, release audit, checkpoint status and current boundaries.
- Persistent activity feed using the existing event ledger.

### Phase B — Human knowledge workflows (0.27–0.28)
- Claim review queue.
- Evidence inspection and source snapshot viewer.
- Verify/reject/stale/re-evaluate workflows through governed transitions only.
- Conflict reconciliation workflow.
- Knowledge admission workflow: proposed -> evaluated -> verified/rejected.
- Decision/plan/action review with explicit authority grants.
- User/project/workspace identity model.

### Phase C — Real knowledge ingestion (0.29–0.30)
- File ingestion: PDF, HTML, Markdown, text, CSV and structured data.
- Source connectors with explicit provenance adapters.
- Search-provider abstraction; never collapse provider identity into source origin.
- Deduplication and content-addressed source snapshots.
- Incremental re-research and stale-source detection.
- Background jobs for long-running research/investigation.

### Phase D — Intelligence layer (0.31+)
- Optional LLM adapters as explicit, auditable Activities/Agents.
- Structured extraction with model/version/prompt/tool provenance.
- Semantic claim normalization and contradiction candidate generation.
- Retrieval/indexing/embeddings as acceleration only; provenance remains authoritative.
- Calibrated evaluation against fixed benchmark suites.
- Model/provider comparison without treating model consensus as truth.

### Phase E — Production boundary
- Multi-user authentication and authorization.
- Secrets/key custody outside the application database.
- PostgreSQL or equivalent production database plus migrations.
- Object storage for source artifacts.
- Queue/worker infrastructure.
- Observability and incident/audit export.
- Backup/restore and disaster recovery exercises.
- External security review and environment-specific threat model.

## Explicit gaps / missing features

1. **First-class user experience** — currently minimal.
2. **Knowledge graph visualization** — backend graph exists; interactive graph UI does not.
3. **Human review queues** — APIs exist for governed transitions, but no operator workflow.
4. **Document/file ingestion** — current public ingestion is URL-oriented.
5. **Broad search/retrieval** — no production search index or provider ecosystem.
6. **Model integration** — no first-class LLM adapter in the recovered baseline; deterministic reasoning is intentionally limited.
7. **Identity and multi-user workspaces** — not yet an application concern.
8. **Background execution** — long research is currently request/response oriented.
9. **Production persistence/migrations** — SQLite is suitable for the prototype, not the final multi-user deployment.
10. **Operational security** — prototype boundaries are strong, but production secrets, identity, isolation and deployment controls remain external work.
11. **Export/import UX** — checkpoint primitives exist; users need a simple save/restore experience.
12. **Knowledge authoring** — users need to create, edit, relate and review knowledge through governed interfaces.
13. **Source browser** — evidence should be inspectable at the exact locator/span that supports a claim.
14. **Temporal visualization** — the backend models time; the app needs timelines and stale-state explanations.
15. **Audit explainability** — findings need human-readable remediation paths.

## Non-goals for the next phase

- Do not remove provenance to make the UI simpler.
- Do not turn confidence into a fake probability-of-truth score.
- Do not silently resolve contradictions.
- Do not grant autonomy because a tool is technically callable.
- Do not let model-generated text become trusted knowledge without an admission/evaluation path.
- Do not claim that a clean audit means universal factual correctness.

## Definition of the envisioned app

A user should be able to:

1. Ask a question.
2. See what TBOHK already knows.
3. See what it does not know.
4. Launch or inspect research.
5. Inspect the evidence behind a claim.
6. See conflicting evidence instead of having it hidden.
7. See when knowledge became stale and why.
8. Compare hypotheses and predictions.
9. Understand how a conclusion was derived.
10. Approve or reject governed transitions.
11. Inspect what the system is authorized to do.
12. Observe what happened after an action.
13. Save a cryptographically/auditably identified checkpoint.
14. Restore or re-evaluate when the underlying world changes.

## Current milestone acceptance criteria

- [x] Recovered baseline runs cleanly.
- [x] 310 tests pass.
- [x] Current architecture documented.
- [x] Roadmap created.
- [x] Current-state animated architecture map created.
- [x] Operator console upgraded from proof-of-concept.
- [ ] Full human review workflow.
- [ ] File/document ingestion.
- [ ] Search-provider ecosystem.
- [ ] Multi-user identity/workspaces.
- [ ] Production deployment profile.

## Savepoint policy

Every meaningful build should produce:

- source archive;
- exact version;
- test result;
- compile result;
- roadmap state;
- architecture GIF;
- checkpoint manifest when a database is involved;
- SHA-256 hash of the distributable.

A savepoint is a **reproducible engineering state**, not a claim that TBOHK is finished or universally correct.
