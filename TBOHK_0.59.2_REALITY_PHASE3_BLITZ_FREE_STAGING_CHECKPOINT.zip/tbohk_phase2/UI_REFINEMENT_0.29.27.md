# TBOHK 0.29.27 — Public Web Corpus Learning

## Implemented
- Added bounded, resumable Common Crawl ingestion through `tbohk/web_corpus.py`.
- Added authenticated `POST /corpus/ingest` and `GET /corpus/status`.
- Added Learning Lab Web Corpus Learning controls.
- Imported pages are stored as source snapshots/evidence with provenance and untrusted-content boundaries.
- Corpus ingestion does not automatically verify claims or promote Knowledge. Existing epistemic policies remain the authority boundary.
- Batches are bounded (1–100 records) and resumable to support large-scale corpus processing without an unbounded request.
- Common Crawl is treated as a corpus source, not as a complete or infallible representation of the Internet.

## Operational note
The current execution environment cannot resolve external DNS, so a live Common Crawl fetch could not be completed here. The integration is covered by deterministic tests and uses the documented Common Crawl index/data endpoints.
