# TBOHK 0.59.2 — Blitz Free Staging

This checkpoint adds a no-credit-card blitz.cloud deployment target.

## Architecture

Single Blitz web app, HTTPS front end, persistent `/data`, TBOHK API and durable worker in
one process. This matches the current SQLite persistence model and avoids the Blitz limitation
that a managed database belongs to one app.

## Real-network objective

The hosted app is the first staging environment intended to execute TBOHK's existing public-URL
retrieval path outside the ChatGPT sandbox. A successful deployment is not itself evidence of
external retrieval; the follow-up staging smoke must prove DNS/HTTPS retrieval and evidence
persistence.

## Known limitation

Blitz free app files are not nightly backed up; only managed databases receive the platform's
nightly backups. TBOHK's own checkpoint/backup discipline therefore remains authoritative for
staging artifacts.
