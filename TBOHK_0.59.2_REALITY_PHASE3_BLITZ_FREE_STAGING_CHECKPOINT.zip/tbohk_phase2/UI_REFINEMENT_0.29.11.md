# TBOHK 0.29.11 — Library continuity pass

## Focus
Make saved investigations genuinely resumable without pretending that a local snapshot is the current server-authoritative evidence state.

## Changes
- Library/Home **Continue** now opens the saved investigation snapshot instead of immediately replacing the question with a follow-up prompt.
- The saved snapshot shows its saved headline, summary, verified/review/evidence counts, and the explicit **Saved on this device** boundary.
- Added **Rebuild current workspace** to retrieve the current account-scoped answer/evidence for the saved question.
- Added a separate **Follow up** action from the restored snapshot.
- Follow-up now clears stale workspace/answer panels before focusing the question field.

## Verification
- Python compilation: PASS
- JavaScript syntax: PASS
- UI acceptance tests: PASS
- Full regression suite: PASS
