# TBOHK UI Refinement 0.29.14

## Focus
Review queue usability and claim/conflict inspection.

## Changes
- Review queue now supports All / Claims / Conflicts filters.
- Proposed claims are presented as inspection cards with status, evidence count, evidence IDs, metadata, and explicit verification action.
- Conflict cards now show the participating claims and their statuses before resolution.
- Added a direct handoff from a proposed claim to related Knowledge search.
- Preserved the existing governed verification and conflict-resolution endpoints; no backend contract changes.
- Added review-specific styling for clearer evidence footprints and claim text.

## Verification
- JavaScript syntax check: PASS
- UI acceptance tests: 16 passed
- App-surface review tests: PASS
- Full regression suite: PASS (677 tests)
