# TBOHK UI Refinement 0.29.5

## Product-polish pass

Refined the highest-use user journey without changing backend contracts:

- Home: clearer product hierarchy, question-first composer, keyboard shortcut hint, trust signals, richer metric cards.
- Ask: explicit four-step workflow, stronger question composer, clearer transition from question to workspace/answer.
- Research: provenance-oriented source checklist, clearer URL guidance, stronger research framing.
- Answer: distinct evidence status, claim/evidence section hierarchy, source counts, review-required state, cleaner next-action and truth-boundary presentation.
- Review: queue summary metrics, explicit refresh control, clearer empty state, stronger governance framing.
- Plans: stable three-plan presentation, included-feature checklist styling, cached fallback catalog so the page is never blank when the pricing endpoint is temporarily unavailable.

## Interaction safeguards

- Existing navigation, authentication, billing, research, review, answer, and account handlers preserved.
- Existing URL sanitization and external-link hardening preserved.
- Existing keyboard shortcuts and storage-failure handling preserved.
- Responsive behavior retained at 320/360/390/412/768/1440px.

## Verification

- Python compile: PASS
- Full regression suite: 676 passed
- Chromium UI acceptance: PASS — 10 views × 6 viewport widths
- No backend contract changes in this pass
