# TBOHK 0.27 Readiness Matrix

## Verified in this build

- 317 automated tests pass.
- `compileall` passes.
- Clean in-memory graph passes ReleaseAuditor.
- Clean in-memory graph passes SelfCareEngine.
- SQLite integrity and foreign-key checks pass on clean databases.
- File-backed databases use WAL, full synchronous mode, foreign keys and busy timeout.
- Missing ledger entries are treated as forensic failures instead of being auto-rebuilt.
- Malformed persistent metadata causes a failed audit rather than an exception escaping as a false clean result.
- Normal checkpoint creation refuses structurally compromised state.
- Backups are independently opened and checked before being reported successful.
- Non-loopback CLI serving is refused without an API token.
- The architecture GIF now depicts the complete recovered path through assurance, self-care and application transition.

## Deliberately not called complete

### Trust root
The local SQLite ledger is tamper-evident but not an independent immutable trust root. A sufficiently privileged attacker who can rewrite the database can rewrite both data and local anchors. Signed external checkpoints or append-only external anchoring are still required.

### Independent verification
The current verifier machinery is structurally separated, but a genuinely independent implementation/runtime is still a future production requirement.

### Ingestion security
The URL fetcher has SSRF protections and size limits, but production ingestion needs a dedicated sandbox, DNS-rebinding-resistant transport, content-type policy, decompression limits, parser isolation and adversarial document testing.

### State transitions
The application has governed workflows for sensitive transitions, but the low-level graph API still exposes a general status mutation primitive. A formal transition matrix should become the canonical authorization layer.

### Production persistence
SQLite is excellent for the current auditable prototype and single-process/local deployment. Multi-user production requires a database migration system, transaction/locking design, backups, object storage and operational recovery procedures.

### Self-care
Self-care currently observes and backs up. It intentionally does not silently “heal” knowledge. Future repair automation must use proposal → independent validation → authorization → apply → observe → rollback/compensate.

## Release posture

A 0.27 release should be treated as a **hardened foundation checkpoint**, not as the final TBOHK product. The next development focus is the human knowledge workspace built on this foundation.
