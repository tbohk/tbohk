# TBOHK 0.28 Hardening Review

## Review questions

### Can the system detect silent structural corruption?
Improved substantially. Local ledger anchors, checkpoint verification, invariant checks, migration checks, state-transition auditing and recovery drills cover additional corruption classes.

### Can the system silently repair corruption during observation?
The design continues to reject silent repair. Audit and self-care are observational. Recovery remains explicit.

### Can the database prove its own integrity against a privileged attacker?
No. Local hashes and chains are tamper-evident, not an independent root of trust. This is why signed external anchors were added.

### Can a release trust only the primary auditor?
No. The independent validator remains a separate path, and a standalone verifier entry point is provided.

### Can schema changes be silently skipped?
The migration ledger is now monotonic and recorded. A non-contiguous history fails migration verification.

### Can arbitrary status mutation bypass the state policy?
The compatibility `set_status` primitive remains for legacy/internal fixtures. The canonical transition engine enforces the explicit matrix, and release/self-care audits inspect historical revisions for invalid transitions. The long-term production goal is to remove compatibility mutation from externally reachable paths.

### Can recovery certify its own repair?
The existing recovery lifecycle prohibits self-validation; the new drill adds an operational exercise around that principle.

## Remaining hard problems

1. independent/offline key custody
2. external transparency or append-only anchoring service
3. sandboxed document ingestion
4. production database and migrations at multi-user scale
5. identity and tenancy
6. queue/workers and idempotent jobs
7. artifact/object storage
8. auditable model adapters
9. formal parser fuzzing and adversarial corpus
10. external security review and penetration testing

## Release conclusion

0.28 is a meaningful structural hardening milestone. It is appropriate to begin application work while keeping the listed production trust gaps explicit and release-blocking for a high-assurance deployment.
