# TBOHK 0.29.20 — Workflow Learning & Smart Automation

## Focus
Add bounded workflow learning and improve smart next-action ordering without changing the authoritative evidence model.

## Changes
- Added local workflow preference memory for four explicit actions: review, research, save, and follow-up.
- Smart next actions are now ordered using recent workflow choices while preserving evidence-state eligibility and the existing three-action limit.
- Learning state is stored only in browser localStorage under `tbohk_workflow_preferences`.
- The UI explicitly explains that workflow history affects ordering only; evidence status determines availability.
- Added regression tests for local-only storage, bounded action classes, evidence gating, and explicit choice recording.

## Verification
- Python compilation: PASS
- JavaScript syntax: PASS
- Targeted tests: 20 passed
- Full regression: 685 passed
- No billing, authentication, provider, or evidence contracts changed.
