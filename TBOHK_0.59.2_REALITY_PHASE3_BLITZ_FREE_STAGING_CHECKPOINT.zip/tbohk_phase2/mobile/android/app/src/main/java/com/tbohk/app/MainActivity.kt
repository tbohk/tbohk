package com.tbohk.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private const val DEFAULT_BASE_URL = "https://tbohk.example"
private const val TOKEN_KEY = "session_token"

class SecureSessionStore(context: Context) {
    private val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(context, "tbohk_secure", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var token: String?
        get() = prefs.getString(TOKEN_KEY, null)
        set(value) { if (value == null) prefs.edit().remove(TOKEN_KEY).apply() else prefs.edit().putString(TOKEN_KEY, value).apply() }
}

data class ApiResult(val ok: Boolean, val body: String, val offline: Boolean = false)

class TbohkClient(private val baseUrl: String, private val store: SecureSessionStore) {
    suspend fun post(path: String, payload: JSONObject): ApiResult = withContext(Dispatchers.IO) {
        try {
            val c = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; doOutput = true; connectTimeout = 8000; readTimeout = 12000
                setRequestProperty("Content-Type", "application/json")
                store.token?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            c.outputStream.use { it.write(payload.toString().toByteArray()) }
            val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            ApiResult(c.responseCode in 200..299, text)
        } catch (_: Exception) { ApiResult(false, "Network unavailable. Your session remains stored securely; retry when connected.", true) }
    }
    suspend fun get(path: String): ApiResult = withContext(Dispatchers.IO) {
        try {
            val c = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 8000; readTimeout = 12000
                store.token?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            ApiResult(c.responseCode in 200..299, text)
        } catch (_: Exception) { ApiResult(false, "Network unavailable. Retry when connected.", true) }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SecureSessionStore(this)
        val base = intent?.data?.let { uri -> uri.getQueryParameter("base") } ?: DEFAULT_BASE_URL
        setContent { TbohkApp(TbohkClient(base, store), store, intent?.data) }
    }
}

@Composable
private fun TbohkApp(client: TbohkClient, store: SecureSessionStore, initialUri: Uri?) {
    var question by remember { mutableStateOf(initialUri?.getQueryParameter("q") ?: "") }
    var answer by remember { mutableStateOf("") }
    var researchUrl by remember { mutableStateOf("") }
    var research by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(if (store.token == null) "Sign in or create an account to begin." else "Signed in.") }
    var busy by remember { mutableStateOf(false) }
    var plan by remember { mutableStateOf("unknown") }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("TBOHK") }) }) { pad ->
            LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Ask → inspect → research → challenge → review", style = MaterialTheme.typography.titleMedium) }
                item {
                    OutlinedTextField(question, { question = it }, Modifier.fillMaxWidth().semantics { contentDescription = "Question" }, label = { Text("Question") }, minLines = 3)
                }
                item {
                    Button(enabled = question.isNotBlank() && !busy && store.token != null, onClick = {
                        scope.launch { busy = true; val r = client.get("/answer?q=" + Uri.encode(question)); answer = r.body; status = r.body; busy = false }
                    }, Modifier.fillMaxWidth().semantics { contentDescription = "Ask TBOHK" }) { Text(if (busy) "Working…" else "Ask TBOHK") }
                }
                item { if (answer.isNotBlank()) Card(Modifier.fillMaxWidth()) { Text(answer, Modifier.padding(16.dp)) } }
                item { HorizontalDivider() }
                item { Text("Research a public source", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(researchUrl, { researchUrl = it }, Modifier.fillMaxWidth(), label = { Text("https://… source URL") }) }
                item {
                    Button(enabled = researchUrl.startsWith("http://") || researchUrl.startsWith("https://"), onClick = {
                        scope.launch { busy = true; val r = client.post("/research", JSONObject().put("query", question.ifBlank { "source" }).put("urls", org.json.JSONArray().put(researchUrl))); research = r.body; status = if (r.ok) "Research complete." else r.body; busy = false }
                    }, Modifier.fillMaxWidth()) { Text("Research") }
                }
                item { if (research.isNotBlank()) Card(Modifier.fillMaxWidth()) { Text(research, Modifier.padding(16.dp)) } }
                item { HorizontalDivider() }
                item { Text("Account", style = MaterialTheme.typography.titleMedium) }
                item { OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }) }
                item { OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, visualTransformation = PasswordVisualTransformation()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { scope.launch { val r = client.post("/account/login", JSONObject().put("email", email).put("password", password)); if (r.ok) { store.token = JSONObject(r.body).optString("token"); status = "Signed in." } else status = r.body } }) { Text("Sign in") }
                        OutlinedButton(onClick = { scope.launch { val r = client.post("/account/register", JSONObject().put("email", email).put("password", password).put("name", email)); if (r.ok) { store.token = JSONObject(r.body).optString("token"); status = "Account created." } else status = r.body } }) { Text("Create") }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = store.token != null, onClick = { scope.launch { val r = client.get("/billing/entitlements"); plan = if (r.ok) JSONObject(r.body).optString("plan", "unknown") else "unknown" } }) { Text("Refresh plan") }
                        OutlinedButton(enabled = store.token != null, onClick = { scope.launch { client.post("/account/logout", JSONObject()); store.token = null; status = "Signed out." } }) { Text("Sign out") }
                    }
                }
                item { Text("Plan: $plan") }
                item { Text(status, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}
