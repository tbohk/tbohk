#if canImport(SwiftUI)
import SwiftUI
#if canImport(StoreKit)
import StoreKit
#endif

public struct TBOHKSessionStore {
    public init() {}
    // Production app: persist only an opaque server session token in Keychain.
    // This source shell intentionally avoids embedding credentials or provider secrets.
    public func saveToken(_ token: String) { _ = token }
}

@MainActor
public final class TBOHKModel: ObservableObject {
    @Published public var question = ""
    @Published public var answer = ""
    @Published public var status = "Ready"
    @Published public var plan = "unknown"
    @Published public var lastFreshAt: Date?
    @Published public var isLoading = false
    public init() {}

    public func ask(baseURL: URL) async {
        guard !question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        isLoading = true; defer { isLoading = false }
        var req = URLRequest(url: baseURL.appendingPathComponent("answer"))
        var parts = URLComponents(url: req.url!, resolvingAgainstBaseURL: false)!; parts.queryItems = [URLQueryItem(name: "q", value: question)]; req.url = parts.url
        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            answer = String(data: data, encoding: .utf8) ?? "No readable answer returned."
            lastFreshAt = Date(); status = "Answer refreshed from server."
        } catch { status = "Offline or unavailable. Retry when connected; no local claim is promoted to verified truth." }
    }
}

public struct TBOHKAppView: View {
    @StateObject private var model = TBOHKModel()
    @State private var showResearch = false
    private let baseURL = URL(string: "https://tbohk.example")!

    public init() {}
    public var body: some View {
        NavigationStack {
            Form {
                Section { Text("Ask, inspect, research, challenge, review.") }
                Section("Question") {
                    TextField("Question", text: $model.question, axis: .vertical)
                        .accessibilityLabel("Question")
                    Button(model.isLoading ? "Working…" : "Ask TBOHK") { Task { await model.ask(baseURL: baseURL) } }
                        .disabled(model.question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.isLoading)
                        .accessibilityHint("Requests an evidence-organized answer from the TBOHK server")
                }
                Section("Answer") {
                    Text(model.answer.isEmpty ? "No answer loaded." : model.answer)
                    Text(model.status).font(.footnote)
                }
                Section("Research") {
                    Button("Research this question") { showResearch = true }
                }
                Section("Subscription") {
                    Text("Entitlements are authoritative on the TBOHK server.")
                    Text("Current plan: \(model.plan)")
                }
                Section { Text("Answers preserve evidence, uncertainty, conflicts and source provenance.") }
            }
            .navigationTitle("TBOHK")
            .sheet(isPresented: $showResearch) { Text("Research workflow — server-authoritative source validation and citation provenance.").padding() }
        }
        .onOpenURL { url in
            if url.host == "ask", let q = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "q" })?.value { model.question = q }
        }
    }
}
#else
public struct TBOHKAppView { public init() {} }
#endif
