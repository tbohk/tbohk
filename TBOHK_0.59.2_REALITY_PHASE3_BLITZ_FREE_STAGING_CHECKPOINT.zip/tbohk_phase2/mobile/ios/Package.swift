// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "TBOHK", platforms: [.iOS(.v17)], products: [.library(name: "TBOHK", targets: ["TBOHK"])], targets: [.target(name: "TBOHK")])
