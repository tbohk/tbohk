# TBOHK native applications

The native clients are deliberately thin presentation clients. The server remains authoritative for authentication, account state, plan entitlements, usage limits, purchase verification, and knowledge provenance.

## Android
- Kotlin + Jetpack Compose.
- Android API 26+, target SDK 35.
- Session tokens are stored with Android Keystore-backed `EncryptedSharedPreferences`.
- `tbohk://ask?q=...` deep links open the question workflow.
- Network failures are surfaced without deleting the local session.
- Accessibility semantics are attached to primary controls.
- The client never decides a paid entitlement from client-supplied values.

## iOS
- SwiftUI, iOS 17+.
- Keychain-backed session storage.
- Universal-link/deep-link routing is represented by the URL router.
- StoreKit 2 purchase/restore calls feed server-side verification; the client never grants entitlement locally.
- Offline/degraded mode keeps the last safe UI state and clearly marks freshness.

Platform signing, store provisioning, TestFlight/closed-track installation, and production purchase verification require Apple/Google operator credentials and their respective store environments.

## Entitlement rule

The native clients may display locally cached subscription state for UX only. A purchase, restore, cancellation, grace period, refund, or expiration is not considered authoritative until the TBOHK server verifies it with the relevant provider and returns the normalized entitlement. Client-supplied plan names and purchase status are never trusted.
