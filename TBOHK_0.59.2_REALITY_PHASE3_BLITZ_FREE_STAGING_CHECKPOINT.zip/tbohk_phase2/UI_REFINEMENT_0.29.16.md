# TBOHK UI Refinement 0.29.16

## Focus
Navigation friction reduction across desktop and mobile.

## Changes
- Mobile navigation is now a single horizontally scrollable workspace/system rail instead of a multi-row grid.
- Navigation buttons keep their full labels and remain touch-sized.
- The active destination is automatically brought into view on mobile when navigation changes programmatically.
- Existing desktop sidebar behavior is unchanged.
- No backend, billing, authentication, knowledge, or evidence contracts changed.

## Verification
- JavaScript syntax: PASS
- UI acceptance: 16 passed
- Full regression: 677 passed
