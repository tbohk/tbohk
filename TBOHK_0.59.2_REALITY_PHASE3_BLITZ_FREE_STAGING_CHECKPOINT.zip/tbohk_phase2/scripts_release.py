"""Build a deterministic release archive for the current package version."""
from __future__ import annotations
import gzip, hashlib, re, shutil, subprocess, tarfile, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION_RE = re.compile(r'^version\s*=\s*["\']([^"\']+)["\']\s*$', re.MULTILINE)
VERSION = VERSION_RE.search((ROOT / 'pyproject.toml').read_text()).group(1)
OUT = Path('/mnt/data') / f'TBOHK_Reality_Build_{VERSION}.tar.gz'
EXCLUDE_DIRS = {'.git', '.pytest_cache', '__pycache__', '.mypy_cache', '.ruff_cache', '.hypothesis'}
EXCLUDE_SUFFIXES = {'.pyc', '.pyo'}


def check_version():
    pyproject = (ROOT / 'pyproject.toml').read_text()
    init = (ROOT / 'tbohk/__init__.py').read_text()
    if not re.search(rf'^version\s*=\s*["\']{re.escape(VERSION)}["\']\s*$', pyproject, re.MULTILINE):
        raise SystemExit('pyproject version mismatch')
    if not re.search(rf'^__version__\s*=\s*["\']{re.escape(VERSION)}["\']\s*$', init, re.MULTILINE):
        raise SystemExit('package version mismatch')


def build():
    check_version()
    subprocess.run(['python', '-m', 'pytest', '-q', '-W', 'error'], cwd=ROOT, check=True)
    subprocess.run(['python', '-m', 'compileall', '-q', 'tbohk', 'run_tbohk.py'], cwd=ROOT, check=True)
    with tempfile.TemporaryDirectory(prefix='tbohk_release_') as td:
        stage = Path(td) / f'tbohk_reality_{VERSION}'
        shutil.copytree(ROOT, stage, ignore=shutil.ignore_patterns(*EXCLUDE_DIRS, '*.pyc', '*.pyo', '.coverage'))
        leaked = [str(p.relative_to(stage)) for p in stage.rglob('*') if p.is_file() and (p.suffix in EXCLUDE_SUFFIXES or p.name in {'.coverage'})]
        if leaked:
            raise SystemExit('excluded artifact leaked into stage: ' + repr(leaked))
        if OUT.exists():
            OUT.unlink()
        def normalize(info):
            info.mtime = 0
            info.uid = 0; info.gid = 0
            info.uname = ''; info.gname = ''
            return info
        with OUT.open('wb') as raw:
            with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
                with tarfile.open(fileobj=gz, mode='w') as tf:
                    tf.add(stage, arcname=f'tbohk_reality_{VERSION}', filter=normalize)
    with tarfile.open(OUT, 'r:gz') as tf:
        names = tf.getnames()
        if any('/__pycache__/' in n or n.endswith(('.pyc', '.pyo')) for n in names):
            raise SystemExit('release archive contains bytecode/cache')
        required = [
            f'tbohk_reality_{VERSION}/pyproject.toml',
            f'tbohk_reality_{VERSION}/tbohk/core.py',
            f'tbohk_reality_{VERSION}/tbohk/investigation_state.py',
            f'tbohk_reality_{VERSION}/tbohk/selfcare.py',
            f'tbohk_reality_{VERSION}/tbohk/ui.html',
            f'tbohk_reality_{VERSION}/tbohk/impact.py',
            f'tbohk_reality_{VERSION}/tests/test_investigation_state.py',
            f'tbohk_reality_{VERSION}/tests/test_dependency_impact.py',
            f'tbohk_reality_{VERSION}/tbohk/reevaluation.py',
            f'tbohk_reality_{VERSION}/tests/test_reevaluation.py',
            f'tbohk_reality_{VERSION}/tests/test_reevaluation_workflow.py',
        ]
        missing = [n for n in required if n not in names]
        if missing:
            raise SystemExit('missing required files: ' + repr(missing))
        data = tf.extractfile(f'tbohk_reality_{VERSION}/pyproject.toml').read().decode()
        if not re.search(rf'^version\s*=\s*["\']{re.escape(VERSION)}["\']\s*$', data, re.MULTILINE):
            raise SystemExit('archive version mismatch')
    print(f'{OUT} {OUT.stat().st_size} bytes sha256={hashlib.sha256(OUT.read_bytes()).hexdigest()}')


if __name__ == '__main__':
    build()
