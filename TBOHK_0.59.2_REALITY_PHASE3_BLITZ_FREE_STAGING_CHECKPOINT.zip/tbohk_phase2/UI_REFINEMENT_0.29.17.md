# TBOHK UI Refinement 0.29.17

## Focus
Continuous cleanup and friction reduction: recovery, accessibility, keyboard flow, and modal behavior.

## Changes
- Added visible focus treatment for keyboard navigation and disabled-button feedback.
- Added ARIA hidden/current state management for views and active navigation.
- Added one-click Retry when answer assembly fails, plus direct Research fallback.
- Home question field submits with Enter.
- Ask question field submits with Ctrl/Cmd+Enter.
- Pricing modal now exposes dialog semantics and closes when its backdrop is tapped/clicked.
- Preserved existing workflow, evidence, billing, authentication, and backend contracts.

## Verification
- JavaScript syntax: PASS
- UI acceptance: 16 passed
- Full regression: 677 passed
