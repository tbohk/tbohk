from tbohk.cli import main

if __name__ == "__main__":
    raise SystemExit(main(["web"]))
