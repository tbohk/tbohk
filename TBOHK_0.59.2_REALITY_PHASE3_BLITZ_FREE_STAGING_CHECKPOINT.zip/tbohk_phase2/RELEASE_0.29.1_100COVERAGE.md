# TBOHK 0.29.1 hardened release

This is the final hardened single-machine bundle. The executable application is 100% statement-covered: 6,515/6,515 production executable statements, with 547 passing tests.

Deployment controls are included for secret-file authentication, non-loopback bind protection, direct TLS, systemd supervision, verified backups, restore verification, and periodic health checks.

Install the exact versions in `requirements.lock` in a clean Python 3.13 environment and rerun the complete suite before production exposure. The current development environment cannot install packages from the public package index, so the locked dependency set is deliberately treated as a cutover verification gate rather than falsely marked as locally reproduced.

The deployment identity is the SHA-256 of the final archive. Verify it before installation.
