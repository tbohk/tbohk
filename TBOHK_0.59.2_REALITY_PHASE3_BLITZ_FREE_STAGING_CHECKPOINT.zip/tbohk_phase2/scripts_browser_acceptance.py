#!/usr/bin/env python3
"""Chromium rendering/viewport acceptance for the TBOHK UI.

The execution sandbox blocks browser navigation to local/file URLs with
ERR_BLOCKED_BY_ADMINISTRATOR. This harness therefore renders the exact UI
HTML through Playwright.set_content(), which exercises Chromium layout,
CSS, DOM, view-state transitions, and screenshots. Live HTTP behavior is
validated separately by the HTTP smoke suite.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
HTML = (ROOT / "tbohk" / "ui.html").read_text()
VIEWS = ["home", "ask", "research", "knowledge", "investigation", "review", "assurance", "learning", "account", "pricing"]
WIDTHS = [320, 360, 390, 412, 768, 1440]


def main() -> None:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])
        for width in WIDTHS:
            page = browser.new_page(viewport={"width": width, "height": 844 if width < 1000 else 1000})
            # Avoid startup network/session behavior; HTTP smoke tests cover that boundary.
            page.set_content(HTML.replace("boot();\n</script>", "</script>"), wait_until="domcontentloaded")
            for view in VIEWS:
                page.evaluate(f"showView('{view}')")
                assert page.locator(f"#{view}").is_visible(), view
                
                sw=page.evaluate("document.documentElement.scrollWidth")
                if sw > width:
                    offenders=page.evaluate("Array.from(document.querySelectorAll('*')).map(e=>{const r=e.getBoundingClientRect();return {tag:e.tagName,id:e.id,cls:e.className,x:r.x,w:r.width,right:r.right,text:(e.innerText||'').slice(0,80)}}).filter(x=>x.right>window.innerWidth+1||x.x< -1).sort((a,b)=>b.right-a.right).slice(0,12)")
                    print('OVERFLOW',width,view,'scrollWidth',sw,'offenders',offenders)
                assert sw <= width, (width, view, sw)
            page.close()
        browser.close()
    print(f"Chromium UI acceptance PASS: {len(VIEWS)} views × {len(WIDTHS)} viewport widths")


if __name__ == "__main__":
    main()
