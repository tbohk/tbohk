from __future__ import annotations
import hashlib, sqlite3, sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 3:
        print('usage: tbohk_backup.py LIVE_DB DEST_DB', file=sys.stderr); return 2
    src = Path(sys.argv[1]).expanduser().resolve(); dst = Path(sys.argv[2]).expanduser().resolve()
    if not src.is_file() or src == dst:
        print('invalid source/destination', file=sys.stderr); return 2
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.unlink(missing_ok=True)
    db = sqlite3.connect(str(src)); out = sqlite3.connect(str(dst))
    try:
        db.backup(out); out.execute('PRAGMA integrity_check'); out.commit()
        integrity = out.execute('PRAGMA integrity_check').fetchone()[0]
        fk = out.execute('PRAGMA foreign_key_check').fetchall()
    finally:
        out.close(); db.close()
    if integrity != 'ok' or fk:
        print(f'backup verification failed integrity={integrity!r} fk={fk!r}', file=sys.stderr); return 3
    digest = hashlib.sha256(dst.read_bytes()).hexdigest()
    print(f'{dst}\nsha256={digest}\nintegrity=ok\nforeign_key_check=clean')
    return 0

if __name__ == '__main__': raise SystemExit(main())
