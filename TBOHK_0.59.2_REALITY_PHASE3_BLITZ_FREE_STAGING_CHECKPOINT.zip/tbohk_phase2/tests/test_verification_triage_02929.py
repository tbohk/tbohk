from tbohk.core import TBOHK
from tbohk.web_corpus import CorpusLearningEngine

def test_triage_orders_conflict_and_independence_needs():
    g=TBOHK(); c1=g.add_node('Claim','plain claim','proposed',{'evidence_ids':['e1']}); c2=g.add_node('Claim','conflicted claim','proposed',{'evidence_ids':['e2']})
    e1=g.add_node('Evidence','e1','supported',{'origin_id':'a','retrieved_at':'x'}); e2=g.add_node('Evidence','e2','supported',{'origin_id':'b','retrieved_at':'x'})
    g.link(e1.id,'evidence_for',c1.id); g.link(e2.id,'evidence_for',c2.id)
    t1=g.add_node('VerificationTask','t1','proposed',{'claim_id':c1.id,'evidence_ids':[e1.id],'independent_origins':['a']})
    t2=g.add_node('VerificationTask','t2','proposed',{'claim_id':c2.id,'evidence_ids':[e2.id],'independent_origins':['b']})
    g.link(c1.id,'contradicts',c2.id)
    out=CorpusLearningEngine(g).verification_triage()
    assert all(x['conflict_count']>=1 for x in out['items'][:2])
    assert out['items'][0]['priority']>=out['items'][1]['priority']
    assert out['not_a_truth_score'] is True

def test_feedback_is_persistent_and_bounded():
    g=TBOHK(); c=g.add_node('Claim','c','proposed',{}); t=g.add_node('VerificationTask','t','proposed',{'claim_id':c.id})
    eng=CorpusLearningEngine(g)
    for i in range(25): eng.record_verification_feedback(t.id,outcome='inconclusive',notes=str(i))
    md=g.get(t.id).metadata
    assert len(md['verification_feedback'])==20
    assert md['last_outcome']=='inconclusive'
