import hashlib
from pathlib import Path
import pytest
from tbohk.deployment import LocalSystemdAdapter, DeploymentManager, DeploymentError

class Runner:
    def __init__(self): self.calls=[]
    def __call__(self,args,**kwargs):
        self.calls.append(args)
        class R: returncode=0; stdout=''; stderr=''
        return R()

def test_deploy_verifies_artifact_and_uses_fixed_systemd(tmp_path):
    src=tmp_path/'artifact.zip'; src.write_bytes(b'hello')
    h=hashlib.sha256(b'hello').hexdigest(); r=Runner(); a=LocalSystemdAdapter(install_root=str(tmp_path/'releases'),runner=r)
    out=a.deploy('rel_1',str(src),h)
    assert out.verified and out.state=='deployed'; assert r.calls[-1]==['systemctl','restart','tbohk']

def test_deploy_rejects_hash_and_path(tmp_path):
    src=tmp_path/'a'; src.write_bytes(b'x'); a=LocalSystemdAdapter(install_root=str(tmp_path/'r'),runner=Runner())
    with pytest.raises(DeploymentError): a.deploy('rel',str(src),'0'*64)
    with pytest.raises(DeploymentError): a.deploy('../bad',str(src),hashlib.sha256(b'x').hexdigest())

def test_deploy_rejects_existing_release_and_unconfigured_manager(tmp_path):
    src=tmp_path/'a'; src.write_bytes(b'x'); r=Runner(); a=LocalSystemdAdapter(install_root=str(tmp_path/'r'),runner=r); h=hashlib.sha256(b'x').hexdigest(); a.deploy('rel',str(src),h)
    with pytest.raises(DeploymentError): a.deploy('rel',str(src),h)
    with pytest.raises(DeploymentError): DeploymentManager().deploy('systemd','r',str(src),h)

def test_health_and_rollback_without_previous(tmp_path):
    r=Runner(); a=LocalSystemdAdapter(install_root=str(tmp_path/'r'),runner=r)
    assert a.health()['healthy']
    with pytest.raises(DeploymentError): a.rollback('rel')

def test_api_deployment_route(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.deployment import DeploymentResult
    api.deployment_manager=DeploymentManager({'test': type('A',(),{'deploy':lambda self,*x: DeploymentResult('r','test','deployed','a'*64,True,False,'ok','now'),'rollback':lambda self,*x: DeploymentResult('r','test','rolled_back','',True,False,'ok','now'),'health':lambda self:{'healthy':True}})()})
    monkeypatch.setattr(api.release_control,'report',lambda rid:{'state':'completed'})
    monkeypatch.setattr(api.g,'update_metadata',lambda *a,**k: None)
    client=TestClient(api.app)
    h='a'*64
    resp=client.post('/release/r/deploy',json={'adapter':'test','artifact_path':'/tmp/a','artifact_sha256':h})
    assert resp.status_code==200
    assert client.get('/release/r/deployment-health?adapter=test').status_code==200
    assert client.post('/release/r/rollback?adapter=test').status_code==200
    monkeypatch.setattr(api.release_control,'report',lambda rid:{'state':'prepared'})
    assert client.post('/release/r/deploy',json={'adapter':'test','artifact_path':'/tmp/a','artifact_sha256':h}).status_code==400

def test_deployment_edge_paths(tmp_path):
    from tbohk.deployment import LocalSystemdAdapter, DeploymentManager, DeploymentError
    r=Runner()
    with pytest.raises(DeploymentError): LocalSystemdAdapter(service='bad space')
    a=LocalSystemdAdapter(install_root=str(tmp_path/'r'),runner=r)
    with pytest.raises(DeploymentError): a.deploy('r',str(tmp_path/'missing'),'a'*64)
    src=tmp_path/'a'; src.write_bytes(b'x'); h=hashlib.sha256(b'x').hexdigest()
    with pytest.raises(DeploymentError): a.deploy('r',str(src),'short')
    # Cover failed service health and rollback from a verified previous release.
    class BadRunner:
        def __call__(self,args,**kwargs):
            if args[:3]==['systemctl','is-active','--quiet']: raise RuntimeError('down')
            return Runner() (args,**kwargs)
    bad=LocalSystemdAdapter(install_root=str(tmp_path/'bad'),runner=BadRunner())
    assert bad.health()['healthy'] is False
    first=a.deploy('r1',str(src),h); second=a.deploy('r2',str(src),h)
    assert second.rollback_available
    rb=a.rollback('r2'); assert rb.state=='rolled_back'
    with pytest.raises(DeploymentError): DeploymentManager().rollback('x','r')
    with pytest.raises(DeploymentError): DeploymentManager().health('x')

def test_installed_artifact_verification_failure(monkeypatch,tmp_path):
    src=tmp_path/'a'; src.write_bytes(b'x'); h=hashlib.sha256(b'x').hexdigest(); r=Runner(); a=LocalSystemdAdapter(install_root=str(tmp_path/'r'),runner=r)
    import tbohk.deployment as d
    original=d.sha256_file
    calls=[0]
    def fake(path):
        calls[0]+=1
        return h if calls[0]==1 else '0'*64
    monkeypatch.setattr(d,'sha256_file',fake)
    with pytest.raises(DeploymentError): a.deploy('r',str(src),h)
    monkeypatch.setattr(d,'sha256_file',original)

def test_new_api_error_branches(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    client=TestClient(api.app)
    assert client.get('/observability').status_code==200
    assert client.get('/observability/recent?limit=0').status_code==400
    assert client.post('/answer/citations/verify',json=['missing']).status_code==200
    class Bad:
        def rollback(self,*a): raise api.DeploymentError('rollback bad')
        def health(self): raise api.DeploymentError('health bad')
        def deploy(self,*a): raise api.DeploymentError('deploy bad')
    api.deployment_manager=DeploymentManager({'bad':Bad()})
    monkeypatch.setattr(api.release_control,'report',lambda rid:{'state':'completed'})
    assert client.post('/release/r/rollback?adapter=bad').status_code==400
    assert client.get('/release/r/deployment-health?adapter=bad').status_code==400
    monkeypatch.setattr(api,'citation_status',lambda *a: (_ for _ in ()).throw(ValueError('bad citation')))
    assert client.post('/answer/citations/verify',json=['x']).status_code==400
