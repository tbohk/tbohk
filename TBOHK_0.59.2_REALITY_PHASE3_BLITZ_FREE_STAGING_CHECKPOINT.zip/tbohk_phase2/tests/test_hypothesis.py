from tbohk.core import TBOHK
from tbohk.hypothesis import HypothesisEngine
from tbohk.intelligence import KnowledgeIntelligence

def test_hypothesis_is_not_truth():
    g=TBOHK(':memory:'); h=HypothesisEngine(g).create('A explains B', predictions=['B occurs when A occurs'])
    assert h.status=='proposed'
    assert g.get(h.id).metadata['requires_independent_evaluation'] is True

def test_competing_hypotheses_share_and_discriminate_evidence():
    g=TBOHK(':memory:'); e1=g.add_node('Evidence','source one','supported',{}); e2=g.add_node('Evidence','source two','supported',{})
    eng=HypothesisEngine(g)
    a=eng.create('A explains B',[e1.id],['B follows A'],['intervention test'])
    b=eng.create('C explains B',[e1.id,e2.id],['B follows C'],['confounder test'])
    c=eng.compare([a.id,b.id])
    assert c.shared_evidence==(e1.id,)
    assert c.discriminating_evidence==(e2.id,)

def test_deterministic_alternative_generation_is_bounded():
    g=TBOHK(':memory:'); hs=HypothesisEngine(g).generate_alternatives('why did result change?', ['result changed'], 4)
    assert len(hs)==4
    assert all(h.status=='proposed' for h in hs)

def test_intelligence_synthesis_exposes_causal_boundary():
    g=TBOHK(':memory:'); k=KnowledgeIntelligence(g); c=g.add_node('Claim','A causes B','proposed',{})
    out=k.synthesize('')
    assert out['causal_assessments']
    assert out['causal_assessments'][0]['relation']=='causal'
