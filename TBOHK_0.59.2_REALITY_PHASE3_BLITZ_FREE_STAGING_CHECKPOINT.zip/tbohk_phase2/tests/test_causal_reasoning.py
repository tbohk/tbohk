from tbohk.core import TBOHK
from tbohk.causal import CausalReasoner
from tbohk.synthesis import EvidenceSynthesizer

def c(g,s): return g.add_node('Claim',s,'proposed')

def test_causal_claim_is_not_proven_by_wording():
    g=TBOHK(':memory:'); r=CausalReasoner(g); n=c(g,'Exercise causes lower blood pressure')
    a=r.assess(n.id)
    assert a.relation=='causal' and a.evidence_level=='not_established'
    assert a.blockers

def test_correlation_is_not_causation():
    g=TBOHK(':memory:'); r=CausalReasoner(g); n=c(g,'Exercise correlates with lower blood pressure')
    a=r.assess(n.id)
    assert a.relation=='correlational' and 'correlation does not establish causation' in a.blockers

def test_temporal_precedence_not_causation():
    g=TBOHK(':memory:'); r=CausalReasoner(g); n=c(g,'Policy A happened before outcome B')
    a=r.assess(n.id)
    assert a.relation=='temporal_precedence' and a.temporal_precedence

def test_dependency_requires_semantic_review():
    g=TBOHK(':memory:'); r=CausalReasoner(g); n=c(g,'System operation depends on network access')
    a=r.assess(n.id)
    assert a.relation=='dependency' and a.evidence_level=='dependency_assertion'

def test_unknown_relation_is_indeterminate():
    g=TBOHK(':memory:'); r=CausalReasoner(g); n=c(g,'The system contains three modules')
    assert r.assess(n.id).relation=='indeterminate'

def test_structured_causal_support_can_upgrade_candidate():
    g=TBOHK(':memory:'); r=CausalReasoner(g)
    n=g.add_node('Claim','Treatment causes improvement','proposed',{'structured':{'causal_support':{'mechanism':True,'intervention':True}}})
    a=r.assess(n.id)
    assert a.evidence_level=='supported_candidate' and not a.blockers

def test_causal_vs_correlation_scope():
    g=TBOHK(':memory:'); r=CausalReasoner(g)
    a=c(g,'Exercise causes lower blood pressure'); b=c(g,'Exercise correlates with lower blood pressure')
    assert r.compare(a.id,b.id)['relationship']=='causal_vs_associational_scope'

def test_synthesis_exposes_causal_assessment():
    g=TBOHK(':memory:'); s=EvidenceSynthesizer(g); n=c(g,'Rain causes flooding')
    out=s.synthesize([n.id])
    assert out['causal_assessments'][0]['relation']=='causal'
