from tbohk.selftest import SelfTestEngine
from tbohk.repair_plan import RepairPlanner
def test_selftest_passes_and_is_deterministically_digestable():
    e=SelfTestEngine(); e.register("x","integrity",lambda:True); e.register("y","performance",lambda:True)
    r=e.run(); assert r.passed_all and r.run_digest and r.total==2
def test_selftest_failure_becomes_bounded_repair_signal():
    e=SelfTestEngine(); e.register("broken","integrity",lambda:False); r=e.run()
    assert r.failed==1 and r.repairs[0].severity=="critical"
    p=RepairPlanner().plan(r.repairs); assert p[0].bounded and p[0].reversible and p[0].action=="recheck"
