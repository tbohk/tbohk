import json
import pytest

from tbohk import TBOHK


def _rule(g, rid="r"):
    meta = {"rule_type":"x", "name":"x", "schema":{}, "authority":"a"}
    meta["rule_sha256"] = g._hash(json.dumps(meta, sort_keys=True))
    return g.add_node("ReasoningRule", rid, "supported", meta)


def _activity(g, aid, premise_ids, conclusion_id, **meta):
    m = {"method":"inductive", "premise_ids":list(premise_ids), "premise_roles":{}, "conclusion_id":conclusion_id}
    m.update(meta)
    a = g.add_node("ReasoningActivity", aid, "supported", m)
    for p in premise_ids:
        g.link(a.id, "uses", p)
    g.link(a.id, "derives", conclusion_id)
    g.link(a.id, "produces", conclusion_id)
    g.link(a.id, "generated_by", conclusion_id)
    return a


def test_inference_private_graph_traversals_cover_all_paths():
    from tbohk.inference import InferenceEvaluator
    g = TBOHK(); ev = InferenceEvaluator(g)
    p = g.add_node("Claim", "p", "supported")
    q = g.add_node("Claim", "q", "supported")
    c = g.add_node("Claim", "c", "supported")
    a1 = _activity(g, "a1", [p.id], q.id)
    a2 = _activity(g, "a2", [q.id], c.id)
    # Ancestor traversal follows claim provenance edges and ignores non-claims.
    g.link(q.id, "derived_from", c.id); g.link(p.id, "derived_from", q.id)
    noise = g.add_node("Evidence", "noise")
    g.link(a1.id, "uses", noise.id)
    assert ev._ancestors(c.id) >= {c.id, q.id, p.id}
    g.link(a2.id, "uses", c.id)
    # Exercise cycle's false paths and the direct cycle detection path.
    assert ev._cycle(a2.id, c.id) is True
    g2 = TBOHK(); ev2 = InferenceEvaluator(g2)
    p2 = g2.add_node("Claim", "p", "supported"); c2 = g2.add_node("Claim", "c", "supported")
    a = _activity(g2, "a", [p2.id], c2.id)
    assert ev2._cycle(a.id, "other") is False
    # A parent activity creates a deeper traversal without being the current activity.
    parent = _activity(g2, "parent", [p2.id], c2.id)
    assert ev2._cycle(a.id, "other") is False
    # Non-activity competing producers are ignored.
    g2.add_node("Evidence", "not activity")
    assert ev2._competing(c2.id, a.id) == (parent.id,)
    g.close(); g2.close()


def test_inference_method_aliases_roles_missing_assumptions_defeaters_and_rule_paths():
    from tbohk.inference import InferenceEvaluator
    g = TBOHK(); ev = InferenceEvaluator(g)
    p = g.add_node("Claim", "p", "supported")
    c = g.add_node("Claim", "c", "supported", {"structured":{"scope":"s"}})
    # Executable legacy method alias exercises effective-method normalization.
    a = _activity(g, "alias", [p.id], c.id, method="modus_ponens", premise_roles={})
    r = _rule(g); g.update_metadata(a.id, {"rule_id":r.id}, replace=False)
    assert ev.assess(a.id).verdict == "warranted"
    # Use a clean graph so competing derivations do not mask conditional verdicts.
    g3 = TBOHK(); ev3 = InferenceEvaluator(g3); p3 = g3.add_node("Claim", "p", "supported"); c3 = g3.add_node("Claim", "c", "supported", {"structured":{"scope":"s"}})
    bad = _activity(g3, "bad", [p3.id], c3.id, method="defeasible", premise_roles={"x":"necessary"},
                     assumption_ids=["missing-a"], defeater_ids=["missing-d"])
    assert ev3.assess(bad.id).verdict == "conditionally_warranted"
    cf = _activity(g3, "cf", [p3.id], c3.id, method="counterfactual", counterfactual={})
    assert ev3.assess(cf.id).verdict == "invalid"
    missing_rule = _activity(g3, "missing-rule", [p3.id], c3.id, method="deductive",
                             premise_roles={p3.id:"necessary"}, rule_id="missing")
    assert ev3.assess(missing_rule.id).verdict == "invalid"
    g.close(); g3.close()


def test_evidence_evaluator_exception_and_conflict_branches():
    from tbohk.evaluation import EvidenceEvaluator
    g = TBOHK(); ee = EvidenceEvaluator(g)
    ev = g.add_node("Evidence", "e", "supported", {"locator":{"type":"document"}, "polarity":"bogus"})
    # No snapshot/provenance and a forced independence failure.
    class Broken:
        def analyze_evidence(self, ids): raise RuntimeError("broken")
    ee.independence = Broken()
    a = ee.assess(ev.id, as_of="not-a-date")
    assert a.dimension_results["source_integrity"] == "insufficient"
    assert a.dimension_results["independence"] == "unknown"
    assert a.dimension_results["polarity"] == "insufficient"
    assert a.dimension_results["corroboration"] == "not_applicable"
    # Conflict exposure branch.
    conflict = g.add_node("ConflictSet", "conflict", "supported")
    g.link(conflict.id, "contains", ev.id)
    ee.independence = Broken()
    assert ee.assess(ev.id).dimension_results["conflict_exposure"] == "conflicted_context"
    g.close()


def test_claim_evaluator_all_warrant_and_temporal_conflict_paths():
    from tbohk.evaluation import ClaimEvaluator
    g = TBOHK(); ce = ClaimEvaluator(g)
    claim = g.add_node("Claim", "claim", "proposed", {"structured":{"time":"2026"}})
    vals = ["refutes", "entails", "supports", "correlates", "unassessed"]
    evidence = []
    for i, rel in enumerate(vals):
        ev = g.add_node("Evidence", f"e{i}", "supported", {"claim_relation":rel, "source_id":f"s{i}", "origin_id":f"o{i}", "extraction_method":"x", "locator":{"type":"text_quote"}})
        g.link(ev.id, "evidence_for", claim.id); evidence.append(ev)
    # Mixed relations exercise the final insufficient/warning paths.
    a = ce.assess(claim.id, evidence_relations={e.id:"unassessed" for e in evidence})
    assert a.dimensions["evidence_warrant"] == "insufficient"
    # Temporal misalignment and conflict exception branches.
    original = g.db
    class BrokenDB:
        def execute(self, *args, **kwargs): raise RuntimeError("db")
    g.db = BrokenDB()
    with pytest.raises(Exception):
        ce.assess(claim.id, evidence_relations={evidence[0].id:"supports", evidence[1].id:"supports", evidence[2].id:"supports", evidence[3].id:"supports", evidence[4].id:"supports"})
    g.db = original
    g.close()


def test_claim_synthesizer_uncertainty_and_disposition_fallbacks():
    from tbohk.evaluation import ClaimEvaluator, ClaimSynthesizer
    g = TBOHK(); e = ClaimEvaluator(g); s = ClaimSynthesizer(g)
    claim = g.add_node("Claim", "c", "proposed", {"structured":{"uncertainty":{"kind":"claim"}}})
    ev = g.add_node("Evidence", "e", "supported", {"claim_relation":"supports", "uncertainty":{"lower":1,"upper":2,"unit":"C"}})
    g.link(ev.id, "evidence_for", claim.id)
    a = e.assess(claim.id)
    assert s.synthesize(claim.id, a).disposition == "supported"
    # Unit mismatch falls through interval aggregation to no uncertainty, then claim uncertainty.
    ev2 = g.add_node("Evidence", "e2", "supported", {"claim_relation":"supports", "uncertainty":{"lower":3,"upper":4,"unit":"F"}})
    assert s._uncertainty_from_evidence([ev, ev2]) is None
    # Bad numeric values exercise conversion exception paths.
    assert s._uncertainty_from_evidence([g.add_node("Evidence","bad",metadata={"uncertainty":{"lower":"x","upper":"y","value":"z","confidence_level":"q"}})]) is None
    g.close()


def test_investigation_remaining_ranking_and_prediction_filter_paths():
    from tbohk.investigation import AdaptiveInvestigator
    g = TBOHK(); inv = AdaptiveInvestigator(g)
    h1 = g.add_node("Hypothesis", "h1"); h2 = g.add_node("Hypothesis", "h2"); h3 = g.add_node("Hypothesis", "h3")
    p_shared = g.add_node("Prediction", "same", metadata={"discriminator":True})
    p_other = g.add_node("Prediction", "same")
    non_prediction = g.add_node("Claim", "not prediction")
    g.link(h1.id, "predicts", p_shared.id); g.link(h2.id, "predicts", p_shared.id); g.link(h3.id, "predicts", p_other.id)
    g.link(h1.id, "predicts", non_prediction.id)
    ranked = inv.rank_targets([h1.id, h2.id, h3.id])
    assert ranked[0].discrimination_potential == "medium"
    g.close()


def test_workspace_remaining_assessment_conflict_and_action_branches(monkeypatch):
    import tbohk.workspace as wsmod
    from tbohk.workspace import QuestionWorkspace
    g = TBOHK(); w = QuestionWorkspace(g)
    claim = g.add_node("Claim", "alpha answer", "verified")
    class Assessment:
        evidence_ids = ("e1",)
        independent_evidence_count = 2
        limitations = ("limitation",)
    monkeypatch.setattr(wsmod.ClaimEvaluator, "assess", lambda self, cid: Assessment())
    monkeypatch.setattr(w.intelligence, "conflicts", lambda: [{"conflict_id":"cx"}])
    a = w.assess("alpha")
    assert a.supported_claims == (claim.id,)
    assert a.conflicts == ("cx",)
    # An exception during assessment produces an unresolved claim and failure limitation.
    monkeypatch.setattr(wsmod.ClaimEvaluator, "assess", lambda self, cid: (_ for _ in ()).throw(RuntimeError("x")))
    b = w.assess("alpha")
    assert claim.id in b.unresolved_claims and any("RuntimeError" in x for x in b.limitations)
    # Conflict action is covered by the open workflow; no-evidence action is covered with no candidates.
    monkeypatch.setattr(w.intelligence, "plan_research", lambda q: {})
    monkeypatch.setattr(w.intelligence, "gaps", lambda q: [])
    monkeypatch.setattr(w.intelligence, "conflicts", lambda: [])
    empty = w.open("no-match")
    assert "research unresolved claims" in empty.next_actions
    g.close()


def test_repair_remaining_validation_and_learning_feedback_paths(monkeypatch):
    import tbohk.repair as rmod
    from tbohk.repair import SelfRepairController
    g = TBOHK(); c = SelfRepairController(g); target = g.add_node("Claim", "target")
    cand = c.propose(target.id, "repair", expected_effect="effect", risk="high")
    class Result:
        def __init__(self, passed): self.passed = passed
    monkeypatch.setattr(rmod.IndependentSystemValidator, "run", lambda self: Result(False))
    monkeypatch.setattr(rmod.DeepAssurance, "run", lambda self: Result(False))
    v = c.validate(cand, checks={"ok": lambda: True})
    assert not v.passed and "independent_validation" in v.failures and "deep_assurance" in v.failures
    # Learning-backed repair classification path.
    eval_id = g.add_node("Evaluation", "evaluation").id
    feedback = c.propose_from_feedback(target.id, "feedback", [eval_id], expected_effect="effect")
    assert feedback.risk == "medium"
    g.close()


def test_reconstitution_remaining_integrity_and_apply_rollback_paths():
    from tbohk.reconstitution import ReconstitutionEngine, RecoverySnapshot, RecoveryLifecycleAuditor
    g = TBOHK(); engine = ReconstitutionEngine(g)
    with pytest.raises(ValueError): engine.export_snapshot("missing")
    node = {"id":"n1","kind":"Claim","status":"supported","content":"x","metadata":json.dumps({"content_sha256":"bad"}),"created_at":"2026-01-01T00:00:00+00:00"}
    edge = {"source_id":"n1","relation":"supports","target_id":"missing","created_at":"2026-01-01T00:00:00+00:00"}
    snap0 = RecoverySnapshot("cp", engine._digest([node],[edge]), (node,), (edge,), "2026-01-01T00:00:00+00:00")
    plan = engine.plan(snap0, exclude_ids=("absent",))
    assert any(f.code == "excluded_node_missing_from_snapshot" for f in plan.findings)
    assert any(f.code == "node_content_hash_mismatch" for f in plan.findings)
    # A clean snapshot with an excluded dependency produces a dependency finding.
    dep = {"id":"dep","kind":"Claim","status":"supported","content":"d","metadata":json.dumps({"content_sha256":g._hash("d"),"dependency_ids":[]}),"created_at":"2026-01-01T00:00:00+00:00"}
    child = {"id":"child","kind":"Claim","status":"supported","content":"c","metadata":json.dumps({"content_sha256":g._hash("c"),"dependency_ids":["dep"]}),"created_at":"2026-01-01T00:00:00+00:00"}
    clean = RecoverySnapshot("cp", engine._digest([dep,child],[]), (dep,child), (), "2026-01-01T00:00:00+00:00")
    p = engine.plan(clean, exclude_ids=("dep",))
    assert any(f.code == "recovered_node_has_missing_dependency" for f in p.findings)
    # Force apply rollback after BEGIN by making the target execute fail.
    good = engine.plan(clean)
    class BrokenDB:
        def __init__(self, real): self.real=real; self.calls=0
        def execute(self, sql, *args):
            self.calls += 1
            if sql.startswith("INSERT INTO nodes") and self.calls > 1: raise RuntimeError("insert failure")
            return self.real.execute(sql,*args)
    target = TBOHK(); real = target.db; target.db = BrokenDB(real)
    with pytest.raises(RuntimeError): engine.apply(good, clean, target_graph=target)
    target.db = real
    # Recovery lifecycle malformed/verified-without-validation/rollback findings.
    rp = g.add_node("RecoveryProposal", "rp", "verified", metadata={})
    badmeta = g.add_node("RecoveryProposal", "bad", "proposed", metadata={"x":1})
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", ("{bad", badmeta.id)); g.db.commit()
    findings = RecoveryLifecycleAuditor(g).audit()
    codes = {f.code for f in findings}
    assert "malformed_recovery_proposal" in codes and "recovery_without_independent_validation" in codes and "verified_recovery_without_rollback" in codes
    g.close(); target.close()


def test_workspace_knowledge_skip_unresolved_conflict_and_clean_re_evaluation_actions(monkeypatch):
    import tbohk.workspace as wsmod
    from tbohk.workspace import QuestionWorkspace
    g = TBOHK(); w = QuestionWorkspace(g)
    knowledge = g.add_node("Knowledge", "alpha knowledge", "supported")
    claim = g.add_node("Claim", "alpha claim", "proposed")
    class Assessment:
        evidence_ids = ("e",)
        independent_evidence_count = 1
        limitations = ()
    monkeypatch.setattr(wsmod.ClaimEvaluator, "assess", lambda self, cid: Assessment())
    monkeypatch.setattr(w, "_claims_for_question", lambda q: [knowledge, claim])
    monkeypatch.setattr(w.intelligence, "conflicts", lambda: [{"id":"cx"}])
    assessed = w.assess("alpha")
    assert claim.id in assessed.unresolved_claims and knowledge.id not in assessed.claim_ids
    opened = w.open("alpha")
    assert "review conflicting claims" in opened.next_actions
    # Clean, fully supported answer with evidence and no conflicts reaches the final action.
    claim2 = g.add_node("Claim", "beta claim", "verified")
    monkeypatch.setattr(w, "_claims_for_question", lambda q: [claim2])
    monkeypatch.setattr(w.intelligence, "conflicts", lambda: [])
    clean = w.open("beta")
    assert clean.next_actions == ("re-evaluate the answer against current evidence",)
    g.close()


def test_local_assurance_script_success_and_failure_branches(monkeypatch, tmp_path):
    import scripts_assurance as sa
    from types import SimpleNamespace
    calls = []
    monkeypatch.setattr(sa, "run", lambda *args: (calls.append(args) or (0, "415 passed", "")))
    monkeypatch.chdir(tmp_path)
    assert sa.main() == 0
    import tbohk; assert (tmp_path / f'ASSURANCE_LOCAL_{tbohk.__version__}.json').exists()
    monkeypatch.setattr(sa, "run", lambda *args: (1, "bad", "err"))
    assert sa.main() == 1
    state = {"n":0}
    def compile_fail(*args):
        state["n"] += 1
        return (0, "tests", "") if state["n"] == 1 else (1, "compile", "bad")
    monkeypatch.setattr(sa, "run", compile_fail)
    assert sa.main() == 1


def test_release_script_build_success_and_version_guard(monkeypatch):
    import scripts_release as sr
    class Result: returncode = 0
    monkeypatch.setattr(sr.subprocess, "run", lambda *args, **kwargs: Result())
    old_version = sr.VERSION
    try:
        sr.VERSION = "0.0.0"
        with pytest.raises(SystemExit): sr.check_version()
    finally:
        sr.VERSION = old_version
    sr.build()
    assert sr.OUT.exists() and sr.OUT.stat().st_size > 0


def test_assurance_run_wrapper_is_measured(monkeypatch):
    import scripts_assurance as sa
    class P: returncode=0; stdout="ok"; stderr=""
    monkeypatch.setattr(sa.subprocess, "run", lambda *a, **k: P())
    assert sa.run("x")[0] == 0


def test_release_script_failure_guards_and_main_entrypoint(monkeypatch, tmp_path):
    import runpy
    import types
    import scripts_release as sr
    class Result: returncode = 0
    monkeypatch.setattr(sr.subprocess, "run", lambda *args, **kwargs: Result())
    original_version = sr.VERSION
    try:
        sr.VERSION = original_version
        real_read = sr.Path.read_text
        def mismatch_read(self, *a, **k):
            text = real_read(self, *a, **k)
            if self.name == "__init__.py": return text.replace(sr.VERSION, "0.0.0", 1)
            return text
        monkeypatch.setattr(sr.Path, "read_text", mismatch_read)
        with pytest.raises(SystemExit, match="package version mismatch"): sr.check_version()
    finally:
        sr.VERSION = original_version
        monkeypatch.setattr(sr.Path, "read_text", real_read)

    # Build-stage leak guard.
    monkeypatch.setattr(sr.subprocess, "run", lambda *args, **kwargs: Result())
    real_copy = sr.shutil.copytree
    def leaking_copy(src, dst, *args, **kw):
        real_copy(src, dst, *args, **kw)
        (sr.Path(dst) / "leak.pyc").write_bytes(b"x")
    monkeypatch.setattr(sr.shutil, "copytree", leaking_copy)
    with pytest.raises(SystemExit, match="excluded artifact leaked"):
        sr.build()
    monkeypatch.setattr(sr.shutil, "copytree", real_copy)

    # Read-side archive guards are tested with a wrapper that delegates writes.
    class FakeTar:
        def __init__(self, mode): self.mode=mode
        def __enter__(self): return self
        def __exit__(self,*a): return False
        def getnames(self): return [f"tbohk_reality_{sr.VERSION}/__pycache__/x.pyc"]
        def extractfile(self, name): return types.SimpleNamespace(read=lambda: b"version = \"%s\"\n" % sr.VERSION.encode())
    real_open = sr.tarfile.open
    def read_guard_open(*args, **kwargs):
        if kwargs.get("mode") == "r:gz": return FakeTar("r:gz")
        if len(args) >= 2 and args[1] == "r:gz": return FakeTar("r:gz")
        return real_open(*args, **kwargs)
    monkeypatch.setattr(sr.tarfile, "open", read_guard_open)
    with pytest.raises(SystemExit, match="release archive contains bytecode/cache"):
        sr.build()
    monkeypatch.setattr(sr.tarfile, "open", real_open)

    # Missing required-file guard and archive-version guard.
    real_open = sr.tarfile.open
    class MissingTar(FakeTar):
        def getnames(self): return []
    monkeypatch.setattr(sr.tarfile, "open", lambda *a, **k: MissingTar("r:gz") if (k.get("mode")=="r:gz" or (len(a)>=2 and a[1]=="r:gz")) else real_open(*a,**k))
    with pytest.raises(SystemExit, match="missing required files"):
        sr.build()
    monkeypatch.setattr(sr.tarfile, "open", real_open)

    class BadVersionTar(FakeTar):
        def getnames(self): return [f"tbohk_reality_{sr.VERSION}/pyproject.toml"] + [f"tbohk_reality_{sr.VERSION}/tbohk/core.py", f"tbohk_reality_{sr.VERSION}/tbohk/investigation_state.py", f"tbohk_reality_{sr.VERSION}/tbohk/selfcare.py", f"tbohk_reality_{sr.VERSION}/tbohk/ui.html", f"tbohk_reality_{sr.VERSION}/tbohk/impact.py", f"tbohk_reality_{sr.VERSION}/tests/test_investigation_state.py", f"tbohk_reality_{sr.VERSION}/tests/test_dependency_impact.py", f"tbohk_reality_{sr.VERSION}/tbohk/reevaluation.py", f"tbohk_reality_{sr.VERSION}/tests/test_reevaluation.py", f"tbohk_reality_{sr.VERSION}/tests/test_reevaluation_workflow.py"]
        def extractfile(self, name): return types.SimpleNamespace(read=lambda: b'version = "0.0.0"\n')
    monkeypatch.setattr(sr.tarfile, "open", lambda *a, **k: BadVersionTar("r:gz") if (k.get("mode")=="r:gz" or (len(a)>=2 and a[1]=="r:gz")) else real_open(*a,**k))
    with pytest.raises(SystemExit, match="archive version mismatch"):
        sr.build()
    monkeypatch.setattr(sr.tarfile, "open", real_open)

    # Main-entry branch is executed with the external commands stubbed.
    monkeypatch.setattr(sr.subprocess, "run", lambda *args, **kwargs: Result())
    runpy.run_path(sr.__file__, run_name="__main__")


def test_release_output_absent_branch(monkeypatch, tmp_path):
    import scripts_release as sr
    class Result: returncode = 0
    monkeypatch.setattr(sr.subprocess, "run", lambda *args, **kwargs: Result())
    old = sr.OUT
    sr.OUT = tmp_path / "brand_new_release.tar.gz"
    try:
        sr.build()
        assert sr.OUT.exists()
    finally:
        sr.OUT = old


def test_entrypoint_run_tbohk_delegates_to_cli(monkeypatch):
    import runpy
    import tbohk.cli
    calls=[]
    monkeypatch.setattr(tbohk.cli, 'main', lambda argv: calls.append(argv) or 0)
    try:
        runpy.run_path('run_tbohk.py', run_name='__main__')
    except SystemExit as exc:
        assert exc.code == 0
    assert calls == [['web']]


def test_complexity_reexport_surface():
    import tbohk.complexity as m
    from tbohk.resource_safety import ReasoningResourceGuard, ComplexityBudget, ComplexityReport
    assert m.ReasoningResourceGuard is ReasoningResourceGuard
    assert m.ComplexityBudget is ComplexityBudget
    assert m.ComplexityReport is ComplexityReport


def test_adaptive_controller_validation_and_failure_paths(tmp_path, monkeypatch):
    from tbohk.core import TBOHK
    from tbohk.adaptive import AdaptiveResearchController
    from tbohk.hypothesis import HypothesisEngine
    from tbohk.prediction import PredictiveReasoner
    from tbohk.research import MockProvider, SourceDocument
    g=TBOHK(str(tmp_path/'adaptive_edges.db'))
    c=AdaptiveResearchController(g)
    for kwargs in ({'question':'','hypothesis_ids':[],'providers':[]}, {'question':'q','hypothesis_ids':[],'providers':[]}, {'question':'q','hypothesis_ids':[],'providers':[object()],'max_cycles':0}, {'question':'q','hypothesis_ids':[],'providers':[object()],'max_targets':0}):
        try: c.run(**kwargs)
        except ValueError: pass
        else: assert False
    h=HypothesisEngine(g); a=h.create('A explains'); p=PredictiveReasoner(g); p.create_prediction(a.id,'A predicts red',discriminator=True)
    class Broken:
        provider_id='broken'
        def search(self, query): raise RuntimeError('boom')
    import tbohk.adaptive as adaptive_module
    class RaisingChain:
        def __init__(self, *args): pass
        def run(self, *args): raise RuntimeError('boom')
    monkeypatch.setattr(adaptive_module, 'ResearchChain', RaisingChain)
    out=c.run('q',[a.id],[Broken()],max_cycles=1)
    assert out.stop_reason == 'research_cycle_failed'
    assert out.cycles[0].status == 'failed'
    assert out.cycles[0].evidence_count == 0


def test_adaptive_controller_no_target_and_diminishing_value(tmp_path, monkeypatch):
    from tbohk.core import TBOHK
    from tbohk.adaptive import AdaptiveResearchController
    from tbohk.hypothesis import HypothesisEngine
    from tbohk.prediction import PredictiveReasoner
    from tbohk.research import MockProvider, SourceDocument
    from tbohk.adaptive_learning import LearningSnapshot
    g=TBOHK(str(tmp_path/'adaptive_stop.db')); h=HypothesisEngine(g); a=h.create('A explains'); p=PredictiveReasoner(g); p.create_prediction(a.id,'A predicts red',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    c=AdaptiveResearchController(g)
    monkeypatch.setattr(c.investigator, 'rank_targets', lambda ids: [])
    out=c.run('q',[a.id],[provider],max_cycles=1)
    assert out.stop_reason == 'no_unresolved_informative_target'
    g2=TBOHK(str(tmp_path/'adaptive_dim.db')); h2=HypothesisEngine(g2); a2=h2.create('A explains'); b2=h2.create('B explains'); p2=PredictiveReasoner(g2); p2.create_prediction(a2.id,'A predicts red',discriminator=True); p2.create_prediction(b2.id,'B predicts blue',discriminator=True)
    c2=AdaptiveResearchController(g2)
    monkeypatch.setattr(c2.learning, 'update', lambda *args: LearningSnapshot(1, 0, 0, 0, 0, 0, 1, True, ('forced',)))
    out2=c2.run('q',[a2.id,b2.id],[provider],max_cycles=1,max_targets=2)
    assert out2.stop_reason == 'diminishing_information_value'


def test_evaluation_remaining_dispositions_and_failure_boundaries(tmp_path, monkeypatch):
    from tbohk.core import TBOHK
    from tbohk.evaluation import ClaimEvaluator, ClaimSynthesizer, ClaimAssessment
    g=TBOHK(str(tmp_path/'eval_edges.db')); ce=ClaimEvaluator(g); cs=ClaimSynthesizer(g)
    with pytest.raises(ValueError): ce.assess('missing')
    c=g.add_node('Claim','claim','supported',{'structured':{}})
    # Force the conflict query failure branch.
    real_db=g.db
    class FailingDB:
        def execute(self,*args,**kwargs):
            if 'SELECT DISTINCT source_id FROM edges' in args[0]: raise RuntimeError('db')
            return real_db.execute(*args,**kwargs)
    ev=g.add_node('Evidence','different',metadata={'polarity':'neutral'})
    g.link(ev.id,'evidence_for',c.id)
    monkeypatch.setattr(g,'db',FailingDB())
    a=ce.assess(c.id,as_of='not-a-time')
    assert a.dimensions['conflict_status']=='unknown'
    monkeypatch.setattr(g,'db',real_db)
    # Exercise every synthesis disposition using explicit assessments.
    for warrant, expected in [('entailed','entailed'),('supported_not_entailed','supported'),('correlation_only','indeterminate'),('insufficient','unsupported')]:
        a=ClaimAssessment(c.id,{}, {'evidence_warrant':warrant,'scope_alignment':'unknown','temporal_alignment':'unknown','uncertainty_propagation':'not_stated','reproducibility':'insufficient','conflict_status':'unknown'},(), '2026-01-01T00:00:00+00:00')
        if warrant=='correlation_only':
            a=ClaimAssessment(c.id,{ev.id:'supports'},dict(a.dimensions),(),a.assessed_at)
        elif warrant=='entailed':
            a=ClaimAssessment(c.id,{ev.id:'entails'},dict(a.dimensions),(),a.assessed_at)
        elif warrant=='supported_not_entailed':
            a=ClaimAssessment(c.id,{ev.id:'supports'},dict(a.dimensions),(),a.assessed_at)
        out=cs.synthesize(c.id,a)
        assert out.disposition==expected
    ref=ClaimAssessment(c.id,{ev.id:'refutes'}, {'evidence_warrant':'refuted','scope_alignment':'unknown','temporal_alignment':'unknown','uncertainty_propagation':'not_stated','reproducibility':'insufficient','conflict_status':'unknown'},(), '2026-01-01T00:00:00+00:00')
    assert cs.synthesize(c.id,ref).disposition=='refuted'
    contested=ClaimAssessment(c.id,{ev.id:'supports','y':'refutes'}, {'evidence_warrant':'supported_not_entailed','scope_alignment':'unknown','temporal_alignment':'unknown','uncertainty_propagation':'not_stated','reproducibility':'insufficient','conflict_status':'unknown'},(), '2026-01-01T00:00:00+00:00')
    assert cs.synthesize(c.id,contested).disposition=='contested'
    structured=g.add_node('Claim','structured','supported',{'structured':{'uncertainty':{'kind':'interval'}}})
    aa=ClaimAssessment(structured.id,{}, {'evidence_warrant':'insufficient','scope_alignment':'unknown','temporal_alignment':'unknown','uncertainty_propagation':'not_stated','reproducibility':'insufficient','conflict_status':'unknown'},(), '2026-01-01T00:00:00+00:00')
    assert cs.synthesize(structured.id,aa).uncertainty=={'kind':'interval'}
    assert cs._uncertainty_from_evidence([g.add_node('Evidence','x',metadata={'uncertainty':{'confidence_level':0.5}})])['type']=='confidence_observations'


def test_impact_scoping_and_reverse_paths(tmp_path):
    from tbohk.core import TBOHK
    from tbohk.impact import DependencyImpactAnalyzer
    g=TBOHK(str(tmp_path/'impact_scope.db'))
    h=g.add_node('Hypothesis','h','proposed'); run=g.add_node('AdaptiveResearchRun','run','supported',{'hypothesis_ids':[h.id],'question':'q'})
    cycle=g.add_node('AdaptiveResearchCycle','cycle','supported',{'cycle':1,'evidence_ids':[]}); g.link(run.id,'contains',cycle.id)
    e=g.add_node('Evidence','e','supported',{'origin_id':'missing'})
    c=g.add_node('Claim','c','supported'); g.link(e.id,'evidence_for',c.id)
    # Valid in-scope evidence plus downstream claim.
    o=g.add_node('Origin','o','supported'); ev=g.add_node('Evidence','ev','supported',{'origin_id':o.id}); cycle.metadata['evidence_ids']=[ev.id]; g.update_metadata(cycle.id,{'evidence_ids':[ev.id]})
    g.link(ev.id,'evidence_for',c.id)
    report=DependencyImpactAnalyzer(g).analyze_investigation(run.id,[ev.id])
    assert c.id in {x.node_id for x in report.items}
    # Root outside scope is skipped, while ordinary analysis still works.
    outside=g.add_node('Evidence','outside','supported',{'origin_id':o.id})
    scoped=DependencyImpactAnalyzer(g).analyze([outside.id],run_id=run.id)
    assert scoped.items==()


def test_independent_validator_remaining_authority_reality_and_checkpoint_paths(tmp_path):
    from tbohk.core import TBOHK
    from tbohk.independent_validation import IndependentSystemValidator
    import json, hashlib
    g=TBOHK(str(tmp_path/'independent_edges.db'))
    # Activity/generated-by provenance defects.
    a=g.add_node('Activity','a','supported',{'attributed_to':'missing'})
    x=g.add_node('Run','x','supported'); g.link(x.id,'generated_by',g.add_node('Claim','notactivity').id)
    # Action branches: no authority, missing capability, then scope mismatch.
    act=g.add_node('Action','a1','verified',{'target':'unsafe'})
    grant=g.add_node('AuthorityGrant','g','verified',{'capabilities':[],'scope':'safe'})
    g.update_metadata(act.id,{'authority_grant_id':grant.id},replace=False)
    # External observation defects and malformed timestamps.
    g.add_node('Observation','obs','supported',{'external':True,'source':'s','observed_at':'bad','retrieved_at':'bad'})
    g.add_node('Observation','obs2','supported',{'external':True})
    pav=g.add_node('PostActionVerification','pav','supported',{'action_id':'missing','observation_id':'missing','verified':True,'expected_effect':'a','actual_effect':'b'})
    # Corrupt checkpoint JSON is represented directly in SQLite to exercise parser recovery.
    g.add_node('Checkpoint','bad','supported',{})
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=(SELECT id FROM nodes WHERE kind='Checkpoint' ORDER BY rowid DESC LIMIT 1)",(json.dumps({'manifest':{},'manifest_sha256':'bad','public_attestation':{}}),)); g.db.commit()
    codes={f.code for f in IndependentSystemValidator(g).run().findings}
    assert 'activity_without_agent' in codes and 'generated_by_non_activity' in codes
    assert 'authority_without_execute_capability' in codes
    assert 'observation_time_malformed' in codes and 'external_observation_missing_provenance' in codes
    assert 'post_action_verification_missing_observation' in codes and 'forged_post_action_verification' in codes
    assert 'checkpoint_manifest_mismatch' in codes and 'malformed_public_attestation' in codes


def test_investigation_state_remaining_matrix(tmp_path):
    from datetime import datetime, timezone
    from tbohk.core import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine, InvestigationState, InvestigationStateDelta
    g=TBOHK(str(tmp_path/'state_matrix.db')); e=InvestigationStateEngine(g)
    with pytest.raises(ValueError): e.build('missing')
    run=g.add_node('AdaptiveResearchRun','run','supported',{'question':'q','hypothesis_ids':[]})
    with pytest.raises(ValueError): e.build(run.id,through_cycle=-1)
    with pytest.raises(ValueError): e.build(run.id,as_of='bad')
    st=e.build(run.id,as_of=datetime(2026,1,1,tzinfo=timezone.utc)); assert st.as_of.startswith('2026-01-01')
    h=g.add_node('Hypothesis','h','proposed'); o1=g.add_node('Origin','o1','supported'); o2=g.add_node('Origin','o2','supported')
    ev1=g.add_node('Evidence','ev1','supported',{'origin_id':o1.id}); ev2=g.add_node('Evidence','ev2','supported',{'origin_id':o2.id})
    cycle=g.add_node('AdaptiveResearchCycle','c','supported',{'cycle':1,'evidence_ids':[ev1.id,ev2.id],'target_prediction_id':'pred'}); g.link(run.id,'contains',cycle.id)
    g.link(o2.id,'depends_on',o1.id); g.link(h.id,'evidence_for',ev1.id); g.link(ev2.id,'contradicts',h.id)
    conflict=g.add_node('ConflictSet','conf','proposed'); g.link(conflict.id,'contains',h.id)
    learning=g.add_node('AdaptiveLearningState','l','supported',{'rationale':['learned']}); g.link(cycle.id,'evaluates',learning.id)
    # Evidence snapshot makes ev1 fresh and ev2 stale.
    s1=g.add_node('SourceSnapshot','s1','supported',{'valid_from':'2020-01-01','valid_until':'2030-01-01'}); g.link(ev1.id,'derived_from',s1.id)
    s2=g.add_node('SourceSnapshot','s2','supported',{'valid_from':'2000-01-01','valid_until':'2001-01-01'}); g.link(ev2.id,'derived_from',s2.id)
    built=e.build(run.id,[h.id],as_of='2026-01-01T00:00:00+00:00')
    assert o2.id in built.dependent_origins and ev1.id in built.supporting_evidence and ev2.id in built.contradicting_evidence
    assert conflict.id in built.unresolved_conflicts and ev2.id in built.stale_evidence and 'pred' in built.unresolved_targets
    assert built.stopping_reason=='learned'
    sid=e.record(run.id,built)
    with pytest.raises(ValueError): e.record(run.id,built,previous_state_id='missing')
    with pytest.raises(ValueError): e.delta('missing',None,sid)
    bad=e.delta(run.id,None,sid)
    bad=InvestigationStateDelta(bad.run_id,bad.from_state_id,'missing',bad.from_revision,bad.to_revision,bad.changed_fields,bad.added,bad.removed,bad.candidate_drivers,bad.new_evidence_ids,bad.temporal_horizon_changed)
    with pytest.raises(ValueError): e.record_delta(run.id,bad)


def test_api_remaining_exception_and_protected_status_boundaries(monkeypatch):
    from fastapi.testclient import TestClient
    import tbohk.api as api
    from dataclasses import dataclass
    client=TestClient(api.app, raise_server_exceptions=False)
    g=api.g
    protected=g.add_node('Claim','protected','proposed')
    # Protected workflow transition is forbidden; malformed ordinary transition is 400.
    assert client.post(f'/nodes/{protected.id}/status',json={'status':'verified'}).status_code==403
    monkeypatch.setattr(api.g,'set_status',lambda *a,**k: (_ for _ in ()).throw(ValueError('bad status')))
    ordinary=g.add_node('Note','ordinary','proposed')
    assert client.post(f'/nodes/{ordinary.id}/status',json={'status':'supported'}).status_code==400
    monkeypatch.setattr(api.g,'set_status',api.TBOHK.set_status.__get__(g,api.TBOHK))
    # Each endpoint's exception boundary is independently exercised.
    monkeypatch.setattr(api.service,'node',lambda *a: (_ for _ in ()).throw(KeyError('x')))
    assert client.get('/nodes/missing').status_code==404
    monkeypatch.setattr(api.service,'search_nodes',lambda *a: (_ for _ in ()).throw(RuntimeError('x')))
    assert client.get('/nodes').status_code==500
    class Boom:
        def run(self,*a,**k): raise RuntimeError('boom')
    monkeypatch.setattr(api,'ResearchChain',Boom)
    assert client.post('/research',json={'query':'q','urls':['https://example.test']}).status_code==400
    monkeypatch.setattr(api.intelligence,'plan_research',lambda *a: (_ for _ in ()).throw(RuntimeError('boom')))
    assert client.post('/research/plan',json={'question':'q'}).status_code==400
    monkeypatch.setattr(api,'QuestionWorkspace',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('boom')))
    assert client.post('/workspace',json={'question':'q'}).status_code==400
    monkeypatch.setattr(api,'AssurancePipeline',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('boom')))
    assert client.post('/assurance/pipeline').status_code==500
    monkeypatch.setattr(api,'SelfRepairController',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('boom')))
    assert client.post('/repairs',json={'target_id':'x','description':'d','expected_effect':'e'}).status_code==400
    monkeypatch.setattr(api,'InvestigationStateEngine',lambda *a,**k: type('E',(),{'history':lambda *a: (_ for _ in ()).throw(ValueError('bad')),'delta':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad')),'build':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad'))})())
    assert client.get('/investigation/x/state').status_code==400
    assert client.get('/investigation/x/history').status_code==400
    assert client.get('/investigation/x/delta').status_code==400
    monkeypatch.setattr(api,'DependencyImpactAnalyzer',lambda *a,**k: type('I',(),{'analyze_investigation':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad')),'analyze':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad'))})())
    assert client.get('/investigation/x/impact',params={'roots':'x'}).status_code==400
    assert client.get('/impact',params={'roots':'x'}).status_code==400
    monkeypatch.setattr(api,'ReEvaluationController',lambda *a,**k: type('R',(),{'create':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad')),'get':lambda *a,**k: (_ for _ in ()).throw(ValueError('bad'))})())
    assert client.post('/reevaluation-queue',params={'roots':'x'}).status_code==400
    assert client.get('/reevaluation-queue/x').status_code==400
    monkeypatch.setattr(api.intelligence,'run_bounded',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('bad')))
    assert client.post('/autonomous-run',json={'question':'q','urls':['https://example.test']}).status_code==400
