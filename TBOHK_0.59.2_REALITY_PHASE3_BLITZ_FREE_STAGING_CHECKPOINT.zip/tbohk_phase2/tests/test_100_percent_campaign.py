import pytest
from tbohk import TBOHK


def test_governance_all_decision_and_authorization_branches():
    from tbohk.governance import GovernanceEngine
    g=TBOHK(); gov=GovernanceEngine(g)
    with pytest.raises(ValueError): gov.approve_grant('missing', approver='x')
    grant=gov.grant('principal',['b','a'],scope='*',approver='approver')
    with pytest.raises(PermissionError): gov.approve_grant(grant.id,approver='wrong')
    grant2=gov.grant('same',['x'],approver='same')
    with pytest.raises(PermissionError): gov.approve_grant(grant2.id,approver='same')
    gov.approve_grant(grant.id,approver='approver')
    p=gov.propose_change('change','code',['x'],proposer='alice')
    bad=gov.evaluate_change(p.id,benchmark_passed=False,metamorphic_passed=False,mutation_passed=False)
    assert not bad.allowed and len(bad.reasons)==3
    with pytest.raises(PermissionError): gov.authorize(p.id,assessment_id='missing')
    ok=gov.evaluate_change(p.id)
    other=gov.propose_change('other','code',[],proposer='bob')
    with pytest.raises(PermissionError): gov.authorize(other.id,assessment_id=next(x['source_id'] for x in g.edges(ok.proposal_id,'in','evaluates')) if False else 'missing')
    aid=g.add_node('GovernanceAssessment','wrong','supported',{'proposal_id':p.id,'allowed':True,'assessor':'alice'})
    g.link(aid.id,'evaluates',p.id)
    with pytest.raises(PermissionError): gov.authorize(p.id,assessment_id=aid.id)
    assert gov.authorize(p.id,assessment_id=__import__('tbohk.governance',fromlist=['GovernanceEngine']) and next(n.id for n in [g.get(r['source_id']) for r in g.edges(p.id,'in','evaluates')] if n and n.kind=='GovernanceAssessment' and n.metadata.get('allowed') and n.metadata.get('assessor')=='independent'))


def test_repair_validation_all_check_outcomes():
    from tbohk.repair import SelfRepairController
    g=TBOHK(); c=SelfRepairController(g); target=g.add_node('Claim','target')
    with pytest.raises(ValueError): c.propose('', 'd', expected_effect='e')
    with pytest.raises(KeyError): c.propose('missing','d',expected_effect='e')
    with pytest.raises(ValueError): c.propose(target.id,'d',expected_effect='e',risk='bad')
    cand=c.propose(target.id,'d',expected_effect='e',risk='low')
    with pytest.raises(KeyError): c.validate(__import__('tbohk.repair',fromlist=['RepairCandidate']).RepairCandidate('missing',target.id,'d','e','low'))
    v=c.validate(cand,checks={'ok':lambda: True,'false':lambda: False,'raises':lambda: (_ for _ in ()).throw(RuntimeError('x'))})
    assert not v.passed and 'ok' in v.checks and any(x.startswith('raises:') for x in v.failures)
    assert c.as_dict(cand)['target_id']==target.id


def test_research_provider_success_empty_failure_and_identity():
    from tbohk.research import ResearchChain, MockProvider, SourceDocument
    g=TBOHK()
    doc=SourceDocument('s','Title','https://x','Water freezes at 0 C.','good','2026-01-01T00:00:00+00:00','origin')
    class Bad:
        provider_id='bad'
        def search(self,q): raise RuntimeError('boom')
    providers=[MockProvider('good',[doc]),MockProvider('empty',[]),Bad()]
    r=ResearchChain(g,providers).run('water')
    assert len(r['results'])==1 and r['research_record']['result_counts']['empty']==0 and len(r['research_record']['failures'])==2
    bad_doc=SourceDocument('s2','Title','https://x','text','wrong','2026-01-01T00:00:00+00:00','o')
    with pytest.raises(ValueError): ResearchChain(g,[MockProvider('good',[bad_doc])]).run('text')
    bad_origin=SourceDocument('s3','Title','https://x','text','good','2026-01-01T00:00:00+00:00','')
    with pytest.raises(ValueError): ResearchChain(g,[MockProvider('good',[bad_origin])]).run('text')


def test_workspace_empty_supported_unresolved_conflict_paths():
    from tbohk.workspace import QuestionWorkspace
    g=TBOHK(); w=QuestionWorkspace(g)
    with pytest.raises(ValueError): w.assess('   ')
    empty=w.open('unmatched question'); assert 'research unresolved claims' in empty.next_actions
    c1=g.add_node('Claim','answer alpha','supported'); c2=g.add_node('Claim','answer beta','proposed')
    ws=w.open('answer')
    assert c1.id in ws.assessment.unresolved_claims or c1.id in ws.assessment.supported_claims
    assert isinstance(w.as_dict(ws),dict)


def test_investigation_all_ranking_branches():
    from tbohk.investigation import AdaptiveInvestigator
    g=TBOHK(); inv=AdaptiveInvestigator(g)
    with pytest.raises(ValueError): inv.rank_targets([])
    with pytest.raises(ValueError): inv.rank_targets(['missing'])
    h1=g.add_node('Hypothesis','h1'); h2=g.add_node('Hypothesis','h2')
    p1=g.add_node('Prediction','unique discriminator',metadata={'discriminator':True})
    p2=g.add_node('Prediction','shared',metadata={'discriminator':False})
    p3=g.add_node('Prediction','unique',metadata={'discriminator':False})
    g.link(h1.id,'predicts',p1.id); g.link(h1.id,'predicts',p2.id); g.link(h2.id,'predicts',p2.id); g.link(h2.id,'predicts',p3.id)
    ev=g.add_node('Observation','obs'); g.link(p1.id,'evaluated_by',ev.id)
    ranked=inv.rank_targets([h1.id,h2.id]); assert {x.prediction_id for x in ranked}=={p1.id,p2.id,p3.id}
    assert any(x.assessed for x in ranked) and any(x.discriminator for x in ranked)
    with pytest.raises(ValueError): inv.plan([h1.id],0)
    assert len(inv.plan([h1.id],1).targets)==1


def test_inference_invalid_insufficient_conditional_contested_and_warranted():
    from tbohk.inference import InferenceEvaluator
    g=TBOHK(); ev=InferenceEvaluator(g)
    with pytest.raises(ValueError): ev.assess('missing')
    # valid warranted semantic record
    premise=g.add_node('Claim','premise','supported')
    rule_payload={'rule_type':'x','name':'x','schema':{},'authority':'a'}
    rule_payload['rule_sha256']=g._hash(__import__('json').dumps({k:v for k,v in rule_payload.items()},sort_keys=True))
    rule=g.add_node('ReasoningRule','rule','supported',rule_payload)
    a=g.add_node('ReasoningActivity','a','supported',{'method':'deductive','premise_ids':[premise.id],'premise_roles':{'p':'necessary'},'rule_id':rule.id,'conclusion_id':None})
    c=g.add_node('Claim','conclusion','supported',{'structured':{'scope':'x','uncertainty':0.1}}); g.update_metadata(a.id,{'conclusion_id':c.id}); g.link(a.id,'uses',premise.id); g.link(a.id,'derives',c.id); g.link(a.id,'produces',c.id); g.link(c.id,'generated_by',a.id)
    assert ev.assess(a.id,as_of='2025-01-01').verdict=='warranted'
    # competing derivation
    a2=g.add_node('ReasoningActivity','a2','supported',{'method':'inductive','premise_ids':[premise.id],'premise_roles':{},'conclusion_id':c.id}); g.link(a2.id,'derives',c.id); g.link(a2.id,'produces',c.id)
    assert ev.assess(a.id).verdict=='contested'
    # conditional on an otherwise uncontested conclusion
    ccond=g.add_node('Claim','conditional','supported',{'structured':{'scope':'x','uncertainty':0.1}})
    ass=g.add_node('Assumption','ass'); a3=g.add_node('ReasoningActivity','a3','supported',{'method':'inductive','premise_ids':[premise.id],'premise_roles':{},'assumption_ids':[ass.id],'conclusion_id':ccond.id}); g.link(a3.id,'uses',premise.id); g.link(a3.id,'derives',ccond.id); g.link(a3.id,'produces',ccond.id)
    assert ev.assess(a3.id).verdict=='conditionally_warranted'
    # insufficient
    a4=g.add_node('ReasoningActivity','a4','supported',{'method':'inductive','premise_ids':['missing'],'premise_roles':{},'conclusion_id':c.id})
    assert ev.assess(a4.id).verdict=='insufficient'
    # invalid method and counterfactual missing intervention
    a5=g.add_node('ReasoningActivity','a5','supported',{'method':'counterfactual','premise_ids':[premise.id],'premise_roles':{},'counterfactual':{},'conclusion_id':c.id})
    assert ev.assess(a5.id).verdict=='invalid'

def test_epistemic_validation_and_conflict_resolution_matrix():
    from tbohk.epistemic import EpistemicEngine, VerificationPolicy
    g=TBOHK(); e=EpistemicEngine(g,{'default':VerificationPolicy('default',min_independent_origins=1,require_locator=True,allow_automatic=True),'strict':VerificationPolicy('strict',min_independent_origins=1,require_locator=True,allow_automatic=False)})
    with pytest.raises(KeyError): e.propose_claim('x',[],policy_id='missing')
    with pytest.raises(ValueError): e.propose_claim('x',[],modality='bad')
    with pytest.raises(ValueError): e.propose_claim('x',[],uncertainty=1)
    with pytest.raises(ValueError): e.propose_claim('x',[],uncertainty={'bad':1})
    with pytest.raises(ValueError): e.propose_claim('x',[],uncertainty={'confidence_level':2})
    with pytest.raises(ValueError): e.propose_claim('x',[],uncertainty={'lower':2,'upper':1})
    with pytest.raises(ValueError): e.propose_claim('x',['missing'])
    c=e.propose_claim('x',[]); c2=e.propose_claim('y',[])
    with pytest.raises(ValueError): e.contradict('missing',c.id)
    with pytest.raises(ValueError): e.contradict(c.id,c.id)
    conflict=e.contradict(c.id,c2.id)
    with pytest.raises(ValueError): e.resolve_conflict(conflict.id,'bad')
    with pytest.raises(KeyError): e.resolve_conflict('missing','defer')
    with pytest.raises(ValueError): e.resolve_conflict(conflict.id,'accept_claim')
    with pytest.raises(ValueError): e.resolve_conflict(conflict.id,'scope_split')
    e.resolve_conflict(conflict.id,'defer',rationale='later')
    e.resolve_conflict(conflict.id,'scope_split',scope='different scope')
    e.resolve_conflict(conflict.id,'accept_claim',claim_id=c.id)
    with pytest.raises(PermissionError): e.verify_claim(c.id,policy_id='strict')
    with pytest.raises(ValueError): e.promote_knowledge('none',[],epistemic_type='assertion')
    with pytest.raises(ValueError): e.promote_knowledge('none',[],epistemic_type='absence_of_evidence')
    k=e.promote_knowledge('none',[],epistemic_type='absence_of_evidence',absence_scope='known search space'); assert k.kind=='Knowledge'
    with pytest.raises(ValueError): e.promote_knowledge('bad',[c.id])
    with pytest.raises(ValueError): e.promote_knowledge('bad',[],epistemic_type='bad')


def test_integrity_trust_and_recovery_edge_conditions(tmp_path):
    from tbohk.integrity import IntegrityAuditor
    from tbohk.trust import ReleaseSigner, TrustAuditor
    from tbohk.recovery_drill import RecoveryDrill
    g=TBOHK(); ia=IntegrityAuditor(g)
    assert not ia.audit_checkpoint('missing').passed
    cp=g.add_node('Checkpoint','cp','supported',{'manifest':{},'manifest_sha256':'bad'})
    r=ia.audit_checkpoint(cp.id); assert not r.passed and any(f.code=='manifest_hash_mismatch' for f in r.findings)
    g.update_metadata(cp.id,{'manifest':{'node_hash':'bad','edge_hash':'bad'},'manifest_sha256':g._hash(__import__('json').dumps({'node_hash':'bad','edge_hash':'bad'},sort_keys=True))},replace=True)
    r=ia.audit_checkpoint(cp.id); assert not r.passed
    signer=ReleaseSigner(b'key','id'); ta=TrustAuditor(g)
    assert ta.verify_checkpoint('missing',signer).findings==('checkpoint_missing',)
    g.update_metadata(cp.id,{'release_signature':{}},replace=False)
    assert ta.verify_checkpoint(cp.id,signer).findings==('release_signature_missing_or_malformed',)
    assert RecoveryDrill(g).run()[0].name=='in_memory_not_drillable'
    path=tmp_path/'db.sqlite'; fg=TBOHK(str(path)); drill=RecoveryDrill(fg).run(); assert drill and drill[0].destructive and drill[0].name=='event_deletion'


def test_assurance_manifest_write_and_research_workspace_variants(tmp_path):
    from tbohk.assurance_pipeline import AssurancePipeline
    from tbohk.workspace import QuestionWorkspace
    g=TBOHK(); snap=AssurancePipeline(g).run(); p=tmp_path/'manifest.json'; data=AssurancePipeline(g).write_manifest(p,snap,artifact_hashes={'b':'2','a':'1'}); assert p.exists() and data['manifest_sha256']
    w=QuestionWorkspace(g); ws=w.open('nothing matches'); assert 'acquire auditable source evidence' in ws.next_actions

def test_semantics_normalization_and_every_validation_branch():
    from tbohk.semantics import SemanticReasoningEngine
    g=TBOHK(); s=SemanticReasoningEngine(g)
    assert s._norm({'b':[{'z':2,'a':1}], 'a':3})=={'a':3,'b':[{'a':1,'z':2}]}
    premise=g.add_node('Claim','p','supported')
    ass=s.add_assumption('a'); defeater=s.add_defeater('d')
    with pytest.raises(ValueError): s.propose('bad',[premise.id],conclusion='c')
    with pytest.raises(ValueError): s.propose('deductive',[],conclusion='c')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id,premise.id],conclusion='c',rule_id='x')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c',premise_roles={'other':'necessary'},rule_id='x')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c',premise_roles={premise.id:'bad'},rule_id='x')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c',assumption_ids=['missing'],rule_id='x')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c',defeater_ids=['missing'],rule_id='x')
    with pytest.raises(ValueError): s.propose('counterfactual',[premise.id],conclusion='c',counterfactual={})
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c')
    with pytest.raises(ValueError): s.propose('deductive',[premise.id],conclusion='c',rule_id='missing')
    result=s.propose('counterfactual',[premise.id],conclusion='c',counterfactual={'intervention':'I'},assumption_ids=[ass.id],defeater_ids=[defeater.id],premise_roles={premise.id:'necessary'})
    assert result.branch_id
    with pytest.raises(ValueError): s.assess('missing')
    assessment=s.assess(result.activity_id); assert assessment.status=='supported' and assessment.kind=='ReasoningAssessment'

def test_core_ledger_rebuild_temporal_and_transaction_failure_paths():
    from types import MethodType
    g=TBOHK()
    with pytest.raises(RuntimeError):
        g.close(); g.__enter__()
    # rebuild an intentionally absent ledger chain from durable rows
    with TBOHK() as rg:
        n=rg.add_node('Claim','rebuild','proposed')
        rg.set_status(n.id,'supported','x')
        rg.db.execute('DELETE FROM ledger_chain'); rg.db.execute('DELETE FROM ledger_anchor'); rg.db.commit()
        rg._rebuild_missing_ledger_entries(); rg.db.commit()
        assert rg.db.execute('SELECT COUNT(*) FROM ledger_chain').fetchone()[0] > 0
        assert rg._temporal_valid(None,rg._parse_time('2025-01-01')) is False
        snap=rg.add_node('SourceSnapshot','s','supported',{'valid_from':'2026-01-01','valid_until':'2026-12-31'})
        assert rg._temporal_valid(snap,rg._parse_time('2025-01-01')) is False
        assert rg._temporal_valid(snap,rg._parse_time('2027-01-01')) is False
        assert rg._temporal_valid(snap,rg._parse_time('2026-06-01')) is True
    # exercise rollback branches by failing after the mutation has begun
    for operation in ('add','link','meta','status'):
        x=TBOHK(); base=x.add_node('Claim','base')
        original=x._event
        def boom(*a,**k): raise RuntimeError('event failure')
        x._event=boom
        try:
            if operation=='add':
                with pytest.raises(RuntimeError): x.add_node('Claim','boom')
            elif operation=='link':
                x._event=original
                othernode=x.add_node('Claim','other')
                x._event=boom
                with pytest.raises(RuntimeError): x.link(base.id,'supports',othernode.id)
            elif operation=='meta':
                with pytest.raises(RuntimeError): x.update_metadata(base.id,{'x':1})
            else:
                with pytest.raises(RuntimeError): x.set_status(base.id,'supported','boom')
        finally:
            x._event=original
            x.close()


def test_core_reasoning_provenance_and_temporal_invalidation_edges():
    g=TBOHK()
    # verified claim with no evidence exercises the no-evidence maintenance path
    c=g.add_node('Claim','verified','verified')
    assert g.temporal_invalidation('2026-01-01')['invalidated']==[]
    # malformed derived reasoning provenance is audited as a concrete defect
    a=g.add_node('ReasoningActivity','r','supported',{'method':'inductive','semantic_layer':'G4.2','premise_roles':{}})
    rule=g.add_node('ReasoningRule','rule','supported')
    p=g.add_node('Claim','premise','supported'); out=g.add_node('Claim','derived','proposed',{'origin':'reasoning','reasoning_activity_id':'wrong'})
    g.link(a.id,'applies_rule',rule.id); g.link(a.id,'uses',p.id); g.link(a.id,'produces',out.id)
    audit=g.audit(); assert any(x[1]=='derived_claim_missing_reasoning_provenance' for x in audit['problems'])
