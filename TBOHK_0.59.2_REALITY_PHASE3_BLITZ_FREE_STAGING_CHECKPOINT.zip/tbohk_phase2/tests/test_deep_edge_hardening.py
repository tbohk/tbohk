import json, tempfile
import pytest
from tbohk import TBOHK


def _reasoning_fixture():
    from tbohk.reasoning import ReasoningEngine
    g=TBOHK()
    p=g.add_node('Claim','premise','supported',{'structured':{'subject':'s','predicate':'p','object':True,'scope':'global','uncertainty':{'kind':'low'}}})
    r=ReasoningEngine(g); rule=r.add_rule('id','identity',{'consequent':p.metadata['structured']})
    out=r.derive(rule.id,[p.id])
    return g,p,out


def test_robustness_all_scenarios_and_failure_boundaries():
    from tbohk.robustness import ReasoningStressTester
    g,p,out=_reasoning_fixture(); s=ReasoningStressTester(g)
    report=s.test(out.activity_id, as_of='2026-01-01T00:00:00+00:00')
    assert report.resilience in {'fragile','conditional'} and len(report.cases)>=10
    assert s.record(out.activity_id, ['remove_premise'], as_of='2026-01-01T00:00:00+00:00').cases
    with pytest.raises(ValueError): s.test('missing')
    with pytest.raises(ValueError): s.test(p.id)
    with pytest.raises(ValueError): s.test(out.activity_id,['not-a-scenario'])
    g2=TBOHK(); bare=g2.add_node('ReasoningActivity','bare','supported',{'method':'deductive','premise_ids':[]})
    with pytest.raises(ValueError): s.__class__(g2).test(bare.id)
    g3=TBOHK(); c=g3.add_node('Claim','no derivation','supported')
    with pytest.raises(ValueError): s.__class__(g3).test(c.id)
    a=g3.add_node('ReasoningActivity','a','supported',{'method':'deductive','premise_ids':[],'conclusion_id':'x'})
    b=g3.add_node('ReasoningActivity','b','supported',{'method':'deductive','premise_ids':[],'conclusion_id':'x'})
    c2=g3.add_node('Claim','multi','supported')
    g3.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(a.id,'derives',c2.id,g3._now()))
    g3.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(b.id,'derives',c2.id,g3._now())); g3.db.commit()
    with pytest.raises(ValueError): s.__class__(g3).test(c2.id)


def test_inference_evaluator_deep_dimensions_and_competition():
    from tbohk.inference import InferenceEvaluator
    from tbohk.semantics import SemanticReasoningEngine
    g,p,out=_reasoning_fixture(); ev=InferenceEvaluator(g)
    # normal identity inference has enough explicit structure for a warranted result
    a=ev.assess(out.activity_id,as_of='2026-01-01T00:00:00+00:00')
    assert a.activity_id==out.activity_id
    assert ev.record(out.activity_id,as_of='2026-01-01T00:00:00+00:00').verdict
    # unknown method, missing premise, assumptions, defeaters, and missing scope/uncertainty
    bad=g.add_node('ReasoningActivity','bad','supported',{'method':'mystery','premise_ids':['missing'],'conclusion_id':'missing','rule_id':'missing','assumption_ids':['missing'],'defeater_ids':['missing']})
    b=ev.assess(bad.id); assert b.verdict=='invalid'
    # counterfactual without intervention
    c=g.add_node('Claim','cf','supported',{'structured':{'subject':'s'}})
    cf=g.add_node('ReasoningActivity','cfact','supported',{'method':'counterfactual','premise_ids':[p.id],'conclusion_id':c.id,'counterfactual':{}})
    g.link(cf.id,'uses',p.id); g.link(cf.id,'produces',c.id)
    assert ev.assess(cf.id).verdict=='invalid'
    # competing derivation paths and circular dependency
    rr=SemanticReasoningEngine(g); other=rr.propose('deductive',[p.id],conclusion='same',rule_id=out.rule_id)
    # make the existing output conclusion share another derivation edge
    g.link(other.activity_id,'derives',out.conclusion_id)
    comp=ev.assess(out.activity_id); assert comp.competing_activity_ids
    cyc=g.add_node('ReasoningActivity','cycle','supported',{'method':'deductive','premise_ids':[out.conclusion_id],'conclusion_id':out.conclusion_id,'premise_roles':{'premise':'x'}})
    g.link(cyc.id,'uses',out.conclusion_id); g.link(cyc.id,'derives',out.conclusion_id)
    assert ev.assess(cyc.id).verdict=='invalid'


def test_dependency_impact_scope_cycle_and_limits():
    from tbohk.impact import DependencyImpactAnalyzer
    g=TBOHK(); root=g.add_node('Claim','root','supported'); dep=g.add_node('Claim','dep','supported'); leaf=g.add_node('Decision','leaf','proposed')
    g.link(dep.id,'based_on',root.id); g.link(leaf.id,'based_on',dep.id)
    a=DependencyImpactAnalyzer(g)
    rep=a.analyze([root.id]); assert leaf.id in {x.node_id for x in rep.items}
    assert a._reachable_from(root.id,leaf.id)
    assert a._reachable_from(root.id,root.id)
    assert not a._reachable_from(leaf.id,'missing')
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(leaf.id,'depends_on',root.id,g._now())); g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(root.id,'based_on',leaf.id,g._now())); g.db.commit()
    cyc=a.analyze([root.id]); assert cyc.cycle_edges
    with pytest.raises(ValueError): a.analyze([])
    with pytest.raises(ValueError): a.analyze([root.id],max_nodes=0)
    with pytest.raises(ValueError): a.analyze(['missing'])
    run=g.add_node('AdaptiveResearchRun','run','supported',{'hypothesis_ids':[root.id]})
    scoped=a.analyze([root.id],run_id=run.id); assert scoped.scoped_run_id==run.id
    with pytest.raises(ValueError): a.analyze([root.id],run_id='missing')
    ev=g.add_node('Evidence','orphan','supported',{})
    r=a.analyze([ev.id]); assert ev.id in r.excluded_invalid_provenance_roots


def test_reconstitution_validation_exclusion_and_atomic_apply():
    from tbohk.checkpoints import CheckpointManager
    from tbohk.reconstitution import ReconstitutionEngine
    g=TBOHK(); n=g.add_node('Claim','x','supported',{'dependency_ids':[]}); cp=CheckpointManager(g).create(code_version='0.28.2',schema_version=2,invariant_version='1',test_summary='test')
    e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id); plan=e.plan(snap)
    target=TBOHK(); report=e.apply(plan,snap,target_graph=target,validation_id='v1'); assert report.passed and target.get(n.id)
    with pytest.raises(PermissionError): e.apply(plan,snap,target_graph=target)
    tampered=type(snap)(snap.checkpoint_id,'bad',snap.nodes,snap.edges,snap.exported_at)
    assert e.plan(tampered).findings
    malformed_nodes=list(snap.nodes); malformed_nodes[0]=dict(malformed_nodes[0],metadata='not-json')
    malformed=type(snap)(snap.checkpoint_id,e._digest(malformed_nodes,list(snap.edges)),tuple(malformed_nodes),snap.edges,snap.exported_at)
    assert any(f.code=='malformed_node_metadata' for f in e.plan(malformed).findings)
    missing_dep=dict(snap.nodes[0]); meta=json.loads(missing_dep['metadata']); meta['dependency_ids']=['missing']; missing_dep['metadata']=json.dumps(meta,sort_keys=True)
    missing=type(snap)(snap.checkpoint_id,e._digest([missing_dep],list(snap.edges)),(missing_dep,),(),snap.exported_at)
    assert any(f.code=='recovered_node_has_missing_dependency' for f in e.plan(missing).findings)
    with pytest.raises(PermissionError): e.apply(e.plan(tampered),tampered,target_graph=TBOHK())
    badcp=TBOHK(); badcpnode=badcp.add_node('Checkpoint','bad','supported',{'manifest':{}})
    with pytest.raises(ValueError): ReconstitutionEngine(badcp).export_snapshot(badcpnode.id)


def test_governance_authorization_boundaries_and_deep_audit():
    from tbohk.governance import GovernanceEngine
    g=TBOHK(); gov=GovernanceEngine(g)
    p=gov.propose_change('x','schema',['id'],proposer='alice')
    assert not gov.evaluate_change(p.id,benchmark_passed=False).allowed
    good=gov.evaluate_change(p.id)
    with pytest.raises(PermissionError): gov.authorize(p.id,assessment_id='missing')
    a=[n for n in g.db.execute("SELECT id FROM nodes WHERE kind='GovernanceAssessment'").fetchall() if g.get(n[0]).metadata.get('allowed')][0][0]
    other=gov.propose_change('y','schema',['id'],proposer='alice')
    with pytest.raises(PermissionError): gov.authorize(other.id,assessment_id=a)
    own=gov.grant('alice',['execute_action'],scope='*',approver='alice')
    with pytest.raises(PermissionError): gov.approve_grant(own.id,approver='alice')


def test_api_endpoint_contracts_and_error_boundaries(monkeypatch):
    import tbohk.api as api
    from fastapi import HTTPException
    api.TOKEN='secret'
    assert api.auth('Bearer secret') is None
    with pytest.raises(HTTPException): api.auth('Bearer wrong')
    api.TOKEN=None; assert api.auth(None) is None
    assert api.health()['ok'] is True
    # protected status is deliberately blocked at the API boundary
    c=api.g.add_node('Claim','protected','proposed')
    with pytest.raises(HTTPException) as exc: api.set_status(c.id,api.StatusIn(status='verified'))
    assert exc.value.status_code==403
    with pytest.raises(HTTPException): api.create_node(api.NodeIn(kind='Claim',content='x',status='bad'))
    with pytest.raises(HTTPException): api.create_edge(api.EdgeIn(source_id='missing',relation='supports',target_id='missing'))
    with pytest.raises(HTTPException): api.node('missing')
    with pytest.raises(HTTPException): api.research(api.ResearchIn(query='q',urls=[]))
    with pytest.raises(HTTPException): api.causal('missing')
    class Boom:
        def __getattr__(self, name):
            return lambda *a, **k: (_ for _ in ()).throw(ValueError('forced endpoint failure'))
    monkeypatch.setattr(api.intelligence, 'hypotheses', Boom())
    monkeypatch.setattr(api.predictive, 'create_prediction', Boom().x)
    monkeypatch.setattr(api.predictive, 'assess_observation', Boom().x)
    monkeypatch.setattr(api.predictive, 'design_experiment', Boom().x)
    monkeypatch.setattr(api.intelligence, 'investigator', Boom())
    monkeypatch.setattr(api.adaptive, 'run', Boom().x)
    with pytest.raises(HTTPException): api.create_hypothesis(api.HypothesisIn(statement='x'))
    with pytest.raises(HTTPException): api.generate_hypotheses(api.HypothesisGenerateIn(question='x'))
    with pytest.raises(HTTPException): api.compare_hypotheses('x,y')
    with pytest.raises(HTTPException): api.create_prediction(api.PredictionIn(hypothesis_id='x',statement='x'))
    with pytest.raises(HTTPException): api.observe_prediction(api.ObservationIn(prediction_id='x',observation='x'))
    with pytest.raises(HTTPException): api.experiment_design(api.ExperimentIn(hypothesis_ids=['x']))
    with pytest.raises(HTTPException): api.investigation_plan(api.InvestigationIn(hypothesis_ids=['x']))
    with pytest.raises(HTTPException): api.adaptive_research(api.AdaptiveResearchIn(question='q',hypothesis_ids=['x'],urls=['https://example.com']))
    with pytest.raises(HTTPException): api.investigation_state('missing')
    with pytest.raises(HTTPException): api.investigation_history('missing')
    with pytest.raises(HTTPException): api.investigation_delta('missing')
    with pytest.raises(HTTPException): api.hypothesis_assessment('missing')
    with pytest.raises(HTTPException): api.hypothesis('missing')
    with pytest.raises(HTTPException): api.investigation_impact('missing','missing')
    with pytest.raises(HTTPException): api.impact('missing')
    with pytest.raises(HTTPException): api.create_reevaluation_queue('missing')
    with pytest.raises(HTTPException): api.get_reevaluation_queue('missing')
    with pytest.raises(HTTPException): api.reevaluation_policy('missing')
    with pytest.raises(HTTPException): api.reevaluation_assessment('missing','a','supports',rationale='x')
    with pytest.raises(HTTPException): api.reevaluation_transition('missing')
    with pytest.raises(HTTPException): api.autonomous_run(api.AutoIn(question='q',urls=[]))
    assert '<html' in api.home().lower() or 'TBOHK' in api.home()
