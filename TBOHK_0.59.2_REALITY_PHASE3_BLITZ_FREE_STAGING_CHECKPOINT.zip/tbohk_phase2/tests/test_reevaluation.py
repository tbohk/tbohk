import json
from fastapi.testclient import TestClient
from tbohk.core import TBOHK
from tbohk.reevaluation import ReEvaluationController
from tbohk.decisions import DecisionEngine
from tbohk.plans import PlanEngine


def origin(g): return g.add_node('Origin','o','supported')
def ev(g,o):
    e=g.add_node('Evidence','e','supported',{'origin_id':o.id}); g.link(e.id,'derived_from_origin',o.id); return e


def test_queue_is_explicit_and_read_only():
    g=TBOHK(); o=origin(g); e=ev(g,o); c=g.add_node('Claim','c','verified'); g.link(e.id,'evidence_for',c.id)
    before=(g.get(c.id).status, len(g.db.execute('SELECT * FROM revisions').fetchall()))
    q=ReEvaluationController(g).create([e.id])
    assert q.items[0].node_id==c.id
    assert g.get(c.id).status=='verified'
    assert (g.get(c.id).status, len(g.db.execute('SELECT * FROM revisions').fetchall()))==before
    item=g.get(q.item_ids[0]); assert item.metadata['automatic_status_change'] is False


def test_queue_is_idempotent_for_same_current_impact():
    g=TBOHK(); o=origin(g); e=ev(g,o); c=g.add_node('Claim','c','verified'); g.link(e.id,'evidence_for',c.id)
    a=ReEvaluationController(g).create([e.id]); b=ReEvaluationController(g).create([e.id])
    assert a.queue_id==b.queue_id and b.idempotent is True


def test_queue_recomputes_after_state_change():
    g=TBOHK(); o=origin(g); e=ev(g,o); c=g.add_node('Claim','c','verified'); g.link(e.id,'evidence_for',c.id)
    a=ReEvaluationController(g).create([e.id]); g.set_status(e.id,'stale','expired')
    b=ReEvaluationController(g).create([e.id]); assert b.queue_id!=a.queue_id
    assert b.items[0].impact=='potentially_invalidated'


def test_priority_and_downstream_decision_plan_are_preserved_without_promotion():
    g=TBOHK(); o=origin(g); e=ev(g,o)
    d=DecisionEngine(g).propose('d',['A'],evidence_ids=[e.id]); p=PlanEngine(g).create('p',['step'],decision_id=d.decision_id)
    q=ReEvaluationController(g).create([e.id])
    by={i.node_id:i for i in q.items}
    assert by[d.decision_id].priority=='high'
    assert by[p.plan_id].priority=='high'
    assert g.get(d.decision_id).status=='proposed' and g.get(p.plan_id).status=='proposed'


def test_invalid_provenance_creates_no_queue_items():
    g=TBOHK(); e=g.add_node('Evidence','bad','supported',{'origin_id':'missing'}); c=g.add_node('Claim','c'); g.link(e.id,'evidence_for',c.id)
    q=ReEvaluationController(g).create([e.id]); assert q.items==() and q.counts['total']==0


def test_api_create_and_get_queue():
    import tbohk.api as api
    g=TBOHK(); o=origin(g); e=ev(g,o); c=g.add_node('Claim','c'); g.link(e.id,'evidence_for',c.id)
    old=api.g; api.g=g
    try:
        client=TestClient(api.app)
        r=client.post('/reevaluation-queue',params={'roots':e.id}); assert r.status_code==200
        body=r.json(); assert body['counts']['total']==1
        got=client.get('/reevaluation-queue/'+body['queue_id']); assert got.status_code==200
        assert got.json()['queue_id']==body['queue_id']
    finally: api.g=old
