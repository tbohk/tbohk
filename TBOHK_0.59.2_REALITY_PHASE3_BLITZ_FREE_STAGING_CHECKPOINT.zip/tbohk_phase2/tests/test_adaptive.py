from tbohk.core import TBOHK
from tbohk.hypothesis import HypothesisEngine
from tbohk.prediction import PredictiveReasoner
from tbohk.research import MockProvider, SourceDocument
from tbohk.adaptive import AdaptiveResearchController


def setup_adaptive():
    g=TBOHK(':memory:'); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('Mechanism A explains the observation')
    b=h.create('Mechanism B explains the observation')
    p.create_prediction(a.id,'A mechanism produces red output',discriminator=True)
    p.create_prediction(b.id,'B mechanism produces blue output',discriminator=True)
    doc=SourceDocument('src1','Test','https://example.test','A mechanism produces red output','mock','2026-01-01T00:00:00Z','origin1')
    provider=MockProvider('mock',[doc])
    return g,a,b,provider


def test_adaptive_controller_is_bounded_and_records_cycles():
    g,a,b,provider=setup_adaptive(); r=AdaptiveResearchController(g)
    out=r.run('which mechanism explains the observation',[a.id,b.id],[provider],max_cycles=2)
    assert len(out.cycles) == 2
    assert len(g.edges(out.run_id,direction='out',relation='contains')) == 2
    assert g.get(out.run_id).kind == 'AdaptiveResearchRun'
    assert 'does not authorize experiments' in out.authority_boundary


def test_adaptive_controller_stops_when_targets_exhausted():
    g,a,b,provider=setup_adaptive(); r=AdaptiveResearchController(g)
    out=r.run('which mechanism explains the observation',[a.id,b.id],[provider],max_cycles=5)
    assert len(out.cycles) == 2
    assert out.stop_reason == 'no_unresolved_informative_target'


def test_adaptive_controller_rejects_missing_provider():
    g,a,b,_=setup_adaptive(); r=AdaptiveResearchController(g)
    import pytest
    with pytest.raises(ValueError):
        r.run('question',[a.id,b.id],[],max_cycles=1)


def test_adaptive_learning_records_information_value():
    g,a,b,provider=setup_adaptive(); r=AdaptiveResearchController(g)
    out=r.run('which mechanism explains the observation',[a.id,b.id],[provider],max_cycles=2)
    states=[]
    for e in g.edges(out.run_id,direction='out',relation='contains'):
        cycle=g.get(e['target_id'])
        if cycle:
            states.extend(g.get(x['target_id']) for x in g.edges(cycle.id,direction='out',relation='evaluates'))
    states=[n for n in states if n and n.kind=='AdaptiveLearningState']
    assert states
    assert all('marginal_value' in n.metadata for n in states)


def test_adaptive_learning_stops_on_duplicate_information():
    g,a,b,_=setup_adaptive()
    from tbohk.research import MockProvider, SourceDocument
    docs=[SourceDocument('same','Same','https://example.test/same','A mechanism produces red output','mock','2026-01-01T00:00:00Z','origin1')]
    provider=MockProvider('mock',docs)
    r=AdaptiveResearchController(g)
    out=r.run('which mechanism explains the observation',[a.id,b.id],[provider],max_cycles=5)
    assert len(out.cycles) == 2
    assert out.stop_reason in {'no_unresolved_informative_target','diminishing_information_value'}


def test_learning_state_is_attached_to_cycle_and_not_run_contains():
    g,a,b,provider=setup_adaptive(); r=AdaptiveResearchController(g)
    out=r.run('which mechanism explains the observation',[a.id,b.id],[provider],max_cycles=1)
    contained=[g.get(e['target_id']) for e in g.edges(out.run_id,direction='out',relation='contains')]
    assert all(n.kind == 'AdaptiveResearchCycle' for n in contained)
    assert any(g.edges(n.id,direction='out',relation='evaluates') for n in contained)
