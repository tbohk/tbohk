from tbohk.core import TBOHK
from tbohk.intelligence import KnowledgeIntelligence
from tbohk.research import MockProvider, SourceDocument
from datetime import datetime, timezone

def doc(pid, text, sid, oid):
    return SourceDocument(sid, sid, "https://example.test/"+sid, text, pid, datetime.now(timezone.utc).isoformat(), oid)

def test_phase_g_plan_and_gap_detection():
    g=TBOHK(":memory:"); k=KnowledgeIntelligence(g)
    p=k.plan_research("What is X and why does X matter")
    assert len(p.subquestions)>=2
    assert k.gaps("X")[0]["severity"]=="critical"

def test_phase_g_research_candidates_and_knowledge_boundary():
    g=TBOHK(":memory:"); k=KnowledgeIntelligence(g)
    d=doc("p","The system improved reliability. The result was measured over twelve months.","s1","o1")
    out=k.run_bounded("reliability",[MockProvider("p",[d])],max_cycles=3)
    assert out["run_id"].startswith("autonomousrun_")
    claims=out["knowledge"]["claims"]
    assert claims and all(c["status"]=="proposed" for c in claims)
    assert any("evidence" in x["description"] or "verified" in x["description"] for x in out["gaps"])

def test_phase_g_bounded_autonomy_does_not_authorize():
    g=TBOHK(":memory:"); k=KnowledgeIntelligence(g)
    d=doc("p","A bounded research fact is recorded.","s2","o2")
    out=k.run_bounded("fact",[MockProvider("p",[d])],max_cycles=10)
    assert len(out["cycles"])==10
    run=g.get(out["run_id"])
    assert run.metadata["authority_boundary"].startswith("research_and_assessment_only")
    assert not g.db.execute("SELECT 1 FROM nodes WHERE kind='AuthorityGrant'").fetchone()
