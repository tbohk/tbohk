from datetime import datetime, timezone, timedelta
from tbohk.answer import AnswerPresenter

def test_evidence_health_reports_provenance_and_freshness():
    recent=(datetime.now(timezone.utc)-timedelta(days=5)).isoformat()
    h=AnswerPresenter._evidence_health({'url':'https://example.test','publisher':'p','source_id':'s','retrieved_at':recent},2)
    assert h['provenance_completeness']==1.0
    assert h['freshness']=='recent'
    assert not h['needs_provenance_review']
    assert not h['needs_freshness_review']

def test_evidence_health_flags_missing_and_old_metadata():
    old=(datetime.now(timezone.utc)-timedelta(days=500)).isoformat()
    h=AnswerPresenter._evidence_health({'url':'https://example.test','retrieved_at':old},1)
    assert h['provenance_completeness']==0.5
    assert h['freshness']=='old'
    assert h['needs_provenance_review']
    assert h['needs_freshness_review']
