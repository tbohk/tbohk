import base64, json, time
from datetime import datetime, timezone, timedelta
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature, decode_dss_signature
from cryptography.x509.oid import NameOID

from tbohk.store_providers import verify_apple_jws, AppleStoreServerVerifier, GooglePlayVerifier, GoogleRTDNVerifier
from tbohk.store_billing import PurchaseVerificationError


def b64(v): return base64.urlsafe_b64encode(v).rstrip(b'=').decode()

def cert_pair():
    root_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    root_name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Test Root')])
    root=x509.CertificateBuilder().subject_name(root_name).issuer_name(root_name).public_key(root_key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=2)).add_extension(x509.BasicConstraints(ca=True,path_length=2),critical=True).sign(root_key,hashes.SHA256())
    leaf_key=ec.generate_private_key(ec.SECP256R1())
    leaf=x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Test Apple')])).issuer_name(root_name).public_key(leaf_key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=False,path_length=None),critical=True).sign(root_key,hashes.SHA256())
    return root_key,root,leaf_key,leaf

def apple_jws(payload, key, leaf):
    header={'alg':'ES256','x5c':[base64.b64encode(leaf.public_bytes(serialization.Encoding.DER)).decode()]}
    signing=b64(json.dumps(header,separators=(',',':')).encode())+'.'+b64(json.dumps(payload,separators=(',',':')).encode())
    der=key.sign(signing.encode(),ec.ECDSA(hashes.SHA256())); r,s=decode_dss_signature(der)
    return signing+'.'+b64(r.to_bytes(32,'big')+s.to_bytes(32,'big'))


def test_apple_jws_chain_and_signature_validation():
    root_key,root,leaf_key,leaf=cert_pair()
    jws=apple_jws({'transactionId':'tx1','bundleId':'com.tbohk.app'},leaf_key,leaf)
    _,payload=verify_apple_jws(jws,root.public_bytes(serialization.Encoding.PEM).decode())
    assert payload['transactionId']=='tx1'
    bad=jws.rsplit('.',1)[0]+'.'+b64(b'0'*64)
    try: verify_apple_jws(bad,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'signature' in str(e)
    else: raise AssertionError('tampered JWS accepted')


def test_apple_verifier_calls_authoritative_status_api_and_normalizes():
    root_key,root,leaf_key,leaf=cert_pair()
    tx=apple_jws({'transactionId':'tx1','originalTransactionId':'orig1','bundleId':'com.tbohk.app','productId':'tbohk.pro','expiresDate':str(int((time.time()+3600)*1000))},leaf_key,leaf)
    class R:
        status_code=200
        def json(self): return {'environment':'Sandbox','data':[{'lastTransactions':[{'signedTransactionInfo':tx}]}]}
    def transport(*args,**kwargs): return R()
    env={'APPLE_ISSUER_ID':'iss','APPLE_KEY_ID':'kid','APPLE_PRIVATE_KEY_PEM':leaf_key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()).decode(),'APPLE_ROOT_CA_PEM':root.public_bytes(serialization.Encoding.PEM).decode(),'APPLE_BUNDLE_ID':'com.tbohk.app','APPLE_PRODUCT_PRO':'tbohk.pro'}
    v=AppleStoreServerVerifier(env,transport)
    got=v.verify({'signedTransactionInfo':tx})
    assert got['plan']=='pro' and got['status']=='active' and got['original_transaction_id']=='orig1'


def test_google_subscriptionsv2_is_source_of_truth():
    class R:
        status_code=200
        def __init__(self,data): self._data=data
        def json(self): return self._data
    calls=[]
    def transport(method,url,**kwargs):
        calls.append((method,url))
        if 'oauth2.googleapis.com' in url: return R({'access_token':'tok','expires_in':3600})
        return R({'subscriptionState':'SUBSCRIPTION_STATE_IN_GRACE_PERIOD','lineItems':[{'productId':'tbohk.unlimited','expiryTime':'2030-01-01T00:00:00Z','autoRenewingPlan':{'autoRenewEnabled':False},'latestSuccessfulOrderId':'order1'}]})
    env={'GOOGLE_PLAY_PACKAGE_NAME':'com.tbohk.app','GOOGLE_SERVICE_ACCOUNT_EMAIL':'svc@example.com','GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM':rsa.generate_private_key(public_exponent=65537,key_size=2048).private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()).decode(),'GOOGLE_PRODUCT_UNLIMITED':'tbohk.unlimited'}
    v=GooglePlayVerifier(env,transport); got=v.verify({'purchaseToken':'token1'})
    assert got['plan']=='unlimited' and got['status']=='grace_period' and got['current_period_end'].startswith('2030-01-01')
    assert any('subscriptionsv2/tokens/token1' in u for _,u in calls)


def test_google_rtdn_oidc_and_pubsub_validation():
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Google')])
    cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).sign(key,hashes.SHA256())
    header={'alg':'RS256','kid':'k1'}; payload={'iss':'https://accounts.google.com','aud':'aud','exp':time.time()+60}
    signing=b64(json.dumps(header,separators=(',',':')).encode())+'.'+b64(json.dumps(payload,separators=(',',':')).encode())
    token=signing+'.'+b64(key.sign(signing.encode(),__import__('cryptography').hazmat.primitives.asymmetric.padding.PKCS1v15(),hashes.SHA256()))
    class R:
        status_code=200
        def json(self): return {'k1':cert.public_bytes(serialization.Encoding.PEM).decode()}
    v=GoogleRTDNVerifier('aud',lambda *a,**k:R())
    assert v.verify_oidc('Bearer '+token)['aud']=='aud'
    raw={'message':{'data':b64(json.dumps({'version':'1.0','subscriptionNotification':{'purchaseToken':'pt'}}).encode())}}
    assert v.decode_pubsub(raw)['subscriptionNotification']['purchaseToken']=='pt'

def test_jws_rejects_malformed_and_invalid_payloads():
    for raw,msg in [('a.b','compact'),('@@.@@.@@','encoding')]:
        try: __import__('tbohk.store_providers',fromlist=['decode_jws']).decode_jws(raw)
        except PurchaseVerificationError as e: assert msg in str(e)
        else: raise AssertionError('invalid JWS accepted')
    fn=__import__('tbohk.store_providers',fromlist=['decode_jws']).decode_jws
    raw=b64(json.dumps([]).encode())+'.'+b64(json.dumps({}).encode())+'.'+b64(b'x')
    try: fn(raw)
    except PurchaseVerificationError as e: assert 'invalid JWS JSON' in str(e)
    else: raise AssertionError('non-object header accepted')


def test_apple_jws_rejects_missing_roots_bad_alg_and_chain():
    root_key,root,leaf_key,leaf=cert_pair(); good=apple_jws({'x':1},leaf_key,leaf)
    try: verify_apple_jws(good,'')
    except PurchaseVerificationError as e: assert 'trust roots' in str(e)
    else: raise AssertionError('missing roots accepted')
    header=json.loads(__import__('base64').urlsafe_b64decode(good.split('.')[0]+'===')); header['alg']='RS256'
    bad_header=b64(json.dumps(header,separators=(',',':')).encode())+'.'+good.split('.')[1]+'.'+good.split('.')[2]
    try: verify_apple_jws(bad_header,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'algorithm' in str(e)
    else: raise AssertionError('bad algorithm accepted')
    bad=good.rsplit('.',1)[0]+'.'+b64(b'1'*64)
    try: verify_apple_jws(bad,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError: pass
    else: raise AssertionError('bad signature accepted')


def test_google_verifier_configuration_and_failures():
    with_ = GooglePlayVerifier()
    for fn in (with_._jwt_assertion,):
        try: fn()
        except PurchaseVerificationError as e: assert 'not configured' in str(e)
    class R:
        status_code=500
        def json(self): return {}
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    env={'GOOGLE_PLAY_PACKAGE_NAME':'p','GOOGLE_SERVICE_ACCOUNT_EMAIL':'e','GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM':key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()).decode()}
    v=GooglePlayVerifier(env,lambda *a,**k:R())
    try: v.verify({'purchaseToken':'x'})
    except PurchaseVerificationError as e: assert 'OAuth' in str(e)
    else: raise AssertionError('OAuth failure accepted')


def test_google_rtdn_failure_branches():
    v=GoogleRTDNVerifier('aud',lambda *a,**k:type('R',(),{'status_code':500,'json':lambda s:{}})())
    for auth in [None,'Basic x']:
        try: v.verify_oidc(auth)
        except PurchaseVerificationError as e: assert 'authorization' in str(e)
    for body in [{}, {'message':{}}, {'message':{'data':'@@'}}]:
        try: v.decode_pubsub(body)
        except PurchaseVerificationError: pass
        else: raise AssertionError('bad Pub/Sub accepted')

def test_apple_jws_certificate_and_payload_edges():
    root_key,root,leaf_key,leaf=cert_pair(); good=apple_jws({'x':1},leaf_key,leaf)
    import tbohk.store_providers as sp
    header=json.loads(__import__('base64').urlsafe_b64decode(good.split('.')[0]+'===')); header.pop('x5c')
    missing=b64(json.dumps(header,separators=(',',':')).encode())+'.'+good.split('.')[1]+'.'+good.split('.')[2]
    try: sp.verify_apple_jws(missing,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'certificate chain' in str(e)
    # Trusted root with a mismatched issuer reaches the chain-trust branch.
    other_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    other_name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Other Root')])
    other_root=x509.CertificateBuilder().subject_name(other_name).issuer_name(other_name).public_key(other_key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).sign(other_key,hashes.SHA256())
    try: sp.verify_apple_jws(good,other_root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'not trusted' in str(e)
    # Same root but a leaf signed by another key reaches certificate-signature failure.
    other_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    bad_leaf=x509.CertificateBuilder().subject_name(leaf.subject).issuer_name(root.subject).public_key(leaf.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).sign(other_key,hashes.SHA256())
    bad_jws=apple_jws({'x':1},leaf_key,bad_leaf)
    try: sp.verify_apple_jws(bad_jws,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'certificate signature' in str(e)
    # Expired leaf reaches certificate validity failure after its issuer validates.
    expired=x509.CertificateBuilder().subject_name(leaf.subject).issuer_name(root.subject).public_key(leaf.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(days=2)).not_valid_after(datetime.now(timezone.utc)-timedelta(days=1)).sign(root_key,hashes.SHA256())
    expired_jws=apple_jws({'x':1},leaf_key,expired)
    try: sp.verify_apple_jws(expired_jws,root.public_bytes(serialization.Encoding.PEM).decode())
    except PurchaseVerificationError as e: assert 'validity period' in str(e)


def test_apple_provider_status_error_and_renewal_branches():
    root_key,root,leaf_key,leaf=cert_pair()
    tx=apple_jws({'transactionId':'tx2','originalTransactionId':'orig2','bundleId':'com.tbohk.app','productId':'tbohk.pro','expiresDate':str(int((time.time()+3600)*1000))},leaf_key,leaf)
    renewal=apple_jws({'expirationIntent':1,'autoRenewStatus':0},leaf_key,leaf)
    class Bad:
        status_code=500
        def json(self): return {}
    env={'APPLE_ISSUER_ID':'iss','APPLE_KEY_ID':'kid','APPLE_PRIVATE_KEY_PEM':leaf_key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()).decode(),'APPLE_ROOT_CA_PEM':root.public_bytes(serialization.Encoding.PEM).decode(),'APPLE_BUNDLE_ID':'com.tbohk.app','APPLE_PRODUCT_PRO':'tbohk.pro'}
    v=AppleStoreServerVerifier(env,lambda *a,**k:Bad())
    try: v.verify({'signedTransactionInfo':tx})
    except PurchaseVerificationError as e: assert 'rejected request' in str(e)
    class Good:
        status_code=200
        def json(self): return {'environment':'Sandbox','data':[{'lastTransactions':[{'signedTransactionInfo':'bad'}, {'signedTransactionInfo':tx,'signedRenewalInfo':renewal}]}]}
    v=AppleStoreServerVerifier(env,lambda *a,**k:Good())
    got=v.verify({'signedTransactionInfo':tx})
    assert got['status']=='canceled' and got['cancel_at_period_end'] is True
    assert sp_parse(1234).startswith('1970-')
    try: __import__('tbohk.store_providers',fromlist=['_plan_for_product'])._plan_for_product('bad',{'x':'pro'})
    except PurchaseVerificationError as e: assert 'not configured' in str(e)

def sp_parse(v):
    return __import__('tbohk.store_providers',fromlist=['_parse_iso_ms'])._parse_iso_ms(v)


def test_google_oidc_signature_failure():
    v=GoogleRTDNVerifier('aud')
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Google')])
    cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=1)).sign(key,hashes.SHA256())
    header={'alg':'RS256','kid':'k1'}; payload={'iss':'https://accounts.google.com','aud':'aud','exp':time.time()+60}
    signing=b64(json.dumps(header,separators=(',',':')).encode())+'.'+b64(json.dumps(payload,separators=(',',':')).encode())
    token=signing+'.'+b64(b'0'*256)
    class R:
        status_code=200
        def json(self): return {'k1':cert.public_bytes(serialization.Encoding.PEM).decode()}
    v.transport=lambda *a,**k:R()
    try: v.verify_oidc('Bearer '+token)
    except PurchaseVerificationError as e: assert 'signature validation' in str(e)

def test_provider_environment_and_package_mismatch_guards():
    from tbohk.store_providers import AppleStoreServerVerifier, GooglePlayVerifier
    try:
        AppleStoreServerVerifier({'APPLE_ENVIRONMENT':'invalid'})
    except ValueError as e:
        assert 'APPLE_ENVIRONMENT' in str(e)
    else:
        raise AssertionError('invalid Apple environment accepted')
    g=GooglePlayVerifier({'GOOGLE_PLAY_PACKAGE_NAME':'com.tbohk','GOOGLE_SERVICE_ACCOUNT_EMAIL':'a','GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM':'x'})
    g._get_subscription=lambda token:{'packageName':'com.other','lineItems':[{'productId':'tbohk.pro','expiryTime':'2027-01-01T00:00:00Z'}],'subscriptionState':'SUBSCRIPTION_STATE_ACTIVE'}
    try: g.verify({'purchaseToken':'tok'})
    except Exception as e: assert 'package identifier mismatch' in str(e)
    else: raise AssertionError('package mismatch accepted')

def test_apple_environment_mismatch_guard(monkeypatch):
    from tbohk.store_providers import AppleStoreServerVerifier, PurchaseVerificationError
    v=AppleStoreServerVerifier({'APPLE_ENVIRONMENT':'production','APPLE_ISSUER_ID':'i','APPLE_KEY_ID':'k','APPLE_PRIVATE_KEY_PEM':'x','APPLE_ROOT_CA_PEM':'x','APPLE_BUNDLE_ID':'com.tbohk'})
    monkeypatch.setattr('tbohk.store_providers.verify_apple_jws',lambda jws,root: ({},{'bundleId':'com.tbohk','environment':'sandbox','transactionId':'tx','originalTransactionId':'orig'}))
    try: v.verify({'signedTransactionInfo':'x'})
    except PurchaseVerificationError as e: assert 'environment mismatch' in str(e)
    else: raise AssertionError('Apple environment mismatch accepted')
