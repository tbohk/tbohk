from tbohk import TBOHK, DeepAssurance

def test_deep_assurance_integrates_independent_paths():
    g = TBOHK()
    report = DeepAssurance(g).run()
    assert report.passed
    assert report.manifest_sha256
    names = {c.name for c in report.checks}
    assert {"core_audit","selfcare","state_transition_audit","migration_integrity",
            "independent_validator","reasoning_benchmark","metamorphic_suite",
            "mutation_suite","canonical_serialization"} <= names
    assert all(c.passed for c in report.checks)
