from datetime import datetime, timezone, timedelta

from tbohk import TBOHK
from tbohk.living_knowledge import LivingKnowledge


def evidence(g, claim, origin, retrieved, valid_until=None):
    snap = g.add_node("SourceSnapshot", f"snapshot {origin}", "supported", {
        "source_id": origin, "provider_id": "p-" + origin, "origin_id": origin,
        "uri": f"https://example.test/{origin}", "retrieved_at": retrieved,
        **({"valid_until": valid_until} if valid_until else {}),
    })
    ev = g.add_node("Evidence", f"Evidence from {origin}", "supported", {
        "locator": {"type": "document", "source_id": origin},
        "extraction_method": "test", "observation_time": retrieved,
        "polarity": "supports", "observation_basis": "test observation",
        "origin_id": origin, "retrieved_at": retrieved, "uri": snap.metadata["uri"],
    })
    g.link(ev.id, "derived_from", snap.id)
    g.link(ev.id, "evidence_for", claim.id)
    return ev


def test_living_snapshot_tracks_subject_state_and_review_triggers():
    g = TBOHK()
    now = datetime(2026, 9, 27, tzinfo=timezone.utc)
    old = (now - timedelta(days=120)).isoformat()
    c = g.add_node("Claim", "Water freezes at 0 C.", "verified", {
        "structured": {"subject": "water", "predicate": "freezing_point", "object": 0, "scope": "standard pressure", "time": None}
    })
    e = evidence(g, c, "agency-a", old)
    report = LivingKnowledge(g).snapshot("water", as_of=now.isoformat())
    assert report["claim_count"] == 1
    assert report["evidence_count"] == 1
    assert report["distinct_origins"] == ["agency-a"]
    assert report["review_due"] is True
    kinds = {x["kind"] for x in report["review_triggers"]}
    assert "independence" in kinds and "aging_evidence" in kinds
    assert c.status == "verified" and g.get(e.id)


def test_living_snapshot_history_and_change_detection():
    g = TBOHK()
    lk = LivingKnowledge(g)
    c = g.add_node("Claim", "The river level is 10 meters.", "proposed", {"structured": {"subject": "river", "predicate": "level", "object": 10, "scope": None, "time": None}})
    e = evidence(g, c, "a", "2026-09-27T00:00:00+00:00")
    first = lk.record_snapshot("river", as_of="2026-09-27T00:00:00+00:00")
    assert first["changes"]["changed"] is True
    g.set_status(c.id, "verified", "reviewed")
    second = lk.record_snapshot("river", as_of="2026-09-28T00:00:00+00:00")
    assert second["changes"]["changed"] is True
    assert "status_counts" in second["changes"]["deltas"]
    history = lk.history("river", limit=10)
    assert history["count"] == 2
    assert e.id in second["snapshot"]["evidence_ids"]


def test_supersession_and_expiry_surface_without_mutating_claims():
    g = TBOHK()
    old = g.add_node("Claim", "Old statement about policy.", "verified", {"structured": {"subject": "policy", "predicate": "state", "object": "old"}})
    new = g.add_node("Claim", "New statement about policy.", "proposed", {"structured": {"subject": "policy", "predicate": "state", "object": "new"}})
    g.link(new.id, "supersedes", old.id)
    expired = evidence(g, old, "archive", "2025-01-01T00:00:00+00:00", "2025-12-31T00:00:00+00:00")
    report = LivingKnowledge(g).snapshot("policy", as_of="2026-09-27T00:00:00+00:00")
    kinds = {x["kind"] for x in report["review_triggers"]}
    assert "supersession" in kinds and "expired_evidence" in kinds
    assert old.status == "verified" and new.status == "proposed" and g.get(expired.id)
