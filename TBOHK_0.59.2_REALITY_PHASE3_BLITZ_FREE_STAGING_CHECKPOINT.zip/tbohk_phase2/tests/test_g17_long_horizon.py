import json
from datetime import datetime, timezone, timedelta
from tbohk import TBOHK, LongHorizonValidator, CheckpointManager, LearningEngine


def codes(g):
    return {f.code for f in LongHorizonValidator(g).run(cycles=3).findings}


def test_clean_long_horizon_passes_50_cycles():
    g=TBOHK()
    r=LongHorizonValidator(g).run(cycles=50)
    assert r.passed
    assert len(r.snapshots)==51


def test_content_hash_drift_is_detected():
    g=TBOHK(); n=g.add_node('Claim','original')
    m=n.metadata; m['content_sha256']='0'*64
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(m),n.id)); g.db.commit()
    assert 'content_hash_drift' in codes(g)


def test_orphan_event_is_detected():
    g=TBOHK(); g._event('fake','missing-node',{}) ; g.db.commit()
    assert 'orphan_event' in codes(g)


def test_orphan_revision_is_detected():
    g=TBOHK(); g.db.execute('PRAGMA foreign_keys=OFF'); g.db.execute("INSERT INTO revisions VALUES ('r','missing','a','b','x','x','test','now')"); g.db.commit()
    assert 'orphan_revision' in codes(g)


def test_dangling_edge_is_detected_even_with_foreign_keys_disabled():
    g=TBOHK(); a=g.add_node('Claim','a'); g.db.execute('PRAGMA foreign_keys=OFF')
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(a.id,'supports','missing','now')); g.db.commit()
    assert 'dangling_edge' in codes(g)


def test_verified_knowledge_cannot_depend_on_stale_claim():
    g=TBOHK(); c=g.add_node('Claim','claim','stale'); k=g.add_node('Knowledge','knowledge','verified')
    g.link(c.id,'based_on',k.id)
    assert 'verified_stale_dependency' in codes(g)


def test_verified_claim_cannot_depend_on_failed_evidence():
    g=TBOHK(); e=g.add_node('Evidence','e','failed'); c=g.add_node('Claim','c','verified')
    g.link(e.id,'evidence_for',c.id)
    assert 'verified_stale_dependency' in codes(g)


def test_evaluation_suite_drift_is_detected():
    g=TBOHK(); le=LearningEngine(g); target=g.add_node('Model','target')
    s=le.create_evaluation_suite('fixed',[{'q':'x'}]); e=le.evaluate(target.id,s.id,metrics={'score':1,'passed':True})
    m=s.metadata; m['manifest_sha256']='f'*64
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(m),s.id)); g.db.commit()
    assert 'evaluation_suite_drift' in codes(g)


def test_replay_accumulation_is_detected():
    g=TBOHK(); a=g.add_node('Action','act','verified',{'rollback':'undo'})
    g._event('action.executed',a.id,{'success':True}); g._event('action.executed',a.id,{'success':True}); g.db.commit()
    assert 'replay_accumulation' in codes(g)


def test_checkpoint_lineage_monotonicity():
    g=TBOHK(); cm=CheckpointManager(g)
    a=cm.create(code_version='g17',schema_version='1',invariant_version='1',test_summary={},checkpoint_sequence=1)
    b=cm.create(code_version='g17',schema_version='1',invariant_version='1',test_summary={},parent_checkpoint_id=a.checkpoint_id,checkpoint_sequence=2)
    assert LongHorizonValidator(g).run(cycles=2).passed
    m=g.get(b.checkpoint_id).metadata; m['checkpoint_sequence']=1
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(m),b.checkpoint_id)); g.db.commit()
    assert 'non_monotonic_checkpoint_lineage' in codes(g)


def test_missing_checkpoint_parent_is_detected():
    g=TBOHK(); c=g.add_node('Checkpoint','c','supported',{'manifest':{},'manifest_sha256':'x','parent_checkpoint_id':'missing','checkpoint_sequence':2})
    assert 'missing_checkpoint_parent' in codes(g)


def test_duplicate_checkpoint_sequence_is_detected():
    g=TBOHK(); cm=CheckpointManager(g)
    cm.create(code_version='g17',schema_version='1',invariant_version='1',test_summary={},checkpoint_sequence=3)
    cm.create(code_version='g17',schema_version='1',invariant_version='1',test_summary={},checkpoint_sequence=3)
    assert 'duplicate_checkpoint_sequence' in codes(g)


def test_repeated_observation_does_not_mutate_state():
    g=TBOHK(); n=g.add_node('Claim','stable')
    before=LongHorizonValidator(g).snapshot()
    LongHorizonValidator(g).run(cycles=100)
    after=LongHorizonValidator(g).snapshot()
    assert before.node_hash==after.node_hash and before.edge_hash==after.edge_hash and before.event_hash==after.event_hash and before.revision_hash==after.revision_hash


def test_baseline_detects_node_mutation_even_if_hash_is_forged():
    g=TBOHK(); n=g.add_node('Claim','original')
    v=LongHorizonValidator(g); base=v.snapshot()
    g.db.execute("UPDATE nodes SET content=?, metadata=? WHERE id=?",('tampered',json.dumps({'content_sha256':__import__('hashlib').sha256(b'tampered').hexdigest()}),n.id)); g.db.commit()
    findings=v.compare(base,v.snapshot())
    assert 'node_history_mutated' in {f.code for f in findings}


def test_baseline_detects_edge_mutation():
    g=TBOHK(); a=g.add_node('Claim','a'); b=g.add_node('Claim','b'); g.link(a.id,'supports',b.id)
    v=LongHorizonValidator(g); base=v.snapshot()
    g.db.execute('DELETE FROM edges WHERE source_id=?',(a.id,)); g.db.commit()
    assert 'edge_history_deleted' in {f.code for f in v.compare(base,v.snapshot())}


def test_baseline_detects_event_deletion():
    g=TBOHK(); n=g.add_node('Claim','x'); v=LongHorizonValidator(g); base=v.snapshot()
    eid=g.events(n.id)[0]['id']; g.db.execute('PRAGMA foreign_keys=OFF'); g.db.execute('DELETE FROM events WHERE id=?',(eid,)); g.db.commit()
    assert 'event_history_deleted' in {f.code for f in v.compare(base,v.snapshot())}


def test_baseline_detects_event_payload_rewrite():
    g=TBOHK(); n=g.add_node('Claim','x'); v=LongHorizonValidator(g); base=v.snapshot()
    eid=g.events(n.id)[0]['id']; g.db.execute('UPDATE events SET payload=? WHERE id=?',(json.dumps({'forged':True}),eid)); g.db.commit()
    assert 'event_history_mutated' in {f.code for f in v.compare(base,v.snapshot())}


def test_baseline_detects_revision_deletion():
    g=TBOHK(); n=g.add_node('Claim','x'); g.set_status(n.id,'supported','test'); v=LongHorizonValidator(g); base=v.snapshot()
    rid=g.revisions(n.id)[0]['id']; g.db.execute('PRAGMA foreign_keys=OFF'); g.db.execute('DELETE FROM revisions WHERE id=?',(rid,)); g.db.commit()
    assert 'revision_history_deleted' in {f.code for f in v.compare(base,v.snapshot())}


def test_g17_clean_release_audit_passes():
    from tbohk import ReleaseAuditor
    g=TBOHK()
    assert ReleaseAuditor(g).audit().passed


def test_g17_release_audit_blocks_stale_verified_dependency():
    from tbohk import ReleaseAuditor
    g=TBOHK(); c=g.add_node('Claim','c','stale'); k=g.add_node('Knowledge','k','verified'); g.link(c.id,'based_on',k.id)
    report=ReleaseAuditor(g).audit()
    assert not report.passed
    assert any(f.code=='G17:verified_stale_dependency' for f in report.findings)
