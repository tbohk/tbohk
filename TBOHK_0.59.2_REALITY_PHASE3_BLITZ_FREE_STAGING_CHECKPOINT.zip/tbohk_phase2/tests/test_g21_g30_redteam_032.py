from tbohk import TBOHK, CheckpointManager
from tbohk.gates_21_30 import G22PortableCheckpointAuditor, G29ActionDurabilityAuditor, G30RedTeamAuditor

def test_g22_detects_snapshot_hash_drift():
    g=TBOHK(); g.add_node("Claim","x")
    cp=CheckpointManager(g).create(code_version="x",schema_version="1",invariant_version="1",test_summary={})
    g.add_node("Claim","after")
    r=G22PortableCheckpointAuditor(g).audit()
    assert any(f.code=="checkpoint_snapshot_drift" for f in r.findings)

def test_g22_detects_manifest_digest_tamper():
    g=TBOHK(); cp=CheckpointManager(g).create(code_version="x",schema_version="1",invariant_version="1",test_summary={})
    row=g.get(cp.checkpoint_id); m=dict(row.metadata); m["manifest_sha256"]="0"*64
    g.update_metadata(row.id,m,replace=True)
    r=G22PortableCheckpointAuditor(g).audit()
    assert any(f.code=="checkpoint_manifest_digest_mismatch" for f in r.findings)

def test_g29_rejects_execution_record_without_execution_id():
    g=TBOHK(); a=g.add_node("Action","a",status="verified",metadata={"compensation":"manual"})
    e=g.add_node("Execution","e",status="supported",metadata={})
    g.link(e.id,"records",a.id)
    r=G29ActionDurabilityAuditor(g).audit()
    assert any(f.code=="execution_record_without_durable_id" for f in r.findings)

def test_g30_blocks_verified_plan_without_assurance_edge():
    g=TBOHK(); p=g.add_node("Plan","p",status="verified")
    r=G30RedTeamAuditor(g).audit()
    assert not r.passed and any(f.code=="cross_gate_verified_bypass" for f in r.findings)
