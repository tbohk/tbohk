from tbohk import TBOHK, KnowledgeLifecycleAuditor

def chain():
    g=TBOHK()
    src=g.add_node("SourceSnapshot","source","supported")
    ev=g.add_node("Evidence","evidence","supported")
    c=g.add_node("Claim","claim","verified")
    k=g.add_node("Knowledge","knowledge","verified")
    d=g.add_node("Decision","decision","verified")
    g.link(ev.id,"derived_from",src.id)
    g.link(ev.id,"evidence_for",c.id)
    g.link(c.id,"based_on",k.id)
    g.link(k.id,"depends_on",d.id)
    return g,src,ev,c,k,d

def test_transitive_impact_is_read_only():
    g,src,ev,c,k,d=chain()
    before=[g.get(x.id).status for x in (src,ev,c,k,d)]
    report=KnowledgeLifecycleAuditor(g).audit()
    assert report.passed
    assert KnowledgeLifecycleAuditor(g).impact((src.id,))
    after=[g.get(x.id).status for x in (src,ev,c,k,d)]
    assert before==after

def test_invalidated_root_reaches_verified_dependents():
    g,src,ev,c,k,d=chain()
    g.set_status(src.id,"stale","source expired")
    report=KnowledgeLifecycleAuditor(g).audit()
    assert not report.passed
    assert any(f.code=="verified_state_after_invalid_dependency" for f in report.findings)
    plan=report.plans[0]
    assert c.id in plan.affected_ids
    assert k.id in plan.affected_ids

def test_multiple_roots_have_deterministic_plan():
    g,src,ev,c,k,d=chain()
    g.set_status(src.id,"contradicted","conflict")
    g.set_status(d.id,"failed","action failed")
    p=KnowledgeLifecycleAuditor(g).plan_invalidation((src.id,d.id))
    assert p.root_ids==(d.id,src.id)
    assert tuple(sorted(p.affected_ids))==p.affected_ids

def test_verified_plan_with_invalid_declared_dependency_blocks():
    g=TBOHK(); root=g.add_node("Claim","bad","contradicted")
    plan=g.add_node("Plan","plan","verified",{"dependency_ids":[root.id]})
    report=KnowledgeLifecycleAuditor(g).audit()
    assert not report.passed
    assert any(f.code=="verified_plan_with_invalid_dependency" for f in report.findings)

def test_missing_nodes_do_not_create_phantom_impact():
    g=TBOHK(); report=KnowledgeLifecycleAuditor(g).audit()
    assert report.passed and report.plans==()
