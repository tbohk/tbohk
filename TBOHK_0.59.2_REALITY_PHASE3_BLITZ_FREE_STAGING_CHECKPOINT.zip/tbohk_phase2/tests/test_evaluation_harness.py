from tbohk import TBOHK, EvaluationHarness

def test_evaluation_harness_runs_isolated_quality_suites():
    r = EvaluationHarness(TBOHK()).run(include_mutation=False, as_of="2026-09-27T00:00:00+00:00")
    assert r.total >= 26
    assert r.failed == 0
    assert r.passed_all
    assert {s.name for s in r.suites} == {"reasoning", "metamorphic", "security_boundary", "meta_evaluation"}

def test_evaluation_record_does_not_mutate_claim_truth():
    g=TBOHK(); c=g.add_node("Claim","A fact","proposed",{})
    before=g.get(c.id).status
    report,node=EvaluationHarness(g).record(include_mutation=False, as_of="2026-09-27T00:00:00+00:00")
    assert report.passed_all and node.kind=="EvaluationRun"
    assert g.get(c.id).status == before

def test_evaluation_failure_becomes_maintenance_signal(monkeypatch):
    from tbohk import evaluation_harness as h
    class Bad:
        corpus_version='x'; corpus_sha256='0'*64; total=1; passed=0; failed=1; results=()
    monkeypatch.setattr(h.ReasoningBenchmark,'run',lambda self,**kw: Bad())
    r=h.EvaluationHarness(TBOHK()).run(include_mutation=False)
    assert 'recheck:reasoning' in r.maintenance_actions
