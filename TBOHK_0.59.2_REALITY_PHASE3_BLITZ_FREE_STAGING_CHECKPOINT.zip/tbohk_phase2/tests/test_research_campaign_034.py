from tbohk.core import TBOHK
from tbohk.research_agent import ResearchAgent
from tbohk.research_campaign import BoundedResearchCampaign


def test_campaign_is_bounded_and_preserves_truth_boundary():
    g=TBOHK(); c=BoundedResearchCampaign(g,research_agent=ResearchAgent(g))
    out=c.create('What is known about migration costs?', max_tasks=3, max_sources=2)
    assert out['limits']=={'max_tasks':3,'max_sources':2}
    assert len(out['tasks'])<=3
    assert 'does not verify' in out['truth_boundary']
    seen=c.inspect(out['campaign_id'])
    assert seen['campaign']['id']==out['campaign_id']


def test_campaign_execution_records_actions_and_stops():
    g=TBOHK(); c=BoundedResearchCampaign(g,research_agent=ResearchAgent(g))
    out=c.create('What is known about migration costs?', max_tasks=2)
    run=c.execute(out['campaign_id'])
    assert len(run['executed'])<=2
    assert run['status']=='completed'
    after=c.inspect(out['campaign_id'])
    assert all(x['status']=='executed' for x in after['tasks'])
    assert 'does not' in run['truth_boundary']


def test_campaign_execution_never_exceeds_creation_limit():
    g=TBOHK(); c=BoundedResearchCampaign(g,research_agent=ResearchAgent(g))
    out=c.create('Question', max_tasks=1)
    run=c.execute(out['campaign_id'], max_tasks=50)
    assert len(run['executed'])<=1
