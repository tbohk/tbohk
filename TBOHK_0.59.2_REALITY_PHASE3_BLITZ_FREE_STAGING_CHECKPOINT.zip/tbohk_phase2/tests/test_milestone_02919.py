from pathlib import Path
import re

UI = Path(__file__).parents[1] / 'tbohk' / 'ui.html'


def html():
    return UI.read_text(encoding='utf-8')


def script():
    text = html()
    return text.split('<script>', 1)[1].split('</script>', 1)[0]


def test_workflow_resume_is_device_local_and_failure_safe():
    s = script()
    assert 'localStorage.setItem(\'tbohk_workflow\'' in s
    assert 'localStorage.getItem(\'tbohk_workflow\'' in s
    assert 'function persistWorkflow' in s
    assert 'function restoreWorkflow' in s
    assert 'catch(_)' in s
    assert 'server-authoritative' in html() or 'Server-authoritative' in html()


def test_research_automatically_refreshes_the_answer():
    s = script()
    assert "await loadAnswer(q);showView('ask')" in s
    assert 'The answer was refreshed with the latest evidence.' in s
    assert 'persistWorkflow()' in s


def test_resume_surface_has_explicit_local_storage_boundary():
    h = html()
    assert 'id="resumeHint"' in h
    assert 'stored only on this device' in h
    assert 'onclick="showView(\'ask\');$(\'question\').focus()"' in h


def test_automation_does_not_create_an_unbounded_background_loop():
    s = script()
    assert 'setInterval' not in s
    assert 'while(true)' not in s.replace(' ', '')
    assert 'setTimeout' in s  # focus/UI scheduling remains bounded
