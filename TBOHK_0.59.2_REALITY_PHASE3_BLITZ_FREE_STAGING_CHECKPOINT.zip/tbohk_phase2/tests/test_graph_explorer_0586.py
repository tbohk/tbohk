from fastapi.testclient import TestClient
from tbohk.core import TBOHK
from tbohk import api

def test_graph_neighborhood_is_bounded_and_read_only():
    g=TBOHK(); a=g.add_node('Claim','alpha','verified',{}); b=g.add_node('Evidence','beta','supported',{})
    g.link(b.id,'evidence_for',a.id)
    old=api.g; api.g=g
    try:
        r=TestClient(api.app).get(f'/graph/neighborhood/{a.id}',params={'limit':1})
        assert r.status_code==200
        body=r.json(); assert body['node']['id']==a.id; assert len(body['neighbors'])==1
        assert body['neighbors'][0]['relation']=='evidence_for'
    finally: api.g=old

def test_graph_neighborhood_missing_node_is_404():
    g=TBOHK(); old=api.g; api.g=g
    try: assert TestClient(api.app).get('/graph/neighborhood/missing').status_code==404
    finally: api.g=old
