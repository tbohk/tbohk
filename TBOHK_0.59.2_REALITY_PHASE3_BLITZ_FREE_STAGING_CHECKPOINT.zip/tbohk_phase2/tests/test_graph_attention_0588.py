from fastapi.testclient import TestClient
from tbohk import __version__
from tbohk.core import TBOHK
from tbohk.api import app
import tbohk.api as api


def test_attention_composes_gaps_conflicts_and_impact(monkeypatch):
    local=TBOHK()
    root=local.add_node('Claim','A claim needing review','unknown',{'subject':'A','predicate':'is','object':'B'})
    other=local.add_node('Claim','Competing claim','verified',{})
    local.link(other.id,'contradicts',root.id)
    dependent=local.add_node('Decision','A decision based on the claim','proposed',{})
    local.link(dependent.id,'based_on',root.id)
    monkeypatch.setattr(api,'g',local)
    c=TestClient(app)
    r=c.get(f'/graph/attention/{root.id}')
    assert r.status_code==200
    body=r.json()
    assert body['attention']=='conflict'
    assert body['summary']['conflict_count']==1
    assert body['summary']['gap_count']>=1
    assert any(x['node_id']==dependent.id for x in body['impact']['items'])
    assert body['actions']
    assert 'Read-only' in body['boundary']


def test_attention_is_bounded_and_missing_is_404(monkeypatch):
    local=TBOHK(); root=local.add_node('Knowledge','Root','supported',{})
    for i in range(20):
        n=local.add_node('Knowledge',f'N{i}','supported',{})
        local.link(root.id,'contains',n.id)
    monkeypatch.setattr('tbohk.api.g',local)
    c=TestClient(app)
    r=c.get(f'/graph/attention/{root.id}?max_nodes=1')
    assert r.status_code==200
    assert r.json()['impact']['counts']['total_impacted'] <= 1
    assert c.get('/graph/attention/missing-node').status_code==404
