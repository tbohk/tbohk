import pytest
from tbohk.core import TBOHK
from tbohk.impact import DependencyImpactAnalyzer


def origin(g, label="origin"):
    return g.add_node("Origin", label, "supported")

def evidence(g, o, text="evidence"):
    e=g.add_node("Evidence", text, "supported", {"origin_id":o.id})
    g.link(e.id, "derived_from_origin", o.id)
    return e


def test_direct_and_multihop_impact():
    g=TBOHK()
    o=origin(g); e=evidence(g,o)
    c=g.add_node("Claim","claim","verified"); h=g.add_node("Hypothesis","hypothesis","proposed"); k=g.add_node("Conclusion","conclusion","supported")
    g.link(e.id,"evidence_for",c.id); g.link(c.id,"derives",h.id); g.link(h.id,"produces",k.id)
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    assert [x.node_id for x in r.items]==sorted([c.id,h.id,k.id])
    assert all(x.impact=="affected" for x in r.items)
    assert r.counts["total_impacted"]==3
    assert next(x for x in r.items if x.node_id==k.id).distance == 3


def test_stale_root_is_potentially_invalidated_not_disproven():
    g=TBOHK(); o=origin(g); e=evidence(g,o); g.set_status(e.id,"stale","source expired")
    c=g.add_node("Claim","claim","verified"); g.link(e.id,"evidence_for",c.id)
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    assert r.items[0].impact=="potentially_invalidated"


def test_explicit_contradiction_is_disproven():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim","verified")
    g.link(e.id,"evidence_for",c.id); g.link(e.id,"contradicts",c.id)
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    assert r.items[0].impact=="disproven"


def test_invalid_provenance_root_cannot_drive_impact():
    g=TBOHK(); bad=g.add_node("Evidence","untrusted", "supported", {"origin_id":"missing-origin"})
    c=g.add_node("Claim","claim","verified"); g.link(bad.id,"evidence_for",c.id)
    r=DependencyImpactAnalyzer(g).analyze([bad.id])
    assert r.excluded_invalid_provenance_roots==(bad.id,)
    assert r.items==()


def test_unrelated_graph_is_excluded_and_cycles_terminate():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim"); h=g.add_node("Hypothesis","h"); other=g.add_node("Claim","other")
    g.link(e.id,"evidence_for",c.id); g.link(c.id,"derives",h.id); g.link(h.id,"derives",c.id)
    g.link(other.id,"derives",other.id) if False else None
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    assert {x.node_id for x in r.items}=={c.id,h.id}
    assert r.counts["cycle_edges"]==1


def test_multiple_roots_deduplicate_shared_dependency_and_keep_paths():
    g=TBOHK(); o1=origin(g,"o1"); o2=origin(g,"o2"); e1=evidence(g,o1,"e1"); e2=evidence(g,o2,"e2"); c=g.add_node("Claim","claim")
    g.link(e1.id,"evidence_for",c.id); g.link(e2.id,"evidence_for",c.id)
    r=DependencyImpactAnalyzer(g).analyze([e2.id,e1.id])
    item=next(x for x in r.items if x.node_id==c.id)
    assert item.roots==tuple(sorted((e1.id,e2.id)))
    assert len(item.paths)==2


def test_investigation_scope_excludes_unrelated_nodes():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim"); h=g.add_node("Hypothesis","h")
    g.link(e.id,"evidence_for",c.id); g.link(c.id,"derives",h.id)
    run=g.add_node("AdaptiveResearchRun","run","supported",{"hypothesis_ids":[h.id],"question":"q"})
    r=DependencyImpactAnalyzer(g).analyze_investigation(run.id,[e.id])
    assert {x.node_id for x in r.items}=={c.id,h.id}


def test_history_is_not_mutated():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim","verified"); g.link(e.id,"evidence_for",c.id)
    before=[(n.id,n.status) for n in [e,c]]
    DependencyImpactAnalyzer(g).analyze([e.id])
    after=[(n.id,n.status) for n in [g.get(e.id),g.get(c.id)]]
    assert after==before


def test_api_impact_route_returns_auditable_report(monkeypatch):
    from fastapi.testclient import TestClient
    import tbohk.api as api
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim")
    g.link(e.id,"evidence_for",c.id)
    monkeypatch.setattr(api, "g", g)
    client=TestClient(api.app)
    response=client.get("/impact", params={"roots":e.id})
    assert response.status_code == 200
    body=response.json()
    assert body["counts"]["total_impacted"] == 1
    assert body["items"][0]["node_id"] == c.id
    assert "boundary" in body


def test_traversal_budget_is_enforced():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim"); g.link(e.id,"evidence_for",c.id)
    with pytest.raises(ValueError, match="max_nodes"):
        DependencyImpactAnalyzer(g).analyze([e.id], max_nodes=1)


def test_decision_and_plan_dependents_are_reached_through_stored_reverse_edges():
    from tbohk.decisions import DecisionEngine
    from tbohk.plans import PlanEngine
    g=TBOHK(); o=origin(g); e=evidence(g,o)
    decision=DecisionEngine(g).propose("decision", ["A"], evidence_ids=[e.id])
    plan=PlanEngine(g).create("plan", ["step"], decision_id=decision.decision_id)
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    ids={x.node_id for x in r.items}
    assert decision.decision_id in ids
    assert plan.plan_id in ids
    assert r.items[-1].node_id == max(ids)


def test_conflict_set_and_resolution_are_impacted_by_member_change():
    from tbohk.epistemic import EpistemicEngine
    g=TBOHK(); o=origin(g); e=evidence(g,o)
    a=g.add_node("Claim","A","verified"); b=g.add_node("Claim","B","verified")
    g.link(e.id,"evidence_for",a.id)
    conflict=EpistemicEngine(g).contradict(a.id,b.id)
    resolution=EpistemicEngine(g).resolve_conflict(conflict.id,"defer",resolver="reviewer")
    r=DependencyImpactAnalyzer(g).analyze([a.id])
    ids={x.node_id for x in r.items}
    assert conflict.id in ids
    assert resolution.id in ids
    assert all(x.impact != "disproven" for x in r.items)


def test_contradicted_root_does_not_automatically_disprove_decision():
    from tbohk.decisions import DecisionEngine
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim","verified")
    g.link(e.id,"evidence_for",c.id)
    decision=DecisionEngine(g).propose("decision", ["A"], evidence_ids=[c.id])
    g.set_status(c.id,"contradicted","new objection")
    r=DependencyImpactAnalyzer(g).analyze([c.id])
    item=next(x for x in r.items if x.node_id==decision.decision_id)
    assert item.impact == "potentially_invalidated"


def test_explicit_invalidation_can_mark_downstream_disproven():
    g=TBOHK(); o=origin(g); e=evidence(g,o); c=g.add_node("Claim","claim","verified")
    g.link(e.id,"evidence_for",c.id); g.link(e.id,"invalidates",c.id)
    r=DependencyImpactAnalyzer(g).analyze([e.id])
    assert next(x for x in r.items if x.node_id==c.id).impact == "disproven"
