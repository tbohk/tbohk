from fastapi.testclient import TestClient
from tbohk import api
from tbohk.core import TBOHK
from tbohk.benchmark import _case
from tbohk.release import ReleaseAuditor


def test_api_research_empty_urls_rejected():
    c=TestClient(api.app)
    r=c.post('/research',json={'query':'x','urls':[]})
    assert r.status_code == 400


def test_api_status_missing_and_protected_paths():
    old=api.g; api.g=TBOHK()
    try:
        c=TestClient(api.app)
        r=c.post('/nodes',json={'kind':'Claim','content':'x','status':'proposed','metadata':{}})
        nid=r.json()['id']
        assert c.post(f'/nodes/{nid}/status',json={'status':'verified','reason':'bad'}).status_code == 403
        assert c.post('/nodes/missing/status',json={'status':'supported','reason':'x'}).status_code == 400
    finally: api.g=old


def test_api_investigation_delta_without_history():
    old=api.g; api.g=TBOHK()
    try:
        assert TestClient(api.app).get('/investigation/missing/delta').status_code == 400
    finally: api.g=old


def test_api_impact_invalid_root():
    old=api.g; api.g=TBOHK()
    try:
        assert TestClient(api.app).get('/impact',params={'roots':'missing'}).status_code in (200,400)
    finally: api.g=old


def test_benchmark_unknown_case_is_rejected():
    try:
        _case('UNKNOWN')
    except KeyError:
        pass
    else:
        raise AssertionError('unknown benchmark case accepted')


def test_release_audit_checkpoint_failure_path():
    g=TBOHK()
    report=ReleaseAuditor(g).audit(checkpoint_id='missing')
    assert not report.passed
    assert any('checkpoint' in f.code for f in report.findings)
