from tbohk.core import TBOHK
from tbohk.hypothesis import HypothesisEngine
from tbohk.prediction import PredictiveReasoner

def setup():
    g=TBOHK(':memory:'); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('Mechanism A explains the observation', predictions=['the mechanism produces higher output'], discriminators=['compare output against baseline'])
    b=h.create('Mechanism B explains the observation', predictions=['the mechanism produces lower output'], discriminators=['compare output against baseline'])
    return g,h,p,a,b

def test_prediction_creation_and_link():
    g,h,p,a,b=setup(); x=p.create_prediction(a.id,'The mechanism produces higher output',discriminator=True)
    assert x.status=='proposed'
    assert any(e['relation']=='predicts' and e['target_id']==x.id for e in g.edges(a.id))

def test_prediction_text_support():
    outcome,_=PredictiveReasoner.assess_text('The system produces higher output','The system produces higher output than baseline')
    assert outcome=='supports'

def test_prediction_text_opposition():
    outcome,_=PredictiveReasoner.assess_text('The system does not produce higher output','The system produces higher output')
    assert outcome=='fails_to_support'

def test_prediction_text_inconclusive():
    outcome,_=PredictiveReasoner.assess_text('The system produces higher output','A completely unrelated observation')
    assert outcome=='inconclusive'

def test_observation_creates_auditable_assessment():
    g,h,p,a,b=setup(); x=p.create_prediction(a.id,'The mechanism produces higher output')
    r=p.assess_observation(x.id,'The mechanism produces higher output',None)
    assert r.outcome=='supports'
    assert g.get(x.id)
    assert any(e['relation']=='evaluated_by' for e in g.edges(x.id))

def test_experiment_design_preserves_competing_hypotheses():
    g,h,p,a,b=setup(); d=p.design_experiment([a.id,b.id])
    assert set(d.hypothesis_ids)=={a.id,b.id}
    assert d.required_observations
    assert d.controls
    assert 'winning' in d.boundary or 'winner' in d.boundary

def test_assessment_does_not_promote_hypothesis():
    g,h,p,a,b=setup(); x=p.create_prediction(a.id,'The mechanism produces higher output')
    p.assess_observation(x.id,'The mechanism produces higher output')
    result=p.update_assessment(a.id)
    assert result['assessment']=='provisional'
    assert g.get(a.id).status=='proposed'

def test_discriminator_is_explicit():
    g,h,p,a,b=setup(); x=p.create_prediction(a.id,'Output exceeds baseline',discriminator=True)
    assert x.discriminator is True


def test_prediction_rejects_missing_evidence_and_deduplicates_assessment():
    from tbohk.core import TBOHK
    from tbohk.hypothesis import HypothesisEngine
    from tbohk.prediction import PredictiveReasoner
    g=TBOHK(); h=HypothesisEngine(g); r=PredictiveReasoner(g)
    hyp=h.create('A', predictions=('red object observed',))
    pred=r.create_prediction(hyp.id,'red object observed')
    import pytest
    with pytest.raises(ValueError):
        r.assess_observation(pred.id,'red object observed','missing')
    a1=r.assess_observation(pred.id,'red object observed')
    a2=r.assess_observation(pred.id,'red object observed')
    assert a1.assessment_id == a2.assessment_id
    assert r.update_assessment(hyp.id)['supporting_predictions'] == 1


def test_adaptive_investigation_prioritizes_unresolved_discriminator():
    from tbohk.core import TBOHK
    from tbohk.hypothesis import HypothesisEngine
    from tbohk.prediction import PredictiveReasoner
    from tbohk.investigation import AdaptiveInvestigator
    g=TBOHK(); h=HypothesisEngine(g); r=PredictiveReasoner(g); i=AdaptiveInvestigator(g)
    a=h.create('A'); b=h.create('B')
    r.create_prediction(a.id,'red object observed',discriminator=True)
    r.create_prediction(b.id,'blue object observed',discriminator=True)
    targets=i.rank_targets([a.id,b.id])
    assert len(targets)==2
    assert all(t.discrimination_potential=='high' for t in targets)
    assert all(not t.assessed for t in targets)


def test_adaptive_investigation_reduces_priority_after_assessment():
    from tbohk.core import TBOHK
    from tbohk.hypothesis import HypothesisEngine
    from tbohk.prediction import PredictiveReasoner
    from tbohk.investigation import AdaptiveInvestigator
    g=TBOHK(); h=HypothesisEngine(g); r=PredictiveReasoner(g); i=AdaptiveInvestigator(g)
    a=h.create('A'); b=h.create('B')
    pa=r.create_prediction(a.id,'red object observed',discriminator=True)
    r.create_prediction(b.id,'blue object observed',discriminator=True)
    before=i.rank_targets([a.id,b.id]); r.assess_observation(pa.id,'red object observed')
    after=i.rank_targets([a.id,b.id])
    assert next(x for x in before if x.prediction_id==pa.id).priority > next(x for x in after if x.prediction_id==pa.id).priority
