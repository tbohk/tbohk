from tbohk.core import TBOHK
from tbohk.hypothesis import HypothesisEngine
from tbohk.prediction import PredictiveReasoner
from tbohk.research import MockProvider, SourceDocument
from tbohk.adaptive import AdaptiveResearchController
from tbohk.investigation_state import InvestigationStateEngine

def test_investigation_state_is_explicit_and_does_not_change_hypothesis_status():
    g=TBOHK(':memory:'); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains observation'); b=h.create('B explains observation')
    p.create_prediction(a.id,'A predicts red',discriminator=True)
    p.create_prediction(b.id,'B predicts blue',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id,b.id],[provider],max_cycles=1)
    st=InvestigationStateEngine(g).build(out.run_id)
    assert st.cycle_count == 1
    assert a.status == 'proposed' and b.status == 'proposed'
    assert g.get(next(e['target_id'] for e in g.edges(out.run_id,direction='out',relation='evaluates') if g.get(e['target_id']).kind=='InvestigationState')).metadata['truth_boundary'].startswith('structural investigation state')

def test_investigation_state_is_deterministic_and_recorded():
    g=TBOHK(':memory:'); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains'); p.create_prediction(a.id,'A predicts red',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id],[provider],max_cycles=1)
    e=InvestigationStateEngine(g)
    x=e.build(out.run_id); y=e.build(out.run_id)
    assert x == y
    assert g.edges(out.run_id,direction='out',relation='evaluates')

def test_provenance_invalid_evidence_does_not_influence_reconciliation(tmp_path):
    from tbohk.core import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK(str(tmp_path/'x.db'))
    h=g.add_node('Hypothesis','h','proposed',{})
    run=g.add_node('AdaptiveResearchRun','q','supported',{'question':'q','hypothesis_ids':[h.id]})
    origin=g.add_node('Origin','o','supported',{})
    good=g.add_node('Evidence','good','supported',{'origin_id':origin.id})
    bad=g.add_node('Evidence','bad','supported',{})
    g.link(h.id,'evidence_for',good.id); g.link(h.id,'evidence_for',bad.id)
    c=g.add_node('AdaptiveResearchCycle','c','supported',{'cycle':1,'evidence_ids':[good.id,bad.id]})
    g.link(run.id,'contains',c.id)
    state=InvestigationStateEngine(g).build(run.id)
    assert state.supporting_evidence == (good.id,)


def test_historical_states_are_revisioned_and_immutable(tmp_path):
    g=TBOHK(str(tmp_path/'history.db')); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains'); b=h.create('B explains')
    p.create_prediction(a.id,'A predicts red',discriminator=True)
    p.create_prediction(b.id,'B predicts blue',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id,b.id],[provider],max_cycles=2)
    history=InvestigationStateEngine(g).history(out.run_id)
    assert len(history) >= 1
    assert [x['state_revision'] for x in history] == list(range(1,len(history)+1))
    if len(history) > 1:
        assert history[1]['previous_state_id'] == history[0]['id']
        assert history[1]['id'] != history[0]['id']
        assert history[0]['cycle_count'] < history[1]['cycle_count']

def test_unrelated_conflict_does_not_contaminate_investigation(tmp_path):
    from tbohk.epistemic import EpistemicEngine
    g=TBOHK(str(tmp_path/'conflict.db')); h=HypothesisEngine(g)
    a=h.create('A explains'); c1=g.add_node('Claim','claim one','supported',{}); c2=g.add_node('Claim','claim two','supported',{})
    other1=g.add_node('Claim','other one','supported',{}); other2=g.add_node('Claim','other two','supported',{})
    conflict=EpistemicEngine(g).contradict(other1.id,other2.id)
    run=g.add_node('AdaptiveResearchRun','q','supported',{'question':'q','hypothesis_ids':[a.id]})
    state=InvestigationStateEngine(g).build(run.id)
    assert conflict.id not in state.unresolved_conflicts

def test_stale_evidence_uses_evidence_derived_snapshot(tmp_path):
    g=TBOHK(str(tmp_path/'stale.db')); h=hyp=HypothesisEngine(g); a=hyp.create('A explains')
    run=g.add_node('AdaptiveResearchRun','q','supported',{'question':'q','hypothesis_ids':[a.id]})
    origin=g.add_node('Origin','o','supported',{})
    snap=g.add_node('SourceSnapshot','old','supported',{'valid_until':'2000-01-01T00:00:00Z'})
    ev=g.add_node('Evidence','old evidence','supported',{'origin_id':origin.id})
    g.link(ev.id,'derived_from',snap.id); g.link(a.id,'evidence_for',ev.id)
    cycle=g.add_node('AdaptiveResearchCycle','c','supported',{'cycle':1,'evidence_ids':[ev.id]}); g.link(run.id,'contains',cycle.id)
    state=InvestigationStateEngine(g).build(run.id,as_of='2026-01-01T00:00:00Z')
    assert state.stale_evidence == (ev.id,)


def test_state_delta_identifies_new_evidence_without_claiming_causation(tmp_path):
    g=TBOHK(str(tmp_path/'delta.db')); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains')
    p.create_prediction(a.id,'A predicts red',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id],[provider],max_cycles=2)
    e=InvestigationStateEngine(g); hist=e.history(out.run_id)
    assert len(hist) >= 1
    if len(hist) > 1:
        d=e.delta(out.run_id,hist[0]['id'],hist[1]['id'])
        assert d.to_revision == 2
        assert 'causal' not in ' '.join(d.candidate_drivers).lower()
        assert d.candidate_drivers


def test_record_delta_is_auditable_and_bound_to_state(tmp_path):
    g=TBOHK(str(tmp_path/'delta_record.db')); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains'); p.create_prediction(a.id,'A predicts red',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id],[provider],max_cycles=1)
    e=InvestigationStateEngine(g); hist=e.history(out.run_id); target=hist[-1]['id']
    d=e.delta(out.run_id,None,target); did=e.record_delta(out.run_id,d)
    node=g.get(did)
    assert node and node.kind == 'InvestigationStateDelta'
    assert node.metadata['to_state_id'] == target
    assert any(e['target_id'] == did for e in g.edges(target,direction='out',relation='records'))


def test_delta_rejects_cross_run_state(tmp_path):
    g=TBOHK(str(tmp_path/'cross.db'))
    r1=g.add_node('AdaptiveResearchRun','r1','supported',{'question':'q','hypothesis_ids':[]})
    r2=g.add_node('AdaptiveResearchRun','r2','supported',{'question':'q','hypothesis_ids':[]})
    s1=g.add_node('InvestigationState','s1','supported',{'run_id':r1.id,'state_revision':1})
    s2=g.add_node('InvestigationState','s2','supported',{'run_id':r2.id,'state_revision':1})
    e=InvestigationStateEngine(g)
    try: e.delta(r1.id,s1.id,s2.id)
    except ValueError: return
    assert False


def test_adaptive_run_records_state_delta_for_each_snapshot(tmp_path):
    g=TBOHK(str(tmp_path/'auto_delta.db')); h=HypothesisEngine(g); p=PredictiveReasoner(g)
    a=h.create('A explains'); p.create_prediction(a.id,'A predicts red',discriminator=True)
    provider=MockProvider('mock',[SourceDocument('s','src','https://x.test','A predicts red','mock','2026-01-01T00:00:00Z','o1')])
    out=AdaptiveResearchController(g).run('question',[a.id],[provider],max_cycles=1)
    states=InvestigationStateEngine(g).history(out.run_id)
    assert states
    sid=states[-1]['id']
    deltas=[g.get(e['target_id']) for e in g.edges(sid,direction='out',relation='records')]
    assert len(deltas)==1
    assert deltas[0].kind=='InvestigationStateDelta'
    assert deltas[0].metadata['to_state_id']==sid
