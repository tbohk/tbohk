from fastapi.testclient import TestClient
from tbohk.core import TBOHK
import tbohk.api as api


def test_command_center_composes_health_attention_and_learning(monkeypatch):
    g=TBOHK()
    claim=g.add_node('Claim','Unsettled claim','unknown',{})
    conflict=g.add_node('ConflictSet','Open disagreement','proposed',{})
    g.add_node('LearningExperience','research: test','supported',{
        'experience_kind':'outcome','task':'research','outcome':'improved','success':True,
        'metadata':{'attention_action':'research','resolution_signal':'improved'}
    })
    monkeypatch.setattr(api,'g',g)
    monkeypatch.setattr(api,'learning_core',__import__('tbohk.learning_core',fromlist=['LearningCore']).LearningCore(g))
    r=TestClient(api.app).get('/command-center')
    assert r.status_code==200
    x=r.json()
    assert x['graph']['nodes']>=3
    assert x['attention']['counts']['open_claims']==1
    assert x['attention']['counts']['conflicts']==1
    assert x['learning']['resolution_counts']['improved']==1
    assert x['learning']['action_signals']['research']['observations']==1
    assert 'Read-only' in x['boundary']
    assert g.get(claim.id).status=='unknown' and g.get(conflict.id).status=='proposed'


def test_command_center_is_bounded(monkeypatch):
    g=TBOHK()
    for i in range(100): g.add_node('Claim',f'claim {i}','unknown',{})
    monkeypatch.setattr(api,'g',g)
    monkeypatch.setattr(api,'learning_core',__import__('tbohk.learning_core',fromlist=['LearningCore']).LearningCore(g))
    x=TestClient(api.app).get('/command-center?limit=3').json()
    assert len(x['attention']['open_claims'])==3
    assert len(x['attention']['conflicts'])==0
    assert len(x['learning']['recent'])<=3
