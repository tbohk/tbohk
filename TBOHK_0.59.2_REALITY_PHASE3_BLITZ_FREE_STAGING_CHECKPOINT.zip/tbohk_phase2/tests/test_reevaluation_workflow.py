import pytest
import json
from tbohk.core import TBOHK
from tbohk.reevaluation import ReEvaluationController, ReEvaluationWorkflow

def setup_graph():
    g=TBOHK(); o=g.add_node('Origin','o','supported'); e=g.add_node('Evidence','e','supported',{'origin_id':o.id}); g.link(e.id,'derived_from_origin',o.id); c=g.add_node('Claim','c','verified'); g.link(e.id,'evidence_for',c.id); q=ReEvaluationController(g).create([e.id]); return g,q,e,c

def test_policy_is_explicit_and_read_only():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); p=w.policy(q.item_ids[0]); assert p.target_id==c.id; assert 'no automatic' in p.authority_boundary; assert g.get(c.id).status=='verified'

def test_assessment_requires_valid_target_and_is_idempotent():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); a=w.submit(q.item_ids[0],assessor_id='independent-1',outcome='contradicts',evidence_ids=[e.id],rationale='review'); b=w.submit(q.item_ids[0],assessor_id='independent-1',outcome='contradicts',evidence_ids=[e.id],rationale='review'); assert a.assessment_id==b.assessment_id; assert g.get(c.id).status=='verified'

def test_assessment_cannot_use_target_as_evidence():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g)
    with pytest.raises(ValueError): w.submit(q.item_ids[0],assessor_id='a',outcome='supports',evidence_ids=[c.id])

def test_proposed_transition_never_changes_target():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[e.id],rationale='review'); t=w.propose_transition(q.item_ids[0]); assert t.proposed_status=='contradicted'; assert t.authorized is False; assert g.get(c.id).status=='verified'; assert g.revisions(c.id)==[]

def test_disagreement_yields_no_proposed_status():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='supports',evidence_ids=[e.id],rationale='support review'); w.submit(q.item_ids[0],assessor_id='b',outcome='contradicts',evidence_ids=[e.id],rationale='review'); t=w.propose_transition(q.item_ids[0]); assert t.proposed_status is None; assert g.get(c.id).status=='verified'

def test_inconclusive_does_not_promote():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='inconclusive',rationale='inconclusive review'); t=w.propose_transition(q.item_ids[0]); assert t.proposed_status is None; assert g.get(c.id).status=='verified'

def test_api_workflow_endpoints():
    import tbohk.api as api
    from fastapi.testclient import TestClient
    g,q,e,c=setup_graph(); old=api.g; api.g=g
    try:
        client=TestClient(api.app)
        p=client.get('/reevaluation-item/'+q.item_ids[0]+'/policy'); assert p.status_code==200
        a=client.post('/reevaluation-item/'+q.item_ids[0]+'/assessment',params={'assessor_id':'api-assessor','outcome':'contradicts','evidence_ids':e.id,'rationale':'api review'}); assert a.status_code==200
        t=client.post('/reevaluation-item/'+q.item_ids[0]+'/propose-transition'); assert t.status_code==200; assert t.json()['authorized'] is False
        assert g.get(c.id).status=='verified'
    finally: api.g=old

def test_policy_never_makes_authority_grant_or_executes_transition():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[e.id],rationale='review'); t=w.propose_transition(q.item_ids[0]); assert t.authorized is False; assert not [g.get(e['target_id']) for e in g.edges(t.transition_id,'out','authorizes')]


def test_critical_reassessment_requires_two_distinct_assessors():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g)
    # Force the review item into a critical class.
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps({**g.get(q.item_ids[0]).metadata, "impact":"potentially_invalidated"}, sort_keys=True), q.item_ids[0])); g.db.commit()
    w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[e.id],rationale='independent review')
    with pytest.raises(ValueError): w.propose_transition(q.item_ids[0])
    w.submit(q.item_ids[0],assessor_id='b',outcome='contradicts',evidence_ids=[e.id],rationale='second independent review')
    t=w.propose_transition(q.item_ids[0]); assert t.proposed_status=='contradicted'

def test_assessment_rejects_non_evidence_and_invalid_provenance():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); bad=g.add_node('Claim','not evidence','supported')
    with pytest.raises(ValueError): w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[bad.id],rationale='bad')
    orphan=g.add_node('Evidence','orphan','supported',{'origin_id':'missing'})
    with pytest.raises(ValueError): w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[orphan.id],rationale='bad provenance')

def test_proposal_rejected_when_target_changed_after_review():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[e.id],rationale='review'); g.set_status(c.id,'stale','changed after review')
    with pytest.raises(ValueError): w.propose_transition(q.item_ids[0])

def test_transition_proposal_is_idempotent():
    g,q,e,c=setup_graph(); w=ReEvaluationWorkflow(g); w.submit(q.item_ids[0],assessor_id='a',outcome='contradicts',evidence_ids=[e.id],rationale='review'); a=w.propose_transition(q.item_ids[0]); b=w.propose_transition(q.item_ids[0]); assert a.transition_id==b.transition_id
