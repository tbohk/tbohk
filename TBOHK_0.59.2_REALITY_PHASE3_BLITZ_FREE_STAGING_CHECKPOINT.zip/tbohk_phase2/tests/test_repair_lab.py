from tbohk.repair_lab import RepairLab


def test_hypothesis_generation_is_bounded_and_deterministic():
    lab = RepairLab()
    a = lab.generate(target="projection", failure_type="stale_projection")
    b = lab.generate(target="projection", failure_type="stale_projection")
    assert a == b and 1 <= len(a) <= 3
    assert all(h.strategy in lab.STRATEGIES for h in a)


def test_minimizer_reduces_to_smallest_reproducing_evidence():
    lab = RepairLab()
    evidence = ("a", "noise", "b", "noise2")
    result = lab.minimize(evidence, lambda xs: "a" in xs and "b" in xs)
    assert result == ("a", "b")


def test_repair_lab_rejects_side_effects():
    lab = RepairLab(); h = lab.generate(target="x", failure_type="missing_link")[0]
    out = lab.evaluate(h, reproduce=lambda: True, apply=lambda _: True, regression=lambda: True, side_effects=lambda: ["unexpected_write"])
    assert not out.accepted and "side-effects-detected" in out.reason
    assert lab.reject_record(out) is not None


def test_repair_lab_accepts_only_full_closed_loop():
    lab = RepairLab(); h = lab.generate(target="x", failure_type="dropped_event")[0]
    out = lab.evaluate(h, reproduce=lambda: True, apply=lambda _: True, regression=lambda: True)
    assert out.accepted and out.digest and len(out.digest) == 64
