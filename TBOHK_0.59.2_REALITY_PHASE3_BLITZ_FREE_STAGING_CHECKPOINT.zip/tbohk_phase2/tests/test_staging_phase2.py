from tbohk.core import TBOHK
from tbohk.staging import StagingOrchestrator
from tbohk.research import SourceDocument, MockProvider, ResearchChain
from tbohk.answer import AnswerPresenter
from tbohk.service import TBOHKService
from datetime import datetime, timezone


def test_staging_module_requires_real_configuration(monkeypatch):
    monkeypatch.delenv("TBOHK_STAGING_URLS", raising=False)
    g = TBOHK(":memory:")
    try:
        StagingOrchestrator(g).run("test question")
    except ValueError as exc:
        assert "TBOHK_STAGING_URLS" in str(exc)
    else:
        raise AssertionError("staging must fail closed without real provider configuration")


def test_staging_workflow_contract_with_real_provider_shape():
    g = TBOHK(":memory:")
    doc = SourceDocument(
        "source-a", "Source A", "https://example.com/a", "The evidence says the project exists.",
        "staging-test", datetime.now(timezone.utc).isoformat(), "example.com"
    )
    out = ResearchChain(g, [MockProvider("staging-test", [doc])]).run("project exists")
    assert out["results"]
    evidence_id = out["results"][0][1].id
    TBOHKService(g).create_claim("The project exists.", [evidence_id])
    answer = AnswerPresenter(g).build("project exists")
    assert answer["sources"]
    assert answer["truth_boundary"]


def test_direct_url_provider_uses_only_explicit_staging_proxy(monkeypatch):
    from tbohk.service import DirectURLProvider
    import urllib.request
    captured = {}
    real = urllib.request.build_opener
    def fake(*handlers):
        captured["handlers"] = handlers
        return object()
    monkeypatch.setattr(urllib.request, "build_opener", fake)
    p = DirectURLProvider(["https://example.com"], proxy="http://proxy.example:8080")
    p._opener()
    assert any(getattr(h, "proxies", {}).get("https") == "http://proxy.example:8080" for h in captured["handlers"])
    assert p.proxy == "http://proxy.example:8080"
