import json
from tbohk import TBOHK, CheckpointManager, IntegrityAuditor


def make_checkpoint():
    g = TBOHK()
    g.add_node('Claim', 'stable claim', status='supported')
    cp = CheckpointManager(g).create(
        code_version='g13-test', schema_version='1', invariant_version='g13',
        test_summary={'passed': 1}, dependency_versions={}
    )
    return g, cp


def test_g13_checkpoint_covers_graph_state():
    g, cp = make_checkpoint()
    report = IntegrityAuditor(g).audit_checkpoint(cp.checkpoint_id)
    assert report.passed
    assert report.findings == ()


def test_g13_node_tamper_is_detected():
    g, cp = make_checkpoint()
    row = g.db.execute("SELECT id FROM nodes WHERE kind='Claim'").fetchone()
    g.db.execute("UPDATE nodes SET content='tampered' WHERE id=?", (row['id'],))
    g.db.commit()
    report = IntegrityAuditor(g).audit_checkpoint(cp.checkpoint_id)
    assert not report.passed
    assert any(f.code == 'node_hash_mismatch' for f in report.findings)


def test_g13_edge_tamper_is_detected():
    g = TBOHK()
    a = g.add_node('Claim', 'a')
    b = g.add_node('Claim', 'b')
    g.link(a.id, 'supports', b.id)
    cp = CheckpointManager(g).create(
        code_version='g13-test', schema_version='1', invariant_version='g13',
        test_summary={'passed': 1}, dependency_versions={}
    )
    g.db.execute("DELETE FROM edges WHERE source_id=? AND target_id=?", (a.id, b.id))
    g.db.commit()
    report = IntegrityAuditor(g).audit_checkpoint(cp.checkpoint_id)
    assert not report.passed
    assert any(f.code == 'edge_hash_mismatch' for f in report.findings)


def test_g13_manifest_tamper_is_detected():
    g, cp = make_checkpoint()
    row = g.db.execute('SELECT metadata FROM nodes WHERE id=?', (cp.checkpoint_id,)).fetchone()
    meta = json.loads(row['metadata'])
    meta['manifest']['code_version'] = 'forged'
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?', (json.dumps(meta), cp.checkpoint_id))
    g.db.commit()
    report = IntegrityAuditor(g).audit_checkpoint(cp.checkpoint_id)
    assert not report.passed
    assert any(f.code == 'manifest_hash_mismatch' for f in report.findings)
