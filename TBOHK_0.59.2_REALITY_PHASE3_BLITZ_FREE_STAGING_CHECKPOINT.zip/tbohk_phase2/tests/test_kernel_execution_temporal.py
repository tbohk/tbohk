from tbohk.core import TBOHK
from tbohk.kernel import DomainKernel, KindSpec
from tbohk.execution import BoundedExecutor
from tbohk.temporal_query import TemporalQuery


def test_domain_kernel_validates_and_reports():
    g=TBOHK(); k=DomainKernel(g); k.register_defaults()
    c=g.add_node('Claim','x','proposed',{'subject':'x'})
    assert k.inspect(c.id)['valid']
    bad=g.add_node('Unknown','u','unknown',{'scope':'s','basis':'b'})
    assert k.inspect(bad.id)['valid']
    assert k.graph_invariants()['valid']


def test_bounded_executor_is_idempotent():
    g=TBOHK(); t=g.add_node('MaintenanceTask','test','proposed',{'task_kind':'safe','reversible':True})
    e=BoundedExecutor(g); calls=[]
    e.register('safe',lambda m: calls.append(1) or {'state':'completed','value':42})
    a=e.execute(t.id); b=e.execute(t.id)
    assert a.id==b.id and len(calls)==1 and a.result['value']==42


def test_temporal_query_exposes_active_and_invalid():
    g=TBOHK()
    a=g.add_node('Claim','active','supported',{'subject':'a','valid_from':'2026-01-01T00:00:00+00:00','valid_until':'2027-01-01T00:00:00+00:00'})
    g.add_node('Claim','bad','supported',{'subject':'b','valid_from':'not-a-date'})
    r=TemporalQuery(g).active(at='2026-09-27T00:00:00+00:00',kinds=['Claim'])
    assert any(x['id']==a.id for x in r['items']) and len(r['invalid_intervals'])==1
