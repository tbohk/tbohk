import pytest
from tbohk.core import TBOHK
from tbohk.learning_core import LearningCore
from tbohk.learning_experiments import LearningExperimentEngine


def _dataset():
    g=TBOHK(); c=LearningCore(g)
    for i in range(40):
        task=('success retrieval evidence ' if i%2==0 else 'failure retrieval error ') + str(i)
        c.record_experience('interaction', task, 'completed' if i%2==0 else 'failed', success=i%2==0, source='test')
    return g, c.build_dataset(limit=40, validation_fraction=.5, record=True)


def test_isolated_adapter_experiment_is_reproducible_and_content_addressed():
    g, d = _dataset(); e=LearningExperimentEngine(g)
    a=e.run(d['dataset_id'], epochs=6, learning_rate=.2)
    b=e.run(d['dataset_id'], epochs=6, learning_rate=.2)
    assert a.candidate_artifact_sha256 == b.candidate_artifact_sha256
    assert a.dataset_manifest_sha256 == d['manifest_sha256']
    assert a.training_count and a.validation_count
    assert g.get(a.experiment_id).kind == 'LearningExperiment'


def test_isolated_adapter_rejects_bad_dataset_and_parameters():
    g=TBOHK(); c=LearningCore(g); d=c.build_dataset(record=True)
    e=LearningExperimentEngine(g)
    with pytest.raises(ValueError): e.run(d['dataset_id'])
    with pytest.raises(ValueError): e.run(d['dataset_id'], epochs=0)
    with pytest.raises(ValueError): e.run(d['dataset_id'], learning_rate=0)
    with pytest.raises(ValueError): e.report('missing')


def test_isolated_adapter_report_preserves_boundary():
    g,d=_dataset(); r=LearningExperimentEngine(g).run(d['dataset_id'])
    out=LearningExperimentEngine(g).report(r.experiment_id)
    assert out['dataset_manifest_sha256'] == d['manifest_sha256']
    assert out['candidate_artifact_sha256']
    assert out['status'] in {'proposed','candidate_ready','rejected'}

def test_isolated_adapter_internal_guard_branches(monkeypatch):
    g,d=_dataset(); e=LearningExperimentEngine(g)
    with pytest.raises(ValueError): e._dataset('missing')
    assert e._baseline([{'success':None}]) == (None,None)
    bad=g.add_node('LearningDataset','bad','proposed',{'training':[{'task':'x','success':None}], 'validation':[{'task':'x','success':None}]})
    with pytest.raises(ValueError): e.run(bad.id)
    one=g.add_node('LearningDataset','one','proposed',{'training':[{'task':'x','success':True}], 'validation':[{'task':'x','success':True}]})
    with pytest.raises(ValueError): e.run(one.id)
    monkeypatch.setattr(e, '_baseline', lambda validation: (None, None))
    r=e.run(d['dataset_id'])
    assert r.status == 'rejected' and 'baseline could not be evaluated' in r.reasons
    monkeypatch.setattr(e, '_baseline', lambda validation: (1.1, 1))
    r=e.run(d['dataset_id'])
    assert r.status == 'rejected' and 'candidate accuracy regresses against baseline' in r.reasons
