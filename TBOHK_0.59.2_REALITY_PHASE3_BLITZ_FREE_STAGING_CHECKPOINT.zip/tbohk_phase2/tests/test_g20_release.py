from tbohk import *

def test_release_blocks_verified_recovery_without_independent_validation():
    g=TBOHK(); re=RecoveryEngine(g); i=re.detect('corruption',['x']); p=re.propose(i.id,'repair',rollback='restore',diagnosis='bad'); g.set_status(p.id,'verified','forged apply')
    report=RecoveryLifecycleAuditor(g).audit(); assert any(f.code=='recovery_without_independent_validation' for f in report)

def test_release_accepts_independently_validated_recovery():
    g=TBOHK(); re=RecoveryEngine(g); i=re.detect('corruption',['x']); p=re.propose(i.id,'repair',rollback='restore',diagnosis='bad'); v=re.validate(p.id); re.apply(p.id,validation_id=v.validation_id)
    assert not RecoveryLifecycleAuditor(g).audit()
