import pytest
from tbohk.observability import Metrics

def test_metrics_snapshot_and_recent():
    m=Metrics(); m.record('/x','GET',200,10,'r1','a'); m.record('/x','GET',500,20,'r2'); m.record('/y','POST',201,5,'r3')
    s=m.snapshot(); assert s['requests']==3 and s['server_errors']['/x GET']==1 and s['latency_ms']['p95']>=10
    assert len(m.recent(2))==2

def test_metrics_validation_and_cap():
    m=Metrics()
    with pytest.raises(ValueError): m.record('','GET',200,1,'r')
    with pytest.raises(ValueError): m.record('/','',200,1,'r')
    with pytest.raises(ValueError): m.record('/','GET',200,1,'')
    with pytest.raises(ValueError): m.recent(0)
    for i in range(5100): m.record('/','GET',200,i%3,f'r{i}')
    assert m.snapshot()['requests']==5000

def test_empty_snapshot_and_timers():
    from tbohk.observability import request_timer, elapsed_ms
    m=Metrics(); assert m.snapshot()['latency_ms']=={'p50':0.0,'p95':0.0,'p99':0.0}
    s=request_timer(); assert elapsed_ms(s)>=0
    with pytest.raises(ValueError): elapsed_ms('bad')
