import os, tempfile

def test_foundation_query_cache_and_related():
    from tbohk.core import TBOHK
    from tbohk.query_engine import QueryEngine
    g=TBOHK()
    a=g.add_node('Claim','alpha knowledge','proposed',{})
    b=g.add_node('Evidence','alpha source','supported',{})
    g.link(b.id,'evidence_for',a.id)
    q=QueryEngine(g,ttl=60)
    first=q.search('alpha'); second=q.search('alpha')
    assert first.items and second.cached and q.related(a.id)[0]['id'] in {a.id,b.id}
    assert q.health()['fts5'] is True

def test_workflow_engine_is_bounded_and_reversible():
    from tbohk.core import TBOHK
    from tbohk.workflow_engine import WorkflowEngine
    g=TBOHK(); w=WorkflowEngine(g)
    task=w.create('recheck','Recheck alpha','stale evidence',priority=88)
    assert task['reversible'] is True and task['status']=='proposed'
    assert w.plan(100)[0]['id']==task['id']

def test_event_bus_isolation_and_capability_registry():
    from tbohk.foundation import EventBus, Capability, CapabilityRegistry
    seen=[]; bus=EventBus(); bus.subscribe('x',lambda e:seen.append(e.payload['v']))
    bus.publish('x','n',{'v':3}); bus.publish('y','n',{'v':4})
    assert seen==[3]
    reg=CapabilityRegistry(); reg.register(Capability('a','A','core','desc'))
    assert reg.list()[0]['id']=='a'

def test_system_foundation_endpoints():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g=TBOHK(); api.service=__import__('tbohk.service',fromlist=['TBOHKService']).TBOHKService(api.g)
    c=TestClient(api.app)
    assert c.get('/system/capabilities').status_code==200
    overview=c.get('/system/overview'); assert overview.status_code==200 and overview.json()['version']==__import__('tbohk').__version__
    api.g.add_node('Claim','foundation search alpha','proposed',{})
    result=c.get('/system/search?q=alpha'); assert result.status_code==200 and result.json()['items']
