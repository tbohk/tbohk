import json, sqlite3, tempfile
from pathlib import Path
from tbohk import TBOHK, CheckpointManager, AnchorStore, StateTransitionEngine, RecoveryDrill
from tbohk.invariants import INVARIANTS, transition_rule
from tbohk.serialization import canonical_json, sha256, envelope, verify_envelope
from tbohk.migrations import CURRENT_SCHEMA_VERSION
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def test_invariant_registry_is_unique_and_complete():
    ids=[i.id for i in INVARIANTS]
    assert len(ids)==len(set(ids))
    assert {"I1","I9","I10","I20"}.issubset(ids)


def test_canonical_serialization_is_stable_and_nan_free():
    assert canonical_json({"b":1,"a":[2,3]}) == '{"a":[2,3],"b":1}'
    assert sha256({"b":1,"a":2}) == sha256({"a":2,"b":1})
    e=envelope("checkpoint",{"x":1}); assert verify_envelope(e,"checkpoint")


def test_migrations_are_monotonic_and_recorded():
    g=TBOHK()
    assert g.migrations.current_version()==CURRENT_SCHEMA_VERSION
    report=g.migrations.verify(); assert report["ok"]
    assert [x.version for x in g.migrations.history()]==[1,2,3]


def test_state_machine_rejects_backward_transition():
    g=TBOHK(); n=g.add_node('Claim','x','proposed')
    assert not StateTransitionEngine(g).assess(n.id,'unknown').allowed
    try: StateTransitionEngine(g).transition(n.id,'unknown',reason='bad')
    except ValueError: pass
    else: assert False


def test_state_machine_requires_workflow_for_sensitive_transition():
    g=TBOHK(); n=g.add_node('Claim','x','supported'); sm=StateTransitionEngine(g)
    try: sm.transition(n.id,'verified',reason='missing workflow')
    except PermissionError: pass
    else: assert False
    sm.transition(n.id,'verified',reason='reviewed',workflow='human-review')
    assert g.get(n.id).status=='verified'


def test_external_anchor_round_trip():
    g=TBOHK(); g.add_node('Claim','x'); cp=CheckpointManager(g).create(code_version='0.28',schema_version='2',invariant_version='I20',test_summary={'passed':1})
    key=Ed25519PrivateKey.generate(); path=Path(tempfile.mktemp())
    try:
        store=AnchorStore(path,key,'test-key'); a=CheckpointManager(g).external_anchor(cp.checkpoint_id,store)
        report=AnchorStore.verify_file(path,{'test-key':key.public_key().public_bytes_raw()})
        assert report['ok'] and a.manifest_sha256==cp.manifest_sha256
    finally: path.unlink(missing_ok=True)


def test_anchor_refuses_unverifiable_checkpoint():
    g=TBOHK(); cp=CheckpointManager(g).create(code_version='0.28',schema_version='2',invariant_version='I20',test_summary={'passed':1})
    g.add_node('Claim','after')
    key=Ed25519PrivateKey.generate(); path=Path(tempfile.mktemp())
    try:
        try: CheckpointManager(g).external_anchor(cp.checkpoint_id,AnchorStore(path,key))
        except ValueError: pass
        else: assert False
    finally: path.unlink(missing_ok=True)


def test_corruption_drill_detects_deleted_event(tmp_path):
    path=tmp_path/'tbohk.sqlite'; g=TBOHK(str(path)); g.add_node('Claim','x'); g._event('drill-target','x',{'x':1}); g.db.commit()
    results=RecoveryDrill(g).run(); assert results[0].detected and results[0].independent_detected


def test_state_audit_detects_invalid_historical_transition():
    g=TBOHK(); n=g.add_node('Claim','x','unknown')
    g.set_status(n.id,'verified','forged fixture')
    findings=StateTransitionEngine(g).audit()
    assert any(f['code']=='invalid_status_transition' for f in findings)


def test_migrations_are_idempotent():
    g=TBOHK(); before=g.migrations.history(); g.migrations.migrate(); after=g.migrations.history()
    assert before==after


def test_external_anchor_tamper_is_detected(tmp_path):
    g=TBOHK(); cp=CheckpointManager(g).create(code_version='0.28',schema_version='2',invariant_version='I20',test_summary={'passed':1})
    key=Ed25519PrivateKey.generate(); path=tmp_path/'anchors.jsonl'; store=AnchorStore(path,key,'k'); store.append(cp.checkpoint_id,cp.manifest,cp.manifest_sha256)
    raw=path.read_text().replace('"checkpoint_id":"'+cp.checkpoint_id+'"','"checkpoint_id":"tampered"')
    path.write_text(raw)
    report=AnchorStore.verify_file(path,{'k':key.public_key().public_bytes_raw()})
    assert not report['ok'] and any('signature_invalid' in x for x in report['findings'])


def test_external_anchor_sequence_gap_is_detected(tmp_path):
    g=TBOHK(); cp=CheckpointManager(g).create(code_version='0.28',schema_version='2',invariant_version='I20',test_summary={'passed':1})
    key=Ed25519PrivateKey.generate(); path=tmp_path/'anchors.jsonl'; store=AnchorStore(path,key,'k'); store.append(cp.checkpoint_id,cp.manifest,cp.manifest_sha256)
    second=store.append(cp.checkpoint_id,cp.manifest,cp.manifest_sha256)
    lines=path.read_text().splitlines(); import json; obj=json.loads(lines[1]); obj['sequence']=3; path.write_text(lines[0]+'\n'+json.dumps(obj)+'\n')
    report=AnchorStore.verify_file(path,{'k':key.public_key().public_bytes_raw()})
    assert not report['ok'] and any(x.startswith('sequence_gap:3') for x in report['findings'])


def test_selfcare_reports_schema_and_transition_checks():
    from tbohk.selfcare import SelfCareEngine
    g=TBOHK(); report=SelfCareEngine(g).inspect(); codes={c.code for c in report.checks}
    assert {'schema_migrations','state_transitions'}.issubset(codes)
    assert report.passed


def test_release_auditor_blocks_invalid_transition():
    from tbohk.release import ReleaseAuditor
    g=TBOHK(); n=g.add_node('Claim','x','unknown'); g.set_status(n.id,'verified','forged fixture')
    report=ReleaseAuditor(g).audit()
    assert not report.passed and any(f.code=='STATE:invalid_status_transition' for f in report.findings)
