from tbohk import TBOHK, ReleaseAuditor, RealityEngine
from tbohk.governance import GovernanceEngine
from tbohk.actions import ActionLedger
from tbohk.checkpoints import CheckpointManager


def test_g12_clean_graph_passes_release_audit():
    g = TBOHK()
    report = ReleaseAuditor(g).audit()
    assert report.passed is True
    assert report.findings == ()


def test_g12_failed_action_cannot_become_verified_by_reality_verification():
    g = TBOHK(); ge = GovernanceEngine(g); al = ActionLedger(g); re = RealityEngine(g)
    grant = ge.grant('agent', ['execute_action'], approver='root')
    ge.approve_grant(grant.id, approver='root')
    a = al.propose('agent', 'switch', 'switch-1', 'on', authority_grant_id=grant.id)
    al.authorize(a.id, grant.id)
    al.record_execution(a.id, 'off', success=False)
    o = re.observe('sensor', 'switch-1=off')
    v = re.verify_action(a.id, o.id, expected_effect='on', actual_effect='off')
    assert v.metadata['verified'] is False
    assert g.get(a.id).status == 'failed'


def test_g12_checkpoint_integrity_is_release_checked():
    g = TBOHK()
    cp = CheckpointManager(g).create(
        code_version='g12-test', schema_version='1', invariant_version='g12',
        test_summary={'passed': 1}, dependency_versions={}
    )
    assert CheckpointManager(g).verify(cp.checkpoint_id)
    assert ReleaseAuditor(g).audit(checkpoint_id=cp.checkpoint_id).passed is True


def test_g12_tampered_checkpoint_blocks_release():
    g = TBOHK()
    cp = CheckpointManager(g).create(
        code_version='g12-test', schema_version='1', invariant_version='g12',
        test_summary={'passed': 1}, dependency_versions={}
    )
    row = g.db.execute('SELECT metadata FROM nodes WHERE id=?', (cp.checkpoint_id,)).fetchone()
    import json
    meta = json.loads(row['metadata'])
    meta['manifest']['code_version'] = 'tampered'
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?', (json.dumps(meta), cp.checkpoint_id))
    g.db.commit()
    report = ReleaseAuditor(g).audit(checkpoint_id=cp.checkpoint_id)
    assert report.passed is False
    assert any(f.code == 'G12:checkpoint_integrity_failure' for f in report.findings)


def test_g13_integrity_failure_blocks_release_after_node_tamper():
    g = TBOHK()
    g.add_node('Claim', 'stable')
    cp = CheckpointManager(g).create(
        code_version='g13-test', schema_version='1', invariant_version='g13',
        test_summary={'passed': 1}, dependency_versions={}
    )
    row = g.db.execute("SELECT id FROM nodes WHERE kind='Claim'").fetchone()
    g.db.execute("UPDATE nodes SET content='tampered' WHERE id=?", (row['id'],))
    g.db.commit()
    report = ReleaseAuditor(g).audit(checkpoint_id=cp.checkpoint_id)
    assert not report.passed
    assert any(f.code == 'G13:node_hash_mismatch' for f in report.findings)
