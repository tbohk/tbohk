import pytest
from tbohk.core import TBOHK
from tbohk.learning_core import LearningCore
from tbohk.learning_experiments import LearningExperimentEngine
from tbohk.learning_canary import LearningCanaryEngine


def _ready():
    g=TBOHK(); c=LearningCore(g)
    for i in range(40):
        c.record_experience('interaction', ('success evidence ' if i%2==0 else 'failure error ')+str(i), 'ok' if i%2==0 else 'bad', success=i%2==0)
    d=c.build_dataset(limit=40, validation_fraction=.5, record=True)
    r=LearningExperimentEngine(g).run(d['dataset_id'])
    return g,r


def test_canary_continue_and_report():
    g,r=_ready(); e=LearningCanaryEngine(g)
    d=e.run(r.experiment_id, observations=100, error_rate=.01, latency_ms=100, baseline_latency_ms=100)
    assert d.decision=='continue' and not d.rollback_required
    out=e.report(d.canary_id)
    assert out['decision']=='continue' and out['observations']==100


def test_canary_rolls_back_on_error_and_latency():
    g,r=_ready(); e=LearningCanaryEngine(g)
    d=e.run(r.experiment_id, observations=100, error_rate=.2, latency_ms=130, baseline_latency_ms=100)
    assert d.decision=='rollback' and d.rollback_required
    assert g.db.execute("SELECT 1 FROM nodes WHERE kind='LearningRollback'").fetchone()


def test_canary_rejects_invalid_inputs_and_non_candidate():
    g=TBOHK(); e=LearningCanaryEngine(g)
    with pytest.raises(ValueError): e.run('missing', observations=1, error_rate=0, latency_ms=1, baseline_latency_ms=1)
    n=g.add_node('LearningExperiment','x','proposed',{'status':'rejected'})
    with pytest.raises(ValueError): e.run(n.id, observations=1, error_rate=0, latency_ms=1, baseline_latency_ms=1)
    with pytest.raises(ValueError): e.run(n.id, observations=0, error_rate=0, latency_ms=1, baseline_latency_ms=1)
    with pytest.raises(ValueError): e.run(n.id, observations=1, error_rate=-1, latency_ms=1, baseline_latency_ms=1)
    with pytest.raises(ValueError): e.run(n.id, observations=1, error_rate=0, latency_ms=1, baseline_latency_ms=1, max_error_rate=2)
    with pytest.raises(ValueError): e.report('missing')

def test_canary_zero_baseline_latency_guard():
    g,r=_ready(); e=LearningCanaryEngine(g)
    d=e.run(r.experiment_id, observations=2, error_rate=0, latency_ms=1, baseline_latency_ms=0)
    assert d.decision == 'rollback'
    assert 'canary latency regression exceeds budget' in d.reasons


def test_canary_api_paths(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    api.g=TBOHK(); api.learning_canary=LearningCanaryEngine(api.g)
    c=TestClient(api.app)
    assert c.post('/learning/canaries?experiment_id=missing&observations=1&error_rate=0&latency_ms=1&baseline_latency_ms=1').status_code == 400
    monkeypatch.setattr(api.learning_canary, 'run', lambda *a, **k: (_ for _ in ()).throw(RuntimeError('canary')))
    assert c.post('/learning/canaries?experiment_id=x&observations=1&error_rate=0&latency_ms=1&baseline_latency_ms=1').status_code == 500
    assert c.get('/learning/canaries/missing').status_code == 400
