import pytest
from fastapi.testclient import TestClient

def test_verifier_rejects_unconfigured_provider():
    from tbohk.store_billing import StorePurchaseVerifier, PurchaseVerificationError
    with pytest.raises(PurchaseVerificationError, match='not configured'):
        StorePurchaseVerifier().verify('apple', {'purchase_id':'x'}, 'acct')

def test_verifier_normalizes_only_adapter_authority():
    from tbohk.store_billing import StorePurchaseVerifier
    v=StorePurchaseVerifier({'apple':lambda p:{'purchase_id':'tx','product_id':'tbohk.pro','plan':'pro','status':'active','transaction_id':'tx','raw':{'verified':True}}})
    got=v.verify('apple', {'purchase_id':'client','plan':'unlimited','status':'active'}, 'acct_1')
    assert got.plan=='pro' and got.purchase_id=='tx'

def test_store_verify_endpoint_uses_server_account_and_verifier(monkeypatch):
    import tbohk.api as api
    api.store_verifier.adapters['google']=lambda p:{'purchase_id':'gp1','product_id':'tbohk.unlimited','plan':'unlimited','status':'active'}
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'storetest@example.com','password':'long-password-123','name':'Store Test'})
    assert r.status_code==200
    token=r.json()['token']; h={'Authorization':'Bearer '+token}
    r=c.post('/billing/store/verify',headers=h,json={'provider':'google','purchase':{'purchase_id':'client','plan':'free'}})
    assert r.status_code==200 and r.json()['verified'] is True
    assert c.get('/billing/entitlements',headers=h).json()['plan']=='unlimited'

def test_store_event_is_idempotent():
    import tbohk.api as api
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'eventtest@example.com','password':'long-password-123','name':'Event Test'})
    token=r.json()['token']; h={'Authorization':'Bearer '+token}
    body={'provider':'apple','event_type':'DID_RENEW','payload':{'transactionId':'a1'}}
    assert c.post('/billing/store/event',headers=h,json=body).json()['duplicate'] is False
    assert c.post('/billing/store/event',headers=h,json=body).json()['duplicate'] is True

def test_store_event_rejects_stale_timestamp():
    import tbohk.api as api
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'staletest@example.com','password':'long-password-123','name':'Stale Test'})
    h={'Authorization':'Bearer '+r.json()['token']}
    body={'provider':'google','event_type':'SUBSCRIPTION_EXPIRED','occurred_at':'2000-01-01T00:00:00+00:00','payload':{}}
    assert c.post('/billing/store/event',headers=h,json=body).status_code==400

def test_verifier_rejects_invalid_provider_account_and_adapter_errors():
    from tbohk.store_billing import StorePurchaseVerifier, PurchaseVerificationError
    with pytest.raises(PurchaseVerificationError, match='unsupported'):
        StorePurchaseVerifier().verify('stripe', {}, 'a')
    with pytest.raises(PurchaseVerificationError, match='account identity'):
        StorePurchaseVerifier({'apple':lambda p:{}}).verify('apple', {}, '')
    with pytest.raises(PurchaseVerificationError, match='purchase verification failed'):
        StorePurchaseVerifier({'apple':lambda p:(_ for _ in ()).throw(RuntimeError())}).verify('apple', {}, 'a')
    with pytest.raises(PurchaseVerificationError, match='store verifier returned'):
        StorePurchaseVerifier({'apple':lambda p:None}).verify('apple', {}, 'a')

def test_verifier_rejects_bad_verified_payloads_and_preserves_adapter_error():
    from tbohk.store_billing import StorePurchaseVerifier, PurchaseVerificationError
    for data, msg in [({'purchase_id':'x'},'missing required'),({'purchase_id':'x','product_id':'p','plan':'gold','status':'active'},'invalid plan'),({'purchase_id':'x','product_id':'p','plan':'pro','status':'bogus'},'invalid status')]:
        with pytest.raises(PurchaseVerificationError, match=msg):
            StorePurchaseVerifier({'apple':lambda p,d=data:d}).verify('apple', {}, 'a')
    def fail(_): raise PurchaseVerificationError('provider rejected')
    with pytest.raises(PurchaseVerificationError, match='provider rejected'):
        StorePurchaseVerifier({'apple':fail}).verify('apple', {}, 'a')

def test_event_timestamp_validation_and_determinism():
    from tbohk.store_billing import validate_event_timestamp, deterministic_event_id, PurchaseVerificationError
    assert validate_event_timestamp(None) is None
    validate_event_timestamp('2026-09-26T00:00:00+00:00', max_age_seconds=10**9)
    with pytest.raises(PurchaseVerificationError, match='invalid event timestamp'):
        validate_event_timestamp('not-a-date')
    assert deterministic_event_id('apple', {'b':2,'a':1}) == deterministic_event_id('apple', {'a':1,'b':2})

def test_store_verify_http_maps_verification_error():
    import tbohk.api as api
    api.store_verifier.adapters['apple']=lambda p: {'purchase_id':'x','product_id':'p','plan':'bogus','status':'active'}
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'badstore@example.com','password':'long-password-123','name':'Bad Store'})
    h={'Authorization':'Bearer '+r.json()['token']}
    assert c.post('/billing/store/verify',headers=h,json={'provider':'apple','purchase':{}}).status_code==400

def test_store_event_rejects_unknown_provider():
    import tbohk.api as api
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'unknownstore@example.com','password':'long-password-123','name':'Unknown Store'})
    h={'Authorization':'Bearer '+r.json()['token']}
    assert c.post('/billing/store/event',headers=h,json={'provider':'stripe','event_type':'x','payload':{}}).status_code==400

def test_store_notification_helpers_cover_lookup_and_apply():
    import tbohk.api as api
    from tbohk.store_billing import VerifiedPurchase
    assert api._find_store_account('apple', []) is None
    v=VerifiedPurchase('apple','p1','acct','tbohk.pro','pro','active',transaction_id='tx',original_transaction_id='orig')
    assert api._apply_store_purchase(v,'acct')['provider']=='apple'
    assert api._find_store_account('apple',['orig'])=='acct'


def test_store_notification_http_paths(monkeypatch):
    import asyncio
    import tbohk.api as api
    from tbohk.store_billing import VerifiedPurchase
    class Req:
        def __init__(self, body, auth='Bearer test'): self._body=body; self.headers={'authorization':auth}
        async def json(self): return self._body
    account='acct_notification_test'
    # Bind identities directly to the provider entitlement ledger for server-to-server callbacks.
    api.account_manager.db.execute("INSERT OR IGNORE INTO accounts(id,name) VALUES (?,?)",(account,'Notification Test'))
    api.account_manager.db.commit()
    vp=VerifiedPurchase('apple','orig','acct','tbohk.pro','pro','active',transaction_id='tx',original_transaction_id='orig')
    def apple_fake(jws, root):
        if jws == 'x': return ({},{'data':{'signedTransactionInfo':'txjws'},'notificationUUID':'n1','notificationType':'DID_RENEW'})
        return ({},{'originalTransactionId':'orig','transactionId':'tx'})
    monkeypatch.setattr('tbohk.store_providers.verify_apple_jws',apple_fake)
    monkeypatch.setattr(api.apple_store_verifier,'root_pem','root')
    monkeypatch.setattr(api.apple_store_verifier,'verify',lambda p: vp)
    api.account_manager.upsert_entitlement(account,'apple','orig','pro','active')
    first=asyncio.run(api.apple_store_notification(Req({'signedPayload':'x'})))
    assert first['applied'] is True
    second=asyncio.run(api.apple_store_notification(Req({'signedPayload':'x'})))
    assert second['duplicate'] is True
    async def verify_oidc(_): return {}
    monkeypatch.setattr(api.google_rtdn_verifier,'verify_oidc',verify_oidc)
    monkeypatch.setattr(api.google_rtdn_verifier,'decode_pubsub',lambda b:{'subscriptionNotification':{'purchaseToken':'gpt'}})
    gvp=VerifiedPurchase('google','gpt',account,'tbohk.pro','pro','active',transaction_id='o',original_transaction_id='gpt')
    monkeypatch.setattr(api.google_play_verifier,'verify',lambda p:gvp)
    api.account_manager.upsert_entitlement(account,'google','gpt','pro','active')
    monkeypatch.setattr(api, '_apply_store_purchase', lambda verified, account_id: {'ok': True})
    monkeypatch.setattr(api.account_manager, 'record_billing_event', lambda *a, **k: True)
    monkeypatch.setattr(api, 'deterministic_event_id', lambda *a, **k: 'google-test-event')
    got=asyncio.run(api.google_play_rtdn(Req({'message':{'data':'x'}})))
    assert got['applied'] is True


def test_store_notification_error_and_duplicate_branches(monkeypatch):
    import asyncio
    import tbohk.api as api
    from fastapi import HTTPException
    class Req:
        def __init__(self, body, auth='Bearer x'): self._body=body; self.headers={'authorization':auth}
        async def json(self): return self._body
    try: asyncio.run(api.apple_store_notification(Req({})))
    except HTTPException as e: assert e.status_code==400
    async def bad_apple(_): raise RuntimeError('boom')
    # Make JSON decoding itself fail to exercise the generic Apple notification guard.
    class BadReq(Req):
        async def json(self): raise RuntimeError('boom')
    try: asyncio.run(api.apple_store_notification(BadReq({})))
    except HTTPException as e: assert e.status_code==400 and e.detail=='invalid Apple notification'
    from tbohk.store_billing import PurchaseVerificationError
    monkeypatch.setattr(api.google_rtdn_verifier,'verify_oidc',lambda _: (_ for _ in ()).throw(PurchaseVerificationError('bad oidc')))
    try: asyncio.run(api.google_play_rtdn(Req({'message':{'data':'x'}})))
    except HTTPException as e: assert e.status_code==400 and e.detail=='bad oidc'
    async def verify_oidc(_): return {}
    monkeypatch.setattr(api.google_rtdn_verifier,'verify_oidc',verify_oidc)
    monkeypatch.setattr(api.google_rtdn_verifier,'decode_pubsub',lambda _: {'subscriptionNotification':{'purchaseToken':'dup-token'}})
    monkeypatch.setattr(api, '_find_store_account', lambda *a: 'acct_notification_test')
    monkeypatch.setattr(api.google_play_verifier,'verify',lambda _: __import__('tbohk.store_billing',fromlist=['VerifiedPurchase']).VerifiedPurchase('google','dup-token','acct_notification_test','tbohk.pro','pro','active'))
    monkeypatch.setattr(api.account_manager,'record_billing_event',lambda *a,**k: False)
    got=asyncio.run(api.google_play_rtdn(Req({'message':{'data':'x'}})))
    assert got['duplicate'] is True
    class BadDecode:
        @staticmethod
        def decode_pubsub(_): raise RuntimeError('decode')
    monkeypatch.setattr(api.google_rtdn_verifier,'decode_pubsub',BadDecode.decode_pubsub)
    try: asyncio.run(api.google_play_rtdn(Req({'message':{'data':'x'}})))
    except HTTPException as e: assert e.status_code==400 and e.detail=='invalid Google RTDN notification'
