import gc
import warnings

import pytest


def test_constructor_failure_closes_sqlite_connection(monkeypatch, tmp_path):
    from tbohk import TBOHK
    from tbohk.migrations import MigrationManager

    original = MigrationManager.migrate

    def fail_migration(self):
        raise RuntimeError("synthetic migration failure")

    monkeypatch.setattr(MigrationManager, "migrate", fail_migration)
    with pytest.raises(RuntimeError, match="synthetic migration failure"):
        TBOHK(str(tmp_path / "partial.sqlite"))
    monkeypatch.setattr(MigrationManager, "migrate", original)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ResourceWarning)
        gc.collect()
    assert not [w for w in caught if issubclass(w.category, ResourceWarning)]

def test_destructor_closes_raw_connection_even_when_close_is_overridden():
    from tbohk import TBOHK
    g = TBOHK()
    original_db = g.db
    g.close = lambda: (_ for _ in ()).throw(RuntimeError('overridden close'))
    TBOHK.__del__(g)
    assert g._closed is True
    with pytest.raises(Exception):
        original_db.execute('SELECT 1')

def test_destructor_swallows_unexpected_close_failure():
    from tbohk import TBOHK
    class BrokenDB:
        def close(self):
            raise RuntimeError('synthetic close failure')
    g = object.__new__(TBOHK)
    g.db = BrokenDB()
    g._closed = False
    TBOHK.__del__(g)
    assert g._closed is False
