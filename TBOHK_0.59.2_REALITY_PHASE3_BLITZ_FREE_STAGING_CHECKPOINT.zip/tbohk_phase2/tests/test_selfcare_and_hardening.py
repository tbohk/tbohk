import json
import tempfile
from pathlib import Path

import pytest

from tbohk import TBOHK, CheckpointManager, SelfCareEngine
from tbohk.gates_21_30 import G21LedgerAuditor


def test_missing_ledger_entry_is_not_repaired_on_reopen(tmp_path):
    path = tmp_path / 'tamper.db'
    g = TBOHK(str(path))
    n = g.add_node('Claim', 'x')
    g._event('target', n.id, {'x': 1})
    row = g.db.execute("SELECT id FROM events WHERE event_type='target'").fetchone()
    g.db.execute("DELETE FROM ledger_chain WHERE table_name='events' AND row_id=?", (row['id'],))
    g.db.commit(); g.db.close()
    reopened = TBOHK(str(path))
    report = G21LedgerAuditor(reopened).audit()
    assert not report.passed
    assert any(f.code == 'ledger_anchor_missing' for f in report.findings)


def test_core_audit_fails_closed_on_malformed_metadata():
    g = TBOHK()
    n = g.add_node('Claim', 'x')
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", ('{broken', n.id)); g.db.commit()
    report = g.audit()
    assert not report['ok']
    assert report['problems'][0][1] == 'audit_exception'


def test_checkpoint_refuses_corrupt_graph():
    g = TBOHK()
    n = g.add_node('Claim', 'x')
    g.db.execute("UPDATE nodes SET content=? WHERE id=?", ('tampered', n.id)); g.db.commit()
    with pytest.raises(ValueError):
        CheckpointManager(g).create(code_version='x', schema_version='1', invariant_version='1', test_summary={})


def test_sqlite_operational_hardening(tmp_path):
    g = TBOHK(str(tmp_path / 'db.sqlite'))
    assert g.db.execute('PRAGMA foreign_keys').fetchone()[0] == 1
    assert g.db.execute('PRAGMA busy_timeout').fetchone()[0] >= 5000
    assert g.db.execute('PRAGMA synchronous').fetchone()[0] >= 2
    assert str(g.db.execute('PRAGMA journal_mode').fetchone()[0]).lower() == 'wal'


def test_selfcare_clean_graph():
    report = SelfCareEngine(TBOHK()).inspect()
    assert report.passed
    assert all(c.passed for c in report.checks if c.severity in {'critical', 'high'})


def test_selfcare_backup_is_verified(tmp_path):
    g = TBOHK(str(tmp_path / 'live.sqlite'))
    g.add_node('Claim', 'backup me')
    result = SelfCareEngine(g).backup(tmp_path / 'backup.sqlite')
    assert result['integrity'] == 'ok'
    assert Path(result['path']).exists()
    assert len(result['sha256']) == 64


def test_cli_refuses_public_bind_without_token():
    import os, subprocess, sys
    env=dict(os.environ); env.pop("TBOHK_API_TOKEN", None)
    out=subprocess.run([sys.executable,"-m","tbohk.cli","web","--host","0.0.0.0","--port","8765"],env=env,text=True,capture_output=True,timeout=10)
    assert out.returncode == 2
    assert "TBOHK_API_TOKEN" in out.stderr
