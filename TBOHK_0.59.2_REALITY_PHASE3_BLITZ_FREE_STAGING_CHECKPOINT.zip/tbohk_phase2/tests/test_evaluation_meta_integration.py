from tbohk.core import TBOHK
from tbohk.evaluation_harness import EvaluationHarness


def test_evaluation_harness_includes_meta_evaluation():
    report = EvaluationHarness(TBOHK()).run(include_mutation=False, as_of="2026-01-01T00:00:00+00:00")
    meta = next(s for s in report.suites if s.name == "meta_evaluation")
    assert meta.passed_all
    assert meta.total >= 5
