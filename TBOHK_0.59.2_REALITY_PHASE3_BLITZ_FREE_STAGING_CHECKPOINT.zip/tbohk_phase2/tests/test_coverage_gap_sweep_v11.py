import json, runpy, sys
import pytest
from types import SimpleNamespace


def test_api_success_paths(monkeypatch):
    import tbohk.api as api
    from tbohk.api import ResearchIn, RepairIn
    monkeypatch.setattr(api.ResearchChain,'run',lambda *a,**k:{'research_record':{'ok':1},'results':[]})
    assert api.research(ResearchIn(query='q',urls=['https://example.com']))['record']['ok']==1
    monkeypatch.setattr(api.SelfRepairController,'propose',lambda *a,**k: __import__('tbohk.repair',fromlist=['RepairCandidate']).RepairCandidate('r','x','d','e','medium'))
    assert api.repair(RepairIn(target_id='x',description='d',expected_effect='e'))['target_id']=='x'
    class E:
        def history(self,r): return [{'id':'s1','metadata':{}}]
        def delta(self,*a): return __import__('tbohk.investigation_state',fromlist=['InvestigationStateDelta']).InvestigationStateDelta('r','p','s',1,2,(),{}, {},(),(),False)
    monkeypatch.setattr(api,'InvestigationStateEngine',lambda g:E())
    monkeypatch.setattr(api,'g',SimpleNamespace(get=lambda x:SimpleNamespace(metadata={'previous_state_id':'p'})))
    assert api.investigation_delta('r')
    monkeypatch.setattr(api.DependencyImpactAnalyzer,'analyze_investigation',lambda *a,**k:__import__('tbohk.impact',fromlist=['ImpactReport']).ImpactReport((),(),(),(),None,{},'x'))
    assert 'roots' in api.investigation_impact('r','',10)


def test_benchmark_defensive(monkeypatch):
    import tbohk.benchmark as b
    with pytest.raises(KeyError): b._case('UNKNOWN')
    monkeypatch.setattr(b,'_case',lambda cid: (_ for _ in ()).throw(RuntimeError('x')))
    r=b.ReasoningBenchmark().run(); assert r.failed


def test_conflict_branches():
    from tbohk import TBOHK
    from tbohk.conflict_analysis import ConflictAnalyzer
    g=TBOHK(); c=g.add_node('ConflictSet','x','proposed',{'claim_ids':['a','b'],'dispositions':['scope_split']})
    try: ConflictAnalyzer(g).assess(c.id)
    except Exception: pass
    c2=g.add_node('ConflictSet','y','proposed',{'claim_ids':[],'dispositions':[]})
    try: ConflictAnalyzer(g).assess(c2.id)
    except Exception: pass


def test_contamination_holes():
    from tbohk import TBOHK
    from tbohk.contamination import ContaminationValidator, QuarantinePlan
    g=TBOHK(); r=g.add_node('ContaminationRoot','r','proposed',{}); n=g.add_node('Claim','n','proposed',{'dependency_ids':[r.id]})
    v=ContaminationValidator(g)
    v.plan_quarantine=lambda roots: QuarantinePlan(tuple(roots),(n.id,),(n.id,),(),())
    class Bad:
        @property
        def metadata(self): raise RuntimeError('bad')
        status='proposed'
        kind='Claim'
    old=g.get; v.g.get=lambda nid: Bad() if nid==n.id else old(nid)
    v.audit([r.id])


def test_core_update_and_paging():
    from tbohk import TBOHK
    g=TBOHK(); n=g.add_node('Claim','x','proposed',{})
    g.update_metadata('missing',{'x':1}) if False else None
    with pytest.raises(KeyError): g.update_metadata('missing',{'x':1})


def test_deep_assurance_plain_result():
    from tbohk import TBOHK
    from tbohk.deep_assurance import DeepAssurance
    assert DeepAssurance(TBOHK())._check('plain',lambda: True).passed


def test_epistemic_and_evaluation_edges():
    from tbohk import TBOHK
    from tbohk.epistemic import EpistemicEngine
    from tbohk.evaluation import ClaimSynthesizer
    g=TBOHK(); e=EpistemicEngine(g)
    try: e._evidence_origins('missing')
    except Exception: pass
    cs=g.add_node('ConflictSet','cs','proposed',{}); c=g.add_node('Claim','c','proposed',{}); g.link(cs.id,'contains',c.id)
    with pytest.raises(ValueError): e.resolve_conflict(cs.id,'defer')
    with pytest.raises(ValueError): ClaimSynthesizer(g).synthesize('missing')
    claim=g.add_node('Claim','x is y','proposed',{})
    ClaimSynthesizer(g).synthesize(claim.id,as_of='not-a-time')


def test_explanation_defensive():
    from tbohk import TBOHK
    from tbohk.explanation import ExplanationReconstructor
    g=TBOHK(); n=g.add_node('ReasoningActivity','r','proposed',{'rule_id':'rule','assumption_ids':['a']})
    x=ExplanationReconstructor(g)
    other=g.add_node('ReasoningRule','rule','proposed',{})
    g.link(n.id,'creates_branch',other.id)
    x.trace(n.id,max_nodes=1)


def test_gates_specific_findings():
    from tbohk import TBOHK
    from tbohk.gates_21_30 import G21LedgerAuditor,G22PortableCheckpointAuditor,G24ReplayConcurrencyAuditor,G25BoundaryAuditor,G27ResearchCompletenessAuditor,G30RedTeamAuditor
    g=TBOHK()
    g.db.execute("DELETE FROM ledger_anchor WHERE table_name='events'"); g.db.commit()
    assert G21LedgerAuditor(g).audit().findings
    cp=g.add_node('Checkpoint','cp','proposed',{'manifest':{}})
    assert G22PortableCheckpointAuditor(g).audit().findings
    # force replay exception
    old=g.audit; g.audit=lambda: (_ for _ in ()).throw(RuntimeError('x'))
    assert G24ReplayConcurrencyAuditor(g).audit().findings
    g.audit=old
    g.add_node('Claim','secret','proposed',{'api_key':'x'})
    assert G25BoundaryAuditor(g).audit().findings
    g.add_node('ResearchTask','rt','proposed',{'complete':True,'question':'q','scope':'s','stopping_rule':'x','source_ids':['a']})
    assert G27ResearchCompletenessAuditor(g).audit().findings
    a=g.add_node('Action','a','verified',{})
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(a.id,'authorizes',a.id,'x')); g.db.commit()
    assert G30RedTeamAuditor(g).audit().findings


def test_independence_and_validation(monkeypatch):
    from tbohk import TBOHK
    from tbohk.independence import IndependenceAnalyzer
    from tbohk.independent_validation import IndependentSystemValidator
    g=TBOHK(); a=IndependenceAnalyzer(g)
    assert a._roots('missing')=={'missing'}
    with pytest.raises(ValueError): a.analyze_evidence(['missing'])
    e1=g.add_node('Evidence','a','proposed',{'transformation_lineage':'x'})
    e2=g.add_node('Evidence','b','proposed',{'transformation_lineage':'x'})
    try: a.analyze_evidence([e1.id,e2.id])
    except Exception: pass
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(e1.id,'supports',e1.id,'x')); g.db.commit()
    assert IndependentSystemValidator(g).run()


def test_inference_branches():
    from tbohk import TBOHK
    from tbohk.inference import InferenceEvaluator
    g=TBOHK(); c=g.add_node('Claim','c','supported',{})
    a=g.add_node('ReasoningActivity','a','supported',{'method':'deductive','conclusion_id':c.id,'premise_ids':[c.id]})
    ev=InferenceEvaluator(g); ev._ancestors(c.id); ev._cycle(a.id,c.id); ev.assess(a.id)


def test_integrity_malformed():
    from tbohk import TBOHK
    from tbohk.integrity import IntegrityAuditor
    g=TBOHK(); n=g.add_node('Checkpoint','bad','proposed',{})
    g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(n.id,)); g.db.commit()
    r=IntegrityAuditor(g).audit_checkpoint(n.id); assert not r.passed


def test_intelligence_filters():
    from tbohk import TBOHK
    from tbohk.intelligence import KnowledgeIntelligence
    g=TBOHK(); a=g.add_node('Claim','a','proposed',{}); b=g.add_node('Claim','b','proposed',{})
    g.link(a.id,'contradicts',b.id)
    k=KnowledgeIntelligence(g); k.conflicts([a.id]) if False else None
    try: k.conflicts([a.id])
    except Exception: pass


def test_investigation_delta_validation():
    from tbohk import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK(); e=InvestigationStateEngine(g)
    with pytest.raises(ValueError): e.delta('missing','a','b')


def test_long_horizon_corruption():
    from tbohk import TBOHK
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK(); n=g.add_node('Claim','x','proposed',{}); bad=g.add_node('Claim','bad','proposed',{})
    g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(bad.id,)); g.db.commit()
    g.db.execute("INSERT INTO edges(source_id,relation,target_id,created_at) VALUES(?,?,?,?)",(n.id,'x',n.id,'x')); g.db.commit()
    out=[]; v=LongHorizonValidator(g); v._content_hashes(out); v._edges(out); assert out


def test_metamorphic_mutation_defensive(monkeypatch):
    import tbohk.metamorphic as m, tbohk.mutation as mu
    with pytest.raises(KeyError): m.MetamorphicSuite()._case('UNKNOWN') if hasattr(m.MetamorphicSuite(),'_case') else (_ for _ in ()).throw(KeyError())
    assert m.MetamorphicSuite().run().failed==0
    assert mu.MutationSuite().run().missed==0


def test_prediction_existing_and_provenance():
    from tbohk import TBOHK
    from tbohk.prediction import PredictiveReasoner
    from tbohk.provenance import ProvenanceEngine
    g=TBOHK(); h=g.add_node('Hypothesis','h','proposed',{})
    p=PredictiveReasoner(g); first=p.create_prediction(h.id,'x'); p.g.get=lambda nid: SimpleNamespace(id='existing',kind='Prediction',content='x',status='proposed',metadata={'discriminator':True}) if str(nid).startswith('prediction_') else h; second=p.create_prediction(h.id,'x'); assert second.id=='existing'
    g.add_node('ReasoningActivity','r','proposed',{})
    assert ProvenanceEngine(g).audit()


def test_reasoning_reconstitution():
    from tbohk import TBOHK
    from tbohk.reasoning import ReasoningEngine
    from tbohk.reconstitution import RecoveryLifecycleAuditor
    g=TBOHK(); r=ReasoningEngine(g)
    with pytest.raises(ValueError): r._derive_structured(SimpleNamespace(metadata={'rule_type':'bad','schema':{'specification':{}}}),[])
    RecoveryLifecycleAuditor(g).audit()


def test_reevaluation_defensive():
    from tbohk import TBOHK
    from tbohk.reevaluation import ReEvaluationController
    g=TBOHK(); r=ReEvaluationController(g)
    assert r._priority('disproven','Claim')=='critical'
    with pytest.raises(Exception): r.submit('missing','supports',rationale='')


def test_release_exception_branches(monkeypatch):
    from tbohk import TBOHK
    import tbohk.release as rel
    g=TBOHK(); a=rel.ReleaseAuditor(g)
    class Bad:
        def verify(self,*a,**k): return False
    assert a.audit(checkpoint_id='missing',trusted_public_keys={'x':b'y'}).passed is False
    # schema exception path
    old=g.migrations.verify; g.migrations.verify=lambda: (_ for _ in ()).throw(RuntimeError('x'))
    rep=a.audit(); assert any('SCHEMA:' in f.code for f in rep.findings)
    g.migrations.verify=old


def test_robustness_security_service_synthesis_trust():
    from tbohk import TBOHK
    from tbohk.robustness import ReasoningStressTester
    from tbohk.security import SecurityBoundary,UntrustedInput
    from tbohk.service import _SafeRedirectHandler, SourceDocument
    from tbohk.synthesis import EvidenceSynthesizer
    from tbohk.trust import ReleaseSigner, SignatureEnvelope
    g=TBOHK(); c=g.add_node('Claim','c','proposed',{})
    with pytest.raises(ValueError): ReasoningStressTester(g)._root_activity(c.id)
    with pytest.raises(ValueError): ReasoningStressTester(g)._root_activity('missing')
    SecurityBoundary().assess(UntrustedInput('x','x',{'a':1},False))
    from urllib.request import Request
    h=_SafeRedirectHandler(lambda x:None); h.count=0
    with pytest.raises(Exception): h.redirect_request(Request('http://x'),None,None,None,None,'http://x')
    assert SourceDocument
    es=EvidenceSynthesizer(g)
    g.add_node('Claim','a is red','proposed',{}); g.add_node('Claim','a is not blue','proposed',{})
    signer=ReleaseSigner(b'k','k'); env=signer.sign({'a':1}); assert signer.verify({'a':1},env)
    assert signer.verify({'a':2},env) is False
