import pytest
from tbohk.core import TBOHK
from tbohk.research import SourceDocument, MockProvider, ResearchChain, source_fingerprint, validate_source_document, citation_status

NOW='2026-01-01T00:00:00Z'
def doc(**kw):
    d=dict(source_id='s',title='T',uri='https://example.test/a',text='fact',provider_id='p',retrieved_at=NOW,origin_id='o'); d.update(kw); return SourceDocument(**d)

def test_source_validation_and_fingerprint():
    assert source_fingerprint(doc())==source_fingerprint(doc())
    with pytest.raises(ValueError): validate_source_document(doc(uri='ftp://example.test/a'))
    with pytest.raises(ValueError): validate_source_document(doc(uri='https://'))
    with pytest.raises(ValueError): validate_source_document(doc(source_id=''))
    with pytest.raises(ValueError): validate_source_document(doc(provider_id=''))
    with pytest.raises(ValueError): validate_source_document(doc(origin_id=''))
    with pytest.raises(ValueError): validate_source_document(doc(text=''))

def test_duplicate_source_is_omitted_and_citations_are_checked():
    g=TBOHK(); d=doc(); out=ResearchChain(g,[MockProvider('p',[d,d])]).run('fact')
    assert len(out['results'])==1
    sid=out['results'][0][0].metadata['source_id']; node=g.get(sid)
    status=citation_status(g,[sid,'missing','',sid])
    assert status['requested']==[sid,'missing'] and status['all_verified'] is False and sid in status['verified']
    status2=citation_status(g,[]); assert status2['all_verified'] is True
