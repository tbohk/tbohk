import tempfile
from pathlib import Path
import pytest
from tbohk import TBOHK, CheckpointManager
from tbohk.gates_21_30 import G21LedgerAuditor
from tbohk.governance import GovernanceEngine
from tbohk.recovery import RecoveryEngine
from tbohk.plans import PlanEngine


def test_g21_anchor_detects_delete_of_event_and_chain_after_reopen():
    path = tempfile.mktemp(suffix='.sqlite')
    try:
        g = TBOHK(path); n = g.add_node('Claim','x'); g._event('tamper-target', n.id, {'x': 1}); g.db.commit()
        row = g.db.execute("SELECT id FROM events WHERE event_type='tamper-target'").fetchone()
        g.db.execute("DELETE FROM events WHERE id=?", (row['id'],))
        g.db.execute("DELETE FROM ledger_chain WHERE table_name='events' AND row_id=?", (row['id'],)); g.db.commit(); g.db.close()
        reopened = TBOHK(path)
        assert not G21LedgerAuditor(reopened).audit().passed
        assert any(f.code in {'ledger_anchor_count_mismatch','ledger_anchor_head_mismatch'} for f in G21LedgerAuditor(reopened).audit().findings)
    finally:
        Path(path).unlink(missing_ok=True)


def test_checkpoint_verification_fails_after_live_graph_change():
    g = TBOHK(); g.add_node('Claim','before'); cp = CheckpointManager(g).create(code_version='x', schema_version='1', invariant_version='1', test_summary={'passed':1})
    g.add_node('Claim','after')
    assert not CheckpointManager(g).verify(cp.checkpoint_id)


def test_checkpoint_manifest_ignores_prior_checkpoint_nodes_consistently():
    g = TBOHK(); first = CheckpointManager(g).create(code_version='x', schema_version='1', invariant_version='1', test_summary={'passed':1})
    second = CheckpointManager(g).create(code_version='y', schema_version='1', invariant_version='1', test_summary={'passed':1}, parent_checkpoint_id=first.checkpoint_id)
    assert CheckpointManager(g).verify(first.checkpoint_id)
    assert CheckpointManager(g).verify(second.checkpoint_id)


def test_plan_step_dependency_points_to_predecessor():
    g = TBOHK(); p = PlanEngine(g).create('p',['one','two','three'])
    assert g.edges(p.step_ids[1], 'out', 'depends_on')[0]['target_id'] == p.step_ids[0]
    assert g.edges(p.step_ids[2], 'out', 'depends_on')[0]['target_id'] == p.step_ids[1]


def test_governance_cannot_authorize_with_assessment_for_other_proposal():
    g = TBOHK(); ge = GovernanceEngine(g)
    p1 = ge.propose_change('p1','architecture',[],proposer='owner')
    p2 = ge.propose_change('p2','architecture',[],proposer='owner')
    assessment = ge.evaluate_change(p1.id, approver='reviewer')
    aid = next(e['target_id'] for e in g.edges(p1.id,'in','evaluates')) if g.edges(p1.id,'in','evaluates') else None
    assert aid
    with pytest.raises(PermissionError): ge.authorize(p2.id, assessment_id=aid)


def test_governance_proposer_cannot_serve_as_independent_assessor():
    g = TBOHK(); ge = GovernanceEngine(g); p = ge.propose_change('p','architecture',[],proposer='owner')
    ge.evaluate_change(p.id, approver='owner')
    aid = next(e['target_id'] for e in g.edges(p.id,'in','evaluates'))
    with pytest.raises(PermissionError): ge.authorize(p.id, assessment_id=aid)


def test_recovery_cannot_apply_validation_for_other_proposal():
    g = TBOHK(); re = RecoveryEngine(g)
    i1 = re.detect('corruption',['x']); p1 = re.propose(i1.id,'repair1',rollback='restore',diagnosis='bad')
    i2 = re.detect('corruption',['y']); p2 = re.propose(i2.id,'repair2',rollback='restore',diagnosis='bad')
    v = re.validate(p1.id)
    with pytest.raises(PermissionError): re.apply(p2.id, validation_id=v.validation_id)


def test_recovery_proposer_cannot_validate_own_proposal_as_independent():
    g = TBOHK(); re = RecoveryEngine(g); i = re.detect('corruption',['x']); p = re.propose(i.id,'repair',rollback='restore',diagnosis='bad',proposer='owner')
    v = re.validate(p.id, assessor='owner')
    assert not v.validated


def test_api_protected_status_transition_is_blocked():
    from fastapi.testclient import TestClient
    import tbohk.api as api
    n = api.g.add_node('Claim','protected')
    response = TestClient(api.app).post(f'/nodes/{n.id}/status', json={'status':'verified','reason':'bypass'})
    assert response.status_code == 403


def test_core_mutation_rolls_back_on_event_failure(monkeypatch):
    from tbohk import TBOHK
    g=TBOHK()
    def boom(*args, **kwargs): raise RuntimeError('forced event failure')
    monkeypatch.setattr(g, '_event', boom)
    try: g.add_node('Claim','rollback-me')
    except RuntimeError: pass
    else: assert False
    assert g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0] == 0
    assert g.db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0


def test_core_writes_are_serialized_under_concurrency(tmp_path):
    from tbohk import TBOHK
    from concurrent.futures import ThreadPoolExecutor
    g=TBOHK(str(tmp_path/'concurrent.db'))
    def add(i): return g.add_node('Claim',f'c{i}').id
    with ThreadPoolExecutor(max_workers=12) as ex:
        ids=list(ex.map(add, range(100)))
    assert len(ids)==100 and len(set(ids))==100
    assert g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0] == 100
    assert g.db.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 100


def test_governance_grant_principal_cannot_self_approve():
    from tbohk import TBOHK, GovernanceEngine
    g=TBOHK(); ge=GovernanceEngine(g)
    grant=ge.grant('alice',['execute_action'],approver='alice')
    try: ge.approve_grant(grant.id,approver='alice')
    except PermissionError: pass
    else: assert False
    assert g.get(grant.id).status == 'proposed'


def test_g30_recognizes_outgoing_decision_approval():
    from tbohk import TBOHK
    from tbohk.gates_21_30 import G30RedTeamAuditor
    g=TBOHK(); d=g.add_node('Decision','d',status='verified')
    grant=g.add_node('AuthorityGrant','g',status='verified')
    g.link(d.id,'approved_by',grant.id)
    assert G30RedTeamAuditor(g).audit().passed


def test_browser_surface_uses_canonical_version():
    from tbohk import __version__
    from tbohk import api
    html=api.home()
    assert f'v{__version__}' in html
    assert 'v0.23' not in html
