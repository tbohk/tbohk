import pytest
from types import SimpleNamespace


def test_impact_active_root_skip():
    from tbohk.impact import DependencyImpactAnalyzer
    class G:
        def __init__(self): self.nodes={k:SimpleNamespace(id=k,kind='Claim',status='proposed',metadata={}) for k in ('a','b')}
        def get(self,n): return self.nodes.get(n)
        def edges(self,*a,**k): return []
    g=G(); a=DependencyImpactAnalyzer(g); a._neighbors=lambda n:[('b','evidence_for')] if n=='a' else []
    r=a.analyze(['a','b']); assert r.roots==('a','b')


def test_inference_parent_activity_uses_branch():
    from tbohk import TBOHK
    from tbohk.inference import InferenceEvaluator
    g=TBOHK(); c=g.add_node('Claim','c','proposed',{}); p=g.add_node('Claim','p','proposed',{}); a=g.add_node('ReasoningActivity','a','proposed',{}); b=g.add_node('ReasoningActivity','b','proposed',{})
    g.link(a.id,'uses',p.id); g.link(b.id,'generated_by',p.id); g.link(b.id,'uses',c.id)
    InferenceEvaluator(g)._cycle(a.id,c.id)


def test_investigation_relevant_claims():
    from tbohk import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK(); run=g.add_node('AdaptiveResearchRun','r','proposed',{}); h=g.add_node('Claim','h','proposed',{}); child=g.add_node('Claim','child','proposed',{}); g.link(h.id,'derives',child.id)
    InvestigationStateEngine(g).build(run.id,[h.id])


def test_robustness_dependent_claims():
    from tbohk import TBOHK
    from tbohk.robustness import ReasoningStressTester
    g=TBOHK(); dep=g.add_node('Claim','dep','proposed',{}); child=g.add_node('Claim','child','proposed',{}); g.link(child.id,'derived_from',dep.id)
    r=ReasoningStressTester(g); assert child.id in r._dependent_claims(dep.id)


def test_reevaluation_observation_and_rationale_guards():
    from tbohk import TBOHK
    from tbohk.reevaluation import ReEvaluationWorkflow
    g=TBOHK(); target=g.add_node('Claim','t','proposed',{}); item=g.add_node('ReEvaluationItem','i','proposed',{'target_id':target.id,'impact':'affected'}); w=ReEvaluationWorkflow(g)
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='supports',observation_ids=[target.id],rationale='ok')
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='inconclusive',rationale='' )


def test_conflict_bool_false_branch():
    from tbohk import TBOHK
    from tbohk.conflict_analysis import ConflictAnalyzer
    g=TBOHK(); cs=g.add_node('ConflictSet','x','proposed',{})
    c1=g.add_node('Claim','a','proposed',{}); c2=g.add_node('Claim','b','proposed',{})
    g.link(cs.id,'contains',c1.id); g.link(cs.id,'contains',c2.id)
    class Weird:
        def __iter__(self): return iter((c1,c2))
        def __len__(self): return 2
        def __bool__(self): return False
    ca=ConflictAnalyzer(g); ca._claims=lambda _: Weird(); ca._scope=lambda c: None
    try: ca.assess(cs.id)
    except Exception: pass


def test_reevaluation_exact_guard_lines():
    from tbohk import TBOHK
    from tbohk.reevaluation import ReEvaluationWorkflow
    g=TBOHK(); target=g.add_node('Observation','o','proposed',{}); item=g.add_node('ReEvaluationItem','i','proposed',{'target_id':target.id,'impact':'affected'}); w=ReEvaluationWorkflow(g)
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='supports',observation_ids=[target.id],rationale='ok')
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='inconclusive',rationale='' )


def test_selfcare_backup_integrity_failure(tmp_path, monkeypatch):
    import sqlite3
    import tbohk.selfcare as sc
    from tbohk import TBOHK
    from tbohk.selfcare import SelfCareEngine
    class BadConn(sqlite3.Connection):
        def execute(self, sql, *args):
            if 'integrity_check' in sql:
                class R:
                    def fetchall(self): return [('corrupt',)]
                return R()
            if 'foreign_key_check' in sql:
                class R:
                    def fetchall(self): return []
                return R()
            return super().execute(sql,*args)
    g=TBOHK(); s=SelfCareEngine(g); real=sc.sqlite3.connect
    sc.sqlite3.connect=lambda p: real(p, factory=BadConn)
    try:
        with pytest.raises(RuntimeError): s.backup(tmp_path/'bad.sqlite')
    finally: sc.sqlite3.connect=real

def test_core_best_effort_destructor():
    from tbohk import TBOHK
    g=TBOHK(); g.__del__(); g.__del__()
