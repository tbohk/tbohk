from fastapi.testclient import TestClient
from pathlib import Path
import re


UI = Path(__file__).parents[1] / "tbohk" / "ui.html"
API = Path(__file__).parents[1] / "tbohk" / "api.py"


def _html():
    return UI.read_text(encoding="utf-8")


def _script():
    text = _html()
    return text.split("<script>", 1)[1].split("</script>", 1)[0]


def _api_routes():
    text = API.read_text(encoding="utf-8")
    return set(re.findall(r'@app\.(?:get|post|put|patch|delete)\("([^"]+)"', text))


def test_every_ui_view_has_a_navigation_target():
    html = _html()
    views = set(re.findall(r'<section id="([^"]+)" class="view', html))
    nav = set(re.findall(r'<button[^>]*data-view="([^"]+)"', html))
    assert views == nav


def test_every_inline_click_handler_is_defined():
    html = _html()
    handlers = set(re.findall(r'onclick=["\']([A-Za-z_$][\w$]*)\s*\(', html))
    functions = set(re.findall(r'(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(', _script()))
    assert handlers <= functions


def test_every_ui_api_path_exists_server_side():
    script = _script()
    routes = _api_routes()
    paths = set(re.findall(r"\bapi\(['\"]([^'\"]+)", script))
    paths |= set(re.findall(r"\bfetch\(['\"]([^'\"]+)", script))
    normalized = {p.split("?", 1)[0] for p in paths}
    dynamic = {p for p in normalized if p.startswith('/review/') or p.startswith('/release/') or p.startswith('/graph/neighborhood/') or p.startswith('/graph/attention/')}
    normalized -= dynamic
    assert normalized <= routes
    assert '/review/claims/{node_id}/verify' in routes and '/review/conflicts/{conflict_id}/resolve' in routes


def test_ui_has_required_product_views_and_controls():
    html = _html()
    for view in ("home", "ask", "library", "research", "knowledge", "investigation", "review", "assurance", "learning", "pricing", "account"):
        assert f'id="{view}"' in html
    for control in (
        "Build knowledge workspace", "Your Library", "Save", "Follow up", "What changed", "Watchlist", "Plan research", "Run bounded research",
        "Search", "Find gaps", "Load conflicts", "Generate candidate hypotheses",
        "Core audit", "Release audit", "Self-care", "Migrations", "Invariants",
        "Manage billing", "Revoke all sessions", "Delete account", "Refresh learning state", "Run fixed benchmark", "Build replay dataset", "Run isolated adapter", "Run canary check", "Prepare release", "Stage 5%", "Health check", "Complete", "Record", "Privacy", "Terms", "Support",
    ):
        assert control in html


def test_058_product_experience_explains_core_and_advanced_capabilities():
    html = _html()
    for text in (
        "Not just an AI answer box",
        "How TBOHK works",
        "The basic workflow",
        "Ask", "Research", "Inspect", "Keep", "Review",
        "Evidence", "Claim", "Verified", "Unknown", "Conflict",
        "Architecture-aware", "Invariant-aware", "Adversarial", "Self-improving",
        "For most users:", "advanced", "system assurance",
    ):
        assert text in html


def test_058_system_assurance_ui_uses_new_control_plane_endpoints():
    script = _script()
    for path in ("/assurance/system", "/assurance/system/contracts", "/assurance/system/architecture"):
        assert path in script

def test_external_answer_links_are_sanitized_and_hardened():
    script = _script()
    assert "function safeUrl" in script
    assert "rel=\"noopener noreferrer\"" in script
    assert "target=\"_blank\"" in script

def test_new_operational_api_paths_exist():
    from tbohk import api
    paths={r.path for r in api.app.routes}
    assert '/observability' in paths and '/observability/recent' in paths
    assert '/answer/citations/verify' in paths
    assert '/release/{release_id}/deploy' in paths
    assert '/release/{release_id}/rollback' in paths
    assert '/release/{release_id}/deployment-health' in paths

def test_provider_readiness_endpoint_hides_values():
    import tbohk.api as api
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'readiness@example.com','password':'long-password-123','name':'Readiness'})
    out=c.get('/billing/provider-readiness',headers={'Authorization':'Bearer '+r.json()['token']})
    assert out.status_code==200
    assert set(out.json())=={'stripe','apple','google'}
    assert all('configured' in v and 'missing' in v for v in out.json().values())


def test_library_continuity_is_explicit_and_local():
    html = _html()
    script = _script()
    assert 'localStorage' in script
    assert 'tbohk_library' in script
    assert 'Saved on this device' in html
    assert 'Server-authoritative knowledge' in html
    assert 'function saveAnswerToLibrary' in script
    assert 'function showChanges' in script
    assert 'function followUp' in script

def test_attention_learning_ui_is_explicit_and_bounded():
    text=UI.read_text()
    assert "recordMapAttentionFeedback" in text
    assert "/graph/attention/" in text
    assert "Worked" in text and "Didn’t help" in text
    block=text[text.index("async function recordMapAttentionFeedback"):text.index("async function loadMapImpact")]
    assert "success" in block
