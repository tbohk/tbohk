import hashlib, hmac, json, tempfile
from pathlib import Path


def test_account_manager_isolates_usage_and_tokens():
    from tbohk.accounts import AccountManager, QuotaExceeded
    root=Path(tempfile.mkdtemp())
    m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    one, token1=m.create_account('one@example.com','long-password-1','One')
    two, token2=m.create_account('two@example.com','long-password-2','Two')
    assert token1 != token2
    assert m.authenticate_token(token1).account_id == one.account_id
    assert m.authenticate_token(token2).account_id == two.account_id
    for _ in range(25): m.consume_ask(one.account_id)
    assert m.identity(one.user_id).ask_used == 25
    try: m.consume_ask(one.account_id)
    except QuotaExceeded as e: assert (e.used,e.limit)==(25,25)
    else: assert False
    assert m.identity(two.user_id).ask_used == 0
    m.close()


def test_paid_plans_activate_only_through_billing_state():
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp())
    m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,_=m.create_account('pay@example.com','long-password-3','Pay')
    assert identity.plan == 'free'
    try: m.create_account('bad@example.com','long-password-4','Bad','pro')
    except ValueError as e: assert 'checkout' in str(e)
    else: assert False
    m.update_plan(identity.account_id,'pro','active','cus_123','sub_123')
    got=m.identity(identity.user_id)
    assert got.plan == 'pro' and got.ask_limit == 250 and got.billing_status == 'active'
    m.close()


def test_billing_webhook_signature_and_subscription_state(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager, StripeBilling
    root=Path(tempfile.mkdtemp())
    manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,_=manager.create_account('hook@example.com','long-password-5','Hook')
    secret='whsec_test'
    old_manager,old_billing,old_token=api.account_manager,api.billing,api.TOKEN
    api.account_manager=manager
    api.billing=StripeBilling('sk_test',secret,{'pro':'price_pro','unlimited':'price_unlimited'})
    api.TOKEN=None
    try:
        event={'type':'checkout.session.completed','data':{'object':{'id':'cs_1','customer':'cus_1','subscription':'sub_1','metadata':{'account_id':identity.account_id,'plan':'pro'}}}}
        payload=json.dumps(event,separators=(',',':')).encode()
        import time
        ts=str(int(time.time()))
        sig=hmac.new(secret.encode(),(ts+'.'+payload.decode()).encode(),hashlib.sha256).hexdigest()
        r=TestClient(api.app).post('/billing/webhook',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'})
        assert r.status_code == 200
        got=manager.identity(identity.user_id)
        assert got.plan=='pro' and got.billing_status=='active'
        bad=TestClient(api.app).post('/billing/webhook',content=payload,headers={'stripe-signature':'t=1,v1=bad'})
        assert bad.status_code == 400
    finally:
        api.account_manager,api.billing,api.TOKEN=old_manager,old_billing,old_token
        manager.close()


def test_http_account_login_workspace_meter_and_tenant_isolation(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    from tbohk.workspace import QuestionWorkspace
    root=Path(tempfile.mkdtemp())
    old=(api.account_manager,api.TOKEN,api.g)
    from tbohk.accounts import AccountManager
    manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    api.account_manager=manager
    api.TOKEN='master-token-abcdefghijklmnopqrstuvwxyz-123456'
    manager.ensure_bootstrap(api.TOKEN)
    api.g=TBOHK(str(root/'legacy.sqlite'))
    class FakeWorkspace:
        def __init__(self,g): pass
        def open(self,q): return type('W',(),{'__dict__':{},'workspace_id':'ws_test'})()
        def as_dict(self,w): return {'workspace_id':w.workspace_id,'assessment':{},'next_actions':[]}
    old_ws=api.QuestionWorkspace; api.QuestionWorkspace=FakeWorkspace
    try:
        c=TestClient(api.app)
        reg=c.post('/account/register',json={'email':'a@example.com','password':'long-password-6','name':'A'})
        assert reg.status_code==200
        token=reg.json()['token']
        assert c.get('/account',headers={'Authorization':'Bearer '+token}).json()['asks']['limit']==25
        n=c.post('/nodes',headers={'Authorization':'Bearer '+token},json={'kind':'Claim','content':'private A','status':'proposed','metadata':{}})
        assert n.status_code==200
        reg2=c.post('/account/register',json={'email':'b@example.com','password':'long-password-7','name':'B'})
        token2=reg2.json()['token']
        assert c.get('/nodes',headers={'Authorization':'Bearer '+token2},params={'q':'private A'}).json()==[]
        for _ in range(25): assert c.post('/workspace',headers={'Authorization':'Bearer '+token},json={'question':'q'}).status_code==200
        limited=c.post('/workspace',headers={'Authorization':'Bearer '+token},json={'question':'q'})
        assert limited.status_code==429 and limited.json()['detail']['code']=='ask_limit_reached'
        assert c.get('/account/usage',headers={'Authorization':'Bearer '+token2}).json()['used']==0
    finally:
        api.QuestionWorkspace=old_ws
        for item in list(api._runtime_cache.values()):
            try: item[0].close()
            except Exception: pass
        api._runtime_cache.clear()
        api.account_manager,api.TOKEN,api.g=old


def test_account_manager_validation_and_bootstrap_paths():
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    try: m.create_account('x@example.com','short','X')
    except ValueError as e: assert '10 characters' in str(e)
    try: m.create_account('bad-email','long-password-8','X')
    except ValueError as e: assert 'valid email' in str(e)
    a,_=m.create_account('dup@example.com','long-password-9','X')
    try: m.create_account('dup@example.com','long-password-9','X')
    except ValueError as e: assert 'already exists' in str(e)
    try: m.create_account('z@example.com','long-password-0','Z','bogus')
    except ValueError as e: assert 'invalid plan' in str(e)
    try: m.update_plan(a.account_id,'bogus')
    except ValueError as e: assert 'invalid plan' in str(e)
    assert m.authenticate_token('') is None
    assert m.authenticate_token('missing') is None
    assert m.identity(a.user_id).ask_used == 0
    assert m.data_path(a.account_id).endswith(a.account_id+'.sqlite')
    b=m.ensure_bootstrap('master-token-coverage')
    assert b.plan=='unlimited'
    b2=m.ensure_bootstrap('master-token-coverage')
    assert b2.account_id==b.account_id
    try: m.consume_ask(a.account_id,0)
    except ValueError as e: assert 'positive' in str(e)
    else: assert False
    m.close()


def test_password_and_stripe_edge_cases(monkeypatch):
    from tbohk.accounts import AccountManager, StripeBilling
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    a,_=m.create_account('edge@example.com','long-password-x','Edge')
    assert m._password_ok('wrong',m.db.execute('SELECT password_hash FROM users WHERE id=?',(a.user_id,)).fetchone()[0]) is False
    assert m._password_ok('long-password-x','bad-format') is False
    try: m.authenticate_password('edge@example.com','wrong')
    except ValueError as e: assert 'invalid credentials' in str(e)
    try: m.authenticate_password('missing@example.com','long-password-x')
    except ValueError as e: assert 'invalid credentials' in str(e)
    b=StripeBilling(None,None,{})
    assert b.configured() is False
    try: b._request('x',{})
    except RuntimeError as e: assert 'not configured' in str(e)
    try: b.checkout('free',a.account_id,'s','c')
    except ValueError as e: assert 'free plan' in str(e)
    try: b.checkout('pro',a.account_id,'s','c')
    except RuntimeError as e: assert 'price ID' in str(e)
    try: b.verify_webhook(b'{}','')
    except ValueError as e: assert 'not configured' in str(e)
    b=StripeBilling('sk','whsec',{})
    for sig,msg in [('','invalid Stripe signature'),('t=bad,v1=x','invalid Stripe signature timestamp'),('t=1,v1=x','expired Stripe signature')]:
        try: b.verify_webhook(b'{}',sig)
        except ValueError as e: assert msg in str(e)
    import tbohk.accounts as accounts
    class Resp:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def read(self): return b'{"id":"sess","url":"https://checkout"}'
    monkeypatch.setattr(accounts,'urlopen',lambda *a,**k: Resp())
    b=StripeBilling('sk','whsec',{'pro':'price_pro'})
    assert b.checkout('pro',a.account_id,'s','c')['id']=='sess'
    assert b.portal('cus','return')['id']=='sess'
    import time, json, hashlib, hmac
    payload=b'{}'; ts=str(int(time.time())); sig=hmac.new(b'whsec',(ts+'.{}').encode(),hashlib.sha256).hexdigest()
    assert b.verify_webhook(payload,f't={ts},v1={sig}') == {}
    try: b.verify_webhook(payload,'t='+ts+',v1=wrong')
    except ValueError as e: assert 'invalid Stripe signature' in str(e)
    m.close()


def test_http_billing_checkout_portal_errors_and_login(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,_=manager.create_account('httpedge@example.com','long-password-11','Edge')
    old=(api.account_manager,api.TOKEN,api.billing)
    class FakeBilling:
        price_ids={'pro':'price'}
        def checkout(self,*a): return {'url':'https://checkout.test','id':'cs'}
        def portal(self,*a): return {'url':'https://portal.test'}
    api.account_manager=manager; api.TOKEN=None; api.billing=FakeBilling()
    try:
        c=TestClient(api.app)
        bad=c.post('/account/login',json={'email':'httpedge@example.com','password':'wrong-password'})
        assert bad.status_code==401
        good=c.post('/account/login',json={'email':'httpedge@example.com','password':'long-password-11'})
        token=good.json()['token']; h={'Authorization':'Bearer '+token}
        assert c.post('/billing/checkout',headers=h,json={'plan':'free','success_url':'s','cancel_url':'c'}).status_code==400
        assert c.post('/billing/checkout',headers=h,json={'plan':'pro','success_url':'s','cancel_url':'c'}).json()['session_id']=='cs'
        assert c.post('/billing/portal',headers=h,json={'return_url':'r'}).status_code==400
        manager.update_plan(identity.account_id,'pro','active','cus_http','sub_http')
        assert c.post('/billing/portal',headers=h,json={'return_url':'r'}).json()['portal_url']=='https://portal.test'
    finally:
        for item in list(api._runtime_cache.values()):
            try: item[0].close()
            except Exception: pass
        api._runtime_cache.clear()
        api.account_manager,api.TOKEN,api.billing=old
        manager.close()


def test_api_billing_remaining_error_and_webhook_paths(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager, StripeBilling
    import json, time, hmac, hashlib
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=manager.create_account('apiedge@example.com','long-password-12','Edge')
    old=(api.account_manager,api.TOKEN,api.billing)
    secret='whsec_edge'; api.account_manager=manager; api.TOKEN=None
    class BadBilling:
        price_ids={'pro':'price_pro'}
        def checkout(self,*a): raise RuntimeError('checkout failed')
        def portal(self,*a): raise RuntimeError('portal failed')
        def verify_webhook(self,*a): raise ValueError('webhook failed')
    api.billing=BadBilling()
    try:
        c=TestClient(api.app); h={'Authorization':'Bearer '+token}
        dup=c.post('/account/register',json={'email':'apiedge@example.com','password':'long-password-12','name':'Duplicate'})
        assert dup.status_code==400
        assert c.post('/billing/checkout',headers=h,json={'plan':'pro','success_url':'s','cancel_url':'c'}).status_code==503
        manager.update_plan(identity.account_id,'pro','active','cus_edge','sub_edge')
        assert c.post('/billing/portal',headers=h,json={'return_url':'r'}).status_code==503
        api.billing=StripeBilling('sk',secret,{'pro':'price_pro','unlimited':'price_unlimited'})
        event={'type':'invoice.payment_failed','data':{'object':{'id':'inv_1','customer':'cus_edge','subscription':'sub_edge','metadata':{'account_id':identity.account_id,'plan':'pro'}}}}
        payload=json.dumps(event,separators=(',',':')).encode(); ts=str(int(time.time())); sig=hmac.new(secret.encode(),(ts+'.'+payload.decode()).encode(),hashlib.sha256).hexdigest()
        assert c.post('/billing/webhook',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'}).status_code==200
        assert manager.identity(identity.user_id).billing_status=='past_due'
        # Exercise subscription update without metadata: lookup uses stored subscription id.
        api.billing=StripeBilling('sk',secret,{'pro':'price_pro','unlimited':'price_unlimited'})
        event={'type':'customer.subscription.updated','data':{'object':{'id':'sub_edge','customer':'cus_edge','metadata':{'plan':'pro'}}}}
        payload=json.dumps(event,separators=(',',':')).encode(); ts=str(int(time.time())); sig=hmac.new(secret.encode(),(ts+'.'+payload.decode()).encode(),hashlib.sha256).hexdigest()
        assert c.post('/billing/webhook',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'}).status_code==200
        event['type']='customer.subscription.deleted'; payload=json.dumps(event,separators=(',',':')).encode(); sig=hmac.new(secret.encode(),(ts+'.'+payload.decode()).encode(),hashlib.sha256).hexdigest()
        assert c.post('/billing/webhook',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'}).status_code==200
        assert manager.identity(identity.user_id).plan=='free'
    finally:
        for item in list(api._runtime_cache.values()):
            try: item[0].close()
            except Exception: pass
        api._runtime_cache.clear(); api.account_manager,api.TOKEN,api.billing=old; manager.close()


def test_api_rebind_graph_handles_readonly_property():
    from tbohk import api
    class Bad:
        @property
        def g(self): return None
        @g.setter
        def g(self,value): raise RuntimeError('readonly')
    api._rebind_graph(Bad(), object())


def test_account_manager_close_is_idempotent():
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    m.close(); m.close(); m.__del__(); assert m._closed is True


def test_account_manager_destructor_is_best_effort(monkeypatch):
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    monkeypatch.setattr(m,'close',lambda: (_ for _ in ()).throw(RuntimeError('close failed')))
    m.__del__()


def test_account_manager_context_manager():
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp())
    with AccountManager(str(root/'accounts.sqlite'),str(root/'data')) as m:
        assert not m._closed
    assert m._closed


def test_account_logout_deletion_and_trusted_billing_redirects(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=manager.create_account('delete@example.com','long-password-delete','Delete')
    tenant=Path(manager.data_path(identity.account_id))
    old=(api.account_manager,api.TOKEN,api.billing,api.PUBLIC_BASE_URL)
    class FakeBilling:
        price_ids={'pro':'price_pro','unlimited':'price_unlimited'}
        def configured(self): return True
        def checkout(self,*args):
            assert args[2:] == ('https://app.tbohk.test/billing/success','https://app.tbohk.test/billing/cancel')
            return {'url':'https://checkout.test','id':'cs'}
        def portal(self,*args):
            assert args[1] == 'https://app.tbohk.test/account'
            return {'url':'https://portal.test'}
        def cancel_subscription(self,*args): return {'status':'canceled'}
    api.account_manager=manager; api.TOKEN=None; api.billing=FakeBilling(); api.PUBLIC_BASE_URL='https://app.tbohk.test'
    try:
        c=TestClient(api.app); h={'Authorization':'Bearer '+token}
        assert c.post('/billing/checkout',headers=h,json={'plan':'pro'}).json()['session_id']=='cs'
        assert c.post('/billing/portal',headers=h,json={}).status_code==400
        manager.update_plan(identity.account_id,'pro','active','cus_delete','sub_delete')
        assert c.post('/billing/checkout',headers=h,json={'plan':'pro'}).json()['checkout_url']=='https://checkout.test'
        assert c.post('/billing/portal',headers=h,json={}).json()['portal_url']=='https://portal.test'
        assert c.post('/account/delete',headers=h,json={'confirmation':'wrong'}).status_code==400
        assert c.post('/account/delete',headers=h,json={'confirmation':'DELETE MY ACCOUNT'}).json()=={'deleted':True}
        assert not tenant.exists()
        assert manager.authenticate_token(token) is None
    finally:
        api.account_manager,api.TOKEN,api.billing,api.PUBLIC_BASE_URL=old
        manager.close()


def test_logout_revokes_only_present_token():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=manager.create_account('logout@example.com','long-password-logout','Logout')
    old=(api.account_manager,api.TOKEN)
    api.account_manager=manager; api.TOKEN=None
    try:
        c=TestClient(api.app); h={'Authorization':'Bearer '+token}
        assert c.get('/account',headers=h).status_code==200
        assert c.post('/account/logout',headers=h).json()=={'logged_out':True}
        assert c.get('/account',headers=h).status_code==200 or c.get('/account',headers=h).status_code==401
        assert manager.authenticate_token(token) is None
    finally:
        api.account_manager,api.TOKEN=old
        manager.close()


def test_account_deletion_error_paths_and_stripe_cancel(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager, StripeBilling
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=manager.create_account('errors@example.com','long-password-errors','Errors')
    old=(api.account_manager,api.TOKEN,api.billing)
    class FakeBilling:
        def configured(self): return True
        def cancel_subscription(self,*args): raise RuntimeError('provider unavailable')
        def checkout(self,*args): return {'url':'x','id':'x'}
        def portal(self,*args): return {'url':'x'}
    api.account_manager=manager; api.TOKEN=None; api.billing=FakeBilling()
    try:
        c=TestClient(api.app); h={'Authorization':'Bearer '+token}
        manager.update_plan(identity.account_id,'pro','active','cus','sub')
        assert c.post('/account/delete',headers=h,json={'confirmation':'DELETE MY ACCOUNT'}).status_code==503
        manager.update_plan(identity.account_id,'free','active')
        api.billing=type('NoBilling',(),{'configured':lambda self:False})()
        original=manager.delete_account
        manager.delete_account=lambda aid: (_ for _ in ()).throw(ValueError('gone'))
        assert c.post('/account/delete',headers=h,json={'confirmation':'DELETE MY ACCOUNT'}).status_code==404
        manager.delete_account=lambda aid: (_ for _ in ()).throw(RuntimeError('filesystem failure'))
        assert c.post('/account/delete',headers=h,json={'confirmation':'DELETE MY ACCOUNT'}).status_code==500
        manager.delete_account=original
    finally:
        api.account_manager,api.TOKEN,api.billing=old
        manager.close()


def test_account_manager_delete_missing_and_tenant_unlink_failure(monkeypatch):
    from tbohk.accounts import AccountManager, StripeBilling
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    try:
        try: manager.delete_account('missing')
        except ValueError as e: assert 'account not found' in str(e)
        else: assert False
        identity,_=manager.create_account('unlink@example.com','long-password-unlink','Unlink')
        tenant=Path(manager.data_path(identity.account_id)); tenant.write_bytes(b'not-used')
        real_unlink=Path.unlink
        def fail_unlink(self,*args,**kwargs): raise OSError('locked')
        monkeypatch.setattr(Path,'unlink',fail_unlink)
        try: manager.delete_account(identity.account_id)
        except RuntimeError as e: assert 'could not be deleted' in str(e)
        else: assert False
        monkeypatch.setattr(Path,'unlink',real_unlink)
    finally:
        manager.close()


def test_stripe_cancel_and_missing_price(monkeypatch):
    import tbohk.accounts as accounts
    from tbohk.accounts import StripeBilling
    class Resp:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def read(self): return b'{"id":"subscription"}'
    seen=[]
    def fake_open(req,**kwargs):
        seen.append((req.full_url,req.data)); return Resp()
    monkeypatch.setattr(accounts,'urlopen',fake_open)
    b=StripeBilling('sk','whsec',{'pro':'price_pro'})
    try: b.checkout('unlimited','acct','s','c')
    except RuntimeError as e: assert 'price ID missing' in str(e)
    else: assert False
    assert b.cancel_subscription('sub_1')['id']=='subscription'
    assert seen[-1][0].endswith('/subscriptions/sub_1')


def test_stripe_cancel_subscription_delegates_to_request(monkeypatch):
    from tbohk.accounts import StripeBilling
    b=StripeBilling('sk','whsec',{})
    seen=[]
    monkeypatch.setattr(b,'_request',lambda path,params: seen.append((path,params)) or {'ok':True})
    assert b.cancel_subscription('sub_delegate') == {'ok':True}
    assert seen == [('subscriptions/sub_delegate', {'cancel_at_period_end':'true'})]


def test_account_delete_tolerates_runtime_close_failure():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=manager.create_account('closefail@example.com','long-password-closefail','CloseFail')
    old=(api.account_manager,api.TOKEN,api.billing,dict(api._runtime_cache))
    class BadClose:
        def close(self): raise RuntimeError('already closed')
    api.account_manager=manager; api.TOKEN=None; api.billing=type('B',(),{'configured':lambda self:False})()
    api._runtime_cache[identity.account_id]=(BadClose(),None,None,None,None)
    try:
        r=TestClient(api.app).post('/account/delete',headers={'Authorization':'Bearer '+token},json={'confirmation':'DELETE MY ACCOUNT'})
        assert r.status_code==200 and r.json()['deleted'] is True
    finally:
        api.account_manager,api.TOKEN,api.billing,old_cache=old
        api._runtime_cache.clear(); api._runtime_cache.update(old_cache)
        manager.close()

def test_account_security_recovery_sessions_and_throttle():
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    identity,token=m.create_account('secure@example.com','long-password-secure','Secure')
    verify=m.issue_email_verification(identity.email)
    assert verify and m.verify_email(verify) is True
    assert m.verify_email(verify) is False
    reset=m.request_password_reset(identity.email)
    assert reset and m.reset_password(reset,'new-long-password') is True
    assert m.authenticate_token(token) is None
    _,new_token=m.authenticate_password(identity.email,'new-long-password')
    assert m.sessions(identity.user_id)[0]['revoked'] is False
    assert m.revoke_all_tokens(identity.user_id) >= 1
    assert m.authenticate_token(new_token) is None
    for _ in range(9):
        try: m.authenticate_password(identity.email,'wrong-password')
        except ValueError: pass
        except PermissionError: break
    else: raise AssertionError('throttle did not engage')
    try: m.authenticate_password(identity.email,'wrong-password')
    except PermissionError: pass
    else: raise AssertionError('throttle did not persist')
    m.close()


def test_account_security_http_endpoints_and_non_enumerating_reset():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    old=api.account_manager; api.account_manager=manager
    try:
        c=TestClient(api.app)
        reg=c.post('/account/register',json={'email':'security-http@example.com','password':'long-password-http','name':'Security'})
        assert reg.status_code==200
        token=reg.json()['token']; h={'Authorization':'Bearer '+token}
        assert c.get('/account/sessions',headers=h).status_code==200
        verify=manager.issue_email_verification('security-http@example.com')
        assert c.post('/account/verify-email',json={'token':verify}).json()=={'verified':True}
        assert c.post('/account/password-reset/request',json={'email':'security-http@example.com'}).json()=={'accepted':True}
        assert c.post('/account/password-reset/request',json={'email':'missing-security-http@example.com'}).json()=={'accepted':True}
        reset=manager.request_password_reset('security-http@example.com')
        assert c.post('/account/password-reset/complete',json={'token':reset,'password':'new-http-password'}).json()=={'reset':True}
        login=c.post('/account/login',json={'email':'security-http@example.com','password':'new-http-password'})
        assert login.status_code==200
        assert c.post('/account/sessions/revoke-all',headers={'Authorization':'Bearer '+login.json()['token']}).json()['revoked'] >= 1
    finally:
        api.account_manager=old; manager.close()

def test_auth_throttle_window_resets():
    from tbohk.accounts import AccountManager
    from datetime import datetime, timezone, timedelta
    root=Path(tempfile.mkdtemp()); m=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    a,_=m.create_account('window@example.com','long-password-window','Window')
    key='login:'+m._token_hash(a.email)
    with m.db:
        m.db.execute('INSERT INTO auth_throttle(key,failures,window_started_at,locked_until) VALUES (?,?,?,?)',(key,1,(datetime.now(timezone.utc)-timedelta(seconds=901)).isoformat(),None))
    m._throttle(key)
    assert m.db.execute('SELECT 1 FROM auth_throttle WHERE key=?',(key,)).fetchone() is None
    m.close()


def test_password_reset_http_validation():
    from fastapi.testclient import TestClient
    from tbohk import api
    old=api.account_manager
    root=Path(tempfile.mkdtemp()); from tbohk.accounts import AccountManager
    m=AccountManager(str(root/'accounts.sqlite'),str(root/'data')); api.account_manager=m
    try:
        c=TestClient(api.app)
        assert c.post('/account/password-reset/complete',json={'token':'x'*24,'password':'short'}).status_code==422
    finally:
        api.account_manager=old; m.close()

def test_password_reset_complete_internal_validation_error():
    from fastapi.testclient import TestClient
    from tbohk import api
    old=api.account_manager
    class M:
        def reset_password(self, token, password): raise ValueError('password must be at least 10 characters')
    api.account_manager=M()
    try:
        r=TestClient(api.app).post('/account/password-reset/complete',json={'token':'x'*24,'password':'long-password'})
        assert r.status_code==400 and '10 characters' in r.text
    finally: api.account_manager=old

def test_invoice_payment_failed_resolves_account_from_subscription(monkeypatch):
    from fastapi.testclient import TestClient
    import tbohk.api as api
    c=TestClient(api.app)
    r=c.post('/account/register',json={'email':'invoicefail@example.com','password':'long-password-123','name':'Invoice Fail'})
    h={'Authorization':'Bearer '+r.json()['token']}; aid=api.account_manager.authenticate_token(r.json()['token']).account_id
    api.account_manager.update_plan(aid,'pro','active','cus_invoice','sub_invoice')
    api.billing.webhook_secret='whsec'
    body={'id':'evt_invoice_fail_resolve','type':'invoice.payment_failed','data':{'object':{'subscription':'sub_invoice','customer':'cus_invoice','metadata':{}}}}
    sig=api_test_signature(body, api.billing.webhook_secret) if 'api_test_signature' in globals() else None
    import json,time,hmac,hashlib
    raw=json.dumps(body).encode(); ts=str(int(time.time())); secret=api.billing.webhook_secret
    signature='t='+ts+',v1='+hmac.new(secret.encode(),(ts+'.'+raw.decode()).encode(),hashlib.sha256).hexdigest()
    rr=c.post('/billing/webhook',content=raw,headers={'stripe-signature':signature})
    assert rr.status_code==200
    ident=api.account_manager.authenticate_token(r.json()['token'])
    assert ident.billing_status=='past_due'
