from tbohk.core import TBOHK
from tbohk.research_agent import ResearchAgent


def graph():
    g=TBOHK()
    p=g.add_node('Claim','The river level increased in 2025.','proposed',{'structured':{'subject':'river','predicate':'increased','object':'level','scope':'basin','time':'2025'}})
    e1=g.add_node('Evidence','Report A says the river level increased.','supported',{'origin_id':'agency-a','url':'https://a.example/report','retrieved_at':'2026-09-27T00:00:00+00:00'})
    e2=g.add_node('Evidence','Report B repeats the result.','supported',{'origin_id':'agency-b','url':'https://b.example/report','upstream_origin_ids':['dataset-x'],'retrieved_at':'2026-09-27T00:00:00+00:00'})
    e3=g.add_node('Evidence','Dataset X contains the measurements.','supported',{'origin_id':'dataset-x','url':'https://data.example/x','retrieved_at':'2026-09-27T00:00:00+00:00'})
    g.link(e1.id,'evidence_for',p.id); g.link(e2.id,'evidence_for',p.id); g.link(e3.id,'evidence_for',p.id)
    child=g.add_node('Claim','The river level increase caused flooding.','proposed',{'structured':{'subject':'river level','predicate':'caused','object':'flooding'}})
    g.link(child.id,'derived_from',p.id)
    return g,p,e1,e2,e3,child


def test_gap_map_detects_missing_time_and_verification():
    g,p,*_=graph(); r=ResearchAgent(g).gaps('river level', [p.id])
    kinds={x['kind'] for x in r['gaps']}
    assert 'verification' in kinds
    assert r['not_a_truth_score'] is True


def test_lineage_preserves_evidence_and_dependency_edges():
    g,p,*_=graph(); r=ResearchAgent(g).claim_lineage(p.id)
    assert any(n['kind']=='Evidence' for n in r['nodes'])
    assert any(e['relation']=='evidence_for' for e in r['edges'])


def test_source_family_flags_upstream_grouping():
    g,p,*_=graph(); r=ResearchAgent(g).source_families(p.id)
    assert any(x['family']=='upstream:dataset-x' for x in r['families'])


def test_leverage_is_structural_not_truth_score():
    g,p,*_=graph(); r=ResearchAgent(g).claim_leverage(p.id)
    assert r['bounded_downstream_count'] >= 1
    assert 'truth' in r['interpretation'].lower()


def test_challenge_adds_causal_and_primary_source_checks():
    g,p,*_,child=graph(); r=ResearchAgent(g).challenge_claim(child.id)
    kinds={x['kind'] for x in r['tests']}
    assert 'causality' in kinds
    assert 'primary_source' in kinds


def test_agent_plan_is_bounded_and_deterministic_shape():
    g,p,*_=graph(); r=ResearchAgent(g).plan('river level',[p.id],max_steps=3)
    assert len(r['steps']) <= 3
    assert r['bounded'] is True
    assert r['truth_boundary']
