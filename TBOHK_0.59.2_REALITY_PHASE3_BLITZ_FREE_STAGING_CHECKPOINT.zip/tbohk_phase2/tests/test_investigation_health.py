from tbohk.core import TBOHK
from tbohk.investigation_health import InvestigationHealthAnalyzer


def graph():
    g=TBOHK(':memory:')
    o=g.add_node('Origin','origin','supported')
    e1=g.add_node('Evidence','source one','supported',{'origin_id':o.id,'source_id':'s1'})
    e2=g.add_node('Evidence','source two','supported',{'origin_id':o.id,'source_id':'s2'})
    s1=g.add_node('SourceSnapshot','snapshot one','supported',{'origin_id':o.id,'source_id':'s1','uri':'https://one.test','retrieved_at':'2026-09-27T00:00:00+00:00'})
    s2=g.add_node('SourceSnapshot','snapshot two','supported',{'origin_id':o.id,'source_id':'s2','uri':'https://two.test','retrieved_at':'2026-09-27T00:00:00+00:00'})
    g.link(e1.id,'derived_from',s1.id); g.link(e2.id,'derived_from',s2.id)
    c1=g.add_node('Claim','Revenue was 10 in 2025','verified',{'subject':'revenue','predicate':'value'})
    c2=g.add_node('Claim','Revenue was 12 in 2025','proposed',{'subject':'revenue','predicate':'value'})
    g.link(e1.id,'evidence_for',c1.id); g.link(e2.id,'evidence_for',c2.id)
    return g,e1,e2,c1,c2

def test_composite_health_is_read_only_and_covers_all_sections():
    g,e1,e2,c1,c2=graph(); before=[(n.id,n.status) for n in [e1,e2,c1,c2]]
    h=InvestigationHealthAnalyzer(g).analyze([c1.id,c2.id])
    assert h.coverage['claim_count']==2
    assert h.coverage['covered_claims']==2
    assert h.redundancy['independent_count']==1
    assert h.temporal and h.temporal[0]['relationship']=='quantitative_disagreement'
    assert h.counterfactuals
    assert h.maintenance
    assert h.graph['nodes']
    assert h.boundary.startswith('Composite diagnostic')
    assert [(g.get(n.id).id,g.get(n.id).status) for n in [e1,e2,c1,c2]]==before

def test_counterfactual_source_impact_is_structural_not_status_mutation():
    g,e1,e2,c1,c2=graph(); h=InvestigationHealthAnalyzer(g).analyze([e1.id])
    row=next(x for x in h.counterfactuals if x['evidence_id']==e1.id)
    assert c1.id in row['affected_ids']
    assert g.get(c1.id).status=='verified'

def test_api_route(monkeypatch):
    from fastapi.testclient import TestClient
    import tbohk.api as api
    g,e1,e2,c1,c2=graph(); monkeypatch.setattr(api,'g',g)
    r=TestClient(api.app).get('/investigation/health',params={'roots':c1.id})
    assert r.status_code==200
    body=r.json(); assert body['coverage']['claim_count']==1
    assert 'graph' in body and 'adversarial' in body
