from fastapi.testclient import TestClient

from tbohk.api import app

client=TestClient(app)

def test_operations_queue_is_bounded_and_structural():
    r=client.get('/operations/queue?limit=12')
    assert r.status_code == 200
    body=r.json()
    assert len(body['items']) <= 12
    assert body['ordering'] == 'structural_need_only'
    assert body['not_a_truth_score'] is True
    assert 'never establishes truth' in body['boundary']


def test_operations_queue_items_have_operator_fields():
    body=client.get('/operations/queue?limit=5').json()
    for item in body['items']:
        assert {'type','priority','id','title','reason','target_id','action'} <= item.keys()
