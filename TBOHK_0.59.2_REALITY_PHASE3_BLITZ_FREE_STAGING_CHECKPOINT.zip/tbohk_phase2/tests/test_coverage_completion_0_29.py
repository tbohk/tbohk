import pytest

def test_cli_commands_cover_operational_surface(tmp_path, monkeypatch):
    import tbohk.cli as cli
    db=tmp_path/'cli.sqlite'; monkeypatch.setenv('TBOHK_DB',str(db))
    assert cli.main(['version'])==0
    assert cli.main(['stats'])==0
    assert cli.main(['audit'])==0
    assert cli.main(['invariants'])==0
    assert cli.main(['migrations'])==0
    assert cli.main(['selfcare'])==0
    assert cli.main(['drill'])==2
    backup=tmp_path/'backup.sqlite'; assert cli.main(['backup',str(backup)])==0
    assert backup.exists()
    assert cli.main([])==0
    import uvicorn
    calls=[]; monkeypatch.setattr(uvicorn,'run',lambda *a,**kw:calls.append((a,kw)))
    assert cli.main(['web','--host','127.0.0.1','--port','8765'])==0
    assert calls
    monkeypatch.delenv('TBOHK_API_TOKEN',raising=False)
    assert cli.main(['web','--host','192.0.2.1','--port','8765'])==2
    monkeypatch.setenv('TBOHK_API_TOKEN','token')
    assert cli.main(['web','--host','example.invalid','--port','8766'])==0

def test_verifier_cli(tmp_path):
    import tbohk.verifier_cli as vc
    from tbohk import TBOHK
    db=tmp_path/'verify.sqlite'; TBOHK(str(db)).db.close()
    result=vc.verify_database(str(db)); assert result['passed']
    assert vc.main([str(db)])==0

def test_serialization_security_trust_and_simple_guards():
    from tbohk.serialization import envelope, verify_envelope
    with pytest.raises(ValueError): envelope('',{})
    assert verify_envelope({'serialization_version':'bad','payload':{},'kind':'x'}) is False
    assert verify_envelope(envelope('x',{}),'x') is True
    from tbohk.security import SecurityBoundary, UntrustedInput
    assert SecurityBoundary().assess(UntrustedInput('x',{'a':1},'test'))
    from tbohk.trust import ReleaseSigner
    with pytest.raises(ValueError): ReleaseSigner(b'', '')
    signer=ReleaseSigner(b'k','id'); env=signer.sign({'a':1})
    assert signer.verify({'a':1},env); assert not signer.verify({'a':2},env)

def test_action_checkpoint_and_recovery_error_paths():
    from tbohk import TBOHK
    from tbohk.actions import ActionLedger
    g=TBOHK(); a=ActionLedger(g)
    with pytest.raises(ValueError): a.propose('p','a','t','e',idempotency_key='   ')
    from tbohk.checkpoints import CheckpointManager
    with pytest.raises(ValueError): CheckpointManager(g).create(code_version='x',schema_version=1,invariant_version=1,test_summary={},checkpoint_sequence=-1)
    from tbohk.recovery import RecoveryEngine
    with pytest.raises(PermissionError): RecoveryEngine(g).apply('missing',validation_id='missing')
