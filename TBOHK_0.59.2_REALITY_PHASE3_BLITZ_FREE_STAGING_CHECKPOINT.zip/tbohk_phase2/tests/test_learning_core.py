import pytest
from tbohk.core import TBOHK
from tbohk.learning import LearningEngine
from tbohk.learning_core import LearningCore


def _evals(g):
    suite = LearningEngine(g).create_evaluation_suite("golden", [{"q": "x", "expected": "y"}])
    g.add_node("Target", "baseline target", "supported", {})
    g.add_node("Target", "candidate target", "supported", {})
    base_target = g.db.execute("SELECT id FROM nodes WHERE kind='Target' ORDER BY rowid LIMIT 1").fetchone()[0]
    cand_target = g.db.execute("SELECT id FROM nodes WHERE kind='Target' ORDER BY rowid DESC LIMIT 1").fetchone()[0]
    base = LearningEngine(g).evaluate(base_target, suite.id, metrics={"score": 0.80, "passed": True})
    cand = LearningEngine(g).evaluate(cand_target, suite.id, metrics={"score": 0.85, "passed": True})
    return suite, base, cand


def test_experience_self_model_and_plan_are_auditable():
    g = TBOHK()
    core = LearningCore(g)
    core.record_experience("interaction", "research batteries", "answer delivered", success=True, value=0.9)
    core.record_failure("research batteries", "retrieval_failure", "source unavailable")
    core.record_correction("research batteries", "use primary source", source="user")
    model = core.self_model()
    assert model["sample_size"] == 3
    assert model["observed_outcomes"] == 3
    assert model["failure_classes"]["retrieval_failure"] == 1
    plan = core.plan()
    assert plan.priorities and plan.priorities[0]["task"] == "research batteries"
    assert g.audit()["ok"]


def test_experience_rejects_unknown_kind_and_bad_value():
    core = LearningCore(TBOHK())
    with pytest.raises(ValueError): core.record_experience("magic", "x", "y")
    with pytest.raises(ValueError): core.record_experience("interaction", "x", "y", value="bad")


def test_promotion_requires_same_suite_and_all_gates():
    g = TBOHK(); core = LearningCore(g); suite, base, cand = _evals(g)
    cid = core.propose_candidate("reranker-v2", "retrieval", {"strategy": "rerank"},
        baseline_evaluation_id=base.evaluation_id, candidate_evaluation_id=cand.evaluation_id,
        adversarial_passed=True, security_passed=True, latency_regression_pct=2)
    decision = core.promotion_gate(cid)
    assert decision.decision == "approved"
    assert g.get(cid).status == "verified"


def test_promotion_rejects_regression_and_security_failure():
    g = TBOHK(); core = LearningCore(g)
    suite = LearningEngine(g).create_evaluation_suite("golden", [{"q": "x"}])
    base_target = g.add_node("Target", "baseline", "supported", {})
    cand_target = g.add_node("Target", "candidate", "supported", {})
    base = LearningEngine(g).evaluate(base_target.id, suite.id, metrics={"score": .9, "passed": True})
    cand = LearningEngine(g).evaluate(cand_target.id, suite.id, metrics={"score": .8, "passed": True})
    cid = core.propose_candidate("bad", "reasoning", {}, baseline_evaluation_id=base.evaluation_id,
        candidate_evaluation_id=cand.evaluation_id, adversarial_passed=True, security_passed=False, latency_regression_pct=20)
    decision = core.promotion_gate(cid)
    assert decision.decision == "rejected"
    assert "security evaluation failed" in decision.reasons
    assert "latency regression exceeds promotion budget" in decision.reasons
    assert "candidate score regresses against baseline" in decision.reasons
    assert g.get(cid).status == "rejected"


def test_promotion_rejects_mismatched_suite_and_failed_evaluation():
    g = TBOHK(); core = LearningCore(g)
    a = LearningEngine(g).create_evaluation_suite("a", [{"q": "a"}])
    b = LearningEngine(g).create_evaluation_suite("b", [{"q": "b"}])
    base_target = g.add_node("Target", "baseline", "supported", {})
    cand_target = g.add_node("Target", "candidate", "supported", {})
    base = LearningEngine(g).evaluate(base_target.id, a.id, metrics={"score": .8, "passed": True})
    cand = LearningEngine(g).evaluate(cand_target.id, b.id, metrics={"score": .9, "passed": False})
    cid = core.propose_candidate("mismatch", "routing", {}, baseline_evaluation_id=base.evaluation_id,
        candidate_evaluation_id=cand.evaluation_id, adversarial_passed=True, security_passed=True)
    d = core.promotion_gate(cid)
    assert d.decision == "rejected"
    assert "different evaluation suites" in " ".join(d.reasons)
    assert "baseline and candidate evaluations must both pass" in " ".join(d.reasons)


def test_dashboard_is_safe_and_does_not_promote():
    g = TBOHK(); core = LearningCore(g)
    dashboard = core.dashboard()
    assert dashboard["promotion_boundary"].startswith("approved candidates")
    assert dashboard["self_model"]["sample_size"] == 0


def test_learning_api_endpoints_and_dashboard_are_integrated():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g = TBOHK()
    api.learning_core = LearningCore(api.g)
    client = TestClient(api.app)
    before = api.g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    dashboard = client.get('/learning/dashboard')
    assert dashboard.status_code == 200
    after = api.g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    assert before == after
    recorded = client.post('/learning/experience', json={"kind":"failure","task":"demo","outcome":"failed","success":False,"source":"test","metadata":{"failure_class":"demo"}})
    assert recorded.status_code == 200
    plan = client.post('/learning/plan')
    assert plan.status_code == 200 and plan.json()['priorities'][0]['task'] == 'demo'


def test_learning_core_validation_and_failure_branches():
    g = TBOHK(); core = LearningCore(g)
    with pytest.raises(ValueError): core.record_experience("interaction", "", "outcome")
    with pytest.raises(ValueError): core.self_model(limit=0)
    with pytest.raises(ValueError): core.plan(limit=0)
    with pytest.raises(ValueError): core.propose_candidate("", "target", {}, baseline_evaluation_id="x", candidate_evaluation_id="y", adversarial_passed=True, security_passed=True)
    with pytest.raises(ValueError): core.propose_candidate("x", "", {}, baseline_evaluation_id="x", candidate_evaluation_id="y", adversarial_passed=True, security_passed=True)
    with pytest.raises(ValueError): core.propose_candidate("x", "target", {}, baseline_evaluation_id="x", candidate_evaluation_id="y", adversarial_passed=True, security_passed=True)
    with pytest.raises(ValueError): core.promotion_gate("missing")


def test_learning_core_unknown_success_and_missing_scores_and_adversarial_gate():
    g=TBOHK(); core=LearningCore(g)
    core.record_experience("interaction", "unknown", "no outcome yet", success=None)
    assert core.self_model()["sample_size"] == 1
    suite=LearningEngine(g).create_evaluation_suite("s", [{"q":"x"}])
    bt=g.add_node("Target","b","supported",{}); ct=g.add_node("Target","c","supported",{})
    base=LearningEngine(g).evaluate(bt.id,suite.id,metrics={"passed":True})
    cand=LearningEngine(g).evaluate(ct.id,suite.id,metrics={"passed":True})
    cid=core.propose_candidate("c","target",{},baseline_evaluation_id=base.evaluation_id,candidate_evaluation_id=cand.evaluation_id,adversarial_passed=False,security_passed=True)
    d=core.promotion_gate(cid); assert "adversarial evaluation failed" in d.reasons and "both baseline and candidate scores are required" in d.reasons


def test_learning_api_error_paths(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g=TBOHK(); api.learning_core=LearningCore(api.g)
    c=TestClient(api.app)
    monkeypatch.setattr(api.learning_core, "dashboard", lambda: (_ for _ in ()).throw(RuntimeError("dash")))
    assert c.get('/learning/dashboard').status_code == 500
    monkeypatch.setattr(api.learning_core, "record_experience", lambda *a, **k: (_ for _ in ()).throw(ValueError("bad")))
    assert c.post('/learning/experience', json={"kind":"interaction","task":"x","outcome":"y"}).status_code == 400
    monkeypatch.setattr(api.learning_core, "plan", lambda: (_ for _ in ()).throw(RuntimeError("plan")))
    assert c.post('/learning/plan').status_code == 500
    monkeypatch.setattr(api.learning_core, "propose_candidate", lambda *a, **k: (_ for _ in ()).throw(ValueError("candidate")))
    body={"name":"n","target":"t","change":{},"baseline_evaluation_id":"b","candidate_evaluation_id":"c","adversarial_passed":True,"security_passed":True}
    assert c.post('/learning/candidates',json=body).status_code == 400
    monkeypatch.setattr(api.learning_core, "promotion_gate", lambda *a, **k: (_ for _ in ()).throw(ValueError("promote")))
    assert c.post('/learning/candidates/x/promote').status_code == 400


def test_learning_safe_telemetry_does_not_break_primary_api(monkeypatch):
    from tbohk import api
    class Broken:
        def record_experience(self,*a,**k): raise RuntimeError("telemetry unavailable")
    old=api.learning_core; api.learning_core=Broken()
    try:
        assert api._learn_safe("interaction","x","y") is None
    finally:
        api.learning_core=old


def test_replay_batch_is_deterministic_and_non_mutating():
    g=TBOHK(); core=LearningCore(g)
    core.record_experience("interaction","a","ok",success=True,value=.5)
    core.record_failure("b","retrieval","miss")
    before=g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    first=core.replay(limit=10)
    second=core.replay(limit=10)
    assert first == second
    assert first["count"] == 2 and first["batch_sha256"]
    assert g.db.execute("SELECT COUNT(*) FROM nodes").fetchone()[0] == before
    assert core.replay(limit=10,kinds={"failure"})["count"] == 1
    with pytest.raises(ValueError): core.replay(limit=0)


def test_benchmark_runs_and_records_auditable_result():
    g=TBOHK(); core=LearningCore(g)
    result=core.run_benchmark(record=True, assessor="test")
    assert result["total"] == 12
    assert result["failed"] == 0
    assert result["benchmark_run_id"]
    assert g.get(result["benchmark_run_id"]).kind == "BenchmarkRun"
    observational=core.run_benchmark(record=False)
    assert "benchmark_run_id" not in observational


def test_learning_benchmark_api_error_path(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g=TBOHK(); api.learning_core=LearningCore(api.g)
    c=TestClient(api.app)
    monkeypatch.setattr(api.learning_core, "run_benchmark", lambda **_: (_ for _ in ()).throw(RuntimeError("bench")))
    assert c.post('/learning/benchmark').status_code == 500


def test_learning_dataset_is_deterministic_provenance_preserving_and_non_overlapping():
    g = TBOHK(); core = LearningCore(g)
    core.record_experience("interaction", "a", "ok", success=True)
    core.record_failure("b", "retrieval", "miss")
    core.record_correction("c", "use primary source")
    first = core.build_dataset(limit=10, validation_fraction=0.2, record=False)
    second = core.build_dataset(limit=10, validation_fraction=0.2, record=False)
    assert first == second
    assert first["source_count"] == 3
    assert not ({x["experience_id"] for x in first["training"]} & {x["experience_id"] for x in first["validation"]})
    assert all(x["example_sha256"] for x in first["training"] + first["validation"])
    assert first["contamination_check"] == "passed"


def test_learning_dataset_validation_and_recording():
    g = TBOHK(); core = LearningCore(g)
    core.record_experience("interaction", "a", "ok")
    with pytest.raises(ValueError): core.build_dataset(limit=0)
    with pytest.raises(ValueError): core.build_dataset(validation_fraction=0.01)
    result = core.build_dataset(validation_fraction=0.5, record=True)
    assert result["dataset_id"]
    assert g.get(result["dataset_id"]).kind == "LearningDataset"


def test_learning_dataset_api_error_and_success(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g = TBOHK(); api.learning_core = LearningCore(api.g)
    c = TestClient(api.app)
    ok = c.post('/learning/datasets?limit=10&validation_fraction=0.2')
    assert ok.status_code == 200
    assert ok.json()['dataset_id']
    bad = c.post('/learning/datasets?limit=0')
    assert bad.status_code == 400
    monkeypatch.setattr(api.learning_core, 'build_dataset', lambda **_: (_ for _ in ()).throw(RuntimeError('dataset')))
    assert c.post('/learning/datasets').status_code == 500


def test_learning_dataset_empty_and_contamination_guard():
    class EmptyResult:
        def fetchall(self): return []
    class EmptyDB:
        def execute(self, *args): return EmptyResult()
    class EmptyGraph:
        db = EmptyDB()
    empty = LearningCore(EmptyGraph()).build_dataset(record=False)
    assert empty['source_count'] == 0 and empty['generated_at'] == ''

    class BlankResult:
        def fetchall(self):
            return [RowBlank()]
    class RowBlank:
        def __getitem__(self, key):
            return {'id':'blank','metadata':__import__('json').dumps({'experience_kind':'interaction','task':'','outcome':'ignored'}),'created_at':'x'}[key]
    class BlankDB:
        def execute(self, *args): return BlankResult()
    class BlankGraph:
        db = BlankDB()
    assert LearningCore(BlankGraph()).build_dataset(record=False)['source_count'] == 0

    class Row:
        def __init__(self, i, outcome): self.values={'id':'same','metadata':__import__('json').dumps({'experience_kind':'interaction','task':i,'outcome':outcome,'success':True,'source':'test'}),'created_at':i}
        def __getitem__(self, key): return self.values[key]
    class DupResult:
        def fetchall(self): return [Row('a','one'), Row('b','two')]
    class DupDB:
        def execute(self, *args): return DupResult()
    class DupGraph:
        db = DupDB()
    class ForcedSplit(LearningCore):
        calls = 0
        @staticmethod
        def _digest(value):
            ForcedSplit.calls += 1
            return ('00' if ForcedSplit.calls == 1 else 'ff') + ('0' * 62)
    with pytest.raises(RuntimeError, match='contamination'):
        ForcedSplit(DupGraph()).build_dataset(record=False)

def test_learning_experiment_api_error_paths(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g=TBOHK(); api.learning_experiments=__import__('tbohk.learning_experiments',fromlist=['LearningExperimentEngine']).LearningExperimentEngine(api.g)
    c=TestClient(api.app)
    assert c.post('/learning/experiments?dataset_id=missing').status_code == 400
    monkeypatch.setattr(api.learning_experiments,'run',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('experiment')))
    assert c.post('/learning/experiments?dataset_id=x').status_code == 500
    assert c.get('/learning/experiments/missing').status_code == 400
