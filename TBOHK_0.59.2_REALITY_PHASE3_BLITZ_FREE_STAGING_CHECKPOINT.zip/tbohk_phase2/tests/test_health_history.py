from tbohk.core import TBOHK
from tbohk.investigation_health import InvestigationHealthAnalyzer
from tbohk.health_history import InvestigationHealthHistory


def graph():
    g=TBOHK(':memory:')
    c=g.add_node('Claim','A claim','verified')
    e=g.add_node('Evidence','support','supported',{'origin_id':'o1','source_id':'s1'})
    g.link(e.id,'evidence_for',c.id)
    return g,c,e


def test_health_snapshot_persists_and_detects_longitudinal_change():
    g,c,e=graph(); h=InvestigationHealthAnalyzer(g).analyze([c.id]); history=InvestigationHealthHistory(g)
    first=history.snapshot([c.id],health=__import__('dataclasses').asdict(h))
    assert first.previous_snapshot_id is None
    assert history.history([c.id])[0]['id']==first.snapshot_id
    g.add_node('Claim','Uncovered claim','proposed')
    h2=InvestigationHealthAnalyzer(g).analyze([c.id])
    second=history.snapshot([c.id],health=__import__('dataclasses').asdict(h2))
    assert second.previous_snapshot_id==first.snapshot_id
    assert second.comparison['baseline'] is False


def test_health_snapshot_is_excluded_from_release_checkpoint_hashes():
    from tbohk.checkpoints import CheckpointManager
    g,c,e=graph(); cp=CheckpointManager(g).create(code_version='test',schema_version='test',invariant_version='test',test_summary='ok',require_clean=False)
    assert cp.manifest_sha256
    health=__import__('dataclasses').asdict(InvestigationHealthAnalyzer(g).analyze([c.id]))
    InvestigationHealthHistory(g).snapshot([c.id],health=health)
    assert CheckpointManager(g).verify(cp.checkpoint_id)


def test_health_history_api_persists_and_returns_snapshots(monkeypatch):
    from fastapi.testclient import TestClient
    import tbohk.api as api
    g,c,e=graph(); monkeypatch.setattr(api,'g',g)
    client=TestClient(api.app)
    r=client.post('/investigation/health/snapshot',params={'roots':c.id})
    assert r.status_code==200
    sid=r.json()['snapshot_id']
    h=client.get('/investigation/health/history',params={'roots':c.id})
    assert h.status_code==200
    assert h.json()['snapshots'][0]['id']==sid


def test_health_history_rejects_ambiguous_roots_and_invalid_limits():
    g,c,e=graph(); history=InvestigationHealthHistory(g)
    import pytest
    with pytest.raises(ValueError, match="iterable"):
        history.history(c.id)
    with pytest.raises(ValueError, match="between 1 and 100"):
        history.history([c.id], limit=0)
    with pytest.raises(ValueError, match="between 1 and 100"):
        history.history([c.id], limit=101)


def test_health_snapshot_digest_is_stable_for_equivalent_health_payload():
    g,c,e=graph(); history=InvestigationHealthHistory(g)
    import dataclasses
    health=dataclasses.asdict(InvestigationHealthAnalyzer(g).analyze([c.id]))
    a=history.snapshot([c.id], health=health)
    b=history.snapshot([c.id], health=dict(health))
    assert a.digest == b.digest
    assert b.previous_snapshot_id == a.snapshot_id
