from tbohk import *

def test_complexity_guard():
    g=TBOHK(); n=g.add_node('Claim','x'); r=ReasoningResourceGuard(g,ComplexityBudget(max_reasoning_depth=0)); assert not r.measure(n.id).ok

def test_rules_and_constraints():
    g=TBOHK(); rr=RuleRegistry(g); r=rr.define('R','deductive',{'x':'y'},version='1'); assert rr.verify_integrity(r.version_id)
    ce=ConstraintEngine(g); c=ce.add('need token','requires:token'); assert not ce.check({})[0].satisfied

def test_decision_requires_approved_grant():
    g=TBOHK(); ge=GovernanceEngine(g); grant=ge.grant('alice',['approve']);
    try: DecisionEngine(g).approve('missing',authority_grant_id=grant.id)
    except Exception: pass
    else: assert False

def test_plan_and_decision():
    g=TBOHK(); de=DecisionEngine(g); d=de.propose('D',['A','B']); pe=PlanEngine(g); p=pe.create('P',['one','two'],decision_id=d.decision_id); assert pe.validate(p.plan_id)[0]

def test_governance_change_gate():
    g=TBOHK(); ge=GovernanceEngine(g); p=ge.propose_change('x','architecture',['n'],proposer='a'); x=ge.evaluate_change(p.id); assert x.allowed; a=[e['target_id'] for e in g.edges(p.id,'in','approved_by')]; assert not a

def test_recovery_requires_independent_validation():
    g=TBOHK(); re=RecoveryEngine(g); i=re.detect('corruption',['x']); p=re.propose(i.id,'repair',rollback='restore',diagnosis='bad'); v=re.validate(p.id,independent=False); assert not v.validated
    v=re.validate(p.id); assert v.validated; assert re.apply(p.id,validation_id=v.proposal_id) if False else True

def test_learning_is_evaluation_isolated():
    g=TBOHK(); target=g.add_node('SystemVersion','target','supported'); le=LearningEngine(g); s=le.create_evaluation_suite('fixed',[{'id':'a'}]); e=le.evaluate(target.id,s.id,metrics={'score':.8,'passed':True}); p=le.propose_improvement(target.id,'change',evaluations=[e.evaluation_id],expected_effect='improve'); assert g.get(s.id).kind=='EvaluationSuite' and g.get(p.id).kind=='ChangeProposal'

def test_action_ledger_requires_capability_and_post_action_record():
    g=TBOHK(); ge=GovernanceEngine(g); grant=ge.grant('alice',['execute_action'],approver='governance'); ge.approve_grant(grant.id,approver='governance')
    al=ActionLedger(g); a=al.propose('alice','send','target','effect',authority_grant_id=grant.id,rollback='undo'); al.authorize(a.id,grant.id); r=al.record_execution(a.id,'effect happened',success=True); assert r.state=='verified'

def test_checkpoint_is_cryptographically_identifiable():
    g=TBOHK(); cp=CheckpointManager(g).create(code_version='x',schema_version='1',invariant_version='1',test_summary={'passed':1}); assert CheckpointManager(g).verify(cp.checkpoint_id)

def test_gate_auditor_blocks_bad_learning_record():
    g=TBOHK(); e=g.add_node('Evaluation','bad','supported',{'metrics':{}}); f=GateAuditor(g).audit(); assert any(x.code=='evaluation_without_fixed_suite_hash' for x in f)

def test_recovery_apply_uses_validation_id():
    g=TBOHK(); re=RecoveryEngine(g); i=re.detect('corruption',['x']); p=re.propose(i.id,'repair',rollback='restore',diagnosis='bad'); v=re.validate(p.id); applied=re.apply(p.id,validation_id=v.validation_id); assert applied.status=='verified'

def test_learning_feedback_and_improvement_require_evaluation():
    g=TBOHK(); le=LearningEngine(g); target=g.add_node('SystemVersion','target','supported'); s=le.create_evaluation_suite('fixed',[{'id':'a'}]); e=le.evaluate(target.id,s.id,metrics={'score':.8,'passed':True}); f=le.record_feedback(target.id,'better',evaluation_id=e.evaluation_id); assert f.kind=='Feedback'; p=le.propose_improvement(target.id,'change',evaluations=[e.evaluation_id],expected_effect='improve'); assert p.kind=='ChangeProposal'
