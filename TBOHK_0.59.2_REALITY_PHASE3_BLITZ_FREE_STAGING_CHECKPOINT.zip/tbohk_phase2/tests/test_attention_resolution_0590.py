from tbohk.core import TBOHK
from tbohk.learning_core import LearningCore


def test_attention_feedback_records_before_after_resolution_signal_without_mutation():
    import tempfile
    g=TBOHK(tempfile.mktemp(suffix='.sqlite'))
    n=g.add_node('Claim','A claim','proposed',{})
    before=(n.status,n.content,n.metadata)
    lc=LearningCore(g)
    x=lc.attention_feedback(n.id,'research',success=True,
        baseline={'gap_count':2,'conflict_count':1,'impact_count':4},
        current={'gap_count':1,'conflict_count':1,'impact_count':3})
    meta=g.get(x.experience_id).metadata['metadata']
    assert meta['state_delta']=={'gap_count':-1.0,'conflict_count':0.0,'impact_count':-1.0}
    assert meta['resolution_signal']=='improved'
    after=g.get(n.id)
    assert (after.status,after.content,after.metadata)==before


def test_attention_feedback_marks_expansion_or_unchanged():
    import tempfile
    g=TBOHK(tempfile.mktemp(suffix='.sqlite'))
    n=g.add_node('Claim','A claim','proposed',{})
    lc=LearningCore(g)
    a=lc.attention_feedback(n.id,'impact',success=False,baseline={'gap_count':0},current={'gap_count':1})
    assert g.get(a.experience_id).metadata['metadata']['resolution_signal']=='expanded'
    b=lc.attention_feedback(n.id,'impact',success=True,baseline={'gap_count':1},current={'gap_count':1})
    assert g.get(b.experience_id).metadata['metadata']['resolution_signal']=='unchanged'
