from tbohk.differential import DifferentialComparator

def test_differential_equal_is_deterministic():
    c=DifferentialComparator(); a=c.compare({"x":[1,2]}, {"x":[1,2]}); b=c.compare({"x":[1,2]}, {"x":[1,2]})
    assert a.equal and a.digest == b.digest

def test_differential_exposes_precise_mismatch():
    r=DifferentialComparator().compare({"x":[1,2]}, {"x":[1,3]})
    assert not r.equal and r.mismatches[0].path == "/x/1"
