import json
from tbohk import TBOHK, CheckpointManager
from tbohk.gates_21_30 import *

def test_g21_chain_detects_event_tamper():
    g=TBOHK(); n=g.add_node('Claim','x'); g._event('test',n.id,{'x':1})
    g.db.execute("UPDATE events SET payload='tampered' WHERE event_type='test'"); g.db.commit()
    r=G21LedgerAuditor(g).audit(); assert not r.passed and any(f.code=='ledger_chain_break' for f in r.findings)

def test_g21_clean():
    g=TBOHK(); g.add_node('Claim','x'); assert G21LedgerAuditor(g).audit().passed

def test_g22_checkpoint_contains_full_history_hashes():
    g=TBOHK(); g.add_node('Claim','x'); cp=CheckpointManager(g).create(code_version='g22',schema_version='1',invariant_version='1',test_summary={})
    assert all(k in cp.manifest for k in ('event_hash','revision_hash','ledger_hash'))
    assert G22PortableCheckpointAuditor(g).audit().passed

def test_g23_secret_material_blocked():
    g=TBOHK(); g.add_node('Tool','x',metadata={'api_token':'SECRET'})
    assert not G23KeyLifecycleAuditor(g).audit().passed

def test_g24_observation_replay_is_nonmutating():
    g=TBOHK(); g.add_node('Claim','x'); assert G24ReplayConcurrencyAuditor(g).audit().passed

def test_g25_tool_requires_policy():
    g=TBOHK(); g.add_node('Tool','search',metadata={'tool':'search'})
    r=G25BoundaryAuditor(g).audit(); assert any(f.code=='tool_without_policy' for f in r.findings)

def test_g26_verified_conflict_blocks():
    g=TBOHK(); a=g.add_node('Claim','a',status='verified',metadata={'confidence':.9}); b=g.add_node('Claim','b',status='verified',metadata={'confidence':.9}); g.link(a.id,'contradicts',b.id)
    assert not G26UncertaintyConflictAuditor(g).audit().passed

def test_g27_research_contract():
    g=TBOHK(); g.add_node('ResearchTask','q',metadata={'question':'q'})
    assert not G27ResearchCompletenessAuditor(g).audit().passed

def test_g28_is_nonblocking_when_single_verifier():
    g=TBOHK(); g.add_node('EvaluationSuite','e',metadata={'implementation_id':'one'})
    r=G28VerifierConformanceAuditor(g).audit(); assert r.passed
    assert any(f.code=='single_verifier_implementation' for f in r.findings)

def test_g29_verified_action_needs_durable_execution():
    g=TBOHK(); g.add_node('Action','a',status='verified',metadata={})
    assert not G29ActionDurabilityAuditor(g).audit().passed

def test_g30_verified_decision_needs_assurance_edge():
    g=TBOHK(); g.add_node('Decision','d',status='verified')
    assert not G30RedTeamAuditor(g).audit().passed

def test_all_gates_run():
    g=TBOHK(); g.add_node('Claim','x')
    reports=run_all(g); assert len(reports)==10; assert all(r.gate for r in reports)
