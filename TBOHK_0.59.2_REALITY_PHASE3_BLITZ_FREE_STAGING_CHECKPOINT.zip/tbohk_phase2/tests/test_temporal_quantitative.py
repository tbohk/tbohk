from tbohk.core import TBOHK
from tbohk.synthesis import EvidenceSynthesizer
from tbohk.temporal_quantitative import TemporalQuantitativeAnalyzer

def claim(g, text): return g.add_node('Claim', text, 'proposed')

def test_different_years_are_not_called_contradictions():
    g=TBOHK(':memory:'); s=EvidenceSynthesizer(g)
    a=claim(g,'Revenue is 100 million in 2024')
    b=claim(g,'Revenue is 120 million in 2025')
    c=s.compare(a.id,b.id)
    assert c.relationship=='temporal_scope_difference'

def test_same_period_different_values_are_quantitative_disagreement():
    g=TBOHK(':memory:'); s=EvidenceSynthesizer(g)
    a=claim(g,'Revenue is 100 million in 2024')
    b=claim(g,'Revenue is 120 million in 2024')
    c=s.compare(a.id,b.id)
    assert c.relationship=='quantitative_disagreement'

def test_relative_duration_is_preserved_without_fabricated_date():
    t=TemporalQuantitativeAnalyzer.parse_time('reliable after twelve months')
    assert t is not None
    assert t.kind=='relative_duration'
    assert t.start is None and t.end is None

def test_quarter_parser():
    t=TemporalQuantitativeAnalyzer.parse_time('growth in Q2 2025')
    assert t.kind=='quarter'
    assert t.start=='2025-04-01'

def test_numeric_parser():
    q=TemporalQuantitativeAnalyzer.parse_quantity('grew by 17.5%')
    assert q.value==17.5 and q.unit=='%'

def test_version_bumped():
    import tbohk.api as api
    import tbohk; assert api.app.version==tbohk.__version__
