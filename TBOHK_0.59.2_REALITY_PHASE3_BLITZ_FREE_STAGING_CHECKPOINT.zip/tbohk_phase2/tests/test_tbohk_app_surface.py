import os, tempfile

def test_operator_console_surface():
    os.environ['TBOHK_DB'] = tempfile.mktemp(suffix='.sqlite')
    from fastapi.testclient import TestClient
    from tbohk.api import app
    client = TestClient(app)
    response = client.get('/')
    assert response.status_code == 200
    assert 'Ask a question' in response.text
    assert 'Bounded, provenance-preserving source acquisition' in response.text
    assert 'Assurance' in response.text
    assert 'Plans' in response.text

def test_pricing_catalog_is_public_and_complete():
    from fastapi.testclient import TestClient
    from tbohk.api import app
    data = TestClient(app).get('/pricing').json()
    assert data['currency'] == 'USD'
    assert [p['id'] for p in data['plans']] == ['free', 'pro', 'unlimited']
    assert [p['price_monthly'] for p in data['plans']] == [0, 10, 20]
    assert [p['asks_monthly'] for p in data['plans']] == [25, 250, 1000]

def test_review_queue_and_conflict_resolution():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g = TBOHK()
    from tbohk.intelligence import KnowledgeIntelligence
    api.intelligence = KnowledgeIntelligence(api.g)
    ev1 = api.g.add_node('Evidence', 'source one', 'supported', {'locator':'https://a.example'})
    ev2 = api.g.add_node('Evidence', 'source two', 'supported', {'locator':'https://b.example'})
    a = api.g.add_node('Claim', 'A', 'proposed', {})
    b = api.g.add_node('Claim', 'B', 'proposed', {})
    api.g.link(ev1.id, 'evidence_for', a.id); api.g.link(ev2.id, 'evidence_for', b.id)
    conflict = api.intelligence.epistemic.contradict(a.id, b.id, 'test')
    c = TestClient(api.app)
    q = c.get('/review/queue')
    assert q.status_code == 200 and len(q.json()['conflicts']) == 1 and len(q.json()['claims']) == 2
    r = c.post('/review/conflicts/'+conflict.id+'/resolve', json={'disposition':'defer','resolver':'reviewer','rationale':'needs more evidence'})
    assert r.status_code == 200

def test_review_verify_endpoint_success_and_fail_closed(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    api.g = TBOHK()
    node = api.g.add_node('Claim', 'verified candidate', 'proposed', {})
    api.intelligence.epistemic.verify_claim = lambda node_id, reviewer: api.g.get(node_id)
    c = TestClient(api.app)
    r = c.post('/review/claims/'+node.id+'/verify', json={'reviewer':'reviewer'})
    assert r.status_code == 200 and r.json()['id'] == node.id
    def fail(*args, **kwargs): raise ValueError('not enough evidence')
    api.intelligence.epistemic.verify_claim = fail
    r = c.post('/review/claims/'+node.id+'/verify', json={'reviewer':'reviewer'})
    assert r.status_code == 400
    def deny(*args, **kwargs): raise PermissionError('review forbidden')
    api.intelligence.epistemic.verify_claim = deny
    r = c.post('/review/claims/'+node.id+'/verify', json={'reviewer':'reviewer'})
    assert r.status_code == 403

def test_review_conflict_resolution_rejects_bad_input(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    def fail(*args, **kwargs): raise ValueError('bad disposition')
    api.intelligence.epistemic.resolve_conflict = fail
    r = TestClient(api.app).post('/review/conflicts/conflict_missing/resolve', json={'disposition':'bad','resolver':'reviewer'})
    assert r.status_code == 400

def test_answer_presentation_is_grounded_and_media_rich(monkeypatch):
    from tbohk import api
    from tbohk.core import TBOHK
    from tbohk.answer import AnswerPresenter
    from fastapi.testclient import TestClient
    api.g=TBOHK(); api.intelligence=__import__('tbohk.intelligence',fromlist=['KnowledgeIntelligence']).KnowledgeIntelligence(api.g)
    e1=api.g.add_node('Evidence','source text','supported',{'uri':'https://example.com/article','title':'Example article','source_id':'src1','publisher_id':'Example','media':[{'type':'image','url':'https://example.com/a.jpg','alt':'Example image'},{'type':'video','url':'https://example.com/v.mp4','alt':'Example video'}],'observation_time':'2026-09-27T00:00:00Z'})
    c=api.g.add_node('Claim','Gravity is a measured phenomenon.','verified',{})
    api.g.link(e1.id,'evidence_for',c.id)
    a=AnswerPresenter(api.g).build('gravity')
    assert a['items'][0]['confidence']=='supported' and a['sources'][0]['url'].startswith('https://')
    assert len(a['images'])==1 and len(a['videos'])==1 and a['truth_boundary']
    r=TestClient(api.app).get('/answer?q=gravity')
    assert r.status_code==200 and r.json()['items'][0]['text'].startswith('Gravity')
    empty=AnswerPresenter(api.g).build('quantum banana')
    assert empty['items']==[] and empty['headline'].startswith('No verified')
    proposed=api.g.add_node('Claim','Gravity has unresolved scope.','proposed',{})
    partial=AnswerPresenter(api.g).build('gravity')
    assert partial['headline'].startswith('A partial answer') and proposed.id in partial['unresolved_claim_ids']
    import pytest
    with pytest.raises(ValueError): AnswerPresenter(api.g).build('   ')
    assert AnswerPresenter._confidence('verified',2,2)=='well-supported'
    assert AnswerPresenter._confidence('verified',1,1)=='supported'
    assert AnswerPresenter._confidence('proposed',1,1).startswith('evidence')
    assert AnswerPresenter._confidence('proposed',0,0)=='unverified'
    assert AnswerPresenter(api.g)._media([e1])[0][0]['url'].endswith('a.jpg')
    assert AnswerPresenter(api.g)._media([e1])[1][0]['url'].endswith('v.mp4')
    class BadString:
        def __str__(self): raise RuntimeError('bad string')
    assert AnswerPresenter._public_url(BadString()) is False


def test_direct_url_media_extraction_and_safe_media_failures(monkeypatch):
    from tbohk.service import DirectURLProvider
    import tbohk.service as svc
    class Resp:
        headers={'content-type':'text/html'}
        def read(self,n): return b'''<html><title>Media</title><body><img src="/a.jpg" alt="A"><img data-src="/b.jpg"><video src="/v.mp4"></video><source src="/s.mp4"><iframe src="https://youtube.com/embed/x"></iframe></body></html>'''
        def __enter__(self): return self
        def __exit__(self,*a): pass
    class Op:
        def open(self,*a,**k): return Resp()
    p=DirectURLProvider(['https://example.com']); monkeypatch.setattr(p,'_safe_host',lambda h:None); monkeypatch.setattr(p,'_opener',lambda:Op())
    docs=p.search('media'); assert len(docs[0].media)==5
    old=svc.urljoin
    def boom(base,src): raise ValueError('bad media url')
    monkeypatch.setattr(svc,'urljoin',boom)
    docs=p.search('media'); assert docs[0].media==()
    monkeypatch.setattr(svc,'urljoin',old)


def test_answer_endpoint_bad_input_and_evidence_filtering(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.answer import AnswerPresenter
    from tbohk.core import TBOHK
    api.g=TBOHK()
    e=api.g.add_node('Evidence','e','supported',{'uri':'not-a-url','source_id':'x','media':[{'type':'other','url':'https://x.test/x'},{'url':'https://x.test/y'},'bad']})
    c=api.g.add_node('Claim','alpha claim','proposed',{})
    api.g.link(e.id,'evidence_for',c.id)
    assert AnswerPresenter(api.g)._evidence(c.id)==()
    assert AnswerPresenter(api.g)._media([e])==( [], [] )
    old=api.AnswerPresenter; api.AnswerPresenter=lambda g: (_ for _ in ()).throw(ValueError('answer failed'))
    try: assert TestClient(api.app).get('/answer?q=alpha').status_code==400
    finally: api.AnswerPresenter=old
