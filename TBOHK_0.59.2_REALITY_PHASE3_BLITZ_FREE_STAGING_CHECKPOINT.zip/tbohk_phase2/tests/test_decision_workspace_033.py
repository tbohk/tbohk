from tbohk.core import TBOHK
from tbohk.decision_workspace import DecisionWorkspace

def test_decision_workspace_preserves_assumptions_unknowns_and_change_conditions():
    g=TBOHK(); w=DecisionWorkspace(g)
    r=w.create('Choose a system', objective='Reduce risk', question='Which option fits?',
               alternatives=['A', {'text':'B','cost':10}],
               assumptions=[{'text':'Demand remains stable','strengthen_with':['new demand data'],'weaken_with':['decline'],'overturn_with':['structural change']}],
               unknowns=[{'text':'Migration cost','affects':['A','B']}])
    out=w.inspect(r.decision_id)
    assert len(out['alternatives'])==2
    assert out['change_my_mind'][0]['overturn_with']==['structural change']
    assert out['sensitivity'][0]['information_value']=='high'
    assert 'does not select' in out['boundary']

def test_decision_workspace_links_entity_and_rejects_missing_entity():
    g=TBOHK(); w=DecisionWorkspace(g); e=g.add_node('Entity','Acme','proposed',{})
    r=w.create('Decision',entity_id=e.id)
    assert any(x['target_id']==e.id for x in g.edges(r.decision_id,'out','about'))
    try: w.create('Bad',entity_id='missing')
    except ValueError as exc: assert 'invalid entity' in str(exc)
    else: raise AssertionError('expected invalid entity')
