import json
from pathlib import Path
from tempfile import TemporaryDirectory

def test_provider_neutral_entitlement_and_event_idempotency():
    from tbohk.accounts import AccountManager
    m=AccountManager('/tmp/tbohk-g2-events.sqlite','/tmp/tbohk-g2-data')
    try:
        a,_=m.create_account('g2@example.com','long-password-g2','G2')
        event={'id':'evt_1','type':'customer.subscription.updated'}
        assert m.record_billing_event('stripe','evt_1',event['type'],event) is True
        assert m.record_billing_event('stripe','evt_1',event['type'],event) is False
        row=m.upsert_entitlement(a.account_id,'stripe','sub_1','pro','active',cancel_at_period_end=True,raw=event)
        assert row['plan']=='pro' and row['cancel_at_period_end']==1
        state=m.entitlement_state(a.account_id)
        assert state['plan']=='pro' and state['billing_status']=='active'
        assert state['entitlements'][0]['provider']=='stripe'
    finally:
        m.close()
        Path('/tmp/tbohk-g2-events.sqlite').unlink(missing_ok=True)
        for p in Path('/tmp/tbohk-g2-data').glob('*') if Path('/tmp/tbohk-g2-data').exists() else []: p.unlink(missing_ok=True)

def test_normalize_rejects_invalid_provider_and_plan():
    from tbohk.billing import normalize_entitlement
    import pytest
    with pytest.raises(ValueError, match='unsupported billing provider'):
        normalize_entitlement(provider='paypal',external_id='x',account_id='a',plan='pro',status='active')
    with pytest.raises(ValueError, match='invalid plan'):
        normalize_entitlement(provider='apple',external_id='x',account_id='a',plan='gold',status='active')

def test_http_entitlement_is_account_scoped():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    with TemporaryDirectory() as d:
        root=Path(d); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
        a,token=manager.create_account('g2http@example.com','long-password-g2','G2')
        old=api.account_manager; api.account_manager=manager
        try:
            c=TestClient(api.app); h={'Authorization':'Bearer '+token}
            r=c.post('/billing/entitlement',headers=h,json={'provider':'google','external_id':'purchase-1','plan':'unlimited','status':'active'})
            assert r.status_code==200 and r.json()['provider']=='google'
            assert c.get('/billing/entitlements',headers=h).json()['plan']=='unlimited'
            bad=c.post('/billing/entitlement',headers=h,json={'provider':'apple','external_id':'x','account_id':'other','plan':'pro','status':'active'})
            assert bad.status_code==403
        finally:
            api.account_manager=old; manager.close()

def test_canceled_entitlement_reconciles_to_free():
    from tbohk.accounts import AccountManager
    with TemporaryDirectory() as d:
        root=Path(d); m=AccountManager(str(root/'a.sqlite'),str(root/'data'))
        a,_=m.create_account('cancel@example.com','long-password-g2','Cancel')
        m.upsert_entitlement(a.account_id,'stripe','sub-cancel','pro','canceled')
        state=m.entitlement_state(a.account_id)
        assert state['plan']=='free' and state['billing_status']=='canceled'
        m.close()

def test_http_entitlement_validation_error():
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    with TemporaryDirectory() as d:
        root=Path(d); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
        _,token=manager.create_account('g2bad@example.com','long-password-g2','G2')
        old=api.account_manager; api.account_manager=manager
        try:
            c=TestClient(api.app)
            r=c.post('/billing/entitlement',headers={'Authorization':'Bearer '+token},json={'provider':'paypal','external_id':'x','plan':'pro','status':'active'})
            assert r.status_code==400 and 'unsupported billing provider' in r.text
        finally:
            api.account_manager=old; manager.close()
