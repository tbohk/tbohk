from tbohk.core import TBOHK
from tbohk.intelligence import KnowledgeIntelligence
from tbohk.research import MockProvider, SourceDocument
from datetime import datetime, timezone

def mk(pid,sid,oid,text):
    return SourceDocument(pid,sid,"https://example.test/"+sid,text,pid,datetime.now(timezone.utc).isoformat(),oid)

def test_structured_claim_and_independence():
    g=TBOHK(':memory:'); k=KnowledgeIntelligence(g)
    docs=[mk('p1','s1','o1','Reliability is 0.91 after twelve months.'), mk('p2','s2','o2','Reliability is 0.88 after twelve months.')]
    k.run_bounded('reliability',[MockProvider('p1',[docs[0]]),MockProvider('p2',[docs[1]])],max_cycles=3)
    structured=g.db.execute("SELECT id FROM nodes WHERE kind='Claim' AND json_extract(metadata,'$.structured') IS NOT NULL").fetchall()
    assert structured
    view=k.evidence_independence(structured[0][0])
    assert view['evidence_count'] >= 1

def test_synthesis_preserves_uncertainty_and_gaps():
    g=TBOHK(':memory:'); k=KnowledgeIntelligence(g)
    result=k.synthesize('nothing known')
    assert result['boundary'].startswith('Synthesis')
    assert result['gaps'][0]['severity']=='critical'

def test_version_and_compile_surface():
    import tbohk.api as api
    import tbohk; assert api.app.version == tbohk.__version__
