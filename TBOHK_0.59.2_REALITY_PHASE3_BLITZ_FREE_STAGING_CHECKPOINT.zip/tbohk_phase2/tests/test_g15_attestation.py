import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from tbohk import TBOHK, CheckpointManager, ReleaseAttestor, IndependentVerifier

def manifest(): return {"code_version":"g15","schema_version":"1","invariant_version":"1","test_summary":{"passed":1},"dependency_versions":{}}

def test_public_attestation_verifies_independently():
    a=ReleaseAttestor.generate("release-key-1"); m=manifest(); env=a.attest(m)
    pub=a.private_key.public_key().public_bytes_raw()
    r=IndependentVerifier.verify(m,env,{"release-key-1":pub})
    assert r.passed

def test_wrong_manifest_fails():
    a=ReleaseAttestor.generate("k"); env=a.attest(manifest()); m=manifest(); m["code_version"]="tampered"
    assert not IndependentVerifier.verify(m,env,{"k":a.private_key.public_key().public_bytes_raw()}).passed

def test_wrong_public_key_fails():
    a=ReleaseAttestor.generate("k"); env=a.attest(manifest()); b=Ed25519PrivateKey.generate()
    assert not IndependentVerifier.verify(manifest(),env,{"k":b.public_key().public_bytes_raw()}).passed

def test_untrusted_key_fails():
    a=ReleaseAttestor.generate("k"); env=a.attest(manifest())
    assert not IndependentVerifier.verify(manifest(),env,{}).passed

def test_checkpoint_can_carry_public_attestation():
    g=TBOHK(); a=ReleaseAttestor.generate("k")
    cp=CheckpointManager(g).create(code_version="g15",schema_version="1",invariant_version="1",test_summary={})
    att=a.attest(cp.manifest)
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?",(json.dumps({"manifest":cp.manifest,"manifest_sha256":cp.manifest_sha256,"public_attestation":att.__dict__}),cp.checkpoint_id)); g.db.commit()
    row=g.db.execute("SELECT metadata FROM nodes WHERE id=?",(cp.checkpoint_id,)).fetchone()
    meta=json.loads(row[0]); env=meta["public_attestation"]
    from tbohk.attestation import PublicAttestation
    report=IndependentVerifier.verify(meta["manifest"],PublicAttestation(**env),{"k":a.private_key.public_key().public_bytes_raw()})
    assert report.passed
