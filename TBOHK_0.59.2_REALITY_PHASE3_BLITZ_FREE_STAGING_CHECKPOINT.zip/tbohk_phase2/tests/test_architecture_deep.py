from tbohk import TBOHK
from tbohk.event_store import EventStore
from tbohk.projections import GraphProjection
from tbohk.resource_budget import Budget,BudgetExceeded,ResourceBudget
from tbohk.interchange import GraphInterchange

def test_event_store_replay_and_projection():
    g=TBOHK(); n=g.add_node('Claim','A claim','proposed',{'subject':'A'})
    es=EventStore(g); es.append('test.event',n.id,{'x':1})
    seen=es.replay(lambda s,e:(s or 0)+e.payload.get('x',0),0,subject_id=n.id)
    assert seen==1 and GraphProjection(g).overview()['node_count']==1

def test_budget_is_bounded():
    b=Budget(ResourceBudget(max_steps=2,max_seconds=2,max_items=2)); b.step(2)
    try: b.step()
    except BudgetExceeded: pass
    else: assert False

def test_interchange_is_deterministic_and_bounded():
    g=TBOHK(); g.add_node('Claim','one','proposed',{'subject':'one'}); g.add_node('Evidence','two','supported',{})
    a=GraphInterchange(g).dumps(); c=GraphInterchange(g).dumps(); assert a==c and 'tbohk.graph.json' in a
