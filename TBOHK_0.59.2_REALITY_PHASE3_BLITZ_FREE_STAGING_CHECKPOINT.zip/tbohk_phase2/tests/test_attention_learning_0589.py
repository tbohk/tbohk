from tbohk.learning_core import LearningCore


def test_attention_feedback_is_auditable_and_does_not_change_node():
    from tbohk.core import TBOHK
    import tempfile
    g=TBOHK(tempfile.mktemp(suffix='.sqlite'))
    n=g.add_node('Claim','A claim','proposed',{})
    before=(n.status,n.content,n.metadata)
    lc=LearningCore(g)
    x=lc.attention_feedback(n.id,'research',success=True,note='Resolved evidence gap')
    assert x.kind=='outcome' and x.success is True
    after=g.get(n.id)
    assert (after.status,after.content,after.metadata)==before
    assert lc.attention_profile(['research'])["research"]["observations"]==1


def test_attention_profile_uses_conservative_prior_and_bounds_history():
    from tbohk.core import TBOHK
    import tempfile
    g=TBOHK(tempfile.mktemp(suffix='.sqlite'))
    n=g.add_node('Claim','A claim','proposed',{})
    lc=LearningCore(g)
    for ok in (True,True,False): lc.attention_feedback(n.id,'impact',success=ok)
    p=lc.attention_profile(['impact','lineage'],limit=2)
    assert p['impact']['observations']==2
    assert p['impact']['success_rate']==2/4
    assert p['lineage']['observations']==0


def test_invalid_attention_feedback_is_rejected():
    from tbohk.core import TBOHK
    import tempfile
    g=TBOHK(tempfile.mktemp(suffix='.sqlite'))
    n=g.add_node('Claim','A claim','proposed',{})
    lc=LearningCore(g)
    try: lc.attention_feedback(n.id,'invented',success=True)
    except ValueError as e: assert 'invalid attention action' in str(e)
    else: raise AssertionError('invalid action accepted')
