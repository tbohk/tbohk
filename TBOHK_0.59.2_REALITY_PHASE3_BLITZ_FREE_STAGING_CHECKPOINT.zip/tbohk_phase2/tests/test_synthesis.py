from tbohk.core import TBOHK
from tbohk.synthesis import EvidenceSynthesizer

def claim(g, text): return g.add_node("Claim", text, "proposed")

def test_structural_parser_and_opposition():
    g=TBOHK(":memory:"); s=EvidenceSynthesizer(g)
    a=claim(g,"The system is reliable")
    b=claim(g,"The system is not reliable")
    c=s.compare(a.id,b.id)
    assert c.relationship=="contradictory"

def test_different_predicates_are_not_declared_conflicts():
    g=TBOHK(":memory:"); s=EvidenceSynthesizer(g)
    a=claim(g,"The system improves reliability")
    b=claim(g,"The system measures reliability")
    assert s.compare(a.id,b.id).relationship=="different_scope_or_relation"

def test_synthesis_preserves_uncertainty():
    g=TBOHK(":memory:"); s=EvidenceSynthesizer(g)
    a=claim(g,"The system is reliable")
    b=claim(g,"The system is not reliable")
    out=s.synthesize([a.id,b.id])
    assert len(out["contradictions"])==1
    assert "not a truth determination" in out["boundary"]
