from tbohk import __version__
from tbohk.regression import RegressionIntelligence


def test_failure_capsule_is_deterministic():
    a = RegressionIntelligence.make_failure("case-a", "suite-a", seed=7, failure_type="assertion", detail="x", reproduction="run case-a --seed 7", source_version=__version__)
    b = RegressionIntelligence.make_failure("case-a", "suite-a", seed=7, failure_type="assertion", detail="x", reproduction="run case-a --seed 7", source_version=__version__)
    assert a.digest == b.digest


def test_prioritization_keeps_mandatory_cases_and_learns_from_failures():
    failure = RegressionIntelligence.make_failure("case-a", "suite-a", seed=1, failure_type="assertion", detail="x", reproduction="run case-a", source_version=__version__)
    priorities = RegressionIntelligence([failure]).prioritize(["case-b", "case-a"], mandatory=["case-b"])
    assert [p.case_id for p in priorities] == ["case-b", "case-a"]
    assert priorities[0].score == 100
    assert "failed:1" in priorities[1].reasons
