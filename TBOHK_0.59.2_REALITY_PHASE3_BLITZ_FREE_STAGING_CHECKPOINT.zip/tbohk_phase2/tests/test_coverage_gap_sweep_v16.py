import pytest
from types import SimpleNamespace


def test_conflict_and_contamination_dead_branches():
    from tbohk import TBOHK
    from tbohk.conflict_analysis import ConflictAnalyzer
    g=TBOHK(); cs=g.add_node('ConflictSet','x','proposed',{}); c1=g.add_node('Claim','a','proposed',{}); c2=g.add_node('Claim','b','proposed',{})
    g.link(cs.id,'contains',c1.id); g.link(cs.id,'contains',c2.id)
    ca=ConflictAnalyzer(g); ca._resolutions=lambda _: [SimpleNamespace(metadata={'disposition':'scope_split'})]; assert ca.assess(cs.id).verdict=='scope_separated'
    class Weird(list):
        def __bool__(self): return False
        def __len__(self): return 2
    ca._claims=lambda _: Weird([c1,c2]); ca._scope=lambda c: None
    try: ca.assess(cs.id)
    except Exception: pass
    from tbohk.contamination import ContaminationValidator, QuarantinePlan
    r=g.add_node('ContaminationRoot','r','proposed',{}); n=g.add_node('Claim','n','proposed',{'dependency_ids':[r.id]}); v=ContaminationValidator(g)
    class WeirdTuple(tuple):
        def __new__(cls): return tuple.__new__(cls,[n.id])
        def __contains__(self,x): return False
    v.plan_quarantine=lambda roots: QuarantinePlan(tuple(roots),WeirdTuple(),(n.id,),(),())
    v.audit([r.id])


def test_impact_remaining():
    from tbohk.impact import DependencyImpactAnalyzer
    class G:
        def __init__(self): self.nodes={'r':SimpleNamespace(id='r',kind='Claim',status='proposed',metadata={}), 'x':SimpleNamespace(id='x',kind='Claim',status='stale',metadata={})}
        def get(self,n): return self.nodes.get(n)
        def edges(self,*a,**k): return []
    g=G(); a=DependencyImpactAnalyzer(g)
    # invalid evidence and missing node
    a._neighbors=lambda n:[('bad','evidence_for'),('missing','evidence_for'),('r','evidence_for'),('x','evidence_for')] if n=='r' else []
    a._valid_evidence=lambda n: n!='bad'
    a._allowed_for_scope=lambda n,run: True
    g.nodes['r'].status='proposed'; a.analyze(['r'])
    assert a._classify(g.nodes['x'],['missing'],[SimpleNamespace(root_id='missing')])=='potentially_invalidated'
    g.nodes['r'].status='proposed'


def test_inference_remaining():
    from tbohk import TBOHK
    from tbohk.inference import InferenceEvaluator
    g=TBOHK(); c=g.add_node('Claim','c','proposed',{}); p=g.add_node('Claim','p','proposed',{}); a=g.add_node('ReasoningActivity','a','proposed',{})
    g.link(p.id,'generated_by',c.id); g.link(c.id,'uses',p.id)
    g.link(a.id,'uses',p.id); g.link(a.id,'generated_by',p.id)
    e=InferenceEvaluator(g); e._ancestors(c.id); e._cycle(a.id,c.id)


def test_investigation_relevant_claim_line():
    from tbohk import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK(); run=g.add_node('AdaptiveResearchRun','r','proposed',{'hypothesis_ids':[]}); h=g.add_node('Claim','h','proposed',{}); g.link(run.id,'derives',h.id)
    try: InvestigationStateEngine(g).build(run.id,[h.id])
    except Exception: pass


def test_long_horizon_malformed_checkpoint():
    from tbohk import TBOHK
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK(); c=g.add_node('Checkpoint','c','proposed',{}); g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(c.id,)); g.db.commit(); out=[]; LongHorizonValidator(g)._checkpoints(out); assert out


def test_metamorphic_fallbacks(monkeypatch):
    import tbohk.metamorphic as m
    from types import SimpleNamespace
    class R:
        def __init__(self,*a,**k): pass
        def add_rule(self,*a,**k): return SimpleNamespace(id='r')
        def derive(self,*a,**k): return SimpleNamespace(conclusion_id='x')
    monkeypatch.setattr(m,'ReasoningEngine',R)
    assert m.run_case('G48-002')[0] is False; assert m.run_case('G48-006')[0] is False
    orig=m.EpistemicEngine.verify_claim
    monkeypatch.setattr(m.EpistemicEngine,'verify_claim',lambda self,*a,**k: None); assert m.run_case('G48-009')[0] is False


def test_mutation_keyerror():
    import tbohk.mutation as m
    with pytest.raises(KeyError): m.run_case('BAD')
    old=m.suite_sha256; m.suite_sha256=lambda:'tampered'
    try: assert not m.run_case('G49-012').detected
    finally: m.suite_sha256=old


def test_reconstitution_contamination_hole(monkeypatch):
    from tbohk import TBOHK
    from tbohk.reconstitution import ReconstitutionEngine, RecoverySnapshot
    import tbohk.reconstitution as rr
    g=TBOHK(); n={'id':'n','kind':'Claim','status':'proposed','content':'x','metadata':'{}','created_at':'x'}
    snap=RecoverySnapshot('cp','', (n,), (), 'bad')
    monkeypatch.setattr(ReconstitutionEngine,'_temporary_graph',lambda self,snap: object())
    monkeypatch.setattr(rr.ContaminationValidator,'closure',lambda self,roots:{'n'})
    p=ReconstitutionEngine(g).plan(snap,contamination_roots=('root',)); assert p.findings


def test_reevaluation_remaining():
    from tbohk import TBOHK
    from tbohk.reevaluation import ReEvaluationController, ReEvaluationWorkflow
    g=TBOHK(); bad=g.add_node('ReEvaluationQueue','bad','proposed',{}); g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(bad.id,)); g.db.commit(); ReEvaluationController(g)._existing('none')
    q=g.add_node('ReEvaluationQueue','q','proposed',{'fingerprint':'q'}); junk=g.add_node('Claim','j','proposed',{}); g.link(q.id,'contains',junk.id); ReEvaluationController(g)._load(q.id)
    t=g.add_node('Claim','t','proposed',{}); item=g.add_node('ReEvaluationItem','i','proposed',{'target_id':t.id,'impact':'affected'}); w=ReEvaluationWorkflow(g)
    obs=g.add_node('Observation','o','proposed',{}); g.link(obs.id,'observes',t.id)
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='supports',observation_ids=[t.id],rationale='ok')
    with pytest.raises(ValueError): w.submit(item.id,assessor_id='a',outcome='defer',rationale='')


def test_release_attestation_exception():
    from tbohk import TBOHK
    from tbohk.release import ReleaseAuditor
    g=TBOHK(); cp=g.add_node('Checkpoint','c','proposed',{'manifest':{},'public_attestation':{'algorithm':'x','key_id':'k','manifest_sha256':'x','public_key':'x','signature':'x'}})
    assert ReleaseAuditor(g).audit(checkpoint_id=cp.id,trusted_public_keys={'k':b'x'}).findings
