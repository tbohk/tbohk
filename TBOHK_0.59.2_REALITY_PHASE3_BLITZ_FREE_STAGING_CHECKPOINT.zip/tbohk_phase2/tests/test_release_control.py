import base64
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from tbohk.core import TBOHK
from tbohk.learning_core import LearningCore
from tbohk.learning_experiments import LearningExperimentEngine
from tbohk.learning_canary import LearningCanaryEngine
from tbohk.release_control import ReleaseControlEngine


def ready():
    g=TBOHK(); c=LearningCore(g)
    for i in range(40): c.record_experience('interaction', ('success ' if i%2==0 else 'failure ')+str(i), 'ok', success=i%2==0)
    d=c.build_dataset(limit=40, validation_fraction=.5)
    e=LearningExperimentEngine(g).run(d['dataset_id'])
    can=LearningCanaryEngine(g).run(e.experiment_id, observations=100, error_rate=0, latency_ms=10, baseline_latency_ms=10)
    # release control accepts the gated experiment artifact directly
    return g,e,can


def test_release_lifecycle_and_signed_authorization():
    g,e,can=ready(); relkey=Ed25519PrivateKey.generate(); depkey=Ed25519PrivateKey.generate()
    ctl=ReleaseControlEngine(g, relkey, depkey.public_key().public_bytes_raw())
    r=ctl.prepare(e.experiment_id, can.canary_id, version='0.29.2', artifact_sha256=e.candidate_artifact_sha256, evaluation_suite='fixed-v1', benchmark_sha256='a'*64)
    node=g.get(r.release_id); imm=node.metadata['immutable_manifest']
    msg=ctl._id(r.release_id,'authorize')+b':'+ctl._canonical(imm)
    sig=base64.b64encode(depkey.sign(msg)).decode()
    a=ctl.authorize(r.release_id, operator='release-operator', deployment_signature=sig)
    assert a.authorized and a.state=='authorized'
    assert ctl.stage(r.release_id, traffic_percent=5).state=='staged'
    assert ctl.health_gate(r.release_id, observations=100, error_rate=0, latency_ms=10, max_latency_ms=20).state=='active'
    assert ctl.complete(r.release_id).state=='completed'
    assert ctl.report(r.release_id)['state']=='completed'


def test_release_rolls_back_on_health_failure():
    g,e,can=ready(); ctl=ReleaseControlEngine(g, Ed25519PrivateKey.generate(), None)
    r=ctl.prepare(e.experiment_id, can.canary_id, version='0.29.2', artifact_sha256=e.candidate_artifact_sha256, evaluation_suite='fixed-v1', benchmark_sha256='b'*64)
    # manually establish authorized state for isolated health-gate branch
    g.update_metadata(r.release_id, {'state':'authorized'})
    ctl.stage(r.release_id, traffic_percent=10)
    d=ctl.health_gate(r.release_id, observations=20, error_rate=.5, latency_ms=100, max_latency_ms=20)
    assert d.rollback_required and d.state=='rolled_back'
    assert g.db.execute("SELECT 1 FROM nodes WHERE kind='ReleaseRollback'").fetchone()


def test_release_rejects_invalid_and_unauthorized_paths():
    g,e,can=ready(); ctl=ReleaseControlEngine(g, None, None)
    with pytest.raises(ValueError): ctl.prepare('missing', can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    with pytest.raises(ValueError): ctl.stage('missing', traffic_percent=5)
    r=ctl.prepare(e.experiment_id, can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    with pytest.raises(ValueError): ctl.authorize(r.release_id, operator='op', deployment_signature='bad')
    with pytest.raises(ValueError): ctl.stage(r.release_id, traffic_percent=5)
    with pytest.raises(ValueError): ctl.complete(r.release_id)
    with pytest.raises(ValueError): ctl.health_gate(r.release_id, observations=1, error_rate=0, latency_ms=1)


def test_release_signature_and_health_validation():
    g,e,can=ready(); rel=Ed25519PrivateKey.generate(); ctl=ReleaseControlEngine(g, rel, None)
    r=ctl.prepare(e.experiment_id, can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    node=g.get(r.release_id); meta=dict(node.metadata); meta['release_signature']='bad'; g.update_metadata(r.release_id, meta, replace=True)
    dep=Ed25519PrivateKey.generate(); ctl.deployment_public_key=dep.public_key().public_bytes_raw()
    msg=ctl._id(r.release_id,'authorize')+b':'+ctl._canonical(node.metadata['immutable_manifest'])
    with pytest.raises(ValueError): ctl.authorize(r.release_id, operator='op', deployment_signature=base64.b64encode(dep.sign(msg)).decode())
    with pytest.raises(ValueError): ctl.stage(r.release_id, traffic_percent=0)
    with pytest.raises(ValueError): ctl.stage(r.release_id, traffic_percent=101)


def test_release_control_edge_branches():
    g,e,can=ready(); rel=Ed25519PrivateKey.generate(); dep=Ed25519PrivateKey.generate(); ctl=ReleaseControlEngine(g, rel, dep.public_key().public_bytes_raw())
    with pytest.raises(ValueError): ctl.prepare(e.experiment_id, 'missing', version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    bad_can=g.add_node('LearningCanary','bad','supported',{'decision':'rollback'})
    with pytest.raises(ValueError): ctl.prepare(e.experiment_id, bad_can.id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    bad_exp=g.add_node('LearningExperiment','bad','proposed',{'status':'rejected'})
    with pytest.raises(ValueError): ctl.prepare(bad_exp.id, can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    bad_candidate=g.add_node('LearningCandidate','bad candidate','proposed',{})
    with pytest.raises(ValueError): ctl.prepare(bad_candidate.id, can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    with pytest.raises(ValueError): ctl.prepare(e.experiment_id, can.canary_id, version='', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    unsigned=ReleaseControlEngine(g, None, None).prepare(e.experiment_id, can.canary_id, version='x', artifact_sha256='a'*64, evaluation_suite='s', benchmark_sha256='b'*64)
    unsigned_node=g.get(unsigned.release_id)
    assert ReleaseControlEngine(g, None, dep.public_key().public_bytes_raw())._verify_release_signature(unsigned_node)
    node=g.add_node('Release','x','proposed',{'state':'prepared','immutable_manifest':{'release_id':'x'}})
    with pytest.raises(ValueError): ctl.authorize(node.id, operator='', deployment_signature='x')
    with pytest.raises(ValueError): ctl.authorize(node.id, operator='op', deployment_signature='x')
    with pytest.raises(ValueError): ctl.stage(unsigned.release_id, traffic_percent=5)
    g.update_metadata(unsigned.release_id, {'state':'authorized'})
    with pytest.raises(ValueError): ctl.stage(unsigned.release_id, traffic_percent=0)
    ctl.stage(unsigned.release_id, traffic_percent=5)
    with pytest.raises(ValueError): ctl.health_gate(unsigned.release_id, observations=0, error_rate=0, latency_ms=1)
    with pytest.raises(ValueError): ctl.health_gate(unsigned.release_id, observations=1, error_rate=0, latency_ms=-1)
    with pytest.raises(ValueError): ctl.health_gate(unsigned.release_id, observations=1, error_rate=0, latency_ms=1, max_error_rate=2)
    ctl.g.update_metadata(unsigned.release_id, {'state':'blocked'})
    with pytest.raises(ValueError): ctl.complete(unsigned.release_id)
    assert not ReleaseControlEngine(g, rel, dep.public_key().public_bytes_raw())._verify_release_signature(g.add_node('Release','unsigned','proposed',{'immutable_manifest':{'release_id':'x'}}))
    tampered=g.get(unsigned.release_id); m=dict(tampered.metadata); m['immutable_manifest']=dict(m['immutable_manifest'], artifact_sha256='c'*64); g.update_metadata(unsigned.release_id,m,replace=True); assert not ctl._verify_release_signature(g.get(unsigned.release_id))
    signed=ctl.prepare(e.experiment_id, can.canary_id, version='signed', artifact_sha256='d'*64, evaluation_suite='s', benchmark_sha256='e'*64)
    signed_node=g.get(signed.release_id); sm=dict(signed_node.metadata); sm['immutable_manifest']=dict(sm['immutable_manifest'], artifact_sha256='f'*64); g.update_metadata(signed.release_id, sm, replace=True); assert not ctl._verify_release_signature(g.get(signed.release_id))
    with pytest.raises(ValueError): ctl.authorize(unsigned.release_id, operator='op', deployment_signature='sig')
    g.update_metadata(unsigned.release_id, {'state':'authorized'})
    with pytest.raises(ValueError): ctl.stage(unsigned.release_id, traffic_percent=101)


def test_release_api_endpoints_and_key_helpers(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.release_control import ReleaseDecision
    import base64
    key=Ed25519PrivateKey.generate()
    monkeypatch.setenv('TEST_PRIVATE', base64.b64encode(key.private_bytes_raw()).decode())
    monkeypatch.setenv('TEST_PUBLIC', base64.b64encode(key.public_key().public_bytes_raw()).decode())
    assert api._ed25519_private_env('TEST_PRIVATE') is not None
    assert api._ed25519_private_env('MISSING') is None
    monkeypatch.setenv('TEST_PRIVATE','bad'); assert api._ed25519_private_env('TEST_PRIVATE') is None
    assert api._ed25519_public_env('TEST_PUBLIC') is not None
    monkeypatch.setenv('TEST_PUBLIC','bad'); assert api._ed25519_public_env('TEST_PUBLIC') is None
    api.release_control = __import__('tbohk.release_control',fromlist=['ReleaseControlEngine']).ReleaseControlEngine(api.g, None, None)
    client=TestClient(api.app)
    # route-level success and ValueError branches
    monkeypatch.setattr(api.release_control,'prepare',lambda *a,**k: __import__('tbohk.release_control',fromlist=['ReleaseManifest']).ReleaseManifest('r','c','k','v','a'*64,'s','b'*64,'now','m'))
    assert client.post('/release/prepare',json={'candidate_id':'c','canary_id':'k','version':'v','artifact_sha256':'a'*64,'evaluation_suite':'s','benchmark_sha256':'b'*64}).status_code==200
    monkeypatch.setattr(api.release_control,'authorize',lambda *a,**k: ReleaseDecision('r','authorized',True,False,(), 'now'))
    assert client.post('/release/r/authorize',json={'operator':'op','deployment_signature':'sig'}).status_code==200
    monkeypatch.setattr(api.release_control,'stage',lambda *a,**k: ReleaseDecision('r','staged',True,False,(), 'now'))
    assert client.post('/release/r/stage?traffic_percent=5').status_code==200
    monkeypatch.setattr(api.release_control,'health_gate',lambda *a,**k: ReleaseDecision('r','active',True,False,(), 'now'))
    assert client.post('/release/r/health?observations=1&error_rate=0&latency_ms=1').status_code==200
    monkeypatch.setattr(api.release_control,'complete',lambda *a,**k: ReleaseDecision('r','completed',True,False,(), 'now'))
    assert client.post('/release/r/complete').status_code==200
    monkeypatch.setattr(api.release_control,'report',lambda *a,**k: {'release_id':'r','state':'completed'})
    assert client.get('/release/r').status_code==200
    for name, method, url, kwargs in [
        ('prepare','post','/release/prepare',{'json':{'candidate_id':'c','canary_id':'k','version':'v','artifact_sha256':'a'*64,'evaluation_suite':'s','benchmark_sha256':'b'*64}}),
        ('authorize','post','/release/r/authorize',{'json':{'operator':'op','deployment_signature':'sig'}}),
        ('stage','post','/release/r/stage?traffic_percent=5',{}),
        ('health_gate','post','/release/r/health?observations=1&error_rate=0&latency_ms=1',{}),
        ('complete','post','/release/r/complete',{}),
        ('report','get','/release/r',{}),
    ]:
        monkeypatch.setattr(api.release_control,name,lambda *a,**k: (_ for _ in ()).throw(ValueError('bad')))
        assert getattr(client,method)(url,**kwargs).status_code==400
