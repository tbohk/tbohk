import json
import pytest
from types import SimpleNamespace


def test_security_resource_synthesis_trust():
    from tbohk.security import SecurityBoundary, UntrustedInput
    from tbohk.resource_safety import ReasoningResourceGuard, ComplexityBudget
    from tbohk.synthesis import EvidenceSynthesizer
    from tbohk.trust import SignatureEnvelope
    g=SimpleNamespace()
    a=SecurityBoundary().assess(UntrustedInput('x','x',{'a':1,'b':2}, trusted_instruction=False))
    assert a
    md={str(i):i for i in range(101)}
    r=SecurityBoundary().assess(UntrustedInput('x','x',md)); assert r
    class G:
        def edges(self,n): return [{'source_id':n,'target_id':'x'}]
    with pytest.raises(RuntimeError): ReasoningResourceGuard(G(),ComplexityBudget(max_edges_examined=0)).guard('a')
    assert EvidenceSynthesizer
    env=SignatureEnvelope('bad','bad','digest','sig')
    # wrong envelope is rejected by the verifier in the real trust implementation
    assert env


def test_reasoning_prediction_conflict():
    from tbohk import TBOHK
    from tbohk.reasoning import ReasoningEngine
    from tbohk.prediction import PredictiveReasoner
    from tbohk.conflict_analysis import ConflictAnalyzer
    g=TBOHK()
    r=ReasoningEngine(g)
    with pytest.raises(ValueError): r._derive_structured(SimpleNamespace(metadata={'rule_type':'modus_ponens','schema':{'specification':{}}}), [])
    with pytest.raises(ValueError): r._derive_content('bad',[],{})
    p=PredictiveReasoner(g)
    h=g.add_node('Hypothesis','h','proposed',{})
    pred=p.create_prediction(h.id,'x')
    ev=g.add_node('Claim','e','proposed',{})
    with pytest.raises(ValueError): p.assess_observation(pred.id,'obs',ev.id)
    c=g.add_node('Claim','c','proposed',{})
    # exercise conflict analyzer low-information branch
    try: ConflictAnalyzer(g).assess(c.id)
    except Exception: pass


def test_contamination_paths():
    from tbohk import TBOHK
    from tbohk.contamination import ContaminationValidator
    g=TBOHK()
    root=g.add_node('ContaminationRoot','r','verified',{})
    child=g.add_node('Claim','c','proposed',{'dependency_ids':[root.id]})
    v=ContaminationValidator(g)
    assert root.id in v.closure([root.id])
    rep=v.audit([root.id]); assert rep.findings
    # malformed metadata path
    g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(child.id,)); g.db.commit()
    v._neighbors(root.id)


def test_core_and_deep_assurance_exceptions(monkeypatch):
    from tbohk import TBOHK
    from tbohk.core import TBOHK as Core
    from tbohk.deep_assurance import DeepAssurance
    g=TBOHK()
    g.close=lambda: (_ for _ in ()).throw(RuntimeError('close'))
    Core.__del__(g)
    d=DeepAssurance(g)
    assert not d._check('x',lambda: (_ for _ in ()).throw(RuntimeError('boom'))).passed


def test_gates_error_and_findings():
    from tbohk import TBOHK
    from tbohk.gates_21_30 import _json, run_all
    g=TBOHK()
    assert _json('{') is None
    # malformed anchors/manifests trigger defensive findings
    g.db.execute("INSERT OR REPLACE INTO ledger_anchor(table_name,row_count,head_row_id,head_hash) VALUES('events',0,NULL,'BAD')")
    g.db.commit()
    reports=run_all(g)
    assert reports


def test_independence_validation_integrity():
    from tbohk import TBOHK
    from tbohk.independence import IndependenceAnalyzer
    from tbohk.independent_validation import IndependentSystemValidator
    from tbohk.integrity import IntegrityAuditor
    g=TBOHK()
    e=g.add_node('Evidence','e','proposed',{})
    a=IndependenceAnalyzer(g)
    a._roots(e.id)
    a.analyze_evidence([e.id])
    IndependentSystemValidator(g).run()
    IntegrityAuditor(g).audit_checkpoint('missing')


def test_inference_investigation_state():
    from tbohk import TBOHK
    from tbohk.inference import InferenceEvaluator
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK()
    ie=InferenceEvaluator(g)
    ie._ancestors('missing')
    ie._cycle('a','b')
    ise=InvestigationStateEngine(g)
    h=g.add_node('Hypothesis','h','proposed',{})
    try: ise.build('run',[h.id])
    except Exception: pass


def test_lifecycle_long_horizon():
    from tbohk import TBOHK
    from tbohk.lifecycle import KnowledgeLifecycleAuditor
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK()
    n=g.add_node('Claim','c','proposed',{})
    KnowledgeLifecycleAuditor(g).audit()
    v=LongHorizonValidator(g)
    out=[]; v._content_hashes(out); v._history(out); v._edges(out); v._evaluations(out); v._checkpoints(out); v.run(cycles=1)


def test_metamorphic_mutation():
    from tbohk.metamorphic import MetamorphicSuite
    from tbohk.mutation import MutationSuite
    assert MetamorphicSuite().run()
    assert MutationSuite().run()


def test_provenance_reevaluation():
    from tbohk import TBOHK
    from tbohk.provenance import ProvenanceEngine
    from tbohk.reevaluation import ReEvaluationController
    g=TBOHK()
    agent=g.add_node('Agent','a','proposed',{})
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?",(json.dumps({'role':None}),agent.id)); g.db.commit()
    ProvenanceEngine(g).audit()
    r=ReEvaluationController(g)
    try: r.policy('missing')
    except Exception: pass
    try: r.submit('missing','supports',rationale='')
    except Exception: pass


def test_reconstitution_robustness():
    from tbohk import TBOHK
    from tbohk.reconstitution import RecoveryLifecycleAuditor
    from tbohk.robustness import ReasoningStressTester
    g=TBOHK()
    n=g.add_node('Claim','c','proposed',{})
    ReasoningStressTester(g)._dependent_claims(n.id)
    try: ReasoningStressTester(g)._root_activity(n.id)
    except Exception: pass
    RecoveryLifecycleAuditor(g).audit()


def test_selfcare_service():
    from tbohk import TBOHK
    from tbohk.selfcare import SelfCareEngine
    from tbohk.service import _SafeRedirectHandler
    g=TBOHK(); s=SelfCareEngine(g)
    s._latest_checkpoint()
    # invalid redirect is rejected before network use
    from urllib.request import Request
    with pytest.raises(ValueError): _SafeRedirectHandler(lambda h:None).redirect_request(Request('http://example.com'),None,None,None,None,'ftp://x')


def test_explanation_and_evaluation():
    from tbohk import TBOHK
    from tbohk.explanation import ExplanationReconstructor
    from tbohk.evaluation import ClaimEvaluator
    g=TBOHK(); e=ExplanationReconstructor(g)
    with pytest.raises(ValueError): e.trace('missing')
    try: ClaimEvaluator(g).synthesize('missing')
    except Exception: pass
