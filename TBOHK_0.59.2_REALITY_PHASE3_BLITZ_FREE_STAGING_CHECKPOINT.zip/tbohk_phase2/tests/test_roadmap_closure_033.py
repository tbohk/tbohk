from pathlib import Path
from tbohk import TBOHK, ContentAddressedArtifactStore, DurableWorkQueue, PolicyEngine, PolicySpec, PolicyRule

def test_content_addressed_artifact_store_is_immutable(tmp_path):
    s=ContentAddressedArtifactStore(str(tmp_path)); r=s.put(b'hello'); assert s.get(r.digest)==b'hello'; assert s.exists(r.digest)
    p=Path(r.path); p.write_bytes(b'tampered')
    assert not s.exists(r.digest)

def test_work_queue_is_idempotent_and_leaseable():
    g=TBOHK(); q=DurableWorkQueue(g); a=q.enqueue('research',{'q':'x'},idempotency_key='k'); b=q.enqueue('research',{'q':'x'},idempotency_key='k'); assert a.id==b.id
    leased=q.lease('worker-1'); assert len(leased)==1 and leased[0].attempts==1
    assert q.complete(a.id).status=='supported'

def test_declarative_policy_is_versioned_and_fail_closed():
    p=PolicyEngine(PolicySpec('release-authority','1.0',(PolicyRule('deploy','allow',{'authorized':True}),)))
    assert p.evaluate('deploy',{'authorized':True})['decision']=='allow'
    assert p.evaluate('deploy',{'authorized':False})['decision']=='deny'
