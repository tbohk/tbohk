from pathlib import Path
from tbohk.release_guard import ReleaseGuard, VERSION

ROOT=Path(__file__).resolve().parents[1]

def test_guard_passes():
    r=ReleaseGuard(ROOT).run()
    assert r.passed, [(x.check_id,x.detail) for x in r.checks if not x.passed]

def test_guard_is_deterministic():
    a=ReleaseGuard(ROOT).run(); b=ReleaseGuard(ROOT).run()
    assert a.digest==b.digest

def test_guard_has_all_layers():
    r=ReleaseGuard(ROOT).run()
    assert {x.layer for x in r.checks} >= {"backend","release","frontend","testing","architecture","packaging"}

def test_version_is_single_release():
    assert VERSION == "0.59.2"

def test_ui_contracts_are_explicit():
    r=ReleaseGuard(ROOT).run(); c=next(x for x in r.checks if x.check_id=="ui.contract")
    assert c.passed

def test_no_architecture_self_edges():
    r=ReleaseGuard(ROOT).run(); c=next(x for x in r.checks if x.check_id=="architecture.no_self_edges")
    assert c.passed

def test_test_inventory_gate():
    r=ReleaseGuard(ROOT).run(); c=next(x for x in r.checks if x.check_id=="test.inventory")
    assert c.passed

def test_release_artifact_hygiene_gate():
    r=ReleaseGuard(ROOT).run(); c=next(x for x in r.checks if x.check_id=="artifact.hygiene")
    assert c.passed
