from pathlib import Path
from datetime import datetime, timezone
import pytest
import json
from tbohk.gates_21_30 import G21LedgerAuditor
from tbohk import TBOHK, ReasoningEngine
from tbohk.research import SourceDocument, MockProvider, ResearchChain
from tbohk.epistemic import EpistemicEngine, VerificationPolicy

NOW = datetime.now(timezone.utc).isoformat()

def doc(source, provider, origin, text="Water freezes at 0 C at standard pressure."):
    return SourceDocument(source, source, f"https://example/{source}", text, provider, NOW, origin, NOW)

def build_chain(shared_origin=False):
    a = MockProvider("p1", [doc("s1", "p1", "origin-A")])
    b = MockProvider("p2", [doc("s2", "p2", "origin-A" if shared_origin else "origin-B")])
    g = TBOHK(); out = ResearchChain(g, [a,b]).run("freezes")
    return g, out

def test_hardened_research_records_temporal_lineage_and_completeness():
    g, out = build_chain()
    assert len(out["results"]) == 2
    assert out["research_record"]["result_counts"] == {"p1":1,"p2":1}
    snap, ev = out["results"][0]
    assert snap.metadata["origin_id"] == "origin-A"
    assert snap.metadata["retrieved_at"] == NOW
    assert ev.metadata["locator"]["source_id"] == "s1"
    assert g.audit()["ok"]

def test_two_providers_with_same_origin_are_not_independent():
    g, out = build_chain(shared_origin=True)
    e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [ev.id for _,ev in out["results"]])
    with pytest.raises(ValueError, match="independent origin"):
        e.verify_claim(claim.id)

def test_policy_controls_verification_threshold():
    g, out = build_chain()
    e = EpistemicEngine(g, {"strict": VerificationPolicy("strict", min_independent_origins=2)})
    claim = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id], policy_id="strict")
    with pytest.raises(ValueError): e.verify_claim(claim.id)

def test_claim_structured_semantics_and_conflict_set():
    g, out = build_chain()
    e = EpistemicEngine(g)
    a = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id], subject="water", predicate="freezing_point", object_value=0, units="C", scope="standard pressure")
    b = e.propose_claim("Water freezes at 10 C.", [out["results"][1][1].id], subject="water", predicate="freezing_point", object_value=10, units="C", scope="standard pressure")
    cset = e.contradict(a.id, b.id, "incompatible values")
    assert cset.kind == "ConflictSet"
    assert {x["target_id"] for x in g.edges(cset.id, "out", "contains")} == {a.id,b.id}

def test_evidence_requires_precise_observation_metadata():
    g = TBOHK(); snap = g.add_node("SourceSnapshot", "x", "supported", {"source_id":"s","provider_id":"p","origin_id":"o","retrieved_at":NOW})
    ev = g.add_node("Evidence", "x", "supported", {})
    g.link(ev.id, "derived_from", snap.id)
    assert not g.audit()["ok"]
    assert any(p[1] == "evidence_without_locator" for p in g.audit()["problems"])

def test_hash_tampering_is_detected():
    g = TBOHK(); snap = g.add_node("SourceSnapshot", "immutable", "supported", {"source_id":"s","provider_id":"p","origin_id":"o","retrieved_at":NOW})
    g.db.execute("UPDATE nodes SET content='tampered' WHERE id=?", (snap.id,)); g.db.commit()
    assert any(p[1] == "snapshot_hash_mismatch" for p in g.audit()["problems"])

def test_policy_and_audit_agree_on_single_origin_requirement():
    g, out = build_chain()
    e = EpistemicEngine(g, {"single": VerificationPolicy("single", min_independent_origins=1)})
    claim = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id], policy_id="single")
    e.verify_claim(claim.id)
    assert g.audit()["ok"]

def test_verification_creates_auditable_verification_node():
    g, out = build_chain()
    e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [x[1].id for x in out["results"]])
    e.verify_claim(claim.id, reviewer="test")
    verification = [g.get(x["source_id"]) for x in g.edges(claim.id, "in", "verified_by")]
    assert len(verification) == 1 and verification[0].kind == "Verification"
    assert g.audit()["ok"]

def test_invalid_source_validity_interval_is_detected():
    g = TBOHK()
    snap = g.add_node("SourceSnapshot", "x", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o", "uri":"https://example/s",
        "retrieved_at":"2026-01-01T00:00:00+00:00",
        "valid_from":"2026-02-01T00:00:00+00:00",
        "valid_until":"2026-01-01T00:00:00+00:00"
    })
    assert any(p[1] == "invalid_validity_interval" for p in g.audit()["problems"])

def test_research_record_is_first_class_and_audited():
    g, out = build_chain()
    record_id = out["research_record"]["record_id"]
    record = g.get(record_id)
    assert record.kind == "ResearchRecord"
    assert g.edges(record.id, "out", "records")
    assert g.audit()["ok"]

def test_shared_upstream_lineage_is_not_independent_even_with_two_providers():
    shared = SourceDocument("s2", "Shared", "https://example/s2", "Water freezes at 0 C.", "p2", NOW, "origin-B", NOW, upstream_origin_ids=("primary-source",))
    first = SourceDocument("s1", "First", "https://example/s1", "Water freezes at 0 C.", "p1", NOW, "origin-A", NOW, upstream_origin_ids=("primary-source",))
    g = TBOHK(); out = ResearchChain(g, [MockProvider("p1", [first]), MockProvider("p2", [shared])]).run("freezes")
    e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [x[1].id for x in out["results"]])
    with pytest.raises(ValueError, match="independent origin support"):
        e.verify_claim(claim.id)


def test_conflict_resolution_is_first_class_and_audited():
    g, out = build_chain()
    e = EpistemicEngine(g)
    a = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id])
    b = e.propose_claim("Water freezes at 10 C.", [out["results"][1][1].id])
    conflict = e.contradict(a.id, b.id, "incompatible values")
    resolution = e.resolve_conflict(conflict.id, "accept_claim", resolver="reviewer", claim_id=a.id, rationale="reviewed source scope")
    assert resolution.kind == "ConflictResolution"
    assert g.get(conflict.id).status == "resolved"
    assert g.edges(resolution.id, "out", "resolves")
    assert g.audit()["ok"]


def test_deferred_conflict_remains_unresolved():
    g, out = build_chain()
    e = EpistemicEngine(g)
    a = e.propose_claim("A", [out["results"][0][1].id])
    b = e.propose_claim("B", [out["results"][1][1].id])
    conflict = e.contradict(a.id, b.id)
    resolution = e.resolve_conflict(conflict.id, "defer", resolver="reviewer", rationale="insufficient evidence")
    assert resolution.status == "proposed"
    assert g.get(conflict.id).status == "proposed"
    assert g.audit()["ok"]


def test_temporal_invalidation_stales_claim_and_dependent_knowledge():
    past = "2026-01-01T00:00:00+00:00"
    future = "2026-02-01T00:00:00+00:00"
    g = TBOHK()
    snaps = []
    evs = []
    for i, origin in enumerate(("o1", "o2")):
        snap = g.add_node("SourceSnapshot", f"fact-{i}", "supported", {
            "source_id": f"s{i}", "provider_id": f"p{i}", "origin_id": origin,
            "uri": f"https://example/{i}", "retrieved_at": past,
            "valid_from": past, "valid_until": future,
        })
        ev = g.add_node("Evidence", f"fact-{i}", "supported", {
            "source_id": f"s{i}", "provider_id": f"p{i}", "origin_id": origin,
            "locator": {"type":"document","source_id":f"s{i}"},
            "extraction_method":"test", "observation_time":past, "observation_basis":"test observation",
        })
        g.link(ev.id, "derived_from", snap.id)
        evs.append(ev.id); snaps.append(snap.id)
    e = EpistemicEngine(g)
    claim = e.propose_claim("time-bounded fact", evs)
    e.verify_claim(claim.id)
    knowledge = e.promote_knowledge("time-bounded fact", [claim.id])
    result = g.temporal_invalidation("2026-03-01T00:00:00+00:00")
    assert claim.id in result["invalidated"]
    assert knowledge.id in result["invalidated"]
    assert g.get(claim.id).status == "stale"
    assert g.get(knowledge.id).status == "stale"
    assert g.audit()["ok"]


def test_audit_detects_temporally_invalid_verified_claim_before_mutation():
    past = "2026-01-01T00:00:00+00:00"
    future = "2026-02-01T00:00:00+00:00"
    g = TBOHK(); evs=[]
    for i, origin in enumerate(("o1", "o2")):
        snap = g.add_node("SourceSnapshot", f"x{i}", "supported", {
            "source_id": f"s{i}", "provider_id": f"p{i}", "origin_id": origin,
            "uri": f"https://example/{i}", "retrieved_at": past,
            "valid_from": past, "valid_until": future,
        })
        ev = g.add_node("Evidence", f"x{i}", "supported", {
            "source_id": f"s{i}", "provider_id": f"p{i}", "origin_id": origin,
            "locator": {"type":"document","source_id":f"s{i}"}, "extraction_method":"test", "observation_time":past, "observation_basis":"test observation",
        })
        g.link(ev.id, "derived_from", snap.id); evs.append(ev.id)
    e = EpistemicEngine(g); claim=e.propose_claim("x", evs); e.verify_claim(claim.id)
    audit=g.audit("2026-03-01T00:00:00+00:00")
    assert any(p[1] == "verified_claim_supported_only_by_temporally_invalid_evidence" for p in audit["problems"])

def test_multi_parent_lineage_merges_all_dependent_evidence_groups():
    docs = [
        SourceDocument("s1", "S1", "https://example/s1", "fact", "p1", NOW, "A", NOW, upstream_origin_ids=("root-1",)),
        SourceDocument("s2", "S2", "https://example/s2", "fact", "p2", NOW, "B", NOW, upstream_origin_ids=("root-2",)),
        SourceDocument("s3", "S3", "https://example/s3", "fact", "p3", NOW, "C", NOW, upstream_origin_ids=("root-1", "root-2")),
    ]
    g = TBOHK(); out = ResearchChain(g, [MockProvider("p1", [docs[0]]), MockProvider("p2", [docs[1]]), MockProvider("p3", [docs[2]])]).run("fact")
    from tbohk.independence import IndependenceAnalyzer
    analysis = IndependenceAnalyzer(g).analyze_evidence([e.id for _, e in out["results"]])
    assert analysis.independent_count == 1


def test_audit_requires_first_class_verification_for_verified_claim():
    g, out = build_chain()
    e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [x[1].id for x in out["results"]])
    g.set_status(claim.id, "verified", "manual tampering for audit test")
    audit = g.audit()
    assert any(p[1] == "verified_claim_without_verification_node" for p in audit["problems"])

def test_text_quote_locator_and_evidence_polarity_are_auditable():
    g = TBOHK()
    snap = g.add_node("SourceSnapshot", "Water freezes at 0 C.", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o", "uri":"https://example/s",
        "retrieved_at":NOW,
    })
    ev = g.add_node("Evidence", "Water freezes at 0 C.", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o",
        "locator":{"type":"text_quote", "exact":"freezes at 0 C", "prefix":"Water ", "suffix":"."},
        "extraction_method":"text_quote_selector", "observation_time":NOW,
        "observation_basis":"source snapshot text", "polarity":"supports",
    })
    g.link(ev.id, "derived_from", snap.id)
    assert g.audit()["ok"]


def test_invalid_evidence_polarity_is_detected():
    g = TBOHK()
    snap = g.add_node("SourceSnapshot", "x", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o", "uri":"https://example/s",
        "retrieved_at":NOW,
    })
    ev = g.add_node("Evidence", "x", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o",
        "locator":{"type":"document", "source_id":"s"},
        "extraction_method":"test", "observation_time":NOW,
        "observation_basis":"test", "polarity":"invented",
    })
    g.link(ev.id, "derived_from", snap.id)
    assert any(p[1] == "invalid_evidence_polarity" for p in g.audit()["problems"])


def test_structured_uncertainty_is_validated():
    g, out = build_chain()
    e = EpistemicEngine(g)
    c = e.propose_claim("measurement", [out["results"][0][1].id],
                        uncertainty={"type":"interval", "lower":9.8, "upper":10.2,
                                     "unit":"C", "confidence_level":0.95})
    assert c.metadata["structured"]["uncertainty"]["confidence_level"] == 0.95
    with pytest.raises(ValueError, match="lower bound"):
        e.propose_claim("bad", [out["results"][0][1].id],
                        uncertainty={"type":"interval", "lower":2, "upper":1})


def test_absence_of_evidence_is_not_encoded_as_positive_claim_support():
    g = TBOHK(); e = EpistemicEngine(g)
    k = e.promote_knowledge("No evidence was found for proposition X within the searched corpus.", [],
                            epistemic_type="absence_of_evidence", absence_scope={
                                "query":"proposition X", "corpus":"test-corpus", "as_of":NOW
                            })
    assert k.status == "supported"
    assert k.metadata["epistemic_type"] == "absence_of_evidence"
    assert g.audit()["ok"]


def test_absence_of_evidence_requires_explicit_scope():
    g = TBOHK(); e = EpistemicEngine(g)
    with pytest.raises(ValueError, match="absence_scope"):
        e.promote_knowledge("Nothing found", [], epistemic_type="absence_of_evidence")


def test_evidence_assessment_is_not_truth_score_and_is_auditable():
    from tbohk.evaluation import EvidenceEvaluator
    g, out = build_chain()
    ev = out["results"][0][1]
    assessment = EvidenceEvaluator(g).record(ev.id, assessor="reviewer")
    assert "source_integrity" in assessment.dimension_results
    assert "observation_precision" in assessment.dimension_results
    assessments = [g.get(e["source_id"]) for e in g.edges(ev.id, "in", "evaluates")]
    assert len(assessments) == 1 and assessments[0].kind == "EvidenceAssessment"
    assert g.audit()["ok"]


def test_evidence_assessment_flags_coarse_locator():
    from tbohk.evaluation import EvidenceEvaluator
    g, out = build_chain()
    ev = out["results"][0][1]
    assessment = EvidenceEvaluator(g).assess(ev.id)
    assert assessment.dimension_results["observation_precision"] == "coarse"
    assert any("document-level" in x for x in assessment.limitations)


def test_evidence_assessment_detects_temporal_staleness():
    from tbohk.evaluation import EvidenceEvaluator
    g = TBOHK()
    snap = g.add_node("SourceSnapshot", "old", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o", "uri":"https://example/s",
        "retrieved_at":"2026-01-01T00:00:00+00:00", "valid_until":"2026-01-31T00:00:00+00:00"
    })
    ev = g.add_node("Evidence", "old", "supported", {
        "source_id":"s", "provider_id":"p", "origin_id":"o",
        "locator":{"type":"text_quote", "exact":"old"}, "extraction_method":"test",
        "observation_time":"2026-01-01T00:00:00+00:00", "observation_basis":"snapshot", "polarity":"supports"
    })
    g.link(ev.id, "derived_from", snap.id)
    a = EvidenceEvaluator(g).assess(ev.id, as_of="2026-02-02T00:00:00+00:00")
    assert a.dimension_results["temporal_fitness"] == "stale_or_unknown"


def test_claim_evaluation_distinguishes_entailment_from_support():
    from tbohk.evaluation import ClaimEvaluator
    g, out = build_chain(); e = EpistemicEngine(g)
    ev = out["results"][0][1]
    claim = e.propose_claim(ev.content, [ev.id])
    a = ClaimEvaluator(g).assess(claim.id)
    assert a.evidence_results[ev.id] == "entails"
    assert a.dimensions["evidence_warrant"] == "entailed"


def test_claim_evaluation_rejects_correlation_as_entailment():
    from tbohk.evaluation import ClaimEvaluator
    g, out = build_chain(); e = EpistemicEngine(g)
    ev = out["results"][0][1]
    claim = e.propose_claim("Water freezes at 0 C because of mechanism Y.", [ev.id])
    a = ClaimEvaluator(g).assess(claim.id, evidence_relations={ev.id:"correlates"})
    assert a.dimensions["evidence_warrant"] == "correlation_only"


def test_claim_evaluation_detects_refuting_evidence():
    from tbohk.evaluation import ClaimEvaluator
    g, out = build_chain(); e = EpistemicEngine(g)
    ev = out["results"][0][1]
    claim = e.propose_claim("Water freezes at 10 C.", [ev.id])
    a = ClaimEvaluator(g).assess(claim.id, evidence_relations={ev.id:"refutes"})
    assert a.dimensions["evidence_warrant"] == "refuted"


def test_claim_assessment_is_first_class_and_audited():
    from tbohk.evaluation import ClaimEvaluator
    g, out = build_chain(); e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id])
    ClaimEvaluator(g).record(claim.id, assessor="reviewer")
    rows = g.edges(claim.id, "in", "evaluates")
    assert len(rows) == 1 and g.get(rows[0]["source_id"]).kind == "ClaimAssessment"
    assert g.audit()["ok"]


def test_claim_evaluation_flags_missing_uncertainty_and_scope():
    from tbohk.evaluation import ClaimEvaluator
    g, out = build_chain(); e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id])
    a = ClaimEvaluator(g).assess(claim.id)
    assert a.dimensions["uncertainty_propagation"] == "not_stated"
    assert a.dimensions["scope_alignment"] == "unstated"


def test_claim_synthesis_preserves_conflicting_evidence_and_does_not_set_truth():
    from tbohk.evaluation import ClaimEvaluator, ClaimSynthesizer
    g, out = build_chain(); e = EpistemicEngine(g)
    ev1 = out["results"][0][1]
    ev2 = out["results"][1][1]
    claim = e.propose_claim("Water freezes at 0 C.", [ev1.id, ev2.id])
    a = ClaimEvaluator(g).assess(claim.id, evidence_relations={ev1.id:"supports", ev2.id:"refutes"})
    s = ClaimSynthesizer(g).synthesize(claim.id, a)
    assert s.disposition == "contested"
    assert set(s.supporting_evidence_ids) == {ev1.id}
    assert set(s.refuting_evidence_ids) == {ev2.id}
    assert claim.status == "proposed"


def test_claim_synthesis_propagates_interval_conservatively():
    from tbohk.evaluation import ClaimSynthesizer
    g, out = build_chain(); e = EpistemicEngine(g)
    ev1, ev2 = out["results"][0][1], out["results"][1][1]
    ev1.metadata["uncertainty"] = {"type":"interval", "lower":9, "upper":10, "unit":"C"}
    ev2.metadata["uncertainty"] = {"type":"interval", "lower":9.5, "upper":11, "unit":"C"}
    # Metadata objects are reconstructed from storage; mutate through SQL for the fixture.
    import json
    for ev, u in ((ev1, ev1.metadata["uncertainty"]), (ev2, ev2.metadata["uncertainty"])):
        g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps({**ev.metadata, "uncertainty":u}), ev.id))
    g.db.commit()
    claim = e.propose_claim("measurement", [ev1.id, ev2.id])
    s = ClaimSynthesizer(g).synthesize(claim.id)
    assert s.uncertainty["type"] == "interval"
    assert s.uncertainty["lower"] == 9.0 and s.uncertainty["upper"] == 11.0
    assert s.uncertainty["method"] == "conservative_envelope"


def test_claim_synthesis_is_first_class_and_audited():
    from tbohk.evaluation import ClaimSynthesizer
    g, out = build_chain(); e = EpistemicEngine(g)
    claim = e.propose_claim("Water freezes at 0 C.", [out["results"][0][1].id])
    ClaimSynthesizer(g).record(claim.id, assessor="reviewer")
    rows = g.edges(claim.id, "in", "evaluates")
    assert len(rows) == 1 and g.get(rows[0]["source_id"]).kind == "ClaimSynthesis"
    assert g.audit()["ok"]

def test_reasoning_activity_preserves_premise_rule_and_provenance():
    from tbohk.reasoning import ReasoningEngine
    g = TBOHK()
    e = EpistemicEngine(g)
    c = e.propose_claim("Sky is blue.", [], subject="sky", predicate="color", object_value="blue")
    g.set_status(c.id, "supported", "fixture")
    r = ReasoningEngine(g).add_rule("identity blue", "identity", {
        "consequent":{"predicate":"color","subject":"sky","object":"blue"}
    })
    result = ReasoningEngine(g).derive(rule_id=r.id, premise_ids=[c.id], content="Sky is blue.",
        structured={"predicate":"color","subject":"sky","object":"blue"})
    derived = g.get(result.derived_claim_id)
    assert derived.status == "proposed"
    assert g.get(result.activity_id).kind == "ReasoningActivity"
    assert g.audit()["ok"]


def test_reasoning_rejects_unsupported_premise_and_does_not_auto_verify():
    from tbohk.reasoning import ReasoningEngine
    g = TBOHK(); e = EpistemicEngine(g)
    c = e.propose_claim("X", [], subject="x", predicate="p", object_value="y")
    r = ReasoningEngine(g).add_rule("identity", "identity", {"consequent":{"predicate":"p","subject":"x","object":"y"}})
    with pytest.raises(ValueError, match="supported or verified"):
        ReasoningEngine(g).derive(rule_id=r.id, premise_ids=[c.id], content="X",
            structured={"predicate":"p","subject":"x","object":"y"})


def test_reasoning_semantic_result_must_match_rule():
    from tbohk.reasoning import ReasoningEngine
    g = TBOHK(); e = EpistemicEngine(g)
    c = e.propose_claim("Sky is blue.", [], subject="sky", predicate="color", object_value="blue")
    g.set_status(c.id, "supported", "fixture")
    r = ReasoningEngine(g).add_rule("identity", "identity", {"consequent":{"predicate":"color","subject":"sky","object":"blue"}})
    with pytest.raises(ValueError, match="does not match"):
        ReasoningEngine(g).derive(rule_id=r.id, premise_ids=[c.id], content="Sky is red.",
            structured={"predicate":"color","subject":"sky","object":"red"})


def test_reasoning_audit_detects_missing_rule():
    g = TBOHK(); e = EpistemicEngine(g)
    c = e.propose_claim("Sky is blue.", [], subject="sky", predicate="color", object_value="blue")
    g.set_status(c.id, "supported", "fixture")
    activity = g.add_node("ReasoningActivity", "bad reasoning", "supported", {})
    g.link(activity.id, "uses", c.id)
    assert any(p[1] == "reasoning_activity_without_rule" for p in g.audit()["problems"])


def test_g4_reasoning_is_first_class_and_does_not_verify_conclusion():
    from tbohk.reasoning import ReasoningEngine
    g, out = build_chain(); e = EpistemicEngine(g)
    ev = out["results"][0][1]
    p = e.propose_claim(ev.content, [ev.id])
    q = e.propose_claim("Independent fact", [out["results"][1][1].id])
    g.set_status(p.id, "supported", "fixture")
    g.set_status(q.id, "supported", "fixture")
    r = ReasoningEngine(g).register_rule("conjunction")
    result = ReasoningEngine(g).derive(r.id, [p.id, q.id])
    activity = g.get(result.activity_id); conclusion = g.get(result.conclusion_id)
    assert activity.kind == "ReasoningActivity"
    assert conclusion.kind == "Claim" and conclusion.status == "proposed"
    assert g.audit()["ok"]


def test_g4_reasoning_requires_explicit_rule_and_premise_edges():
    from tbohk.reasoning import ReasoningEngine
    g, out = build_chain(); e = EpistemicEngine(g)
    p = e.propose_claim(out["results"][0][1].content, [out["results"][0][1].id])
    q = e.propose_claim("another fact", [out["results"][1][1].id])
    g.set_status(p.id, "supported", "fixture")
    g.set_status(q.id, "supported", "fixture")
    rr = ReasoningEngine(g); rule = rr.register_rule("conjunction")
    result = rr.derive(rule.id, [p.id, q.id])
    g.db.execute("DELETE FROM edges WHERE target_id=? AND relation='premise_of'", (result.activity_id,)); g.db.commit()
    assert not g.audit()["ok"]


def test_g4_reasoning_rule_hash_is_audited():
    from tbohk.reasoning import ReasoningEngine
    g = TBOHK(); rule = ReasoningEngine(g).register_rule("conjunction")
    import json
    meta = dict(rule.metadata); meta["name"] = "tampered"
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(meta), rule.id)); g.db.commit()
    assert any(x[1] == "reasoning_rule_hash_mismatch" for x in g.audit()["problems"])


def test_g4_modus_ponens_requires_structured_implication():
    from tbohk.reasoning import ReasoningEngine
    g, out = build_chain(); e = EpistemicEngine(g)
    conditional = e.propose_claim("If A then B", [out["results"][0][1].id])
    antecedent = e.propose_claim("A", [out["results"][1][1].id])
    g.set_status(conditional.id, "supported", "fixture")
    g.set_status(antecedent.id, "supported", "fixture")
    rule = ReasoningEngine(g).register_rule("modus_ponens")
    try:
        ReasoningEngine(g).derive(rule.id, [conditional.id, antecedent.id])
    except ValueError as exc:
        assert "implication.consequent" in str(exc)
    else:
        raise AssertionError("modus ponens accepted an unstructured conditional")

def test_g42_explicit_assumption_is_preserved_and_auditable():
    from tbohk.semantics import SemanticReasoningEngine
    g, out = build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test"); e=SemanticReasoningEngine(g)
    a=e.add_assumption("Sensor calibration is current")
    rr=ReasoningEngine(g); rule=rr.add_rule("identity-test","identity",{"consequent":base.metadata["structured"]}); r=e.propose("deductive", [base.id], conclusion="Derived conclusion",
                structured=base.metadata["structured"], premise_roles={base.id:"necessary"},
                assumption_ids=[a.id], rule_id=rule.id)
    assert a.id in r.assumption_ids
    assert g.edges(r.activity_id,"out","assumes")
    assert g.audit()["ok"]

def test_g42_abduction_is_not_marked_as_entailment():
    from tbohk.semantics import SemanticReasoningEngine
    g, out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test"); e=SemanticReasoningEngine(g)
    r=e.propose("abductive", [base.id], conclusion="Candidate explanation", structured={"kind":"hypothesis"})
    c=g.get(r.conclusion_id)
    assert c.status == "proposed" and c.metadata["epistemic_disposition"] == "candidate_explanation"
    assert g.audit()["ok"]

def test_g42_defeater_is_first_class_and_does_not_delete_inference():
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test"); e=SemanticReasoningEngine(g)
    d=e.add_defeater("Exception applies in jurisdiction X")
    r=e.propose("defeasible", [base.id], conclusion="Normally derived", defeater_ids=[d.id])
    assert g.get(r.conclusion_id).status == "proposed"
    assert g.edges(d.id,"out","defeats")
    assert g.audit()["ok"]

def test_g42_counterfactual_isolated_in_branch():
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test"); e=SemanticReasoningEngine(g)
    r=e.propose("counterfactual", [base.id], conclusion="Hypothetical result",
                counterfactual={"intervention":"remove premise X","baseline":"actual","scope":"test"})
    assert r.branch_id and g.get(r.branch_id).kind == "CounterfactualBranch"
    assert g.get(r.conclusion_id).metadata["epistemic_disposition"] == "hypothetical"
    assert g.audit()["ok"]

def test_g42_reasoning_assessment_is_separate_from_conclusion():
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test"); e=SemanticReasoningEngine(g)
    r=e.propose("inductive", [base.id], conclusion="Generalization")
    a=e.assess(r.activity_id)
    assert a.kind == "ReasoningAssessment"
    assert g.get(r.conclusion_id).status == "proposed"
    assert g.audit()["ok"]

def test_g43_independent_inference_assessment_warrants_clean_deduction():
    from tbohk.inference import InferenceEvaluator
    g,out=build_chain(); ep=EpistemicEngine(g)
    base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test")
    rr=ReasoningEngine(g); rule=rr.add_rule("identity-g43","identity",{"consequent":base.metadata["structured"]})
    sr=rr.derive(rule.id,[base.id])
    a=InferenceEvaluator(g).record(sr.activity_id)
    assert a.verdict == "warranted"
    assert g.get(sr.conclusion_id).status == "proposed"
    assert g.audit()["ok"]

def test_g43_assumptions_make_warrant_conditional():
    from tbohk.inference import InferenceEvaluator
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test")
    se=SemanticReasoningEngine(g); ass=se.add_assumption("calibration is current")
    rr=ReasoningEngine(g); rule=rr.add_rule("semantic-deductive-g43","identity",{"consequent":base.metadata["structured"]})
    r=se.propose("deductive",[base.id],conclusion="derived",structured=base.metadata["structured"],premise_roles={base.id:"necessary"},assumption_ids=[ass.id],rule_id=rule.id)
    a=InferenceEvaluator(g).assess(r.activity_id)
    assert a.verdict == "conditionally_warranted"

def test_g43_detects_circular_reasoning():
    from tbohk.inference import InferenceEvaluator
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test")
    rr=ReasoningEngine(g); rule=rr.add_rule("id-g43-cycle","identity",{"consequent":base.metadata["structured"]}); r=rr.derive(rule.id,[base.id])
    # Introduce an adversarial dependency from the derived conclusion back to the activity's premise.
    g.link(r.conclusion_id,"derived_from",r.conclusion_id) if False else None
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(r.activity_id,"uses",r.conclusion_id,g._now())); g.db.commit()
    a=InferenceEvaluator(g).assess(r.activity_id)
    assert a.verdict == "invalid" and a.dimensions["circularity"] == "detected"

def test_g43_competing_derivations_are_exposed():
    from tbohk.inference import InferenceEvaluator
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test")
    rr=ReasoningEngine(g); rule=rr.add_rule("id-g43-compete","identity",{"consequent":base.metadata["structured"]})
    r1=rr.derive(rule.id,[base.id])
    r2=rr.derive(rule.id,[base.id])
    # Deliberately converge the second activity on the first conclusion to model competing derivation routes.
    g.link(r2.activity_id,"derives",r1.conclusion_id)
    g.link(r2.activity_id,"produces",r1.conclusion_id)
    a=InferenceEvaluator(g).assess(r1.activity_id)
    assert a.verdict == "contested" and r2.activity_id in a.competing_activity_ids

def test_g43_record_is_not_self_certification():
    from tbohk.inference import InferenceEvaluator
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","test")
    rr=ReasoningEngine(g); rule=rr.add_rule("id-g43-record","identity",{"consequent":base.metadata["structured"]}); r=rr.derive(rule.id,[base.id])
    node=InferenceEvaluator(g).record(r.activity_id)
    assert node.verdict if hasattr(node,'verdict') else True
    assert g.get(r.conclusion_id).status == "proposed"
    assert g.audit()["ok"]

def test_g44_conflict_analyzer_preserves_unresolved_disagreement():
    from tbohk.conflict_analysis import ConflictAnalyzer
    g,out=build_chain(); ep=EpistemicEngine(g)
    a=ep.propose_claim("A", [out["results"][0][1].id]); b=ep.propose_claim("not A", [out["results"][1][1].id])
    c=ep.contradict(a.id,b.id,reason="fixture disagreement")
    x=ConflictAnalyzer(g).record(c.id)
    assert x.verdict == "balanced"
    assert g.get(a.id).status == "proposed" and g.get(b.id).status == "proposed"
    assert g.audit()["ok"]

def test_g44_scope_split_is_detected_without_selecting_truth():
    from tbohk.conflict_analysis import ConflictAnalyzer
    g,out=build_chain(); ep=EpistemicEngine(g)
    a=ep.propose_claim("A in 2025", [out["results"][0][1].id], scope="2025")
    b=ep.propose_claim("A in 2026", [out["results"][1][1].id], scope="2026")
    c=ep.contradict(a.id,b.id)
    x=ConflictAnalyzer(g).assess(c.id)
    assert x.verdict == "scope_separated"
    assert g.get(a.id).status == "proposed" and g.get(b.id).status == "proposed"

def test_g44_resolution_is_reported_not_endorsed():
    from tbohk.conflict_analysis import ConflictAnalyzer
    g,out=build_chain(); ep=EpistemicEngine(g)
    a=ep.propose_claim("A", [out["results"][0][1].id]); b=ep.propose_claim("not A", [out["results"][1][1].id])
    c=ep.contradict(a.id,b.id); ep.resolve_conflict(c.id,"accept_claim",claim_id=a.id,resolver="reviewer",rationale="fixture")
    x=ConflictAnalyzer(g).assess(c.id)
    assert x.verdict == "unresolved"
    assert x.verdict == "unresolved"
    assert g.get(a.id).status == "proposed" and g.get(b.id).status == "proposed"
    assert g.audit()["ok"]

def test_g44_defeater_exposure_is_preserved():
    from tbohk.conflict_analysis import ConflictAnalyzer
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    se=SemanticReasoningEngine(g); d=se.add_defeater("exception")
    r=se.propose("defeasible",[base.id],conclusion="normally true",defeater_ids=[d.id])
    other=ep.propose_claim("contrary",[out["results"][1][1].id]); c=ep.contradict(r.conclusion_id,other.id)
    x=ConflictAnalyzer(g).assess(c.id)
    assert d.id in x.defeaters
    assert x.dimensions["defeater_analysis"] == "present"
    assert g.audit()["ok"]

def test_g44_external_objection_is_distinguished_from_conflict_members():
    from tbohk.conflict_analysis import ConflictAnalyzer
    g,out=build_chain(); ep=EpistemicEngine(g)
    a=ep.propose_claim("A",[out["results"][0][1].id]); b=ep.propose_claim("not A",[out["results"][1][1].id]); o=ep.propose_claim("objection",[out["results"][0][1].id])
    g.link(o.id,"contradicts",a.id); c=ep.contradict(a.id,b.id)
    x=ConflictAnalyzer(g).assess(c.id)
    assert o.id in x.objections
    assert g.audit()["ok"]

def test_g44_assessment_is_first_class_and_separate():
    from tbohk.conflict_analysis import ConflictAnalyzer
    g,out=build_chain(); ep=EpistemicEngine(g); a=ep.propose_claim("A",[out["results"][0][1].id]); b=ep.propose_claim("B",[out["results"][1][1].id]); c=ep.contradict(a.id,b.id)
    x=ConflictAnalyzer(g).record(c.id)
    node=[n for n in [g.get(xid) for xid in [r[0] for r in g.db.execute("SELECT source_id FROM edges WHERE target_id=? AND relation='evaluates'",(c.id,))]] if n and n.kind=='ConflictAssessment'][0]
    assert node.metadata["assessor"] == "independent-conflict-review"
    assert g.audit()["ok"]

# G4.5 Explanation Reconstruction & Traceability

def test_g45_reconstructs_reasoning_to_source_chain():
    from tbohk.explanation import ExplanationReconstructor
    g,out=build_chain(); ep=EpistemicEngine(g)
    base=ep.propose_claim("base", [out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    rr=ReasoningEngine(g); rule=rr.add_rule("g45-id","identity",{"consequent":base.metadata["structured"]}); r=rr.derive(rule.id,[base.id])
    t=ExplanationReconstructor(g).trace(r.conclusion_id)
    assert r.activity_id in t.node_ids and rule.id in t.node_ids and base.id in t.node_ids
    assert any(x.kind=="Evidence" for x in [g.get(n) for n in t.node_ids] if x)
    assert t.edge_count >= 4

def test_g45_trace_does_not_invent_missing_provenance():
    from tbohk.explanation import ExplanationReconstructor
    g=TBOHK(); c=g.add_node("Claim","derived",metadata={"derived":True})
    t=ExplanationReconstructor(g).trace(c.id)
    assert not t.complete
    assert any("derived claim" in x for x in t.missing_links)

def test_g45_assumptions_and_defeaters_are_exposed():
    from tbohk.explanation import ExplanationReconstructor
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    se=SemanticReasoningEngine(g); a=se.add_assumption("condition"); d=se.add_defeater("exception")
    r=se.propose("defeasible",[base.id],conclusion="normally true",assumption_ids=[a.id],defeater_ids=[d.id])
    t=ExplanationReconstructor(g).trace(r.conclusion_id)
    assert a.id in t.conditional_nodes and d.id in t.conditional_nodes

def test_g45_counterfactual_branch_isolated_in_trace():
    from tbohk.explanation import ExplanationReconstructor
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    se=SemanticReasoningEngine(g); r=se.propose("counterfactual",[base.id],conclusion="would change",counterfactual={"intervention":"remove X"})
    t=ExplanationReconstructor(g).trace(r.conclusion_id)
    assert r.branch_id in t.node_ids

def test_g45_conflict_is_exposed_not_resolved():
    from tbohk.explanation import ExplanationReconstructor
    g,out=build_chain(); ep=EpistemicEngine(g); a=ep.propose_claim("A",[out["results"][0][1].id]); b=ep.propose_claim("not A",[out["results"][1][1].id]); c=ep.contradict(a.id,b.id)
    t=ExplanationReconstructor(g).trace(a.id)
    # conflict is discoverable from the claim's outgoing contradiction edge
    assert c.id in t.conflict_nodes or any(g.get(n) and g.get(n).kind=="ConflictSet" for n in t.node_ids)

def test_g45_record_is_first_class_and_non_mutating():
    from tbohk.explanation import ExplanationReconstructor
    g,out=build_chain(); ep=EpistemicEngine(g); c=ep.propose_claim("A",[out["results"][0][1].id])
    before=g.get(c.id).status; t=ExplanationReconstructor(g).record(c.id)
    assert t.root_id==c.id and g.get(c.id).status==before
    assert g.audit()["ok"]

# G4.6 Reasoning Robustness & Counterfactual Stress Testing

def test_g46_premise_removal_is_detected_without_mutation():
    from tbohk.robustness import ReasoningStressTester
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    rr=ReasoningEngine(g); rule=rr.add_rule("g46-id","identity",{"consequent":base.metadata["structured"]}); r=rr.derive(rule.id,[base.id])
    before=g.get(r.conclusion_id).status
    report=ReasoningStressTester(g).test(r.activity_id, ["remove_premise"])
    assert report.resilience=="fragile" and report.cases[0].outcome=="fragile"
    assert g.get(r.conclusion_id).status==before

def test_g46_assumption_failure_is_conditional():
    from tbohk.robustness import ReasoningStressTester
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    se=SemanticReasoningEngine(g); a=se.add_assumption("condition"); r=se.propose("defeasible",[base.id],conclusion="normally true",assumption_ids=[a.id])
    report=ReasoningStressTester(g).test(r.activity_id,["fail_assumption"])
    assert report.cases[0].outcome=="conditionally_fragile"

def test_g46_defeater_activation_is_exposed():
    from tbohk.robustness import ReasoningStressTester
    from tbohk.semantics import SemanticReasoningEngine
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    se=SemanticReasoningEngine(g); d=se.add_defeater("exception"); r=se.propose("defeasible",[base.id],conclusion="normally true",defeater_ids=[d.id])
    report=ReasoningStressTester(g).test(r.activity_id,["activate_defeater"])
    assert report.cases[0].outcome=="defeated_or_reassess"

def test_g46_contradiction_does_not_choose_winner():
    from tbohk.robustness import ReasoningStressTester
    g,out=build_chain(); ep=EpistemicEngine(g); a=ep.propose_claim("A",[out["results"][0][1].id]); b=ep.propose_claim("not A",[out["results"][1][1].id]); ep.contradict(a.id,b.id)
    rr=ReasoningStressTester(g)
    # target a is not a reasoning claim, so this should be rejected rather than guessed
    try: rr.test(a.id,["inject_contradiction"])
    except ValueError: return
    assert False

def test_g46_record_is_first_class_and_non_mutating():
    from tbohk.robustness import ReasoningStressTester
    g,out=build_chain(); ep=EpistemicEngine(g); base=ep.propose_claim("base",[out["results"][0][1].id]); g.set_status(base.id,"supported","fixture")
    rr=ReasoningEngine(g); rule=rr.add_rule("g46-id","identity",{"consequent":base.metadata["structured"]}); r=rr.derive(rule.id,[base.id])
    before=g.get(r.conclusion_id).status; report=ReasoningStressTester(g).record(r.activity_id,["change_rule_version"])
    assert report.resilience=="conditional" and g.get(r.conclusion_id).status==before
    assert g.audit()["ok"]

# G4.7 Reasoning Benchmarking & Regression Corpus

def test_g47_corpus_manifest_is_stable_and_versioned():
    from tbohk.benchmark import CORPUS_VERSION, CASES, corpus_sha256
    assert CORPUS_VERSION == "G4.7-1"
    assert len(CASES) == 12
    assert len(corpus_sha256()) == 64


def test_g47_full_regression_corpus_passes():
    from tbohk.benchmark import ReasoningBenchmark
    report = ReasoningBenchmark().run(as_of="2026-09-25T00:00:00+00:00")
    assert report.total == 12
    assert report.passed == 12
    assert report.failed == 0
    assert all(r.passed for r in report.results)


def test_g47_corpus_results_are_deterministic():
    from tbohk.benchmark import ReasoningBenchmark
    a = ReasoningBenchmark().run(as_of="2026-09-25T00:00:00+00:00")
    b = ReasoningBenchmark().run(as_of="2026-09-25T00:00:00+00:00")
    assert a.corpus_sha256 == b.corpus_sha256
    assert [(x.case_id,x.passed,x.findings) for x in a.results] == [(x.case_id,x.passed,x.findings) for x in b.results]


def test_g47_record_is_first_class_and_non_mutating():
    from tbohk.benchmark import ReasoningBenchmark
    g = TBOHK(); n = g.add_node("Claim", "fixture")
    before = g.get(n.id).status
    report, run = ReasoningBenchmark().record(g, as_of="2026-09-25T00:00:00+00:00")
    assert report.passed == report.total
    assert run.kind == "BenchmarkRun"
    assert g.get(n.id).status == before
    assert g.audit()["ok"]

# G4.8 Metamorphic Reasoning Tests

def test_g48_suite_manifest_is_stable_and_versioned():
    from tbohk.metamorphic import SUITE_VERSION, CASES, suite_sha256
    assert SUITE_VERSION == "G4.8-1"
    assert len(CASES) == 12
    assert len(suite_sha256()) == 64


def test_g48_full_metamorphic_suite_passes():
    from tbohk.metamorphic import MetamorphicSuite
    report=MetamorphicSuite().run(as_of="2026-09-25T00:00:00+00:00")
    assert report.total == 12
    assert report.passed == 12
    assert report.failed == 0
    assert all(r.passed for r in report.results)


def test_g48_suite_is_deterministic():
    from tbohk.metamorphic import MetamorphicSuite
    a=MetamorphicSuite().run(as_of="2026-09-25T00:00:00+00:00")
    b=MetamorphicSuite().run(as_of="2026-09-25T00:00:00+00:00")
    assert a.suite_sha256==b.suite_sha256
    assert [(x.case_id,x.passed,x.findings) for x in a.results]==[(x.case_id,x.passed,x.findings) for x in b.results]


def test_g48_record_is_first_class_and_non_mutating():
    from tbohk.metamorphic import MetamorphicSuite
    g=TBOHK(); n=g.add_node("Claim","fixture")
    before=g.get(n.id).status
    report,node=MetamorphicSuite().record(g,as_of="2026-09-25T00:00:00+00:00")
    assert report.passed==report.total and node.kind=="MetamorphicRun"
    assert g.get(n.id).status==before and g.audit()["ok"]

# G4.9 mutation testing
from tbohk.mutation import MutationSuite, CASES as MUTATION_CASES

def test_mutation_suite_detects_all_faults():
    report = MutationSuite().run(as_of="2026-01-01T00:00:00+00:00")
    assert report.total == len(MUTATION_CASES) == 12
    assert report.detected == 12
    assert report.missed == 0
    assert all(r.detected for r in report.results)

def test_mutation_suite_is_repeatable():
    a = MutationSuite().run(as_of="2026-01-01T00:00:00+00:00")
    b = MutationSuite().run(as_of="2026-01-01T00:00:00+00:00")
    assert [(r.case_id,r.detected,r.detector) for r in a.results] == [(r.case_id,r.detected,r.detector) for r in b.results]

def test_mutation_record_is_first_class_and_auditable():
    from tbohk import TBOHK
    g=TBOHK(); report,node=MutationSuite().record(g, as_of="2026-01-01T00:00:00+00:00")
    assert report.missed == 0 and node.kind == "MutationRun" and g.audit()["ok"]

def test_source_content_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[0]
    assert r.case_id == "G49-001" and r.detected and r.detector == "graph_audit"

def test_rule_definition_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[3]
    assert r.case_id == "G49-004" and r.detected

def test_provenance_edge_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[4]
    assert r.case_id == "G49-005" and r.detected

def test_self_certification_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[5]
    assert r.case_id == "G49-006" and r.detected

def test_assessment_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[6]
    assert r.case_id == "G49-007" and r.detected

def test_independence_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[8]
    assert r.case_id == "G49-009" and r.detected

def test_explanation_provenance_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[9]
    assert r.case_id == "G49-010" and r.detected

def test_benchmark_manifest_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[10]
    assert r.case_id == "G49-011" and r.detected

def test_metamorphic_manifest_mutation_is_detected():
    r=MutationSuite().run(as_of="2026-01-01T00:00:00+00:00").results[11]
    assert r.case_id == "G49-012" and r.detected


def test_edges_both_relation_filter_is_parenthesized_and_validated():
    g=TBOHK(); a=g.add_node('Claim','a'); b=g.add_node('Claim','b'); c=g.add_node('Claim','c')
    g.link(a.id,'supports',b.id); g.link(c.id,'contradicts',a.id)
    assert [e['target_id'] for e in g.edges(a.id,'both','supports')] == [b.id]
    assert [e['source_id'] for e in g.edges(a.id,'both','contradicts')] == [c.id]
    with pytest.raises(ValueError): g.edges(a.id,'both','not-a-relation')
    with pytest.raises(ValueError): g.edges(a.id,'invalid')


def test_metadata_update_is_ledgered_and_deterministic():
    g=TBOHK(); n=g.add_node('Claim','x',metadata={'a':1}); before=len(g.events(n.id)); g.update_metadata(n.id, {'b':2}, reason='test'); after=g.get(n.id); assert after.metadata['a']==1 and after.metadata['b']==2
    events=g.events(n.id); assert len(events)==before+1 and events[-1]['event_type']=='metadata.updated'
    assert events[-1]['payload'].find('old_metadata') >= 0 and events[-1]['payload'].find('new_metadata') >= 0
    assert G21LedgerAuditor(g).audit().passed


def test_system_owned_integrity_hashes_cannot_be_forged_on_create():
    g=TBOHK(); n=g.add_node('Claim','content',metadata={'content_sha256':'forged','metadata_sha256':'forged'}); assert n.metadata['content_sha256']==g._hash('content'); assert n.metadata['metadata_sha256']==g._metadata_hash(n.metadata); assert not g.audit()['problems']

def test_metadata_tamper_is_detected_without_checkpoint():
    g=TBOHK(); n=g.add_node('Claim','content',metadata={'x':1}); md=dict(n.metadata); md['x']=2; g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(md,sort_keys=True),n.id)); g.db.commit(); assert any(code=='metadata_hash_mismatch' for _,code in g.audit()['problems'])


def test_package_cli_entrypoint_and_public_exports():
    import subprocess, sys
    from tbohk import DependencyImpactAnalyzer, ReEvaluationWorkflow, InvestigationStateEngine, AdaptiveResearchController
    assert DependencyImpactAnalyzer and ReEvaluationWorkflow and InvestigationStateEngine and AdaptiveResearchController
    out=subprocess.check_output([sys.executable,'-m','tbohk.cli','version'],text=True,cwd=Path(__file__).resolve().parents[1]).strip(); import tbohk; assert out==tbohk.__version__

def test_search_rejects_non_positive_limit():
    from tbohk.service import TBOHKService
    g=TBOHK(); g.add_node('Claim','searchable'); service=TBOHKService(g)
    with pytest.raises(ValueError): service.search_nodes('searchable',0)
    with pytest.raises(ValueError): service.search_nodes('searchable',-1)
