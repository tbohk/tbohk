from tbohk import TBOHK, ContaminationValidator

def graph_chain():
    g=TBOHK(); src=g.add_node("SourceSnapshot","source","supported"); ev=g.add_node("Evidence","evidence","supported"); c=g.add_node("Claim","claim","verified"); k=g.add_node("Knowledge","knowledge","verified"); d=g.add_node("Decision","decision","verified"); p=g.add_node("Plan","plan","verified")
    g.link(ev.id,"derived_from",src.id); g.link(ev.id,"evidence_for",c.id); g.link(k.id,"depends_on",c.id); g.link(d.id,"depends_on",k.id); g.link(p.id,"depends_on",d.id)
    return g,src,ev,c,k,d,p

def test_contamination_closure_reaches_all_downstream_derivatives():
    g,src,ev,c,k,d,p=graph_chain(); q=ContaminationValidator(g).plan_quarantine((src.id,)); assert set(q.quarantined_ids)=={x.id for x in (src,ev,c,k,d,p)}; assert set(q.promotion_blocked_ids)=={x.id for x in (src,ev,c,k,d,p)}

def test_verified_contaminated_derivatives_block():
    g,src,*_=graph_chain(); r=ContaminationValidator(g).audit((src.id,)); assert not r.passed; assert any(f.code=="verified_contaminated_derivative" for f in r.findings)

def test_unaffected_knowledge_is_not_quarantined():
    g,src,*_=graph_chain(); clean=g.add_node("Knowledge","independent","verified"); q=ContaminationValidator(g).plan_quarantine((src.id,)); assert clean.id in q.unaffected_ids and clean.id not in q.quarantined_ids

def test_missing_root_blocks():
    r=ContaminationValidator(TBOHK()).audit(("missing-root",)); assert not r.passed and r.findings[0].code=="contamination_root_missing"

def test_audit_is_read_only():
    g,src,ev,c,k,d,p=graph_chain(); before=[g.get(x.id).status for x in (src,ev,c,k,d,p)]; ContaminationValidator(g).audit((src.id,)); assert before==[g.get(x.id).status for x in (src,ev,c,k,d,p)]

def test_multiple_roots_are_deterministic():
    g,src,*_=graph_chain(); other=g.add_node("SourceSnapshot","other","supported"); r=ContaminationValidator(g).audit((other.id,src.id)); assert tuple(p.root_ids for p in r.plans)==tuple((x,) for x in sorted((src.id, other.id)))

def test_declared_dependency_is_blocked():
    g=TBOHK(); root=g.add_node("SourceSnapshot","bad","supported"); x=g.add_node("Knowledge","derived","verified",{"dependency_ids":[root.id]}); q=ContaminationValidator(g).plan_quarantine((root.id,)); assert x.id in q.promotion_blocked_ids

def test_no_roots_passes():
    g, *_=graph_chain(); r=ContaminationValidator(g).audit(); assert r.passed and not r.plans

def test_release_audit_surfaces_contamination_root():
    from tbohk import ReleaseAuditor
    g, src, *_ = graph_chain()
    g.add_node("ContaminationRoot", src.id, "supported", {"root_id": src.id})
    report = ReleaseAuditor(g).audit()
    assert not report.passed
    assert any(f.code.startswith("G19:") for f in report.findings)
