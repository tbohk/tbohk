from tbohk import *

def test_resource_guard_rejects_large_graph():
    g=TBOHK(); root=g.add_node('Claim','root'); nodes=[g.add_node('Claim',str(i)) for i in range(20)]
    for n in nodes: g.link(root.id,'supports',n.id)
    r=ReasoningResourceGuard(g,ComplexityBudget(max_edges_examined=5)).measure(root.id); assert not r.ok and 'edges_examined' in r.exceeded

def test_resource_guard_is_deterministic():
    g=TBOHK(); n=g.add_node('Claim','x'); guard=ReasoningResourceGuard(g); assert guard.measure(n.id).metrics==guard.measure(n.id).metrics
