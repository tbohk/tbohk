from datetime import datetime, timezone, timedelta
from tbohk import TBOHK, AutonomousLoop, AdversarialValidator, RealityEngine
from tbohk.plans import PlanEngine
from tbohk.governance import GovernanceEngine
from tbohk.actions import ActionLedger

def test_g9_loop_is_bounded_and_cannot_authorize():
    g=TBOHK(); loop=AutonomousLoop(g, planner=PlanEngine(g))
    r=loop.start('test objective',max_cycles=2,planner_steps=['observe','audit'])
    run=g.get(r.run_id)
    assert r.cycles==2 and run.status=='supported'
    assert not g.edges(run.id,'out','authorizes')

def test_g10_self_reference_and_authority_escalation_are_detected():
    g=TBOHK(); ev=g.add_node('Evaluation','e','supported',{'target_id':'x','suite_id':'s'})
    g.link(ev.id,'authorizes',ev.id) if False else None
    # direct DB injection simulates a compromised component
    g.db.execute("INSERT INTO edges VALUES (?,?,?,?)",(ev.id,'authorizes',ev.id,'now')); g.db.commit()
    findings=AdversarialValidator(g).run()
    assert any(f.code=='autonomy_authority_escalation' for f in findings)

def test_g10_expired_authority_is_blocking():
    g=TBOHK(); ge=GovernanceEngine(g)
    exp=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
    grant=ge.grant('agent',['execute_action'],expires_at=exp,approver='root'); ge.approve_grant(grant.id,approver='root')
    assert any(f.code=='expired_authority_grant' and f.blocks_release for f in AdversarialValidator(g).run())

def test_g11_freshness_and_reality_conflict():
    g=TBOHK(); re=RealityEngine(g)
    old=(datetime.now(timezone.utc)-timedelta(hours=2)).isoformat()
    a=re.observe('source-a','temperature=10',observed_at=old,retrieved_at=old)
    b=re.observe('source-b','temperature=20')
    assert re.freshness(a.id,max_age_seconds=60).fresh is False
    c=re.contradict(a.id,b.id,reason='different observed value')
    assert c.kind=='RealityConflict'

def test_g11_post_action_verification_is_explicit():
    g=TBOHK(); ge=GovernanceEngine(g); al=ActionLedger(g); re=RealityEngine(g)
    grant=ge.grant('agent',['execute_action'],approver='root'); ge.approve_grant(grant.id,approver='root')
    a=al.propose('agent','turn-switch-on','switch-1','on',authority_grant_id=grant.id)
    al.authorize(a.id,grant.id)
    o=re.observe('sensor-1','switch-1=on')
    v=re.verify_action(a.id,o.id,expected_effect='on',actual_effect='on')
    assert v.metadata['verified'] is True
