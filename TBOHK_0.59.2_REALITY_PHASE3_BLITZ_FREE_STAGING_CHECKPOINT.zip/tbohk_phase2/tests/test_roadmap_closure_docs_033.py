from pathlib import Path

def test_roadmap_closure_document_states_external_boundary():
    root=Path(__file__).resolve().parents[1]
    text=(root/'ROADMAP_CLOSURE_0.59.2.md').read_text()
    assert '814 passed' in text
    assert 'External activation status' in text
    assert 'must not fabricate external credentials' in text
    assert 'G21–G30: 10/10 PASS' in text
