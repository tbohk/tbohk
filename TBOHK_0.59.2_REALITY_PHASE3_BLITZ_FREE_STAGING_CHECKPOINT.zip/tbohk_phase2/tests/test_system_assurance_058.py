from pathlib import Path
from tbohk import TBOHK
from tbohk.system_assurance import *

ROOT=Path(__file__).resolve().parents[1]/"tbohk"

def test_constitution_is_deterministic_and_bounded():
    a=SystemConstitution().build(); b=SystemConstitution().build()
    assert a.digest==b.digest
    assert a.improvement_budget["recursion"]==3
    assert "automatic_source_mutation" in a.forbidden_automatic_actions

def test_architecture_graph_is_deterministic_and_connected():
    a=ArchitectureInspector().scan(ROOT); b=ArchitectureInspector().scan(ROOT)
    assert a.digest==b.digest
    assert len(a.nodes)>50
    assert len(a.edges)>50
    assert all(e.source!=e.target for e in a.edges)

def test_contracts_and_invariants_cover_architecture():
    arch=ArchitectureInspector().scan(ROOT)
    contracts=ContractRegistry().discover(arch, ["test_system_assurance_058.py"])
    inv=InvariantDiscovery().validate(InvariantDiscovery().discover(arch,contracts),arch)
    assert len(contracts)==len(arch.nodes)
    assert len(inv)>=len(contracts)
    assert any(x.status=="promotable" for x in inv)

def test_counterfactual_is_bounded_and_tracks_reverse_impact():
    arch=ArchitectureInspector().scan(ROOT); contracts=ContractRegistry().discover(arch,()); inv=InvariantDiscovery().validate(InvariantDiscovery().discover(arch,contracts),arch)
    sim=CounterfactualSimulator().simulate("tbohk.core",arch,contracts,inv,("test_tbohk.py","test_foundation_040.py"),max_nodes=100)
    assert sim.budget_ok and "tbohk.core" in sim.impacted
    assert sim.digest

def test_experiment_and_regression_generation_are_deterministic():
    e=ExperimentalLearningLoop().run("x","y","change","y",unexpected=("u",),tests=("t",))
    e2=ExperimentalLearningLoop().run("x","y","change","y",unexpected=("u",),tests=("t",))
    assert e.digest==e2.digest and e.conclusion=="confirmed"
    probes=RegressionGenerator().from_failures([{"case_id":"x"}], ["repair"])
    assert len(probes)==2

def test_assurance_snapshot_and_recursive_engine():
    g=TBOHK(":memory:")
    engine=SystemAssuranceEngine(g,ROOT)
    snap=engine.snapshot()
    assert snap.digest and snap.constitution.version=="C1.0-1"
    health=engine.health(snap)
    assert health["contracts"]==len(snap.contracts)
    r=RecursiveImprovementEngine().assess(snap,product_ok=True,engineering_ok=True,improvement_ok=True)
    assert r["healthy"]
    g.close()

def test_adversarial_laboratory_and_immune_composition():
    lab=AdversarialLaboratory()
    report=lab.run(lambda fault: fault in lab.FAULTS)
    assert report["all_detected"] and report["detected"]==report["total"]
    class R: passed_all=True
    immune=ImmuneSystem().run(evaluation=R(),selftest=R(),meta=R())
    assert immune["healthy"] and immune["required_actions"]==()
