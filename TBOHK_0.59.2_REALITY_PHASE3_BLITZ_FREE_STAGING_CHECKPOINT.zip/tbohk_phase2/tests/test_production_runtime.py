from tbohk.production_runtime import ProductionRuntime
from tbohk.observability import metrics
from tbohk.core import TBOHK


def test_production_readiness_and_prometheus():
    g=TBOHK(':memory:')
    rt=ProductionRuntime(g)
    report=rt.readiness()
    assert report['ok'] is True
    text=rt.metrics_prometheus()
    assert 'tbohk_requests_total' in text


def test_production_worker_executes_idempotent_queue_item():
    g=TBOHK(':memory:')
    rt=ProductionRuntime(g)
    seen=[]
    rt.register('unit', lambda payload: seen.append(payload['x']))
    item=rt.queue.enqueue('unit', {'x':7}, idempotency_key='k1')
    assert rt.queue.enqueue('unit', {'x':8}, idempotency_key='k1').id == item.id
    result=rt.run_once()
    assert result == {'leased':1,'completed':1,'failed':0}
    assert seen == [7]
