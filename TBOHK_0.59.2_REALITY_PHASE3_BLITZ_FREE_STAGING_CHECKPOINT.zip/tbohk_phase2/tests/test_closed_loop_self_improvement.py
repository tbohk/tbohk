from tbohk.repair_verification import RepairVerifier
from tbohk.fault_injection import FaultInjectionLab
from tbohk.coverage_intelligence import CoverageIntelligence

def test_repair_verification_requires_original_failure_and_regression():
    v = RepairVerifier().verify("r1", reproduce=lambda: True, apply_candidate=lambda: True, regression=lambda: True)
    assert v.accepted and not v.failures and len(v.digest) == 64

def test_repair_verification_rejects_regression_failure():
    v = RepairVerifier().verify("r1", reproduce=lambda: True, apply_candidate=lambda: True, regression=lambda: False)
    assert not v.accepted and "regression-gate-failed" in v.failures

def test_fault_lab_rejects_unknown_faults():
    lab = FaultInjectionLab()
    try:
        lab.run("execute_code", detect=lambda: True)
    except ValueError:
        pass
    else:
        raise AssertionError("unsafe fault accepted")

def test_fault_probes_are_deterministic_and_reversible():
    probes = FaultInjectionLab().probes()
    assert [p.fault_id for p in probes] == sorted(p.fault_id for p in probes)
    assert all(p.reversible for p in probes)

def test_coverage_intelligence_finds_uncovered_surface():
    gaps = CoverageIntelligence().find_gaps(["kernel", "repair", "release"], ["kernel", "release"])
    assert [(g.surface, g.severity) for g in gaps] == [("repair", "maintenance")]
