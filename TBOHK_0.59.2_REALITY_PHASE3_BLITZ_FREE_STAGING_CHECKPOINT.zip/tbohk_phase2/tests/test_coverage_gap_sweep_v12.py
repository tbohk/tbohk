import json, hashlib
from types import SimpleNamespace
import pytest


def test_impact_all_classifications_and_paths():
    from tbohk.impact import DependencyImpactAnalyzer
    class G:
        def __init__(self):
            self.nodes={
              'r':SimpleNamespace(id='r',kind='Claim',status='stale',metadata={}),
              'x':SimpleNamespace(id='x',kind='Claim',status='proposed',metadata={}),
              'y':SimpleNamespace(id='y',kind='Claim',status='contradicted',metadata={}),
              'e':SimpleNamespace(id='e',kind='Evidence',status='proposed',metadata={'origin_id':'o'}),
              'o':SimpleNamespace(id='o',kind='Origin',status='proposed',metadata={}),
              'run':SimpleNamespace(id='run',kind='AdaptiveResearchRun',status='proposed',metadata={'hypothesis_ids':['r']}),
            }
        def get(self,n): return self.nodes.get(n)
        def edges(self,n,direction='out',relation=None):
            all=[{'source_id':'r','relation':'evidence_for','target_id':'x'}, {'source_id':'x','relation':'depends_on','target_id':'y'}]
            if direction=='out': rows=[e for e in all if e['source_id']==n]
            elif direction=='in': rows=[e for e in all if e['target_id']==n]
            else: rows=[e for e in all if e['source_id']==n or e['target_id']==n]
            return [e for e in rows if relation is None or e['relation']==relation]
    a=DependencyImpactAnalyzer(G())
    assert a._allowed_for_scope('r','run')
    assert a._reachable_from('r','x')
    a._classify(G().nodes['x'],['r'],[SimpleNamespace(root_id='r')])
    G().nodes['r'].status='contradicted'
    assert a.analyze(['r']).items


def test_independence_lineage_union():
    from tbohk.independence import IndependenceAnalyzer
    class G:
        def get(self,n): return SimpleNamespace(id=n,kind='Evidence',metadata={})
        def _snapshot_for_evidence(self,n): return SimpleNamespace(metadata={'origin_id':'o','transformation_id':'t'})
        class DB:
            def execute(self,q): return []
        db=DB()
    a=IndependenceAnalyzer(G())
    # shared transformation lineage exercises the union/reason branch
    r=a.analyze_evidence(['a','b']); assert r.independent_count==1


def test_independent_validation_reality_and_checkpoint():
    from tbohk import TBOHK
    from tbohk.independent_validation import IndependentSystemValidator
    g=TBOHK()
    o=g.add_node('Observation','obs','proposed',{'external':True,'source':'s','observed_at':'2026-01-02T00:00:00+00:00','retrieved_at':'2026-01-01T00:00:00+00:00'})
    c=g.add_node('Checkpoint','cp','proposed',{})
    g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(c.id,)); g.db.commit()
    r=IndependentSystemValidator(g).run(); assert r.findings


def test_inference_ancestor_cycle_and_roles():
    from tbohk import TBOHK
    from tbohk.inference import InferenceEvaluator
    g=TBOHK(); c=g.add_node('Claim','c','supported',{}); p=g.add_node('Claim','p','supported',{})
    a=g.add_node('ReasoningActivity','a','supported',{'method':'deductive','conclusion_id':c.id,'premise_ids':[p.id]})
    g.link(a.id,'uses',p.id); g.link(p.id,'generated_by',c.id); g.link(a.id,'generated_by',p.id)
    ev=InferenceEvaluator(g); assert p.id in ev._ancestors(c.id); assert ev._cycle(a.id,c.id)
    ev.assess(a.id)


def test_investigation_state_invalid_from():
    from tbohk import TBOHK
    from tbohk.investigation_state import InvestigationStateEngine
    g=TBOHK(); run=g.add_node('AdaptiveResearchRun','run','proposed',{}); st=g.add_node('InvestigationState','s','proposed',{'run_id':run.id})
    with pytest.raises(ValueError): InvestigationStateEngine(g).delta(run.id,'other',st.id)


def test_long_horizon_evaluation_checkpoint_corruption_and_drift():
    from tbohk import TBOHK
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK(); suite=g.add_node('EvaluationSuite','s','proposed',{'manifest_sha256':'good'}); ev=g.add_node('Evaluation','e','proposed',{'suite_id':suite.id,'suite_manifest_sha256':'bad'})
    cp=g.add_node('Checkpoint','cp','proposed',{'checkpoint_sequence':1,'parent_checkpoint_id':'missing'})
    bad=g.add_node('Evaluation','bad','proposed',{}); g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(bad.id,)); g.db.commit()
    v=LongHorizonValidator(g); out=[]; v._evaluations(out); v._checkpoints(out); assert out


def test_security_depth_and_limits():
    from tbohk.security import SecurityBoundary, UntrustedInput
    s=SecurityBoundary()
    md={str(i):i for i in range(301)}; assert s.assess(UntrustedInput('x','x',md)).findings
    nested=[]; cur=nested
    for _ in range(20): cur.append([]); cur=cur[0]
    assert s.assess(UntrustedInput('x','x',{'nested':nested})).findings


def test_selfcare_checkpoint_and_backup_failure(tmp_path):
    from tbohk import TBOHK
    from tbohk.selfcare import SelfCareEngine
    g=TBOHK(); s=SelfCareEngine(g)
    # create a checkpoint row whose verification fails
    cp=g.add_node('Checkpoint','bad','proposed',{'manifest':{}})
    assert s._latest_checkpoint()
    assert s._latest_checkpoint()


def test_synthesis_potential_contradiction_and_evidence_profile():
    from tbohk import TBOHK
    from tbohk.synthesis import EvidenceSynthesizer
    g=TBOHK(); a=g.add_node('Claim','Water is red','proposed',{}); b=g.add_node('Claim','Water is not blue','proposed',{})
    e=EvidenceSynthesizer(g); c=e.compare(a.id,b.id); assert c.relationship=='potentially_contradictory'
    assert e.evidence_profile(a.id)['independent_count']==0


def test_robustness_remaining_branches():
    from tbohk import TBOHK
    from tbohk.robustness import ReasoningStressTester
    g=TBOHK(); act=g.add_node('ReasoningActivity','a','proposed',{'conclusion_id':'c','premise_ids':[]})
    c=g.add_node('Claim','c','proposed',{})
    with pytest.raises(ValueError): ReasoningStressTester(g).test(act.id,scenarios=['unknown'])
    r=ReasoningStressTester(g).test(act.id,scenarios=['fail_assumption','activate_defeater']); assert r.resilience=='unaffected_by_recorded_stressors'


def test_trust_invalid_envelope():
    from tbohk.trust import ReleaseSigner, SignatureEnvelope
    s=ReleaseSigner(b'k','k'); env=SignatureEnvelope('wrong','k','d','s'); assert not s.verify({},env)
