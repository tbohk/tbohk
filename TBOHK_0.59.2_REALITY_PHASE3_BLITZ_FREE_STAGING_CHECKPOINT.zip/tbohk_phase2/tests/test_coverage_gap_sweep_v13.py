import gc
import json
import pytest
from types import SimpleNamespace


def test_api_from_state_branch(monkeypatch):
    import tbohk.api as api
    from tbohk.investigation_state import InvestigationStateDelta
    class E:
        def history(self,r): return [{'id':'s'}]
        def delta(self,*a): return InvestigationStateDelta('r','from','s',1,2,(),{}, {},(),(),False)
    monkeypatch.setattr(api,'InvestigationStateEngine',lambda g:E())
    monkeypatch.setattr(api,'g',SimpleNamespace(get=lambda x:SimpleNamespace(metadata={})))
    assert api.investigation_delta('r',from_state_id='from')


def test_benchmark_specific_cases(monkeypatch):
    import tbohk.benchmark as b
    class G:
        def set_status(self,*a,**k): pass
        def get(self,n): return SimpleNamespace(metadata={'structured':{}})
    src1=SimpleNamespace(id='s1'); src2=SimpleNamespace(id='s2'); e1=SimpleNamespace(id='e1'); e2=SimpleNamespace(id='e2')
    monkeypatch.setattr(b,'_base',lambda shared=False:(G(),{'results':[(src1,e1),(src2,e2)]}))
    class EE:
        def __init__(self,g): pass
        def propose_claim(self,*a,**k): return SimpleNamespace(id='c',metadata={'structured':{}})
        def verify_claim(self,*a,**k): return None
    class RR:
        def __init__(self,g): pass
        def add_rule(self,*a,**k): return SimpleNamespace(id='r')
        def derive(self,*a,**k): return SimpleNamespace(conclusion_id='c')
    monkeypatch.setattr(b,'EpistemicEngine',EE); monkeypatch.setattr(b,'ReasoningEngine',RR)
    assert b._case('G47-007')[0] is False
    assert b._case('G47-011')[0] is False


def test_conflict_scope_and_insufficient():
    from tbohk import TBOHK
    from tbohk.conflict_analysis import ConflictAnalyzer
    g=TBOHK(); c1=g.add_node('Claim','a','proposed',{'structured':{'scope':'one'}}); c2=g.add_node('Claim','b','proposed',{'structured':{'scope':'two'}})
    cs=g.add_node('ConflictSet','cs','proposed',{})
    g.link(cs.id,'contains',c1.id); g.link(cs.id,'contains',c2.id)
    assert ConflictAnalyzer(g).assess(cs.id).verdict=='scope_separated'
    cs2=g.add_node('ConflictSet','empty','proposed',{})
    with pytest.raises(ValueError): ConflictAnalyzer(g).assess(cs2.id)


def test_core_rebuild_ledger_branch():
    from tbohk import TBOHK
    g=TBOHK(); g._event('x','none',{})
    # remove the newest chain row so rebuild must encounter an existing start marker
    row=g.db.execute("SELECT id FROM events ORDER BY rowid LIMIT 1").fetchone();
    g.db.execute("DELETE FROM ledger_chain WHERE table_name='events' AND row_id=?",(row[0],)); g.db.commit(); g._rebuild_missing_ledger_entries()


def test_explanation_missing_node_inside_trace():
    from tbohk import TBOHK
    from tbohk.explanation import ExplanationReconstructor
    g=TBOHK(); n=g.add_node('Claim','c','proposed',{'derived':True})
    m=g.add_node('Claim','m','proposed',{})
    g.link(n.id,'derived_from',m.id)
    x=ExplanationReconstructor(g); old=x._node; x._node=lambda nid: None if nid==m.id else old(nid)
    t=x.trace(n.id); assert any('missing node' in z for z in t.missing_links)


def test_gate_key_collision_and_service_search_html():
    from tbohk import TBOHK
    from tbohk.gates_21_30 import G23KeyLifecycleAuditor
    g=TBOHK(); g.add_node('Checkpoint','c','proposed',{'release_signature':{'key_id':'k'}}); g.add_node('Checkpoint','d','proposed',{'release_signature':{'key_id':'k'}}); G23KeyLifecycleAuditor(g).audit()
    from tbohk.service import DirectURLProvider
    import tbohk.service as svc
    class Resp:
        headers={'content-type':'text/html'}
        def read(self,n): return b'<html><title>T</title><body>X</body></html>'
        def __enter__(self): return self
        def __exit__(self,*a): pass
    class Op:
        def open(self,*a,**k): return Resp()
    p=DirectURLProvider(['https://example.com']); old_safe=svc.DirectURLProvider._safe_host; svc.DirectURLProvider._safe_host=lambda self,h:None; p._opener=lambda:Op();
    try: assert p.search('q')[0].title=='T'
    finally: svc.DirectURLProvider._safe_host=staticmethod(old_safe)


def test_long_horizon_more_corruption(monkeypatch):
    from tbohk import TBOHK
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK(); cp=g.add_node('Checkpoint','cp','proposed',{'checkpoint_sequence':1,'parent_checkpoint_id':'p'})
    p=g.add_node('Checkpoint','p','proposed',{'checkpoint_sequence':2})
    v=LongHorizonValidator(g); out=[]; v._checkpoints(out); assert out
    snaps=[SimpleNamespace(node_hash='a',edge_hash='a',event_hash='a',revision_hash='a'),SimpleNamespace(node_hash='b',edge_hash='a',event_hash='a',revision_hash='a')]
    monkeypatch.setattr(v,'snapshot',lambda: snaps.pop(0) if snaps else SimpleNamespace(node_hash='b',edge_hash='a',event_hash='a',revision_hash='a'))
    assert v.run(cycles=1).findings


def test_reevaluation_defensive_paths():
    from tbohk import TBOHK
    from tbohk.reevaluation import ReEvaluationController, ReEvaluationWorkflow
    g=TBOHK(); q=g.add_node('ReEvaluationQueue','q','proposed',{'fingerprint':'f','root_ids':[]})
    bad=g.add_node('ReEvaluationQueue','bad','proposed',{})
    g.db.execute("UPDATE nodes SET metadata='{' WHERE id=?",(bad.id,)); g.db.commit()
    r=ReEvaluationController(g); r._existing('f')
    item=g.add_node('ReEvaluationItem','i','proposed',{'target_id':'missing','impact':'affected'})
    w=ReEvaluationWorkflow(g)
    with pytest.raises(KeyError): w.policy(item.id)
    target=g.add_node('Claim','c','supported',{}); item2=g.add_node('ReEvaluationItem','i2','proposed',{'target_id':target.id,'impact':'affected'})
    with pytest.raises(ValueError): w.submit(item2.id,assessor_id='a',outcome='supports',rationale='')
    with pytest.raises(ValueError): w.submit(item2.id,assessor_id='a',outcome='supports',observation_ids=[target.id],rationale='ok')


def test_release_aggregator_and_security_size():
    from tbohk import TBOHK
    import tbohk.release as rel
    g=TBOHK(); a=rel.ReleaseAuditor(g)
    # force selected aggregators to emit findings without running the whole stack differently
    monkey=None
    assert not a.audit(checkpoint_id='missing').passed
    from tbohk.security import SecurityBoundary,UntrustedInput
    assert SecurityBoundary().assess(UntrustedInput('x','x',{'blob':'x'*70000})).findings
    g.close()
    gc.collect()


def test_synthesis_independence_profile(monkeypatch):
    from tbohk import TBOHK
    from tbohk.synthesis import EvidenceSynthesizer
    g=TBOHK(); c=g.add_node('Claim','c','proposed',{}); e=g.add_node('Evidence','e','proposed',{})
    g.link(e.id,'evidence_for',c.id)
    s=EvidenceSynthesizer(g); assert s.evidence_profile(c.id)['evidence_ids']==[e.id]
