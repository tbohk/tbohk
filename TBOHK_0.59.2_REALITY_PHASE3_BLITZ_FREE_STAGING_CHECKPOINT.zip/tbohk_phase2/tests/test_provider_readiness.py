from tbohk.provider_readiness import readiness, check_provider

def test_provider_readiness_reports_missing_without_secrets():
    r=readiness({})
    assert set(r)=={'stripe','apple','google'}
    assert all(v['configured'] is False for v in r.values())
    assert 'STRIPE_SECRET_KEY' in r['stripe']['missing']
    assert 'APPLE_ISSUER_ID' in r['apple']['missing']
    assert 'GOOGLE_PLAY_PACKAGE_NAME' in r['google']['missing']

def test_provider_readiness_requires_all_fields():
    env={k:'x' for k in (
        'STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET','STRIPE_PRICE_PRO','STRIPE_PRICE_UNLIMITED',
        'APPLE_ISSUER_ID','APPLE_KEY_ID','APPLE_PRIVATE_KEY_PEM','APPLE_ROOT_CA_PEM','APPLE_BUNDLE_ID','APPLE_PRODUCT_PRO','APPLE_PRODUCT_UNLIMITED',
        'GOOGLE_PLAY_PACKAGE_NAME','GOOGLE_SERVICE_ACCOUNT_EMAIL','GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM','GOOGLE_PRODUCT_PRO','GOOGLE_PRODUCT_UNLIMITED','GOOGLE_RTDN_AUDIENCE')}
    r=readiness(env)
    assert all(v['configured'] for v in r.values())

def test_provider_readiness_rejects_unknown_provider():
    try: check_provider('paypal', {})
    except ValueError as e: assert 'unsupported' in str(e)
    else: raise AssertionError('unknown provider accepted')
