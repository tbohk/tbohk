from tbohk.meta_evaluation import MetaEvaluationEngine
from tbohk.selftest import SelfTestEngine


def test_meta_evaluation_is_green():
    report = MetaEvaluationEngine().run()
    assert report.passed_all
    assert report.total >= 5
    assert report.digest


def test_selftest_digest_ignores_timing_noise():
    a = SelfTestEngine(); a.register("x", "integrity", lambda: True)
    b = SelfTestEngine(); b.register("x", "integrity", lambda: True)
    assert a.run().run_digest == b.run().run_digest
