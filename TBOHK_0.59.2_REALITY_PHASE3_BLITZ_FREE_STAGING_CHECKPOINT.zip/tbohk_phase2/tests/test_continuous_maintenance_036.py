from tbohk import TBOHK
from tbohk.continuous_maintenance import *

def test_maintenance_turns_failures_and_gaps_into_bounded_tasks():
    g=TBOHK(); c=g.add_node('Claim','A fact','verified',{})
    plan=ContinuousMaintenanceEngine(g).plan()
    assert any(t.kind=='evidence_gap' and t.target_id==c.id for t in plan.tasks)
    assert plan.authority_boundary.startswith('bounded')

def test_evidence_precision_preserves_exact_span_and_does_not_change_truth():
    g=TBOHK(); e=g.add_node('Evidence','Source text','supported',{}); before=e.status
    span=EvidencePrecision(g).add_span(e.id,'page=4','exact source sentence',start_offset=2,end_offset=23)
    assert span.quote=='exact source sentence'; assert g.get(e.id).status==before
    assert EvidencePrecision(g).spans(e.id)[0].locator=='page=4'

def test_source_independence_exposes_families():
    g=TBOHK(); a=g.add_node('Evidence','a','supported',{'origin_id':'o1','source_family':'wire'}); b=g.add_node('Evidence','b','supported',{'origin_id':'o2','source_family':'wire'}); c=g.add_node('Evidence','c','supported',{'origin_id':'o3','source_family':'primary'})
    r=SourceIndependence(g).analyze([a.id,b.id,c.id]); assert set(r['source_families'])=={'wire','primary'}

def test_unknown_is_not_false():
    g=TBOHK(); u=NegativeKnowledge(g).record('Is X true?',scope='2026',basis='no independent evidence')
    assert g.get(u.unknown_id).metadata['truth_boundary'].startswith('unknown is not false')

def test_temporal_validity_is_explicit():
    g=TBOHK(); n=g.add_node('Claim','timed','verified',{'valid_from':'2026-01-01T00:00:00+00:00','valid_until':'2026-12-31T23:59:59+00:00'})
    r=TemporalValidity(g).assess(n.id,as_of='2026-09-27T00:00:00+00:00'); assert r.valid is True

def test_verification_policy_requires_independence_and_spans():
    g=TBOHK(); c=g.add_node('Claim','fact','proposed',{}); e=g.add_node('Evidence','source','supported',{'origin_id':'o1'}); g.link(e.id,'evidence_for',c.id)
    r=VerificationPolicyEngine(g).assess(c.id,required_evidence=1,minimum_independent=2,require_spans=True)
    assert not r.ready and 'insufficient_independence' in r.blockers and 'missing_evidence_spans' in r.blockers

def test_audit_digest_changes_when_ledger_changes():
    g=TBOHK(); ca=CryptographicAudit(g); before=ca.digest(); g.add_node('Claim','x','proposed',{}); after=ca.digest(); assert before.digest != after.digest; assert ca.verify(after.digest)


def test_maintenance_internal_recheck_executes_without_truth_mutation():
    g=TBOHK(); c=g.add_node('Claim','fact','verified',{}); plan=ContinuousMaintenanceEngine(g).plan(); task=next(t for t in plan.tasks if t.kind=='evidence_gap')
    assert g.get(c.id).status=='verified'
    result=ContinuousMaintenanceEngine(g).execute(task.task_id)
    assert result['state']=='queued_for_review' and result['truth_status_changed'] is False

def test_decision_action_bridge_links_but_does_not_authorize():
    g=TBOHK(); d=g.add_node('Decision','choose a path','proposed',{}); a=DecisionActionBridge(g).propose(d.id,'do thing','target','expected effect',rollback='undo thing')
    assert g.get(a.id).status=='proposed'; assert DecisionActionBridge(g).context(d.id)['actions'][0]['id']==a.id
