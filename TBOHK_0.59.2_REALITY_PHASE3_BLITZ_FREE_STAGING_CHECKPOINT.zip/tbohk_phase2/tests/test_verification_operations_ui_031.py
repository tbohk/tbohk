from pathlib import Path

def test_review_ui_exposes_verification_operations():
    html = Path('tbohk/ui.html').read_text()
    assert 'Verification operations' in html
    assert '/corpus/verification-queue?limit=25' in html
    assert '/corpus/research-tactics?claim_id=' in html
    assert '/corpus/verification-feedback' in html
    assert 'completeVerificationTask' in html

def test_verification_operations_preserve_epistemic_boundary():
    html = Path('tbohk/ui.html').read_text()
    assert 'queue ordering is structural prioritization only' in html
    assert 'they do not establish truth' in html
