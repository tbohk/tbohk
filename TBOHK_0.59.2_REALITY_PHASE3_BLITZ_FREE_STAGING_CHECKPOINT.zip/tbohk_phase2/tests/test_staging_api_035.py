from fastapi.testclient import TestClient
from tbohk.api import app


def test_staging_run_fails_closed_without_staging_sources(monkeypatch):
    monkeypatch.delenv("TBOHK_STAGING_URLS", raising=False)
    c = TestClient(app)
    r = c.post("/staging/run", json={"question":"test question"})
    assert r.status_code == 400
    assert "TBOHK_STAGING_URLS" in r.text
