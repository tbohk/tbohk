from tbohk.core import TBOHK
from tbohk.web_corpus import CorpusLearningEngine

def test_research_tactics_use_structural_gap_and_history():
    g=TBOHK(); c=g.add_node('Claim','A claim','proposed',{})
    eng=CorpusLearningEngine(g)
    out=eng.recommend_research_tactics(c.id)
    assert out['recommendations'][0]['tactic'] in {'coverage_search','independent_source'}

def test_feedback_creates_bounded_research_profile():
    g=TBOHK(); c=g.add_node('Claim','A claim','proposed',{})
    t=g.add_node('VerificationTask','A claim','proposed',{'claim_id':c.id,'recommended_tactic':'independent_source'})
    eng=CorpusLearningEngine(g)
    r=eng.record_verification_feedback(t.id,outcome='verified',evidence_pattern='independent_source')
    assert r['feedback_profile_id']
    hist=eng.research_tactic_history()
    assert hist['profiles'][0]['tactic']=='independent_source'
    assert hist['profiles'][0]['success_rate']==1.0
