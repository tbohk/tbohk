import json, pytest
from types import SimpleNamespace
from tbohk import TBOHK


def test_lifecycle_invalid_dependency_matrix():
    from tbohk.lifecycle import KnowledgeLifecycleAuditor
    g=TBOHK(); bad=g.add_node('Claim','bad','stale'); dep=g.add_node('Claim','dep','verified'); g.link(bad.id,'supports',dep.id)
    p=g.add_node('Plan','plan','verified',{'dependency_ids':[bad.id]})
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',('{bad',p.id)); g.db.commit()
    old=g.add_node('Claim','old','proposed'); new=g.add_node('Claim','new','proposed'); g.link(old.id,'supersedes',new.id)
    r=KnowledgeLifecycleAuditor(g).audit(); codes={f.code for f in r.findings}
    assert 'verified_state_after_invalid_dependency' in codes and 'invalid_supersession_direction' in codes
    g.close()


def test_contamination_metadata_and_verified_paths():
    from tbohk.contamination import ContaminationValidator
    g=TBOHK(); root=g.add_node('Claim','root','verified'); child=g.add_node('Claim','child','verified',{'dependency_ids':[root.id]});
    g.link(root.id,'supports',child.id)
    bad=g.add_node('Claim','bad','supported'); g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',('{bad',bad.id)); g.db.commit()
    r=ContaminationValidator(g).audit([root.id]); assert not r.passed and any('verified' in f.code for f in r.findings)
    assert bad.id not in ContaminationValidator(g).closure([root.id])
    g.close()


def test_long_horizon_all_persisted_corruption_detectors():
    from tbohk.long_horizon import LongHorizonValidator
    g=TBOHK(); n=g.add_node('Claim','n','supported'); g.db.execute("UPDATE nodes SET metadata=? WHERE id=?",('{\"content_sha256\":\"wrong\"}',n.id)); g.db.commit()
    g.db.execute('PRAGMA foreign_keys=OFF'); g.db.execute("INSERT INTO revisions(id,node_id,old_status,new_status,old_content,new_content,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",('rev', 'missing','a','b','x','y','r','2026')); g.db.execute('PRAGMA foreign_keys=ON')
    g.db.execute("INSERT INTO events(id,event_type,subject_id,payload,created_at) VALUES(?,?,?,?,?)",('ev','x','missing','{}','2026'))
    g.db.execute("INSERT INTO edges(source_id,relation,target_id,created_at) VALUES(?,?,?,?)",('missing','supports',n.id,'2026'))
    cp=g.add_node('Checkpoint','cp','supported',{'checkpoint_sequence':1,'parent_checkpoint_id':'missing'})
    cp2=g.add_node('Checkpoint','cp2','supported',{'checkpoint_sequence':1,'parent_checkpoint_id':cp.id})
    e=g.add_node('Evaluation','e','supported',{'suite_id':'missing','suite_manifest_sha256':'x'})
    a=g.add_node('Action','a','supported');
    g._event('action.executed',a.id,{})
    g._event('action.executed',a.id,{})
    v=LongHorizonValidator(g); out=[]; v._content_hashes(out); v._history(out); v._edges(out); v._evaluations(out); v._actions(out); v._checkpoints(out)
    codes={f.code for f in out}
    assert {'content_hash_drift','orphan_revision','orphan_event','dangling_edge','missing_checkpoint_parent','duplicate_checkpoint_sequence','evaluation_suite_missing','replay_accumulation'} <= codes
    g.close()


def test_redirect_and_direct_url_security_guards():
    from tbohk.service import _SafeRedirectHandler, DirectURLProvider
    h=_SafeRedirectHandler(lambda host: None,max_redirects=0)
    req=SimpleNamespace(full_url='https://example.com/a')
    with pytest.raises(ValueError): h.redirect_request(req,None,302,'',{},'https://example.com/b')
    h=_SafeRedirectHandler(lambda host: None)
    with pytest.raises(ValueError): h.redirect_request(req,None,302,'',{},'file:///tmp/x')
    with pytest.raises(ValueError): DirectURLProvider._safe_host(None)
    class S:
        def getaddrinfo(self,*a): return []
    import tbohk.service as sm; old=sm.socket; sm.socket=S()
    try:
        with pytest.raises(ValueError): DirectURLProvider._safe_host('x')
    finally: sm.socket=old
    with pytest.raises(ValueError): DirectURLProvider(['file:///x']).search('x')


def test_release_exception_and_attestation_paths(monkeypatch):
    from tbohk.release import ReleaseAuditor
    g=TBOHK()
    class BrokenState:
        def __init__(self,*a,**k): pass
        def audit(self): raise RuntimeError('boom')
    import tbohk.state_machine as smod
    monkeypatch.setattr(smod, 'StateTransitionEngine', BrokenState)
    r=ReleaseAuditor(g).audit(checkpoint_id='missing',trusted_public_keys={'x':'y'})
    assert not r.passed and any(f.code.startswith('STATE:') for f in r.findings)
    g.close()
