from fastapi.testclient import TestClient
from tbohk import api

def test_health_and_stats():
    c=TestClient(api.app)
    assert c.get('/health').status_code==200
    assert c.get('/stats').status_code==200

def test_node_edge_and_explanation():
    c=TestClient(api.app)
    a=c.post('/nodes',json={'kind':'Claim','content':'test claim','status':'proposed','metadata':{}})
    b=c.post('/nodes',json={'kind':'Evidence','content':'evidence','status':'supported','metadata':{}})
    assert a.status_code==200 and b.status_code==200
    assert c.post('/edges',json={'source_id':b.json()['id'],'relation':'evidence_for','target_id':a.json()['id']}).status_code==200
    assert c.get('/nodes/'+a.json()['id']).status_code==200
    assert c.get('/explain/'+a.json()['id']).status_code==200

def test_token_gate(monkeypatch):
    monkeypatch.setattr(api,'TOKEN','secret')
    c=TestClient(api.app)
    assert c.get('/stats').status_code==401
    assert c.get('/stats',headers={'Authorization':'Bearer secret'}).status_code==200
    monkeypatch.setattr(api,'TOKEN',None)


def test_release_audit_endpoint_uses_report_passed(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.core import TBOHK
    monkeypatch.setattr(api, 'g', TBOHK())
    response = TestClient(api.app).get('/release-audit')
    assert response.status_code == 200
    assert response.json()['ok'] is True
