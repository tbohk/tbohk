import json
import pytest
from tbohk.core import TBOHK
from tbohk.epistemic import EpistemicEngine
from tbohk.reasoning import ReasoningEngine
from tbohk.reevaluation import ReEvaluationController, ReEvaluationWorkflow


def test_core_disk_backend_and_closed_context(tmp_path):
    db = tmp_path / "durable.sqlite"
    with TBOHK(str(db)) as g:
        n = g.add_node("Claim", "durable", "supported")
        assert g.get(n.id).content == "durable"
        assert str(g.db.execute("PRAGMA journal_mode").fetchone()[0]).lower() == "wal"
    with pytest.raises(Exception):
        g.db.execute("SELECT 1").fetchone()
    with TBOHK(str(db)) as g2:
        assert g2.get(n.id).content == "durable"


def test_reasoning_private_semantic_guards_and_rule_shapes():
    g = TBOHK(); r = ReasoningEngine(g)
    assert r._matches(1, 1) and not r._matches(1, 2)
    rule = r.register_rule("identity", name="")
    assert rule.metadata["name"] == "identity"
    with pytest.raises(ValueError): r.add_rule("bad", "unsupported", {})
    with pytest.raises(ValueError): r._claim("missing")

    p = g.add_node("Claim", "p", "supported", {"structured": {"x": 1}})
    q = g.add_node("Claim", "q", "supported", {"structured": {"y": 2}})
    ident = r.add_rule("id", "identity", {"consequent": {"x": 1}})
    with pytest.raises(ValueError): r._derive_structured(ident, [p, q])
    with pytest.raises(ValueError): r._derive_structured(ident, [q])

    conj_plain = r.add_rule("and-plain", "conjunction", {})
    with pytest.raises(ValueError): r._derive_structured(conj_plain, [p])
    got = r._derive_structured(conj_plain, [p, q])
    assert got["conjunction"]

    conj_req = r.add_rule("and-req", "conjunction", {"consequent": {"z": 3}, "required_semantics": [{"x": 1}, {"missing": 9}]})
    with pytest.raises(ValueError): r._derive_structured(conj_req, [p, q])

    mp_explicit = r.add_rule("mp-explicit", "modus_ponens", {"antecedent": {"missing": 9}, "consequent": {"z": 3}})
    with pytest.raises(ValueError): r._derive_structured(mp_explicit, [p, q])

    mp = r.register_rule("modus_ponens")
    conditional = g.add_node("Claim", "if", "supported", {"structured": {"implication": {"antecedent": {"x": 1}, "consequent": {"z": 3}}}})
    with pytest.raises(ValueError): r._derive_structured(mp, [conditional, q])
    with pytest.raises(ValueError): r._derive_structured(mp, [p, q])


def test_reasoning_derive_rejects_structural_and_premise_integrity_errors():
    g = TBOHK(); r = ReasoningEngine(g)
    p = g.add_node("Claim", "p", "supported", {"structured": {"x": 1}})
    rule = r.add_rule("id", "identity", {"consequent": {"x": 1}})
    with pytest.raises(ValueError): r.derive(rule.id, [])
    with pytest.raises(ValueError): r.derive(rule.id, [p.id, p.id])
    with pytest.raises(ValueError): r.derive(rule.id, [p.id], structured={"x": 2})
    bad_rule = g.add_node("ReasoningRule", "bad", "supported", {"rule_type": "bogus", "schema": {}})
    with pytest.raises(ValueError): r.derive(bad_rule.id, [p.id])
    with pytest.raises(KeyError): r.derive("missing", [p.id])


def _reeval_fixture():
    g = TBOHK(); origin = g.add_node("Origin", "o", "supported")
    evidence = g.add_node("Evidence", "e", "supported", {"origin_id": origin.id})
    g.link(evidence.id, "derived_from_origin", origin.id)
    target = g.add_node("Claim", "target", "verified")
    g.link(evidence.id, "evidence_for", target.id)
    q = ReEvaluationController(g).create([evidence.id])
    return g, q.item_ids[0], evidence, target


def test_reevaluation_validation_matrix_and_static_status_paths():
    g, item, evidence, target = _reeval_fixture(); w = ReEvaluationWorkflow(g)
    with pytest.raises(ValueError): w.policy("missing")
    with pytest.raises(ValueError): w.submit(item, assessor_id="a", outcome="bogus", rationale="x")
    with pytest.raises(ValueError): w.submit(item, assessor_id="", outcome="inconclusive", rationale="x")
    with pytest.raises(ValueError): w.submit("missing", assessor_id="a", outcome="inconclusive", rationale="x")
    with pytest.raises(ValueError): w.submit(item, assessor_id="a", outcome="supports", rationale="")
    with pytest.raises(ValueError): w.submit(item, assessor_id="a", outcome="supports")
    with pytest.raises(KeyError): w.submit(item, assessor_id="a", outcome="supports", evidence_ids=["missing"], rationale="x")
    observation = g.add_node("Observation", "obs", "supported")
    with pytest.raises(ValueError): w.submit(item, assessor_id="a", outcome="supports", observation_ids=[evidence.id], rationale="x")
    with pytest.raises(ValueError): w.submit(item, assessor_id="a", outcome="supports", observation_ids=[target.id], rationale="x")
    with pytest.raises(ValueError): w.propose_transition(item)  # no independent assessment
    assert w._proposed_status("verified", "contradicts") == "contradicted"
    assert w._proposed_status("rejected", "supports") is None
    assert w._proposed_status("verified", "inconclusive") is None


def test_reevaluation_policy_covers_critical_and_observation_requirements():
    g, item, evidence, target = _reeval_fixture()
    obs = g.add_node("Observation", "obs", "supported")
    g.link(obs.id, "observes", target.id)
    meta = dict(g.get(item).metadata)
    meta["impact"] = "disproven"
    g.db.execute("UPDATE nodes SET metadata=? WHERE id=?", (json.dumps(meta, sort_keys=True), item)); g.db.commit()
    p = ReEvaluationWorkflow(g).policy(item)
    assert p.minimum_independent_assessments == 2
    assert evidence.id in p.required_evidence

    hyp = g.add_node("Hypothesis", "h", "proposed")
    g.link(obs.id, "observes", hyp.id)
    oi_node = g.add_node("ReEvaluationItem", "review hyp", "proposed", {"target_id": hyp.id, "current_status": hyp.status, "impact": "affected"})
    po = ReEvaluationWorkflow(g).policy(oi_node.id)
    assert obs.id in po.required_observations
