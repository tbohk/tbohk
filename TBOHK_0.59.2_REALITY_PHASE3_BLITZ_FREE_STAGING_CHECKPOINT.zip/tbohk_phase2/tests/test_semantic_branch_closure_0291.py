import pytest
from tbohk.core import TBOHK
from tbohk.epistemic import EpistemicEngine, VerificationPolicy


def evidence(g, locator="https://example.test/evidence"):
    return g.add_node("Evidence", "e", "supported", {"locator": locator, "origin": "o"})


def claim(g):
    return EpistemicEngine(g).propose_claim("c", [])


def test_propose_claim_rejects_unknown_policy_and_modality():
    g=TBOHK()
    e=EpistemicEngine(g, policies={})
    with pytest.raises(KeyError): e.propose_claim("c", [], policy_id="missing")
    e=EpistemicEngine(g)
    with pytest.raises(ValueError): e.propose_claim("c", [], modality="bogus")


def test_propose_claim_validates_uncertainty_shape_and_bounds():
    g=TBOHK(); e=EpistemicEngine(g)
    cases=[
        ("bad type", "x"),
        ("unknown key", {"bogus": 1}),
        ("confidence low", {"confidence_level": -0.01}),
        ("confidence high", {"confidence_level": 1.01}),
        ("reversed interval", {"lower": 2, "upper": 1}),
    ]
    for _, value in cases:
        with pytest.raises(ValueError): e.propose_claim("c", [], uncertainty=value)


def test_propose_claim_rejects_non_evidence_ids():
    g=TBOHK(); e=EpistemicEngine(g)
    n=g.add_node("Claim", "not evidence", "proposed", {})
    with pytest.raises(ValueError): e.propose_claim("c", [n.id])


def test_verify_claim_policy_and_evidence_guards():
    g=TBOHK(); e=EpistemicEngine(g)
    with pytest.raises(KeyError): e.verify_claim("missing")
    c=e.propose_claim("c", [])
    with pytest.raises(ValueError): e.verify_claim(c.id)
    ev=evidence(g)
    c=e.propose_claim("c2", [ev.id])
    with pytest.raises(ValueError): e.verify_claim(c.id)
    c2=e.propose_claim("c3", [ev.id], policy_id="default")
    e2=EpistemicEngine(g, policies={"locked":VerificationPolicy("locked", allow_automatic=False)})
    c3=e2.propose_claim("c4", [ev.id], policy_id="locked")
    with pytest.raises(PermissionError): e2.verify_claim(c3.id)
    with pytest.raises(KeyError): e.verify_claim(c2.id, policy_id="missing")


def test_contradiction_and_resolution_validation():
    g=TBOHK(); e=EpistemicEngine(g)
    a=e.propose_claim("a", []); b=e.propose_claim("b", [])
    with pytest.raises(ValueError): e.contradict(a.id, a.id)
    with pytest.raises(ValueError): e.contradict(a.id, "missing")
    conflict=e.contradict(a.id,b.id)
    for bad in ["bogus"]:
        with pytest.raises(ValueError): e.resolve_conflict(conflict.id,bad)
    with pytest.raises(KeyError): e.resolve_conflict("missing","defer")
    with pytest.raises(ValueError): e.resolve_conflict(conflict.id,"accept_claim",claim_id="missing")
    with pytest.raises(ValueError): e.resolve_conflict(conflict.id,"scope_split")
    # All disposition paths are intentional and must remain explicit.
    for disposition in ["defer", "scope_split", "accept_claim", "reject_claim", "supersede"]:
        aa=e.propose_claim(f"a-{disposition}", [])
        bb=e.propose_claim(f"b-{disposition}", [])
        c=e.contradict(aa.id,bb.id)
        kwargs = {"scope":"EU"} if disposition=="scope_split" else ({"claim_id":aa.id} if disposition in {"accept_claim","supersede"} else ({"claim_id":bb.id} if disposition=="reject_claim" else {}))
        e.resolve_conflict(c.id,disposition,**kwargs)


def test_promote_knowledge_validation_and_absence_mode():
    g=TBOHK(); e=EpistemicEngine(g)
    with pytest.raises(ValueError): e.promote_knowledge("k", [], epistemic_type="bogus")
    with pytest.raises(ValueError): e.promote_knowledge("k", [], epistemic_type="absence_of_evidence")
    with pytest.raises(ValueError): e.promote_knowledge("k", ["x"], epistemic_type="absence_of_evidence", absence_scope="S")
    k=e.promote_knowledge("k", [], epistemic_type="absence_of_evidence", absence_scope="S")
    assert k.status=="supported"
    with pytest.raises(ValueError): e.promote_knowledge("k", [])
    c=e.propose_claim("c",[])
    with pytest.raises(ValueError): e.promote_knowledge("k",[c.id])
