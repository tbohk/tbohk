import json
from tbohk import TBOHK, ProvenanceEngine, ReleaseSigner, TrustAuditor, CheckpointManager


def test_g14_provenance_agent_activity_derivation():
    g = TBOHK(); p = ProvenanceEngine(g)
    agent = p.agent('research-agent', role='researcher')
    act = p.activity('retrieval', activity_type='research', agent_id=agent.id)
    src = g.add_node('SourceSnapshot', 'source', status='supported')
    ev = g.add_node('Evidence', 'evidence', status='supported')
    p.derive(ev.id, src.id, activity_id=act.id)
    report = p.audit()
    assert report.passed
    assert any(r['relation']=='attributed_to' for r in [dict(x) for x in g.db.execute("SELECT relation FROM edges WHERE source_id=?",(act.id,))])


def test_g14_activity_without_agent_fails():
    g = TBOHK(); p = ProvenanceEngine(g); p.activity('orphan', activity_type='research')
    report = p.audit(); assert not report.passed
    assert any(f.code == 'activity_missing_agent' for f in report.findings)


def test_g14_signed_release_verifies():
    g = TBOHK(); g.add_node('Claim','stable',status='supported')
    cp = CheckpointManager(g).create(code_version='g14',schema_version='1',invariant_version='g14',test_summary={'passed':1})
    signer = ReleaseSigner(b'correct horse battery staple', 'release-key-1')
    env = signer.sign(cp.manifest)
    row = g.db.execute('SELECT metadata FROM nodes WHERE id=?',(cp.checkpoint_id,)).fetchone()
    meta = json.loads(row['metadata']); meta['release_signature'] = env.__dict__
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(meta),cp.checkpoint_id)); g.db.commit()
    assert TrustAuditor(g).verify_checkpoint(cp.checkpoint_id, signer).passed


def test_g14_signature_detects_manifest_tamper():
    g = TBOHK(); g.add_node('Claim','stable',status='supported')
    cp = CheckpointManager(g).create(code_version='g14',schema_version='1',invariant_version='g14',test_summary={'passed':1})
    signer = ReleaseSigner(b'correct horse battery staple', 'release-key-1')
    env = signer.sign(cp.manifest)
    row = g.db.execute('SELECT metadata FROM nodes WHERE id=?',(cp.checkpoint_id,)).fetchone()
    meta = json.loads(row['metadata']); meta['release_signature'] = env.__dict__; meta['manifest']['code_version']='tampered'
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(meta),cp.checkpoint_id)); g.db.commit()
    assert not TrustAuditor(g).verify_checkpoint(cp.checkpoint_id, signer).passed


def test_g14_wrong_key_fails():
    g = TBOHK(); g.add_node('Claim','stable',status='supported')
    cp = CheckpointManager(g).create(code_version='g14',schema_version='1',invariant_version='g14',test_summary={'passed':1})
    signer = ReleaseSigner(b'key-a', 'release-key-1'); env = signer.sign(cp.manifest)
    row = g.db.execute('SELECT metadata FROM nodes WHERE id=?',(cp.checkpoint_id,)).fetchone()
    meta=json.loads(row['metadata']); meta['release_signature']=env.__dict__
    g.db.execute('UPDATE nodes SET metadata=? WHERE id=?',(json.dumps(meta),cp.checkpoint_id)); g.db.commit()
    assert not TrustAuditor(g).verify_checkpoint(cp.checkpoint_id, ReleaseSigner(b'key-b','release-key-1')).passed

def test_g14_signed_checkpoint_and_release_audit():
    from tbohk import ReleaseAuditor
    g = TBOHK(); g.add_node('Claim','stable',status='supported')
    signer = ReleaseSigner(b'release-secret', 'release-key-2')
    cp = CheckpointManager(g).create(code_version='g14', schema_version='1', invariant_version='g14', test_summary={'passed':1}, signer=signer)
    report = ReleaseAuditor(g).audit(checkpoint_id=cp.checkpoint_id, signer=signer)
    assert report.passed
