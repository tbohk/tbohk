from tbohk.core import TBOHK
from tbohk.personal_graph import PersonalKnowledgeGraph

def test_entity_create_resolve_and_reuse():
    g=TBOHK(':memory:'); p=PersonalKnowledgeGraph(g)
    a=p.create_or_get('Open River', aliases=['open river project'], identifiers={'registry':'R-1'})
    b=p.create_or_get('open river project')
    assert a['created'] is True and b['created'] is False
    assert b['entity'].id==a['entity'].id
    assert p.resolve('R-1', identifiers={'registry':'R-1'})[0]['entity_id']==a['entity'].id
    assert p.resolve('anything', identifiers={'registry':'R-1'})[0]['entity_id']==a['entity'].id

def test_attach_profile_preserves_node_provenance():
    g=TBOHK(':memory:'); p=PersonalKnowledgeGraph(g)
    e=p.create_or_get('Water').get('entity'); c=g.add_node('Claim','Water freezes at 0 C','proposed',{'structured':{'subject':'water'}})
    r=p.attach(e.id,c.id)
    assert r['created'] is True
    profile=p.profile(e.id)
    assert c.id in profile['claim_ids']
    assert 'not a truth' not in profile['boundary'].lower()

def test_fuzzy_names_do_not_auto_merge():
    g=TBOHK(':memory:'); p=PersonalKnowledgeGraph(g)
    a=p.create_or_get('New York City')
    assert p.resolve('New York')==[]
    assert p.create_or_get('New York')['created'] is True
