from tbohk.core import TBOHK
from tbohk.answer import AnswerPresenter

def _graph():
    g=TBOHK(':memory:')
    s=g.add_node('Source','s',metadata={'uri':'https://example.test','publisher_id':'p','source_id':'s'})
    e1=g.add_node('Evidence','e1',metadata={'uri':'https://example.test/a','source_id':'s','publisher':'p'})
    e2=g.add_node('Evidence','e2',metadata={'uri':'https://example.test/b','source_id':'s','publisher':'p'})
    c1=g.add_node('Claim','Alpha is true',status='verified')
    c2=g.add_node('Claim','Beta is true',status='verified')
    g.link(e1.id,'evidence_for',c1.id); g.link(e2.id,'evidence_for',c2.id)
    return g,c1,c2

def test_dependency_profile_reports_short_chain_and_single_source():
    g,c1,c2=_graph()
    premise=g.add_node('Claim','Premise is true',status='verified')
    g.link(c1.id,'derived_from',premise.id)
    p=AnswerPresenter(g)._dependency_profile(c1.id, AnswerPresenter(g)._evidence(c1.id))
    assert p['direct_dependency_count']==1
    assert p['dependency_count']==1
    assert p['single_source_support']

def test_support_impact_detects_shared_source_load():
    g,c1,c2=_graph(); a=AnswerPresenter(g)
    items=[]
    for c in (c1,c2):
        ev=a._evidence(c.id); items.append({'claim_id':c.id,'evidence':ev,'dependency_profile':a._dependency_profile(c.id,ev)})
    impact=a._support_impact(items)
    assert impact['source_count']==1
    assert impact['max_claim_load']==2
    assert impact['concentration_ratio']==1.0
