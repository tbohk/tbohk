from tbohk.core import TBOHK
from tbohk.knowledge_compiler import KnowledgeCompiler
from tbohk.scheduler import Scheduler
from tbohk.model_gateway import ModelGateway
from tbohk.memory_hierarchy import MemoryHierarchy
from tbohk.tenant_boundary import TenantBoundary

def g(): return TBOHK(':memory:')
def test_compiler():
 r=KnowledgeCompiler(g()).compile([{'content':'obs','subject':'A','predicate':'is','object':'B'}],unknowns=[{'scope':'C','basis':'none'}]); assert len(r.claim_ids)==1 and len(r.unknown_ids)==1
def test_scheduler():
 graph=g(); s=Scheduler(graph); a=s.schedule('recheck',dedupe_key='x'); b=s.schedule('recheck',dedupe_key='x'); assert a.id==b.id
def test_gateway():
 m=ModelGateway(); m.register('test',lambda req:{'ok':req.operation}); assert m.invoke('test','x',{}).output['ok']=='x'
def test_memory():
 m=MemoryHierarchy(); m.put('a',1,tier='session'); assert m.get('a')==1; m.forget('a'); assert m.get('a') is None
def test_tenant():
 md=TenantBoundary('one').stamp({}); assert TenantBoundary('one').owns(md)
