"""Test isolation: never bind the test suite to a developer/user SQLite database."""
import os
import pytest
import tempfile
from pathlib import Path

_TEST_DB_DIR = Path(tempfile.mkdtemp(prefix="tbohk-pytest-"))
os.environ.setdefault("TBOHK_DB", str(_TEST_DB_DIR / "tbohk.sqlite"))
