from datetime import datetime, timezone
import sqlite3
import json
import pytest
from tbohk import TBOHK, QuestionWorkspace, SelfRepairController, AssurancePipeline
from tbohk.research import SourceDocument, MockProvider, ResearchChain

NOW=datetime.now(timezone.utc).isoformat()

def build():
    g=TBOHK()
    docs=[SourceDocument('s1','S1','https://example/s1','Water freezes at 0 C.','p1',NOW,'o1',NOW),
          SourceDocument('s2','S2','https://example/s2','Water freezes at 0 C.','p2',NOW,'o2',NOW)]
    out=ResearchChain(g,[MockProvider('p1',[docs[0]]),MockProvider('p2',[docs[1]])]).run('freezes')
    return g,out

def test_workspace_records_uncertainty_and_next_actions():
    g,out=build()
    from tbohk.epistemic import EpistemicEngine
    claim=EpistemicEngine(g).propose_claim('Water freezes at 0 C.',[x[1].id for x in out['results']])
    ws=QuestionWorkspace(g).open('Why does water freeze at 0 C?')
    assert ws.workspace_id.startswith('knowledgeworkspace_')
    assert claim.id in ws.assessment.claim_ids
    assert ws.next_actions
    assert g.audit()['ok']

def test_workspace_rejects_empty_question():
    with pytest.raises(ValueError): QuestionWorkspace(TBOHK()).open('   ')

def test_repair_proposal_is_bounded_and_validatable():
    g=TBOHK(); node=g.add_node('Claim','x','supported',{})
    ctl=SelfRepairController(g)
    c=ctl.propose(node.id,'recompute evidence',expected_effect='refresh evidence',risk='low')
    r=ctl.validate(c,checks={'invariant':lambda: True})
    assert r.passed
    assert g.get(c.repair_id).status=='supported'

def test_repair_rejects_invalid_risk_and_unknown_target():
    ctl=SelfRepairController(TBOHK())
    with pytest.raises(KeyError): ctl.propose('missing','x',expected_effect='y')
    g=TBOHK(); n=g.add_node('Claim','x')
    with pytest.raises(ValueError): ctl=SelfRepairController(g); ctl.propose(n.id,'x',expected_effect='y',risk='unsafe')

def test_assurance_pipeline_produces_content_addressed_snapshot():
    g=TBOHK()
    snap=AssurancePipeline(g).run()
    assert snap.core_audit and snap.independent_validation and snap.deep_assurance and snap.selfcare and snap.release_audit
    assert len(snap.manifest_sha256)==64

def test_workspace_api_and_assurance_api():
    import tbohk.api as api
    from fastapi.testclient import TestClient
    client=TestClient(api.app)
    r=client.post('/workspace',json={'question':'What is known about gravity?'})
    assert r.status_code==200 and r.json()['question']=='What is known about gravity?'
    r=client.post('/assurance/pipeline')
    assert r.status_code==200 and len(r.json()['manifest_sha256'])==64

def test_repair_api_requires_existing_target():
    import tbohk.api as api
    from fastapi.testclient import TestClient
    client=TestClient(api.app)
    r=client.post('/repairs',json={'target_id':'missing','description':'x','expected_effect':'y'})
    assert r.status_code==400


def test_tbohk_context_manager_closes_connection():
    with TBOHK() as g:
        node = g.add_node("Claim", "context-managed")
        assert g.get(node.id) is not None
    assert g._closed is True
    with pytest.raises((sqlite3.ProgrammingError,)):  # closed sqlite connection
        g.db.execute("SELECT 1")
