from tbohk import *
import hashlib, json


def make_graph():
    g=TBOHK()
    a=g.add_node('Claim','clean root','verified')
    b=g.add_node('Knowledge','derived clean','verified',{'dependency_ids':[a.id]})
    g.link(b.id,'based_on',a.id)
    cp=CheckpointManager(g).create(code_version='g20',schema_version='1',invariant_version='g20',test_summary={'passed':1})
    return g,a,b,cp


def test_clean_snapshot_plans_and_reconstitutes_into_empty_graph():
    g,a,b,cp=make_graph(); e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id); plan=e.plan(snap)
    assert not plan.findings and a.id in plan.included_nodes and b.id in plan.included_nodes
    target=TBOHK(); r=e.apply(plan,snap,target_graph=target,validation_id='v1')
    assert r.passed and target.get(a.id).content=='clean root' and target.get(b.id).status=='verified'


def test_tampered_snapshot_content_is_blocked():
    g,_,_,cp=make_graph(); e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id)
    nodes=list(snap.nodes); n=dict(nodes[0]); n['content']='tampered'; nodes[0]=n
    bad=RecoverySnapshot(snap.checkpoint_id,snap.source_digest,tuple(nodes),snap.edges,snap.exported_at)
    plan=e.plan(bad); assert any(f.code=='node_content_hash_mismatch' for f in plan.findings)


def test_contaminated_root_is_excluded_and_clean_remainder_can_restore():
    g,a,b,_=make_graph(); root=g.add_node('ContaminationRoot','bad source','supported')
    contaminated=g.add_node('Claim','tainted','verified',{'dependency_ids':[root.id]}); g.link(contaminated.id,'based_on',root.id)
    cp=CheckpointManager(g).create(code_version='g20',schema_version='1',invariant_version='g20',test_summary={'passed':1})
    e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id)
    plan=e.plan(snap,contamination_roots=(root.id,))
    assert root.id not in plan.included_nodes and contaminated.id not in plan.included_nodes
    assert not any(f.code=='contamination_quarantine_hole' for f in plan.findings)


def test_declared_dependency_exclusion_blocks_reconstitution():
    g,a,b,cp=make_graph(); e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id)
    plan=e.plan(snap,exclude_ids=(a.id,))
    assert any(f.code=='recovered_node_has_missing_dependency' for f in plan.findings)


def test_reconstitution_is_atomic_and_requires_empty_target():
    g,_,_,cp=make_graph(); e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id); plan=e.plan(snap)
    target=TBOHK(); target.add_node('Claim','existing')
    try: e.apply(plan,snap,target_graph=target)
    except PermissionError: pass
    else: assert False


def test_source_digest_changes_when_snapshot_changes():
    g,_,_,cp=make_graph(); e=ReconstitutionEngine(g); snap=e.export_snapshot(cp.checkpoint_id)
    nodes=list(snap.nodes); n=dict(nodes[0]); n['metadata']=json.dumps({**json.loads(n['metadata']),'x':'changed'},sort_keys=True); nodes[0]=n
    altered=RecoverySnapshot(snap.checkpoint_id,e._digest(nodes,list(snap.edges)),tuple(nodes),snap.edges,snap.exported_at)
    assert altered.source_digest != snap.source_digest
