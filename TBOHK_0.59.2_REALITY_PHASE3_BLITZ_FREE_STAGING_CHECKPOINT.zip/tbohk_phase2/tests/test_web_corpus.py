import json
from tbohk.core import TBOHK
from tbohk.web_corpus import CommonCrawlProvider, CorpusLearningEngine, StaticDocumentsProvider
from tbohk.research import SourceDocument


def test_common_crawl_rejects_unbounded_configuration():
    import pytest
    with pytest.raises(ValueError): CommonCrawlProvider(max_results=101)
    with pytest.raises(ValueError): CommonCrawlProvider(max_bytes=10_000_000)


def test_corpus_learning_keeps_observations_unverified(monkeypatch):
    g=TBOHK()
    doc=SourceDocument('cc:test','Example','https://example.org/a','Observed text about water',
                       'common-crawl','2026-09-27T00:00:00+00:00','example.org')
    monkeypatch.setattr(CommonCrawlProvider,'search',lambda self,q,cursor=None:[doc])
    out=CorpusLearningEngine(g).ingest_batch('water',max_results=1)
    assert out['batch']['imported']==1
    evidence=g.get(out['results'][0]['evidence'])
    assert evidence.kind=='Evidence'
    assert evidence.status=='supported'
    assert not g.db.execute("SELECT 1 FROM nodes WHERE kind='Knowledge' AND status='verified'").fetchone()


def test_corpus_route_exists():
    from fastapi.testclient import TestClient
    from tbohk.api import app
    r=TestClient(app).post('/corpus/ingest',json={'query':'water','max_results':1})
    assert r.status_code in {200,400}

def test_web_learning_cycle_builds_verification_queue_and_keeps_claims_proposed(monkeypatch):
    from tbohk.web_corpus import CorpusLearningEngine
    from tbohk.core import TBOHK
    from tbohk.research import SourceDocument
    g=TBOHK(':memory:')
    docs=[
        SourceDocument('s1','A','https://a.example/x','Water is important for sustaining life across ecosystems and human societies.','common-crawl','2026-01-01T00:00:00Z','a.example'),
        SourceDocument('s2','A','https://b.example/x','Water is important for sustaining life across ecosystems and human societies.','common-crawl','2026-01-01T00:00:00Z','b.example'),
    ]
    monkeypatch.setattr('tbohk.web_corpus.CommonCrawlProvider.search', lambda self,q,cursor=None: docs)
    out=CorpusLearningEngine(g).learn_batch('water', max_results=2)
    assert len(out['candidate_claim_ids']) >= 1
    assert len(out['verification_task_ids']) >= 1
    c=g.get(out['candidate_claim_ids'][0])
    assert c.status == 'proposed'
    task=g.get(out['verification_task_ids'][0])
    assert task.metadata['independent_origin_count'] >= 2
    assert task.metadata['automatic_verification'] is False


def test_web_learning_cycle_records_structured_conflict(monkeypatch):
    from tbohk.web_corpus import CorpusLearningEngine
    from tbohk.core import TBOHK
    from tbohk.research import SourceDocument
    g=TBOHK(':memory:')
    docs=[
        SourceDocument('s1','A','https://a.example/x','Mars is red in the visible spectrum today.','common-crawl','2026-01-01T00:00:00Z','a.example'),
        SourceDocument('s2','B','https://b.example/x','Mars is blue in the visible spectrum today.','common-crawl','2026-01-01T00:00:00Z','b.example'),
    ]
    monkeypatch.setattr('tbohk.web_corpus.CommonCrawlProvider.search', lambda self,q,cursor=None: docs)
    out=CorpusLearningEngine(g).learn_batch('mars', max_results=2)
    assert out['conflict_ids']
    conflict=g.get(out['conflict_ids'][0])
    assert conflict.kind == 'ConflictSet'


def test_common_crawl_real_request_path_builds_user_agent_without_version_error(monkeypatch):
    captured = {}
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self): return b'ok'
    def fake_urlopen(req, timeout):
        captured['ua'] = req.get_header('User-agent')
        captured['timeout'] = timeout
        return Response()
    import tbohk.web_corpus as wc
    monkeypatch.setattr(wc.urllib.request, 'urlopen', fake_urlopen)
    out=CommonCrawlProvider._request('https://index.commoncrawl.org/ping', timeout=3)
    assert out == b'ok'
    assert captured['ua'].startswith('TBOHK/0.59.2 corpus-learner')
    assert captured['timeout'] == 3
