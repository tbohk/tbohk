from pathlib import Path
import re

UI = Path(__file__).resolve().parents[1] / 'tbohk' / 'ui.html'
TEXT = UI.read_text()


def test_workflow_preferences_are_local_only():
    assert "tbohk_workflow_preferences" in TEXT
    assert "localStorage.setItem('tbohk_workflow_preferences'" in TEXT
    assert '/learning/' not in TEXT[TEXT.find('function getWorkflowPreferences'):TEXT.find('function renderAnswer')]


def test_smart_actions_remain_evidence_bounded():
    start = TEXT.index('function renderSmartNextActions')
    end = TEXT.index('\n\nfunction renderAnswer', start)
    block = TEXT[start:end]
    assert "if(needsReview>0)" in block
    assert "if(sourceCount===0)" in block
    assert "sourceCount<2" in block
    assert "verified>0 && needsReview===0" in block
    assert "preferredActionOrder(actions)" in block


def test_learning_cannot_create_new_action_classes():
    block = TEXT[TEXT.index('function preferredActionOrder'):TEXT.index('function renderAnswer')]
    for key in ('review', 'research', 'save', 'followup'):
        assert f"key:'{key}'" in block


def test_preference_clicks_are_explicit_and_bounded():
    start = TEXT.index('return (learned?')
    end = TEXT.index("function renderAnswer", start)
    block = TEXT[start:end]
    assert "recordWorkflowChoice('${x.key}')" in block
    assert 'slice(0,3)' in TEXT[TEXT.index('function renderSmartNextActions'):end]


def test_adaptive_plan_is_evidence_driven_and_bounded():
    assert "function evidenceGapGuidance" in TEXT
    assert "function renderAdaptivePlan" in TEXT
    block=TEXT[TEXT.index("function evidenceGapGuidance"):TEXT.index("function renderSmartNextActions")]
    assert "!sourceCount" in block
    assert "sourceCount<2" in block
    assert "needsReview>0" in block
    assert "claim status" not in block.lower() or "does not change" in TEXT


def test_ui_self_check_exists_and_runs_at_boot():
    assert "function runUiSelfCheck()" in TEXT
    assert "runUiSelfCheck();" in TEXT[TEXT.index("async function boot"):TEXT.index("async function boot")+400]
    assert "window.tbohkUiSelfCheck" in TEXT


def test_adaptive_plan_does_not_authorize_new_actions():
    block=TEXT[TEXT.index("function renderAdaptivePlan"):TEXT.index("function renderSmartNextActions")]
    assert "fetch(" not in block and "api(" not in block
    assert "recordWorkflowChoice" not in block
