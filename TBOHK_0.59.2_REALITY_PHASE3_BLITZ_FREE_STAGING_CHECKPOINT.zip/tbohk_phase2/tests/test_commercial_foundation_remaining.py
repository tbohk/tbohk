from pathlib import Path
import tempfile


def test_transactional_email_smtp_adapter(monkeypatch):
    from tbohk.email import EmailConfig, TransactionalEmail
    sent=[]
    class FakeSMTP:
        def __init__(self, host, port, timeout): sent.append((host,port,timeout))
        def __enter__(self): return self
        def __exit__(self,*args): return False
        def starttls(self): sent.append('tls')
        def login(self,u,p): sent.append(('login',u,p))
        def send_message(self,msg): sent.append((msg['To'],msg['Subject'],msg.get_content()))
    monkeypatch.setattr('tbohk.email.smtplib.SMTP', FakeSMTP)
    e=TransactionalEmail(EmailConfig(host='smtp.test',port=587,username='u',password='p',sender='no-reply@test',public_base_url='https://app.test'))
    assert e.config.configured
    assert e.verification('a@test','tok-1')
    assert e.password_reset('a@test','tok-2')
    messages=[x for x in sent if isinstance(x,tuple) and len(x)==3 and isinstance(x[2],str)]
    assert any('https://app.test/account/verify-email?token=tok-1' in x[2] for x in messages)
    assert any('https://app.test/account/password-reset?token=tok-2' in x[2] for x in messages)
    assert e._send('a@test','x','y')
    assert not TransactionalEmail(EmailConfig())._send('a@test','x','y')


def test_public_commercial_surfaces_and_email_hooks(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    old_manager, old_sender = api.account_manager, api.email_sender
    class Sender:
        class Config:
            configured=True
        config=Config()
        def __init__(self): self.verifications=[]; self.resets=[]
        def verification(self,email,token): self.verifications.append((email,token)); return True
        def password_reset(self,email,token): self.resets.append((email,token)); return True
    sender=Sender(); api.account_manager=manager; api.email_sender=sender
    try:
        c=TestClient(api.app)
        assert c.get('/legal/privacy').status_code == 200
        assert 'Privacy Policy' in c.get('/legal/privacy').text
        assert c.get('/legal/terms').status_code == 200
        assert 'Terms of Service' in c.get('/legal/terms').text
        assert c.get('/support').status_code == 200
        reg=c.post('/account/register',json={'email':'mail@test.example','password':'long-password-mail','name':'Mail'})
        assert reg.status_code == 200
        assert reg.json()['email_verification']['delivered'] is True
        assert sender.verifications and sender.verifications[0][0]=='mail@test.example'
        assert c.post('/account/password-reset/request',json={'email':'mail@test.example'}).json()=={'accepted':True}
        assert sender.resets and sender.resets[0][0]=='mail@test.example'
        assert c.post('/account/password-reset/request',json={'email':'missing@test.example'}).json()=={'accepted':True}
    finally:
        api.account_manager=old_manager; api.email_sender=old_sender; manager.close()


def test_email_delivery_failures_are_fail_safe(monkeypatch):
    from fastapi.testclient import TestClient
    from tbohk import api
    from tbohk.accounts import AccountManager
    root=Path(tempfile.mkdtemp()); manager=AccountManager(str(root/'accounts.sqlite'),str(root/'data'))
    old_manager, old_sender = api.account_manager, api.email_sender
    class Config: configured=True
    class Failing:
        config=Config()
        def verification(self,*args): raise OSError('smtp down')
        def password_reset(self,*args): raise OSError('smtp down')
    api.account_manager=manager; api.email_sender=Failing()
    try:
        c=TestClient(api.app)
        r=c.post('/account/register',json={'email':'fail@test.example','password':'long-password-fail','name':'Fail'})
        assert r.status_code==200 and r.json()['email_verification']['delivered'] is False
        assert c.post('/account/password-reset/request',json={'email':'fail@test.example'}).json()=={'accepted':True}
    finally:
        api.account_manager=old_manager; api.email_sender=old_sender; manager.close()
