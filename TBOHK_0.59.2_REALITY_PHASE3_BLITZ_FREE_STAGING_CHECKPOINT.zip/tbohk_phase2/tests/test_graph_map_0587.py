from fastapi.testclient import TestClient
from tbohk.core import TBOHK
from tbohk import api

def test_graph_map_is_bounded_deterministic_and_filtered():
    g=TBOHK(); a=g.add_node('Claim','alpha','verified',{}); b=g.add_node('Evidence','beta','supported',{}); c=g.add_node('Claim','gamma','unknown',{})
    g.link(b.id,'evidence_for',a.id); g.link(c.id,'depends_on',a.id)
    old=api.g; api.g=g
    try:
        client=TestClient(api.app)
        r=client.get(f'/graph/map/{a.id}',params={'depth':2,'max_nodes':3})
        assert r.status_code==200
        body=r.json(); assert body['root']==a.id; assert len(body['nodes'])<=3
        assert all(set(e)=={'source_id','target_id','relation'} for e in body['edges'])
        r2=client.get(f'/graph/map/{a.id}',params={'depth':2,'max_nodes':20,'kinds':'Evidence'})
        assert r2.status_code==200
        ids={n['id'] for n in r2.json()['nodes']}
        assert a.id in ids and b.id in ids and c.id not in ids
    finally: api.g=old

def test_graph_map_missing_node_is_404_and_depth_is_bounded():
    g=TBOHK(); a=g.add_node('Claim','alpha','verified',{}); old=api.g; api.g=g
    try:
        client=TestClient(api.app)
        assert client.get('/graph/map/missing').status_code==404
        body=client.get(f'/graph/map/{a.id}',params={'depth':99,'max_nodes':9999}).json()
        assert body['depth']==4 and body['limit']==200
    finally: api.g=old
