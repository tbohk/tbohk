# TBOHK 0.29.24 — Investigation Health Integration

## Purpose

0.29.24 consolidates ten previously separate knowledge-maintenance capabilities into a single bounded investigation-health diagnostic.

## Integrated capabilities

1. **Counterfactual evidence testing** — read-only downstream impact when an evidence item is treated as unavailable.
2. **Claim coverage mapping** — identifies claims with and without directly linked evidence.
3. **Evidence redundancy / independence** — uses documented origin lineage and transformation lineage rather than provider count.
4. **Temporal invalidation / quantitative disagreement** — conservative comparison of explicitly scoped claims.
5. **Contradiction propagation** — dependency impact identifies downstream objects requiring review when foundational support changes.
6. **Investigation checkpoints** — reports whether the latest cryptographic checkpoint still verifies against the current graph.
7. **Knowledge maintenance queue** — surfaces unsupported, stale/contradicted, high-blast-radius, and weak-independence items for review.
8. **Decision-oriented investigation context** — shows relevant decisions, options, and evidence dependencies without selecting an option.
9. **Dependency graph visualization** — bounded node/relationship view rendered in the answer workspace.
10. **Adversarial testing** — surfaces structural self-reference, authority escalation, expired-authority, and action-observation failures.

## Architecture

- Added `tbohk.investigation_health.InvestigationHealthAnalyzer`.
- Added `tbohk.health_history.InvestigationHealthHistory`.
- Added `GET /investigation/health`.
- Added `POST /investigation/health/snapshot` to persist an immutable diagnostic observation.
- Added `GET /investigation/health/history` to retrieve longitudinal observations for the same investigation roots.
- Each new snapshot is compared with the immediately preceding snapshot for the same roots.
- Deterministic recheck triggers are emitted for weakened coverage, reduced provenance independence, new maintenance items, new conflicts, changed evidence blast radius, checkpoint verification loss, and new adversarial findings.
- The answer workspace now records a health snapshot automatically when “Run full diagnostic” is used and displays changes, history, and active recheck triggers.
- HealthSnapshot records are excluded from release checkpoint hashes so monitoring cannot invalidate an otherwise verified knowledge checkpoint.
- Existing specialized analyzers remain the source of each diagnostic; the new layer composes them rather than duplicating their rules.
- Health snapshots and comparisons are observational; they do not change claim status, resolve conflicts, rank decisions, or authorize actions.

## Boundary

The diagnostic does not assign truth probabilities, rank decisions, resolve conflicts, change node status, or authorize actions. It reports structural conditions that warrant human inspection.

## Verification

- Python compilation: PASS
- JavaScript syntax: PASS
- Full regression: 695 passed
