# TBOHK 0.29.32 — Unified Operator Queue

## Purpose
Turn existing review, verification, and conflict signals into one bounded operator worklist without introducing a second source of truth or changing epistemic status.

## Implementation
- Added `GET /operations/queue` as a read-only orchestration endpoint.
- Aggregates verification tasks, proposed claims, and proposed conflict sets.
- Uses deterministic structural ordering only; it is explicitly not a truth/confidence score.
- Bounded to 100 records server-side and 12 displayed by default in the UI.
- Added Operator Queue panel to the Command Center.
- Added refresh and direct handoff to Review.
- Preserved explicit boundary language: the queue recommends work but never establishes truth, changes status, or authorizes actions.

## Verification
- Focused operator-queue tests: 2 passed.
- Full regression: 810 passed.
- Python compilation: PASS.
- JavaScript syntax check: PASS.
- Chromium UI acceptance: PASS — 10 views × 6 viewport widths.

## Release posture
This is a 0.29.32 UI/product refinement on the locked 0.59.2/G30 baseline. No G21–G30 assurance boundary was weakened or reopened.
