# TBOHK 0.29.8 — Knowledge Continuity UI

## User-facing changes
- Added Library to primary Workspace navigation.
- Added local-device saved investigation library with search, pinning, and watchlist filters.
- Added Save action to completed answers.
- Added Follow up action that carries the current investigation into Ask.
- Added saved answer snapshots and a What changed comparison between the two latest saved versions.
- Added explicit local-storage disclosure; server-authoritative knowledge/evidence/account data remain authoritative on the server.
- Avoided implying unattended background monitoring; Watchlist is a local tracking list until scheduled server-side monitoring is implemented.
- Responsive Library toolbar/cards for mobile widths.

## Verification
- 677 pytest tests passed.
- JavaScript syntax check passed.
- Chromium UI acceptance: 10 views x 6 viewport widths passed.
- Fresh-unzip regression is required before release acceptance.
