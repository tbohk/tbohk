# TBOHK 0.29.2 Integrated Launch Hardening

## Control plane

Learning proposes. Evaluation rejects. Canary observes. Release control authorizes. Deployment adapters execute only after an explicitly completed, health-gated release. Rollback is explicit and auditable.

## Deployment

`LocalSystemdAdapter` verifies the artifact SHA-256 before installation, uses a fixed systemd command surface, serializes deployment operations, records the previous verified release, and supports explicit rollback. The API accepts an adapter name and artifact path/hash, never an arbitrary command.

## Research integrity

Every source snapshot requires an absolute HTTP/HTTPS URI, source/provider/origin identity and non-empty text. A content-addressed fingerprint is retained with source snapshots and evidence. Duplicate snapshots within a provider are omitted. `/answer/citations/verify` checks that cited source identities exist in the knowledge graph.

## Observability

Every HTTP request receives/propagates `x-request-id`. Bounded in-memory metrics retain recent requests and expose request count, server-error counts and p50/p95/p99 latency. Tenant identity is attached when authenticated.

## Native clients

Android and iOS source baselines are included. They are thin clients: credentials and subscription authority remain server-side. Platform-specific secure storage and store purchase verification are required. The native source shells do not contain provider secrets.

## Verification

The current tree has 659 passing Python tests and 100% production statement coverage. Browser acceptance and live HTTP smoke pass. Platform-specific Android and Apple store signing/build environments remain external release gates and are not represented as falsely completed local checks.
