# TBOHK 0.58.1 UI/UX Product Release

This release turns the 0.58 system-assurance architecture into a user-facing product experience.

## Product changes
- Added a plain-language product definition: TBOHK is an evidence-first knowledge and research system, not merely an answer box.
- Added a guided “How TBOHK works” workspace covering Ask → Research → Inspect → Keep → Review.
- Added explanations for evidence, claims, review, verified, unknown, and conflict states.
- Added workspace-by-workspace guidance and direct navigation.
- Added explicit novice/advanced separation so system controls do not overwhelm normal users.
- Added visible explanations of architecture awareness, invariants, adversarial testing, and bounded self-improvement.
- Added UI access to the 0.58 system assurance, architecture, contract, and invariant endpoints.
- Added navigation tooltips and clearer advanced-system labeling.

## Verification
- Full regression suite: 780/780 passed.
- UI/system-assurance acceptance: 17/17 passed.
- Python compileall: passed.

The release preserves TBOHK’s existing evidence, provenance, uncertainty, authority, and bounded-improvement boundaries.
