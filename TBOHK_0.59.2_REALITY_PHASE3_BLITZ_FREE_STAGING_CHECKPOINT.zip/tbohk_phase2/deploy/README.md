# TBOHK 0.29.1 deployment

## Filesystem

Create a dedicated `tbohk` user/group. Install the bundle at `/opt/tbohk` owned by root and not writable by the service user. Give the service user write access only to `/var/lib/tbohk` and the backup directory.

Create `/etc/tbohk/api-token` containing a random token of at least 32 characters and set mode `0600`, owner `tbohk:tbohk`.

Create `/etc/tbohk/tbohk.env` with:

```text
TBOHK_DB=/var/lib/tbohk/tbohk.sqlite
TBOHK_HOST=127.0.0.1
TBOHK_PORT=8000
TBOHK_API_TOKEN_FILE=/etc/tbohk/api-token
TBOHK_LOG_LEVEL=info
TBOHK_ACCESS_LOG=1
```

For direct TLS, also set `TBOHK_HOST=0.0.0.0`, `TBOHK_REQUIRE_TLS=1`, `TBOHK_TLS_CERT=/etc/tbohk/tls/fullchain.pem`, and `TBOHK_TLS_KEY=/etc/tbohk/tls/privkey.pem`; keep the private key mode `0600`. Prefer a hardened reverse proxy/load balancer when the environment already provides one.

## Service

Install `deploy/tbohk.service`, then:

```bash
systemctl daemon-reload
systemctl enable --now tbohk.service
systemctl status tbohk.service
```

## Backup

Create `/etc/tbohk/backup.env`:

```text
TBOHK_DB=/var/lib/tbohk/tbohk.sqlite
TBOHK_BACKUP_PATH=/var/backups/tbohk/tbohk.sqlite
```

Install `deploy/tbohk-backup.service` and `deploy/tbohk-backup.timer`, then enable the timer. Every backup is independently checked with SQLite integrity and foreign-key checks and receives a SHA-256 digest in its output.

## Health monitoring

Install `deploy/tbohk-health.service` and `deploy/tbohk-health.timer`. Failed health checks are visible through systemd's journal and timer state. For external alerting, monitor the same `/health` endpoint from the deployment's existing monitoring system.

## Recovery drill

Before production cutover, restore the latest backup to a separate path with:

```bash
./restore_verify.sh /var/backups/tbohk/tbohk.sqlite /var/lib/tbohk/recovery-test.sqlite
```

Then run the application verifier against that restored database:

```bash
TBOHK_DB=/var/lib/tbohk/recovery-test.sqlite python verify_production.py
```

Do not point the production service at the recovery-test database until the restore has been independently inspected.
