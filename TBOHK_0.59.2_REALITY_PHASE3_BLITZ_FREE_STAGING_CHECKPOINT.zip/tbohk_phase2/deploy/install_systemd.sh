#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'run as root' >&2; exit 2; }
BUNDLE=${1:-/opt/tbohk}
PYTHON=${TBOHK_PYTHON:-/usr/bin/python3}

command -v "$PYTHON" >/dev/null 2>&1 || { echo "Python not found: $PYTHON" >&2; exit 2; }
"$PYTHON" - <<'PY'
import sys
if sys.version_info[:2] != (3, 13):
    raise SystemExit(f'requires Python 3.13, found {sys.version.split()[0]}')
PY

getent group tbohk >/dev/null 2>&1 || groupadd --system tbohk
id tbohk >/dev/null 2>&1 || useradd --system --gid tbohk --home-dir /var/lib/tbohk --shell /usr/sbin/nologin tbohk

install -d -o root -g root -m 0755 /opt/tbohk
install -d -o tbohk -g tbohk -m 0750 /var/lib/tbohk /var/lib/tbohk/accounts /var/backups/tbohk
install -d -o root -g tbohk -m 0750 /etc/tbohk
install -d -o tbohk -g tbohk -m 0750 /etc/tbohk/tls

# The application bundle is immutable to the service account.
chown -R root:root "$BUNDLE"
find "$BUNDLE" -type d -exec chmod 0555 {} +
find "$BUNDLE" -type f -exec chmod 0444 {} +
chmod 0555 "$BUNDLE/run_hardened.py" "$BUNDLE/backup_production.sh" "$BUNDLE/restore_verify.sh" "$BUNDLE/tbohk-healthcheck.sh"

# Build an isolated runtime from the exact production lock.
if [ ! -x "$BUNDLE/.venv/bin/python" ]; then
    "$PYTHON" -m venv "$BUNDLE/.venv"
fi
"$BUNDLE/.venv/bin/python" -m pip install --disable-pip-version-check --upgrade-strategy only-if-needed -r "$BUNDLE/requirements.lock"
"$BUNDLE/.venv/bin/python" -m pip check
"$BUNDLE/.venv/bin/python" "$BUNDLE/deploy/preflight.py"

# Generate a strong service secret if one does not already exist.
if [ ! -f /etc/tbohk/api-token ]; then
    umask 077
    "$BUNDLE/.venv/bin/python" - <<'PY' >/etc/tbohk/api-token
import secrets
print(secrets.token_urlsafe(48))
PY
fi
chown tbohk:tbohk /etc/tbohk/api-token
chmod 0600 /etc/tbohk/api-token

if [ ! -f /etc/tbohk/tbohk.env ]; then
    cat >/etc/tbohk/tbohk.env <<'EOF'
TBOHK_DB=/var/lib/tbohk/tbohk.sqlite
TBOHK_ACCOUNTS_DB=/var/lib/tbohk/accounts.sqlite
TBOHK_ACCOUNT_DATA_DIR=/var/lib/tbohk/accounts
TBOHK_HOST=127.0.0.1
TBOHK_PORT=8000
TBOHK_API_TOKEN_FILE=/etc/tbohk/api-token
TBOHK_LOG_LEVEL=info
TBOHK_ACCESS_LOG=1
# Set these for hosted billing; leave unset for local deployments.
# STRIPE_SECRET_KEY=
# STRIPE_WEBHOOK_SECRET=
# STRIPE_PRICE_PRO=
# STRIPE_PRICE_UNLIMITED=
EOF
fi
chown root:tbohk /etc/tbohk/tbohk.env
chmod 0640 /etc/tbohk/tbohk.env

if [ ! -f /etc/tbohk/backup.env ]; then
    cat >/etc/tbohk/backup.env <<'EOF'
TBOHK_DB=/var/lib/tbohk/tbohk.sqlite
TBOHK_ACCOUNTS_DB=/var/lib/tbohk/accounts.sqlite
TBOHK_ACCOUNT_DATA_DIR=/var/lib/tbohk/accounts
TBOHK_BACKUP_DIR=/var/backups/tbohk
TBOHK_BACKUP_RETENTION=14
EOF
fi
chown root:tbohk /etc/tbohk/backup.env
chmod 0640 /etc/tbohk/backup.env

for unit in tbohk.service tbohk-backup.service tbohk-backup.timer tbohk-health.service tbohk-health.timer; do
    install -o root -g root -m 0644 "$BUNDLE/deploy/$unit" "/etc/systemd/system/$unit"
done
systemd-analyze verify /etc/systemd/system/tbohk.service /etc/systemd/system/tbohk-backup.service /etc/systemd/system/tbohk-backup.timer /etc/systemd/system/tbohk-health.service /etc/systemd/system/tbohk-health.timer
systemctl daemon-reload

echo 'TBOHK deployment environment installed but not enabled.'
echo 'Review /etc/tbohk/tbohk.env; configure TLS/reverse proxy before public exposure; then enable tbohk.service and timers.'
