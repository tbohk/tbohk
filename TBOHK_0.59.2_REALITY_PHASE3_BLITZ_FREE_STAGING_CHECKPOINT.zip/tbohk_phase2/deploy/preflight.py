from __future__ import annotations
import importlib.metadata as md
import ipaddress, os, stat, sys
from pathlib import Path

LOCK = Path(__file__).resolve().parents[1] / 'requirements.lock'

def locked_versions():
    out={}
    for line in LOCK.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '==' not in line: continue
        name, version=line.split('==',1)
        out[name.lower().replace('-','_')]=version
    return out

def main():
    if sys.version_info[:2] != (3,13):
        raise SystemExit(f'Python 3.13 required; found {sys.version.split()[0]}')
    expected=locked_versions()
    failures=[]
    for name,want in expected.items():
        try: got=md.version(name)
        except md.PackageNotFoundError: failures.append(f'missing {name}=={want}'); continue
        if got != want: failures.append(f'{name}: expected {want}, found {got}')
    host=os.getenv('TBOHK_HOST','127.0.0.1')
    try: loopback=ipaddress.ip_address(host).is_loopback
    except ValueError: loopback=host.lower()=='localhost'
    token=os.getenv('TBOHK_API_TOKEN','')
    token_file=os.getenv('TBOHK_API_TOKEN_FILE','')
    if not loopback and len(token) < 32 and not token_file:
        failures.append('non-loopback bind requires API token or token file')
    if token_file:
        p=Path(token_file)
        if not p.is_file(): failures.append(f'missing token file: {p}')
        else:
            mode=stat.S_IMODE(p.stat().st_mode)
            if mode & 0o077: failures.append(f'insecure token file mode: {mode:04o}')
            if len(p.read_text(encoding='utf-8').strip()) < 32: failures.append('token file contains a short token')
    if failures:
        for f in failures: print(f, file=sys.stderr)
        return 1
    print('preflight=pass')
    print(f'python={sys.version.split()[0]}')
    print(f'locked_packages={len(expected)}')
    return 0
if __name__ == '__main__': raise SystemExit(main())
