# TBOHK 0.29.1 — Build the deployment target from zero

This release is designed to create its own single-machine deployment target. No pre-existing application host is required.

## Supported baseline

- Linux with systemd
- Python 3.13
- outbound package access during initial installation, or a pre-populated private package mirror/wheelhouse
- a filesystem location for `/opt`, `/var/lib`, `/var/backups`, and `/etc`

## One-command installation

After verifying the release SHA-256, unpack it and run as root:

```bash
./deploy/install_systemd.sh /opt/tbohk
```

The installer creates the dedicated `tbohk` account/group, isolated Python virtual environment, API secret, environment files, database/backup directories, systemd units, and startup preflight.

It deliberately does **not** enable the service automatically.

## Before exposure

Keep TBOHK on `127.0.0.1` and terminate HTTPS at an existing hardened reverse proxy when possible. If TBOHK itself must terminate TLS, configure the certificate and private key under `/etc/tbohk/tls`, both owned by `tbohk:tbohk` with mode `0600`, and set `TBOHK_REQUIRE_TLS=1` plus the certificate/key paths.

Restrict the host firewall so only the intended HTTPS endpoint is reachable. Do not expose port 8000 directly when using a reverse proxy.

## Cutover

```bash
systemctl enable --now tbohk.service
systemctl enable --now tbohk-backup.timer
systemctl enable --now tbohk-health.timer
systemctl status tbohk.service
```

Then run the live health/auth/TLS acceptance checks and perform one restore drill before declaring production cutover complete.

## Recovery

Backups are timestamped and retained according to `TBOHK_BACKUP_RETENTION` (default 14). Each backup receives an integrity/foreign-key verification and a SHA-256 sidecar. Restore into a separate path with `restore_verify.sh`; never overwrite the live database as the first recovery action.

## External monitoring

The built-in health timer is local supervision, not an independent failure domain. Production should also monitor `/health` from outside the TBOHK process/host and alert when it fails.
