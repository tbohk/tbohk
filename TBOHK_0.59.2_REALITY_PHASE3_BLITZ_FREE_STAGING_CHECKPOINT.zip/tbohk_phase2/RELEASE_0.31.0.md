# TBOHK 0.31.0 — Living Knowledge

TBOHK 0.31.0 adds a time-aware living-knowledge layer over the existing auditable graph.

## Added
- Subject-level living knowledge snapshots.
- Historical snapshots with bounded retention reads.
- Change detection between knowledge snapshots.
- Scheduled review dates derived from recorded evidence retrieval time.
- Maintenance triggers for:
  - invalidated or superseded claims
  - missing evidence
  - weak source independence
  - aging evidence
  - undated evidence
  - expired source validity intervals
  - explicit conflicts
- Persistent `KnowledgeProfile` and `KnowledgeSnapshot` graph nodes.
- APIs for current living state, history, review triggers, and explicit snapshot recording.
- Knowledge UI panel for living state and maintenance history.

## Boundary
Living knowledge describes recorded graph state and maintenance needs. It does not create a truth score, confidence score, automatic promotion, or silent status mutation.

## Verification
- Full test suite is required to pass before packaging.
- Release version is aligned across `pyproject.toml`, package metadata, CLI, API, and UI version injection.
