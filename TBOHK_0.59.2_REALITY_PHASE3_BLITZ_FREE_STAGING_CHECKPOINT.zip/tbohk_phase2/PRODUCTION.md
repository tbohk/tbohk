# TBOHK 0.29.1 — Multi-Account Production Bundle

This bundle contains the verified TBOHK application plus deployment controls for multi-account identity, isolated per-account knowledge databases, monthly ask metering, Stripe-backed subscription billing, a dedicated service account, secret-file authentication, optional direct TLS, verified SQLite backups, restore verification, systemd supervision, and periodic health checks.

## Install dependencies

Use a clean Python 3.13 environment and install the exact versions in `requirements.lock`.

```bash
python -m pip install -r requirements.lock
```

Then run the full verification suite before cutover.

## Account and billing configuration

The deployment uses:

- `TBOHK_ACCOUNTS_DB` — central account/user/subscription/usage registry;
- `TBOHK_ACCOUNT_DATA_DIR` — one SQLite knowledge database per account;
- `STRIPE_SECRET_KEY` — Stripe API secret used to create Checkout and Billing Portal sessions;
- `STRIPE_WEBHOOK_SECRET` — Stripe signing secret used to authenticate subscription events;
- `STRIPE_PRICE_PRO` — Stripe Price ID for the $10/month Pro subscription;
- `STRIPE_PRICE_UNLIMITED` — Stripe Price ID for the $20/month Unlimited subscription.

Free accounts are immediately active. Paid accounts are activated only after the signed Stripe webhook is accepted. The application never embeds billing credentials in source or the release archive.

## Ask metering

Each accepted `/workspace` question consumes one account-scoped ask. Limits are calendar-month limits:

- Free: 25/month
- Pro: 250/month
- Unlimited: 1,000/month

Usage is stored transactionally in the central account database. A new month starts at zero without requiring a reset job.

## Secure startup

Use `run_hardened.py`, not the convenience launcher, for production. It:

- loads an API token from a mode-0600 secret file;
- rejects tokens shorter than 32 characters;
- refuses non-loopback binding without authentication;
- can require direct TLS for non-loopback operation;
- rejects world/group-readable TLS private keys;
- runs one Uvicorn worker with `uvloop` and `httptools`.

For a reverse proxy/load balancer, keep TBOHK bound to `127.0.0.1` and terminate TLS at the trusted proxy. For direct public TLS, set `TBOHK_REQUIRE_TLS=1`, `TBOHK_TLS_CERT`, and `TBOHK_TLS_KEY`.

## Data protection

`backup_production.sh` creates a retained snapshot containing the main deployment database, the account registry, and every account knowledge database. Each SQLite file is independently backed up and verified for SQLite integrity and foreign-key integrity, with a snapshot manifest and SHA-256 file list.

## Supervision and monitoring

`deploy/tbohk.service` provides a dedicated systemd service with `NoNewPrivileges`, `ProtectSystem=strict`, `ProtectHome`, restricted write paths, restart-on-failure, and a private temporary directory. The supplied backup and health timers provide recurring operational checks.

## Cutover gate

Do not expose the service until all of these are true:

1. a clean Python 3.13 environment has installed exactly `requirements.lock`;
2. `pytest -q --cov=tbohk` reports **562 passed** and **6,628/6,628 production statements covered**;
3. `verify_production.py` passes;
4. live account registration/login, tenant isolation, ask metering, billing webhook verification, and authentication acceptance checks pass;
5. a fresh multi-database backup snapshot has passed integrity verification;
6. the snapshot's databases have been restored to separate paths and verified;
7. the service account, secret files, account registry, tenant databases, TLS key, and backup directory have restrictive ownership/permissions;
8. the deployment's existing external monitoring system is checking `/health` and alerting on failure.
