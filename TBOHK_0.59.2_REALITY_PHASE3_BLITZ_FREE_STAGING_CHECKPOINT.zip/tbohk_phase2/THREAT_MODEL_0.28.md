# TBOHK 0.28 Threat Model

## Trust boundaries

1. Human/operator boundary — users can submit questions, documents and actions.
2. Retrieval boundary — URLs, HTTP responses, feeds and search providers are untrusted.
3. Parser boundary — PDF/HTML/CSV/document parsers are untrusted computation.
4. Model boundary — LLM/model output is untrusted inference, not authority.
5. Tool boundary — tools can have side effects and credentials.
6. Persistence boundary — the live database is trusted only to the extent its integrity checks and external anchors permit.
7. Release boundary — code, dependencies and build artifacts must be independently identifiable.
8. Recovery boundary — recovery output cannot certify itself.

## Primary threats

- privileged local database tampering
- deletion/reordering of events or revisions
- metadata/content substitution
- schema downgrade or migration skipping
- malicious or oversized documents
- decompression bombs and parser exploits
- SSRF and DNS rebinding
- prompt injection / instruction-like source material
- credential exfiltration through tools or models
- authority escalation through malformed metadata or workflow bypass
- replay or duplicate execution
- stale knowledge surviving beyond validity
- compromised release artifacts
- compromised signing keys
- recovery procedures that erase evidence of failure

## Required controls

- append-only local ledger with integrity anchors
- signed external checkpoint anchoring
- monotonic schema migrations
- canonical serialization
- explicit invariant registry
- explicit state-transition policy
- isolated ingestion workers with resource limits
- content-addressed artifacts
- strict tool/credential boundaries
- independent verification implementation
- non-destructive self-care
- tested disaster recovery
- key rotation/revocation procedures
- structured audit export
- adversarial testing against hostile documents and model outputs

## Residual risks

No local architecture can prove reality from its own database. External trust anchors and independent operational custody are therefore required for high-assurance deployments. No test suite proves absence of all defects; it proves only the behaviors exercised by the test and verification systems.
