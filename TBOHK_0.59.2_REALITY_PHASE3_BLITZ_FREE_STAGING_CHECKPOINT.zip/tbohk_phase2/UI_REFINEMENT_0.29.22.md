# TBOHK 0.29.22 — Evidence Health

## Added
- Evidence-level freshness diagnostics (recent / aging / old / undated / unparseable).
- Provenance completeness diagnostics across URL, publisher, source identity, and retrieval timestamp.
- Answer-level evidence-health summary exposing citation quality, independent-source count, provenance gaps, and freshness gaps.
- Source cards now expose freshness state without converting it into a truth judgment.

## Boundary
These diagnostics describe evidence maintenance and provenance quality. They do not promote, demote, or verify claims.

## Verification
- Full pytest suite passed.
- Python compilation passed.
- JavaScript syntax check passed.
