from __future__ import annotations
import os
import uvicorn

if __name__ == '__main__':
    host = os.getenv('TBOHK_HOST', '127.0.0.1')
    port = int(os.getenv('TBOHK_PORT', '8000'))
    uvicorn.run(
        'tbohk.api:app',
        host=host,
        port=port,
        workers=1,
        loop='uvloop',
        http='httptools',
        access_log=False,
        log_level=os.getenv('TBOHK_LOG_LEVEL', 'warning'),
        server_header=False,
        date_header=False,
        reload=False,
    )
