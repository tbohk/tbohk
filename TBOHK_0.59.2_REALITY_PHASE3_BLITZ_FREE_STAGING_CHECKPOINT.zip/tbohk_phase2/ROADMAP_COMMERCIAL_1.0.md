# TBOHK Commercial Product Roadmap

## Product goal
Ship TBOHK as a reliable commercial knowledge application on web, iOS, and Android with compliant billing, trustworthy answers, strong tenant isolation, continuous assurance, and safe autonomous improvement.

## Gate 1 — Commercial foundation (started)
- [x] Provider-neutral Free/Pro/Unlimited plan limits
- [x] Account isolation and monthly ask metering
- [x] Signed Stripe webhook state changes
- [x] Trusted billing redirect origin
- [x] Logout/token revocation
- [x] Permanent account deletion workflow
- [x] Tenant database deletion on account deletion
- [x] Email verification token workflow
- [x] Password reset/recovery token workflow
- [x] Session/device inventory, expiry, logout, and all-session revocation
- [x] Login throttling and basic abuse detection
- [x] Transactional email provider integration (provider-neutral SMTP adapter)
- [x] Privacy policy / terms / support surfaces

## Gate 2 — Billing authority
- [x] Stripe web checkout foundation
- [x] Stripe portal foundation
- [x] Stripe event idempotency ledger
- [ ] Apple StoreKit subscription products
- [ ] App Store Server API verification
- [ ] App Store Server Notifications V2
- [ ] Google Play Billing subscriptions
- [ ] Google purchase-token verification
- [ ] Google Real-time Developer Notifications
- [x] Unified provider-neutral entitlement reconciliation foundation
- [ ] Refund, grace-period, retry, cancellation and restoration tests

## Gate 3 — Native applications
- [ ] Android project targeting current Play requirement
- [ ] iOS project targeting current App Store requirement
- [ ] Secure credential storage (Keystore/Keychain)
- [ ] Native purchase/restore UX
- [ ] Deep links
- [ ] Offline/degraded-network behavior
- [ ] Accessibility audit
- [ ] Crash/performance instrumentation
- [ ] Store metadata and review flows

## Gate 4 — Research engine
- [ ] Search/discovery provider abstraction
- [ ] Safe extraction for HTML/PDF/documents
- [ ] Images/video/transcript ingestion
- [ ] Source independence and duplicate analysis
- [ ] Contradiction and temporal analysis
- [ ] Citation/provenance graph
- [ ] Prompt-injection/content-boundary defenses

## Gate 5 — Answer experience
- [x] Grounded answer presentation
- [x] Evidence and provenance
- [x] Images/video/source links
- [x] Uncertainty and truth boundary
- [ ] Citation quality scoring
- [ ] Answer latency budgets and streaming
- [ ] Mobile-native answer presentation

## Gate 6 — Autonomous assurance
- [ ] Continuous health monitoring
- [ ] Anomaly detection
- [ ] Automated diagnosis
- [ ] Safe repair proposals
- [ ] Isolated repair testing
- [ ] Canary deployments
- [ ] Automatic rollback
- [ ] Dependency vulnerability response
- [ ] Security incident containment

## Gate 7 — Store/release certification
- [ ] Apple Developer/App Store Connect setup
- [ ] Google Play Console setup
- [ ] Privacy/data-safety declarations
- [ ] Account deletion verification
- [ ] Billing test tracks/sandbox verification
- [ ] TestFlight verification
- [ ] Closed testing / production access requirements
- [ ] Accessibility/performance/crash certification
- [ ] Final store review submissions

## Release invariant
No gate is marked complete from documentation alone. Every completed gate requires executable tests, fresh-build verification, and a reproducible artifact.


## Gate 1 security implementation note — 2026-09-27
Implemented and regression-tested:
- Expiring 30-day account sessions with revocation state.
- Session inventory and all-session revocation endpoint.
- One-time email verification and password-reset workflows.
- Password reset invalidates existing sessions.
- Login failure throttling with a 15-minute lock window.
- Non-enumerating password-reset request responses.
- 579-test regression suite and 100% production-code coverage.

Still external/provider-dependent:
- Transactional email delivery provider and production sender configuration.

## Gate 2 implementation note — 2026-09-26
Implemented and regression-tested:
- Provider-neutral entitlement records for Stripe, Apple, and Google.
- Atomic billing-event idempotency ledger.
- Account-scoped entitlement reconciliation into Free/Pro/Unlimited state.
- Billing entitlement API contract for verified provider events.
- Stripe webhook compatibility for signed legacy fixtures without an explicit event ID via deterministic payload identity.
- 579-test regression suite and 100% production-code coverage.

Still external/provider-dependent:
- Apple App Store Server API credentials and production notification endpoint configuration.
- Google Play purchase-token verification credentials and RTDN configuration.
- Live Stripe Price IDs/webhook secret.
- Store sandbox/test-track verification.

## Gate 1 completion note — 2026-09-26
Implemented and regression-tested:
- Provider-neutral SMTP transactional email adapter for verification and password-reset delivery.
- Fail-safe email delivery: SMTP failure never exposes recovery tokens or breaks account creation/reset acceptance.
- Public Privacy, Terms, and Support routes and authenticated-app footer links.
- Browser acceptance and responsive verification retained across 9 views and 6 viewport widths.
- 587-test regression suite and 100% production-code coverage.

Still deployment-dependent:
- Production SMTP credentials/sender identity and support address must be supplied by the operator.
- Legal text should be reviewed/customized by the operator's counsel before commercial launch.

## Continual Learning Architecture — integrated 2026-09-27
The product now includes a controlled continual-learning plane (`tbohk/learning_core.py`) with experience capture, self-modeling, failure-driven learning plans, isolated improvement candidates, adversarial/security/latency promotion gates, and an explicit non-deploying promotion boundary. See `LEARNING_ARCHITECTURE_0.29.1.md`.

## 0.29.2 integrated launch-hardening pass

This working tree integrates the launch-control layers into executable paths:

- allowlisted systemd deployment adapter with SHA-256 artifact verification, serialized deployment, explicit rollback and deployment health;
- request IDs and bounded request telemetry with tenant attribution and latency/error summaries;
- source-document validation, content-addressed source fingerprints, duplicate suppression and citation-verification API;
- deployment, observability and citation-verification controls exposed through the web UI;
- Android/iOS native project baselines under `mobile/`, with server-authoritative entitlements and platform secure-storage contracts;
- Linux-independent Swift package parsing/build verification for the iOS source shell; iOS StoreKit compilation still requires Apple's Xcode environment;
- the existing Stripe/Apple/Google provider-neutral entitlement authority remains server-side and idempotent;
- learning remains unable to self-authorize deployment; release control remains the authority boundary.

Release invariant remains unchanged: source/docs alone never close a gate. Every completed gate must have executable tests and a fresh-build/reproducibility record, with platform-specific store signing/build gates explicitly identified where this environment cannot execute them.

## 0.29.3 launch-closure pass — 2026-09-26

Executable closure added for native client foundations, research ingestion integrity, answer transport/citation quality, and release certification. The release remains credential/store/infrastructure activation-gated where the environment cannot legitimately perform those external actions.
