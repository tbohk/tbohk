#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys
from tbohk.core import TBOHK
from tbohk.staging import StagingOrchestrator


def main() -> int:
    p = argparse.ArgumentParser(description="Run TBOHK's real networked staging workflow.")
    p.add_argument("question")
    p.add_argument("--common-crawl", action="store_true")
    p.add_argument("--crawl-id", default=None)
    args = p.parse_args()
    urls = [x.strip() for x in os.environ.get("TBOHK_STAGING_URLS", "").split(",") if x.strip()]
    if not urls and not args.common_crawl:
        print("ERROR: set TBOHK_STAGING_URLS to comma-separated public HTTPS URLs, or use --common-crawl", file=sys.stderr)
        return 2
    g = TBOHK(os.environ.get("TBOHK_DB", ":memory:"))
    result = StagingOrchestrator(g).run_dict(args.question, include_common_crawl=args.common_crawl, crawl_id=args.crawl_id)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
