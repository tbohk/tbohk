# TBOHK 0.29.1 Deployment Acceptance Record

## Final application gate

- Tests: 562 passed.
- Strict `ResourceWarning`: PASS.
- Strict `PytestUnraisableExceptionWarning`: PASS.
- Production executable statements: 6,628.
- Missed executable statements: 0.
- Statement coverage: 100%.
- `compileall`: PASS.
- Production verifier: PASS.
- Release audit: PASS.
- Self-care: PASS.
- Migration verification: PASS.

## Deployment-target gate

The release now contains a from-zero Linux/systemd installer that creates:

- dedicated `tbohk` service account and group;
- immutable root-owned application tree;
- isolated Python 3.13 virtual environment;
- exact `requirements.lock` installation and `pip check`;
- dependency-version preflight on every service start;
- generated API secret with mode 0600;
- restrictive environment and TLS-key permissions;
- systemd sandboxing and restart supervision;
- timestamped verified SQLite backups with retention;
- separate restore verification;
- periodic local health checks;
- deployment-from-zero instructions.

## Live drill executed in this environment

- HTTP `/health`: 200.
- Unauthenticated protected endpoint: 401.
- Wrong bearer token: 401.
- Correct bearer token: 200.
- Authenticated node creation: 200.
- Unsafe non-loopback bind without authentication: rejected before service exposure.
- SQLite backup: integrity OK; foreign-key check clean; SHA-256 generated.
- Restore to separate database: integrity OK; foreign-key check clean.
- Restored database production verifier: audit/release-audit/self-care/migrations all PASS.
- Direct TLS `/health`: 200.
- Direct TLS authenticated endpoint: 200.

## Clean dependency installation limitation

This execution environment cannot resolve the external Python package index, so the newly pinned dependency set could not be installed here. The installer therefore performs the exact lock installation and version preflight on the deployment machine and refuses to start if the installed versions differ from the lock.

This is an environmental verification limitation, not a skipped test or an assertion failure.

## Release identity

The external SHA-256 sidecar is the authoritative identity of the final ZIP. Verify it before installation and do not modify the archive after verification.
