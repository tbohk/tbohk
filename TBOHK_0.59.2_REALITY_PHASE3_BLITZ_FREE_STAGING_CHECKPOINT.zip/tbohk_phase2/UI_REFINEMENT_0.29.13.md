# TBOHK UI Refinement 0.29.13

## Focus
Evidence and knowledge readability pass.

## Changes
- Replaced raw Knowledge claim rows with inspectable claim cards showing status, claim ID, confidence/scope when recorded, and evidence counts.
- Added expandable record metadata so the durable record remains available without dominating the default view.
- Added explicit Knowledge search loading and error states.
- Replaced raw Research JSON output with source/evidence cards showing title, URL, retrieval time, origin, evidence text, IDs, and provenance/safety details.
- Preserved the raw provenance metadata behind an expandable disclosure rather than removing it.
- Research completion now surfaces the recorded independent-origin count and duplicate suppression policy when supplied by the research record.
- Kept existing workflow handoffs and API contracts unchanged.

## Verification
- JavaScript syntax: PASS
- Full regression suite: 677 passed
