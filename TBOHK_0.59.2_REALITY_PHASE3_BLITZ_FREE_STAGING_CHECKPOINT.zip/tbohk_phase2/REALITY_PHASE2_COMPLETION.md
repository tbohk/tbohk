# TBOHK Reality Phase 2 — Completion

## Implemented

- `tbohk/staging.py`: real staging orchestrator for question -> external retrieval -> provenance/evidence -> answer -> metrics.
- `scripts_staging_smoke.py`: executable networked staging smoke runner.
- `POST /staging/run`: authenticated API entry point for the same workflow.
- Staging uses the existing SSRF-safe `DirectURLProvider`; no mock provider is substituted.
- Optional Common Crawl provider can be included explicitly.
- Fail-closed behavior when no real staging source is configured.
- Regression coverage for the staging contract and API boundary.

## Verification

- Full regression: **820 passed**
- Python compilation: **PASS**
- Chromium UI acceptance: **10 views x 6 viewport widths — PASS**
- Release script: **PASS**
- Release artifact: `TBOHK_Reality_Build_0.59.2.tar.gz`
- Release artifact SHA-256: `8984f2375b10ebc11be7ccc48c5d65a009ad16f3eb0b9a94405167265f912f06`
- Staging negative gate: **PASS** — exits non-zero without real provider configuration.

## Network boundary

The development execution environment does not provide reliable external DNS/network access.
Therefore a successful live Common Crawl or arbitrary public-URL retrieval cannot be honestly
claimed from this environment. Phase 2 supplies the actual networked execution path and tests
its failure boundary. A networked staging environment with public HTTPS reachability is the
remaining environment prerequisite for a positive external-provider smoke result.

The staging workflow does not auto-promote retrieved evidence to verified knowledge.
