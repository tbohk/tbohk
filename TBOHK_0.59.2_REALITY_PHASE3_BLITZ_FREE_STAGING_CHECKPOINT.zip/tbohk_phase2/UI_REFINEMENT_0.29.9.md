# TBOHK 0.29.9 UI Refinement — Trust & First-Use Pass

## Purpose
Make TBOHK easier to understand for a first-time user while making answer trust boundaries more explicit.

## Changes
- Added a first-use explainer on Home: start with a question, inspect evidence, keep what matters.
- Added an answer-level **Why this answer?** panel.
- Added Technical / Plain language explanation modes.
- Added source comparison for claims with multiple attached sources.
- Added per-claim **Why this status?** path into Review.
- Kept explanations descriptive: no fabricated confidence score or reliability ranking.
- Preserved existing provenance, URL sanitization, review, library, billing, account, and backend behavior.

## Product boundary
The answer explanation describes recorded knowledge-state facts (claim status, review count, attached evidence links). It does not infer that a source is authoritative merely because it is listed.

## Verification
- 677 pytest tests passed.
- Chromium UI acceptance: 10 views x 6 viewport widths passed.
- JavaScript syntax check passed.
- Python compilation passed.
