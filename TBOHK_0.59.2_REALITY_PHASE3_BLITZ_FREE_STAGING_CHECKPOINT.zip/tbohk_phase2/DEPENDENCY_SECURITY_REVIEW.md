# TBOHK 0.29.1 dependency security review

Review date: 2026-09-26.

The production lock now requires `cryptography==50.0.1`, `uvicorn==0.49.0`, `starlette==0.51.0`, and `pydantic==2.13.5`, with the remaining runtime dependencies pinned in `requirements.lock`.

The installed test environment used for the 543-test verification currently contains `cryptography 46.0.4`, `uvicorn 0.48.0`, `starlette 0.50.0`, and `pydantic 2.13.4`. It therefore does **not** constitute a test of the newly pinned dependency set. The environment has no package-index network access, so a fresh dependency installation could not be performed here.

Current external security review found that cryptography 46.0.4 is affected by later 2026 advisories, including issues fixed in 48.0.1, 49.0.0, 50.0.0 and 50.0.1. The locked 50.0.1 release is reported as having no direct vulnerabilities in the consulted current vulnerability database. Uvicorn 0.49.0 is the later 2026 release after 0.48.0 and includes the current forwarding-header behavior; Starlette 0.51.0 is later than the 0.50.0 test environment and incorporates the current security-fix line. See the final release record for source references.

Deployment requirement: install exactly `requirements.lock` in a clean Python 3.13 environment, then rerun the complete 543-test suite and live acceptance checks before exposing the service.
