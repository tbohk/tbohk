# TBOHK 0.29.2 — Stripe / Apple / Google Production Activation

The application-side integration for all three billing providers is complete and tested.

## Stripe

Required production secret-store values:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `STRIPE_PRICE_PRO`
- `STRIPE_PRICE_UNLIMITED`

Webhook:

`POST /billing/webhook`

The server verifies the Stripe signature, deduplicates event IDs, resolves subscriptions server-side, and updates normalized entitlement state. Checkout and Billing Portal redirects use the canonical `TBOHK_PUBLIC_BASE_URL`; client-provided redirect URLs are not trusted.

## Apple

Required production secret-store values:

- `APPLE_ISSUER_ID`
- `APPLE_KEY_ID`
- `APPLE_PRIVATE_KEY_PEM`
- `APPLE_ROOT_CA_PEM`
- `APPLE_BUNDLE_ID`
- `APPLE_ENVIRONMENT=production`
- `APPLE_PRODUCT_PRO`
- `APPLE_PRODUCT_UNLIMITED`

Server notification endpoint:

`POST /billing/store/apple/notifications`

Use App Store Server Notifications V2. The server validates the signed JWS chain, bundle identifier, environment, transaction identifiers, and current subscription state from the App Store Server API.

## Google Play

Required production secret-store values:

- `GOOGLE_PLAY_PACKAGE_NAME`
- `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM`
- `GOOGLE_PRODUCT_PRO`
- `GOOGLE_PRODUCT_UNLIMITED`
- `GOOGLE_RTDN_AUDIENCE`

RTDN endpoint:

`POST /billing/store/google/rtdn`

The server verifies the Pub/Sub OIDC token and configured audience, validates the package identity, deduplicates notifications, and queries `subscriptionsv2` for current state. RTDN is never treated as the complete entitlement record.

## Launch gate

Run:

```bash
python -m tbohk.provider_readiness
```

or query:

```text
GET /billing/provider-readiness
```

All three providers must report `configured=true` before enabling paid production billing.

This repository does not contain production secrets and never should. Apple private keys, Google service-account keys, Stripe secrets, and webhook secrets belong only in the deployment secret store.
