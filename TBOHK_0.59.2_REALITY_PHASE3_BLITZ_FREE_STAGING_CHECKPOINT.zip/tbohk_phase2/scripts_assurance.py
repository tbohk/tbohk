#!/usr/bin/env python3
"""Run the reproducible local assurance surface and emit a compact report."""
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
from tbohk import __version__

ROOT=Path(__file__).resolve().parent

def run(*args):
    p=subprocess.run(args,cwd=ROOT,text=True,capture_output=True)
    return p.returncode,p.stdout,p.stderr

def main():
    rc,out,err=run(sys.executable,'-m','pytest','-q','-W','error::ResourceWarning','-W','error::pytest.PytestUnraisableExceptionWarning')
    if rc:
        print(out+err); return rc
    rc2,out2,err2=run(sys.executable,'-m','compileall','-q','tbohk','run_tbohk.py')
    if rc2:
        print(out2+err2); return rc2
    report={'pytest':out.strip().splitlines()[-1] if out.strip() else 'unknown','compileall':'PASS'}
    Path(f'ASSURANCE_LOCAL_{__version__}.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2)); return 0

if __name__=='__main__': raise SystemExit(main())
