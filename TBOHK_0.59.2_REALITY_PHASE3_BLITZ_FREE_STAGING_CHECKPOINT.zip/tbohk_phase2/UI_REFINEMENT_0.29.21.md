# TBOHK 0.29.21 — Adaptive Investigation & Self-Test Milestone

## Focus
Make investigation planning smarter while keeping automation evidence-bounded, and add a lightweight UI self-test plus regression coverage.

## Changes
- Added reason-specific evidence-gap guidance for coverage, independence, verification, and maintenance states.
- Added an adaptive investigation plan generated from the current evidence state.
- Plan generation is presentation-only: it cannot change claim status, create new evidence, or call server actions.
- Added a lightweight runtime UI self-check for core view/navigation/action functions.
- Added regression tests for adaptive planning, evidence gating, and self-check execution.

## Verification
- Python compilation: PASS
- JavaScript syntax: PASS
- Targeted workflow/UI tests: 15 passed
- Full regression: 688 passed
- No billing, authentication, provider, or evidence contracts changed.
