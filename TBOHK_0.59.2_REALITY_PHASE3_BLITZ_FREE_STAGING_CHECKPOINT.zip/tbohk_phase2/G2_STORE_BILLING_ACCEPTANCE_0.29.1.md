# TBOHK 0.29.1 — Gate 2 Store Billing Acceptance

Date: 2026-09-27

## Implemented

- Apple App Store Server API authority adapter.
- Apple ES256 JWS certificate-chain and transaction signature validation.
- Apple subscription-status refresh through the App Store Server API.
- Apple App Store Server Notifications V2 endpoint: `POST /billing/store/apple/notifications`.
- Google Play `purchases.subscriptionsv2` authority adapter using a service account OAuth assertion.
- Google Play RTDN Pub/Sub push endpoint: `POST /billing/store/google/rtdn`.
- Google RTDN OIDC JWT signature/audience/issuer/expiry validation.
- Provider-authoritative product-to-plan mapping.
- Account binding through previously verified entitlement identifiers; unbound server notifications never grant access.
- Idempotent provider event processing.
- Grace-period, paused/on-hold, canceled, expired, pending, revoked, and active states.
- Malformed provider payload and cryptographic failure handling.

## Verification

- 611 tests passed.
- 7,295 production statements.
- 100% production-code coverage.
- Python compilation passed.
- UI JavaScript syntax check passed.
- Live Uvicorn HTTP smoke passed for root, health, pricing, legal, support, entitlements, and store verification boundary.

## Production configuration required

Apple:
- `APPLE_ISSUER_ID`
- `APPLE_KEY_ID`
- `APPLE_PRIVATE_KEY_PEM`
- `APPLE_ROOT_CA_PEM`
- `APPLE_BUNDLE_ID`
- `APPLE_PRODUCT_PRO`
- `APPLE_PRODUCT_UNLIMITED`
- `APPLE_ENVIRONMENT`

Google:
- `GOOGLE_PLAY_PACKAGE_NAME`
- `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PEM`
- `GOOGLE_PRODUCT_PRO`
- `GOOGLE_PRODUCT_UNLIMITED`
- `GOOGLE_RTDN_AUDIENCE`

Store notification endpoints must be exposed over HTTPS in production. Apple App Store Server Notifications V2 should be configured in App Store Connect. Google Play RTDN should use authenticated Pub/Sub push delivery.

No production store credential was present during this acceptance run, so this artifact verifies the real authority protocol and failure boundaries, not a live purchase against Apple/Google production accounts.
