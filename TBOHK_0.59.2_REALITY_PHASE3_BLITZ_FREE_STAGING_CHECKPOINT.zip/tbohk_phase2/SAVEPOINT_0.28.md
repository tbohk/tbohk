# TBOHK 0.28 Savepoint — Structural Assurance Milestone

## Identity

- Release: **0.28.0**
- Mission: make the substrate explicit, inspectable, externally anchorable and recoverable before the full knowledge workspace.
- Prior baseline: 0.27.0

## Verified result

- 325 automated tests passing.
- Python compilation passing.
- Clean SelfCareEngine passing.
- Clean ReleaseAuditor passing on a clean graph.
- Schema migration ledger: version 2, contiguous and verified.
- Canonical serialization contract: version 1.
- Invariant registry: 20 invariants.
- State-transition matrix: explicit for all core statuses.
- Signed external checkpoint anchoring: implemented and round-trip verified.
- Independent verifier path: `tbohk-verify` / `IndependentSystemValidator`.
- Recovery drill: intentionally deleted event is detected by ledger assurance and independent validation.
- Threat model: documented.
- Updated 16-frame architecture GIF: included.

## New structural controls

### Invariant registry
A single machine-readable catalog defines the system's non-negotiable properties, severity, detection path and remediation posture.

### State machine
Status transitions are no longer merely convention. The canonical transition policy can assess and audit historical revisions. Sensitive targets such as `verified` and `recovered` require a governing workflow when using the production transition engine.

### Canonical serialization
Security-sensitive new artifacts have a deterministic JSON representation with explicit serialization versioning and SHA-256 support.

### Schema migrations
Every database records an ordered migration history. Migrations are monotonic, recorded and idempotent.

### External trust anchors
Checkpoint manifests can be signed and appended to an external append-only anchor file. The live database cannot use that file to silently repair itself. Production deployment should mirror anchors to an independent trust domain/offline custody.

### Independent verification
The independent verifier intentionally does not invoke the primary release auditor. It checks critical structural, provenance, authority, action, autonomy, reality, checkpoint and untrusted-input boundaries directly.

### Recovery drills
The drill harness copies a real file-backed database, intentionally damages the copy and requires detection through more than one validation path.

## What 0.28 does not claim

- It does not prove factual correctness of the outside world.
- It does not make SQLite a multi-user production database.
- It does not make external trust anchors truly independent merely because they are stored in a separate local file.
- It does not make ingestion safe against all hostile documents.
- It does not eliminate the need for external security review.
- It does not make the system unbreakable; it makes important classes of failure more observable, attributable and bounded.

## Next milestone: 0.29

Build the **Knowledge Workspace** while preserving this structural boundary:

> Ask → inspect → research → compare → review → admit → monitor → invalidate → recover.

The application must expose the architecture rather than bypass it.
