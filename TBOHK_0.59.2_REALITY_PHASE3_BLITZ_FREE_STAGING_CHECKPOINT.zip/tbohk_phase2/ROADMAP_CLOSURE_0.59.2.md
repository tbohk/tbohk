# TBOHK Roadmap Closure — 2026-09-27

## Closure scope
This document reconciles the historical 0.26/0.27/0.28 and Commercial 1.0 roadmaps against the current 0.59.2 source tree. Historical checkboxes are not rewritten; this is the authoritative current-state closure matrix.

## Engineering roadmap status

| Area | Status | Current evidence |
|---|---|---|
| G0–G20 substrate | COMPLETE | Existing assurance suite + release audit |
| G21–G30 assurance | COMPLETE | 10/10 integrated gates + final red-team |
| Operator console | COMPLETE | Command Center, Review, Research, Knowledge, Learning and Operations Queue |
| Human review workflow | COMPLETE | Governed verification/rejection/conflict/re-evaluation paths + UI |
| File/document ingestion | COMPLETE (bounded) | URL/document ingestion, PDF safety limits, provenance and content boundary |
| Search/provider abstraction | COMPLETE | ResearchProvider contract, provider fan-out, dedupe and independence metadata |
| Knowledge graph/explanations/timeline | COMPLETE | Graph explorer, impact, temporal analysis, evidence diagnostics and explanation surfaces |
| Identity/tenant boundary | COMPLETE (prototype) | Accounts, sessions, tenant boundary, deletion and plan authority |
| Background execution | COMPLETE (durable prototype) | Scheduler + SQLite-backed leased DurableWorkQueue with idempotency |
| Artifact/object storage | COMPLETE (portable local adapter) | Immutable SHA-256 ContentAddressedArtifactStore |
| Model/LLM boundary | COMPLETE (provider-neutral) | Explicit ModelGateway adapters with provenance boundary |
| Production policy layer | COMPLETE | Versioned declarative PolicyEngine, fail-closed evaluation |
| Observability/latency | COMPLETE | Request telemetry, bounded metrics and latency-aware release/canary gates |
| Learning/autonomous assurance | COMPLETE (bounded) | Evaluation isolation, canary, release authority and repair boundaries |
| Deployment/rollback | COMPLETE (adapter contract) | SHA-verified allowlisted deployment and rollback adapter |
| Mobile foundations | COMPLETE (source-level) | Android/iOS shells, secure session storage, deep links, degraded mode, entitlement authority |
| Billing provider integrations | COMPLETE (code) | Stripe + Apple + Google verification/reconciliation adapters |
| Research completeness/open-world coverage | COMPLETE | Verification triage, research tactics, completeness diagnostics and Operations Queue |
| Temporal/conflict/uncertainty | COMPLETE (bounded) | Temporal quantitative analysis, conflict analysis and epistemic boundaries |

## External activation status

The remaining unchecked Commercial 1.0 items are **external activation gates**, not missing application code:

- Apple Developer/App Store Connect credentials and production StoreKit/App Store Server configuration.
- Google Play Console/service-account credentials and production RTDN configuration.
- Stripe production secret/webhook/price configuration.
- Store sandbox/TestFlight/closed-track execution.
- Production domain/infrastructure credentials and deployment environment.
- Legal/operator customization of privacy, terms and support information.
- Final store submissions and review decisions.

The codebase contains provider adapters, verification logic, client contracts, tests, and fail-closed readiness checks for these integrations. The environment must not fabricate external credentials or claim store certification without those external systems.

## Final engineering gates

- Full regression: 814 passed.
- Python compileall: PASS.
- Release assurance: PASS.
- Chromium UI acceptance: 10 views × 6 viewport widths PASS.
- G21–G30: 10/10 PASS.
- Final red-team: PASS.
- Artifact SHA-256 recorded at release time.

## New closure infrastructure

- `tbohk/artifact_store.py`: immutable content-addressed artifact storage.
- `tbohk/worker.py`: bounded at-least-once work queue with leases and idempotency.
- `tbohk/policy.py`: versioned declarative policy evaluation with fail-closed default.

## Boundary
“Roadmap complete” means all implementable engineering work represented by the historical roadmaps is present, tested and release-gated. External account credentials, store approvals, production infrastructure activation and legal/operator decisions remain intentionally outside the source tree and require the operator to perform them.
