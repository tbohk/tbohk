# TBOHK staging on blitz.cloud — free/no-card deployment

This is the Phase 3 deployment target for TBOHK. It is deliberately a single web app:
TBOHK's current persistence layer is SQLite, so the API and durable worker share one
process and one persistent `/data` folder. Do not split the worker into another app.

## Current Blitz requirements

- Free account; no credit card.
- GitHub project deployment or a public Docker image.
- Linux amd64 container.
- One HTTP port; this image exposes 8080.
- Persistent storage for `/data`.
- HTTPS is supplied by Blitz.

## 1. Create the account

Open https://beta.blitz.cloud and create a free account. Confirm the email address.

## 2. Put this project in GitHub

Create a repository and upload the complete TBOHK project, including the root `Dockerfile`.
The repository may be private; Blitz can connect to a private GitHub repository after you
authorize GitHub.

Do not commit `.env` files, API tokens, private keys, or credentials.

## 3. Deploy

In Blitz:

1. Choose **Host something new**.
2. Choose the GitHub/project deployment option.
3. Select the TBOHK repository and branch.
4. Blitz detects the Dockerfile and port 8080.
5. Enable persistent storage for `/data`.
6. Create the app.

The free plan provides automatic HTTPS and persistent app storage. Database backups are
available for managed databases, but TBOHK staging currently uses SQLite, so the `/data`
volume is NOT treated as a backup. Keep exported TBOHK checkpoints/backups outside Blitz.

## 4. Set environment variables

Set these in the app's Environment settings:

    TBOHK_API_TOKEN=<long-random-secret>
    TBOHK_ENV=staging
    TBOHK_HOST=0.0.0.0
    TBOHK_PORT=8080
    TBOHK_DB=/data/tbohk.sqlite
    TBOHK_ACCOUNTS_DB=/data/accounts.sqlite
    TBOHK_ACCOUNT_DATA_DIR=/data/accounts
    TBOHK_ARTIFACT_ROOT=/data/artifacts
    TBOHK_WORKER_INTERVAL_SECONDS=2
    TBOHK_WORKER_BATCH_SIZE=1

Generate a token locally, for example:

    python -c "import secrets; print(secrets.token_urlsafe(48))"

Never paste a private key or password into source control.

## 5. Verify

Once Blitz reports the app running, open:

    https://<your-app>.<your-blitz-address>.blitz.cloud/health

Expected response contains:

    {"ok":true,"service":"TBOHK"}

Then run the authenticated staging smoke from a machine that can reach the app. The
API token belongs in the HTTP Authorization header as a bearer token.

## Important staging limitation

The ChatGPT execution environment previously could not resolve outbound DNS. This hosted
Blitz runtime is the point at which TBOHK can make the real external HTTPS retrieval attempt.
A successful `/health` response proves the deployment is alive; it does NOT prove external
research works. The next test must use `POST /staging/run` with a real public HTTPS URL.

## Rollback

Blitz keeps prior app versions. Use the Activity/version controls to put a known-good version
back online if a deployment fails.
