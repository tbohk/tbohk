from __future__ import annotations

import os
import threading
import time

import uvicorn


def main() -> None:
    from tbohk.api import app, production_runtime

    if not os.getenv("TBOHK_API_TOKEN"):
        raise SystemExit("TBOHK_API_TOKEN must be set for Blitz staging")

    interval = float(os.getenv("TBOHK_WORKER_INTERVAL_SECONDS", "2"))
    limit = int(os.getenv("TBOHK_WORKER_BATCH_SIZE", "1"))
    production_runtime.start(interval_seconds=interval, limit=limit)

    config = uvicorn.Config(
        app,
        host=os.getenv("TBOHK_HOST", "0.0.0.0"),
        port=int(os.getenv("TBOHK_PORT", "8080")),
        workers=1,
        loop="uvloop",
        http="httptools",
        access_log=False,
        log_level=os.getenv("TBOHK_LOG_LEVEL", "info"),
        server_header=False,
        date_header=False,
        reload=False,
    )
    server = uvicorn.Server(config)
    try:
        server.run()
    finally:
        production_runtime.stop()


if __name__ == "__main__":
    main()
