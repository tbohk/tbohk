# TBOHK UI Refinement 0.29.15

## Focus
Investigation and Assurance usability pass.

## Changes
- Investigation now separates framing, candidate hypotheses, discriminating evidence, and next actions.
- Candidate hypotheses show explicit unverified status and direct handoffs to Research and Review.
- Assurance checks now present a human-readable state summary while retaining the raw record behind an expandable disclosure.
- Assurance controls are grouped by purpose: system integrity, release readiness, repair boundaries, schema state, and knowledge safeguards.
- Operational telemetry now presents scalar metrics as readable cards while retaining raw telemetry.
- No backend contracts, billing, authentication, or deployment behavior changed.

## Verification
- JavaScript syntax: PASS
- Full regression: to be run after packaging
