# TBOHK 0.29.29

## Verification triage and learning feedback

- Added bounded verification-queue triage using observable structural signals: open conflicts, source independence, missing evidence, dependency depth, and provenance freshness gaps.
- Explicitly exposes that triage ordering is not a truth/confidence score.
- Added bounded verification feedback history to VerificationTask nodes.
- Added API endpoints for verification queue and feedback.
- Feedback is retained for up to 20 outcomes per task and records outcome, evidence pattern, notes, and timestamp.
- Version metadata and release tests synchronized to 0.29.29.
- No automatic truth promotion or hidden epistemic scoring was introduced.
