#!/usr/bin/env python3
from __future__ import annotations
import os
import time

from tbohk.core import TBOHK
from tbohk.production_runtime import ProductionRuntime


def main() -> int:
    data_path = os.environ.get("TBOHK_DATA_PATH", "./tbohk.db")
    interval = float(os.environ.get("TBOHK_WORKER_INTERVAL_SECONDS", "1"))
    limit = int(os.environ.get("TBOHK_WORKER_BATCH_SIZE", "1"))
    graph = TBOHK(data_path)
    runtime = ProductionRuntime(graph)
    print(runtime.readiness())
    runtime.start(interval_seconds=interval, limit=limit)
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        runtime.stop()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
