# TBOHK 0.29.1 Final Release Certification

Date: 2026-09-26

## Verified application state

- Test suite: 562 passed.
- Production executable statements: 6,628.
- Missed production executable statements: 0.
- Statement coverage: 100%.
- Compileall: PASS.
- Production verifier: PASS (audit, release audit, self-care, migrations).
- Recovery drill: PASS; destructive event-ledger corruption was detected by both the core/ledger path and the independent validator path.

## Deployment controls added

- Hardened startup wrapper with secret-file support and minimum token length.
- Non-loopback bind refusal without authentication.
- Optional direct TLS with private-key permission checks.
- Verified online SQLite backup and SHA-256 digest.
- Separate restore verification workflow.
- systemd service hardening and restart supervision.
- recurring backup timer.
- recurring health-check timer.
- dedicated deployment user/filesystem guidance.
- pinned production dependency lock.

## Dependency security

The production lock uses cryptography 50.0.1, uvicorn 0.49.0, starlette 0.51.0, and pydantic 2.13.5. The current external security review reports no direct vulnerabilities for cryptography 50.0.1 and identifies the older cryptography 46.0.4 test environment as behind multiple 2026 security fixes. Therefore the clean deployment environment must install `requirements.lock` and rerun the suite before exposure.

The current execution environment could not install a package vulnerability scanner because outbound package-index access is unavailable. This is recorded rather than represented as a successful scanner run.

## Final integrity rule

The release archive's SHA-256 is the deployment identity. Do not modify files after hashing. Verify the SHA-256 before installation.

## Integrated 0.29.2 launch-hardening delta

- Python tests: 659 passed.
- Production statement coverage: 100% (8,214 statements, 0 missed).
- `compileall`: PASS.
- Chromium UI acceptance: 10 views × 6 viewport widths PASS.
- Live HTTP smoke: PASS.
- Production verifier: PASS on isolated fresh database.
- Assurance script: PASS.
- iOS Swift package source build: PASS on Linux using the platform-conditional source shell; native SwiftUI compilation requires Xcode/iOS SDK.
- Android source baseline added; Android SDK/Gradle toolchain is not present in this execution environment, so Android APK/AAB compilation is an explicit external release gate.
- Deployment authority remains explicit and allowlisted; no arbitrary shell commands are accepted from API clients.
