# TBOHK Reality Build 0.2

First runnable application boundary on top of the G30 assurance substrate.

## Run
```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
export TBOHK_DB=$PWD/tbohk.sqlite
# optional: export TBOHK_API_TOKEN='replace-with-a-secret'
uvicorn tbohk.api:app --host 127.0.0.1 --port 8000
```
Open `http://127.0.0.1:8000/`.

## Endpoints
GET `/health`, `/stats`, `/audit`, `/release-audit`, `/nodes`, `/nodes/{id}`, `/explain/{id}`
POST `/nodes`, `/edges`, `/nodes/{id}/status`, `/research`, `/claims`

## Safety
- Optional bearer-token authentication.
- Serialized DB request boundary for the current SQLite substrate.
- URL ingestion only permits HTTP(S), blocks private/loopback/link-local/reserved/multicast destinations, and caps response size.
- Ingestion creates provenance/snapshot/evidence records; it never silently verifies claims.
- Existing G0–G30 audit machinery remains underneath the API.

## Validation
- Existing G0–G30 regression suite: 197 tests.
- Reality API tests: 3 tests.
- Combined: 200 passing.
- Compilation: PASS.
- HTTP API smoke: PASS.
- SSRF boundary: PASS.

## Phase A-G Implementation

Reality Build 0.3 extends the application into the first complete end-to-end research/knowledge/autonomy workflow:

- Phase A: bounded research planning and source ingestion
- Phase B: deterministic claim-candidate extraction, knowledge search, explicit gaps and conflicts
- Phase C: existing semantic reasoning/inference layers remain the controlled reasoning substrate
- Phase D: research-gap inspection and explicit stopping conditions
- Phase E: existing evaluation/learning/change-proposal substrate remains non-self-authorizing
- Phase F: API/browser-facing knowledge, explanation, audit, research, gap, conflict, and plan surfaces
- Phase G: bounded autonomous research/synthesis/evaluation loop with explicit no-authorization boundary

All retrieved material remains evidence/provenance. Candidate claims are `proposed`; the Phase G loop cannot grant itself authority or silently promote knowledge.

Validation baseline: 203 tests passing, compilation passing, HTTP smoke test passing.

## Reality Build 0.4 — Intelligence Deepening

Build 0.4 extends the Phase A–G intelligence layer with conservative structured claim parsing, evidence-independence inspection, prioritized research gaps, and auditable synthesis. Structured extraction remains candidate-only and does not promote claims to verified knowledge. Synthesis explicitly preserves uncertainty and conflicts. Application/API version is 0.3.0.

Validation: 206 tests passed; Python compileall passed.

## Reality Build 0.5 — Semantic Evidence Synthesis

Added a deterministic semantic comparison layer (`tbohk/synthesis.py`) that:
- normalizes simple declarative claims into subject/predicate/object/polarity structures;
- detects high-confidence structural contradictions without selecting a winning claim;
- compares claim sets and exposes indeterminate/compatible relationships explicitly;
- profiles evidence independence using provenance lineage rather than provider count;
- integrates structural comparison into `KnowledgeIntelligence.synthesize()`;
- exposes `/synthesis` through the API;
- updates the browser surface to v0.3.

Validation: 209 tests passing; compileall passing.


## Reality Build 0.8 — Causal & Relational Reasoning

TBOHK now has a conservative causal/relational reasoning layer. Claims can be classified as causal, correlational, temporal-precedence, dependency, association, or indeterminate. Causal wording is recorded as an assertion, not treated as proof. Correlation and temporal precedence explicitly remain insufficient to establish causation.

The layer records blockers such as missing mechanism, intervention, counterfactual evaluation, and unresolved confounding. Explicit structured causal support may elevate an assessment to `supported_candidate`, but the claim itself remains subject to the existing verification and epistemic controls. The `/causal/{node_id}` API exposes the auditable assessment, while `/synthesis` now includes causal assessments and pairwise causal comparisons.

Validation: **223 tests passing**. Application version: **0.5.0**.

## Reality Build 0.8 — Hypothesis & Competing-Explanation Reasoning

Adds explicit proposed hypotheses, alternative explanations, predictions, discriminating evidence, shared-vs-distinct evidence comparison, and evaluation boundaries. Hypotheses remain proposed and are never promoted to truth by generation or evidence count.


## Reality Build 0.13 — Adaptive Research Controller

Build 0.12 adds a bounded adaptive research controller. Given explicit competing hypotheses and explicitly supplied research providers, the controller selects unresolved, potentially discriminating predictions, dispatches bounded evidence-acquisition cycles, records each cycle in the graph, and stops when the cycle bound or informative-target set is exhausted.

The controller never authorizes real-world experiments, external actions, hypothesis promotion, or truth claims. Provider selection remains explicit. Every adaptive run records its provider set, target prediction, query, evidence count, cycle status, rationale, and authority boundary.

New API surface: `POST /adaptive-research`.

Validation: **242 tests passing**, compilation passing, fresh-database health/audit/release-audit smoke passing, and investigation API smoke passing. Application/package version: **0.13.0**.


## Reality Build 0.13 — Evolving Investigation State
Validation includes adaptive evidence-state aggregation, provenance separation, conflict/staleness handling, API smoke coverage, and full regression suite.
