#!/bin/sh
set -eu
umask 077
DB=${TBOHK_DB:?TBOHK_DB must be set}
ACCOUNTS_DB=${TBOHK_ACCOUNTS_DB:-$(dirname "$DB")/accounts.sqlite}
ACCOUNT_DATA_DIR=${TBOHK_ACCOUNT_DATA_DIR:-$(dirname "$DB")/accounts}
DEST_DIR=${1:?usage: backup_production.sh BACKUP_DIR}
RETENTION=${TBOHK_BACKUP_RETENTION:-14}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$DEST_DIR"
ts=$(date -u +%Y%m%dT%H%M%SZ)
snap="$DEST_DIR/tbohk-$ts"
mkdir -p "$snap"
"$ROOT/.venv/bin/python" "$ROOT/tbohk_backup.py" "$DB" "$snap/main.sqlite"
if [ -f "$ACCOUNTS_DB" ]; then
  "$ROOT/.venv/bin/python" "$ROOT/tbohk_backup.py" "$ACCOUNTS_DB" "$snap/accounts.sqlite"
fi
if [ -d "$ACCOUNT_DATA_DIR" ]; then
  for db in "$ACCOUNT_DATA_DIR"/*.sqlite; do
    [ -f "$db" ] || continue
    name=$(basename "$db")
    "$ROOT/.venv/bin/python" "$ROOT/tbohk_backup.py" "$db" "$snap/accounts-$name"
  done
fi
printf '%s\n' "$snap"
sha256sum "$snap"/*.sqlite > "$snap/SHA256SUMS"
"$ROOT/.venv/bin/python" - "$snap" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1])
manifest={'snapshot':p.name,'files':sorted(x.name for x in p.glob('*.sqlite'))}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
PY
# Keep the newest RETENTION complete snapshots.
case "$RETENTION" in ''|*[!0-9]*) echo 'invalid TBOHK_BACKUP_RETENTION' >&2; exit 2;; esac
find "$DEST_DIR" -mindepth 1 -maxdepth 1 -type d -name 'tbohk-*' -printf '%T@ %p\n' \
  | sort -nr | tail -n +$((RETENTION + 1)) | cut -d' ' -f2- \
  | while IFS= read -r old; do rm -rf -- "$old"; done
