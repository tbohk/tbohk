# TBOHK Reality Phase 2 — Networked Staging

This checkpoint adds an executable staging path for the real workflow:

`question -> approved external sources -> provenance/evidence -> answer -> metrics`

## Real inputs

Set `TBOHK_STAGING_URLS` to comma-separated public HTTPS URLs. The existing
SSRF-safe `DirectURLProvider` performs DNS/public-address validation, bounded
retrieval, redirect validation, PDF/HTML extraction, and provenance capture.

Optional Common Crawl retrieval can be enabled with `--common-crawl`.

## Run

```bash
export TBOHK_STAGING_URLS='https://example.com/source-a,https://example.com/source-b'
python scripts_staging_smoke.py 'What does the supplied evidence establish?'
```

For Common Crawl:

```bash
python scripts_staging_smoke.py 'your research question' --common-crawl
```

## Boundary

This repository cannot manufacture live provider credentials or network reachability.
A staging run with no network is therefore a failed environment check, not a successful
provider test. The script exits non-zero when no real source is configured or when
configured providers return no evidence.

The workflow never auto-promotes retrieved material to verified knowledge.
