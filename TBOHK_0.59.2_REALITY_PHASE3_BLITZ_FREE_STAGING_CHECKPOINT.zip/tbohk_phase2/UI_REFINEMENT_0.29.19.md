# TBOHK UI Refinement 0.29.19

## Focus
Milestone hardening: workflow continuity, evidence freshness, bounded automation, and expanded regression coverage.

## Changes
- Added best-effort device-local persistence for the active question and research question.
- Added a Home resume hint for a recent investigation, with an explicit local-storage boundary.
- Research completion now refreshes the current answer automatically before returning to Ask, preventing a stale-answer handoff.
- Added milestone regression tests covering workflow persistence, research refresh automation, local-storage disclosure, and absence of unbounded background loops.
- No server-authoritative knowledge, evidence, account, billing, or authentication state is stored in the workflow snapshot.

## Verification
- Python compilation: PASS
- JavaScript syntax: PASS
- UI acceptance: 16 passed
- Milestone tests: 4 passed
- Full regression: 681 passed
