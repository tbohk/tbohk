# TBOHK 0.29.30 — Research Strategy Learning

Implemented bounded feedback-driven research strategy learning.

- Verification outcomes create bounded `VerificationFeedbackProfile` records.
- Profiles track tactic/evidence-pattern attempts, resolved outcomes, and verified-outcome rate.
- Research recommendations combine current structural evidence gaps with historical verification outcomes.
- Historical learning only refines ordering; it cannot override required evidence or verification steps.
- Added `/corpus/research-tactics` and `/corpus/research-tactic-history`.
- Learning Lab exposes research strategy history.
- No truth/confidence score is inferred from feedback.
- Full regression: 709 passed.
