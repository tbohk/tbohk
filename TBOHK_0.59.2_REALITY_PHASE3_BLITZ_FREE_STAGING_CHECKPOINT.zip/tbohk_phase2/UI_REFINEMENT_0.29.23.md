# TBOHK 0.29.23 — Knowledge Dependency & Impact Diagnostics

## Purpose
Expose the dependency structure already present in the knowledge graph so an investigation can show where conclusions are structurally fragile.

## Changes
- Added bounded dependency profiles to answer claims.
- Reports direct and short transitive `derived_from` prerequisites.
- Flags claims whose displayed evidence comes from one identified source.
- Added answer-level source impact analysis.
- Reports source count, maximum displayed-claim load, single-source claim count, high-impact sources, and concentration ratio.
- Added UI diagnostics explaining what would be affected if a heavily reused source disappeared.
- Added dependency-chain visibility on individual claims.

## Guardrails
- Diagnostics do not alter claim status.
- Diagnostics do not determine truth.
- Dependency traversal is bounded to prevent unbounded graph work in the answer path.
- Source concentration is a fragility signal, not a confidence score.

## Verification
- Python compilation: PASS
- JavaScript syntax: PASS
- Targeted dependency/evidence/adaptive/workflow tests: 17 passed
- Full regression: 692 passed
