# TBOHK Deep Review — Prototype + Gap Analysis

## Source baseline

The supplied project checkpoint says the recursive-audit resume point is user-designated Pass 9, conceptual hardening is recorded through Pass 16, G1 is complete for the minimal substrate, and G2 Research chain is next. The supplied roadmap defines G0–G12 and a gate lifecycle of DESIGN -> INVARIANTS -> IMPLEMENT -> TEST -> ADVERSARIAL AUDIT -> REPAIR -> REGRESSION -> CHECKPOINT -> PASS.

## Visual architecture recovered from the supplied growth representation

The animation progresses from **ORIGIN** to a branching knowledge structure and then to increasingly autonomous architectural themes. Visible stages include:

- "From an answer app -> a living knowledge architecture"
- "KNOWLEDGE BECOMES STRUCTURE"
- "THE SYSTEM LEARNS TO QUESTION ITSELF"
- "THE ARCHITECTURE BECOMES ALIVE"
- "NOT FINISHED — CONTINUALLY VERIFIED"
- loop: "Observe -> challenge -> research -> test -> authorize -> reality -> learn"

The final frame also states several explicit separations:

- Reality != representation
- Evidence != truth
- Capability != authority
- Autonomy != self-authorization
- Self-correction != self-perfection

It describes a next-step loop involving build, test, verify, operate, observe, find gaps, research, learn, deploy, and re-audit. It also references "BHK-1878 -> INTEGRATION -> IMPLEMENTATION"; the supplied material does not define BHK-1878 further, so this review does not infer what that identifier means.

## Prototype completed in this package

The prototype preserves the supplied G1 substrate concept and implements a small, executable G2/G3 vertical slice:

G2:
Unknown -> ResearchRequest -> Provider -> Dispatch -> Run -> SourceSnapshot -> Evidence

G3:
Evidence -> Claim -> Contradiction -> Verification -> Knowledge

The prototype also adds:
- content hashes on nodes;
- revision records for status changes;
- typed relationships;
- source/provider metadata;
- deterministic offline providers;
- an independent-provider verification gate;
- contradiction recording;
- promotion of verified claims into Knowledge;
- graph-wide audit checks;
- repeatable tests and a demo.

## Findings: what is missing or should be hardened

### 1. Provenance needs an explicit activity/agent model
The current graph has providers, dispatches and runs, but the semantics are still application-specific. W3C PROV models entities, activities and agents, including derivation and responsibility. TBOHK should eventually represent these concepts directly so provenance can survive across tools, transformations and organizations.

### 2. A provider is not an independent source
Two providers may return the same upstream publisher, dataset, or copied article. TBOHK therefore needs source lineage and independence analysis before treating multiple observations as independent corroboration.

### 3. Evidence must point to a precise observation
A whole source snapshot is too coarse. Evidence should contain a locator or span, extraction method, relevant text/data, transformation history, and the proposition it actually supports.

### 4. Claims need a structured semantic representation
Free text is useful for humans but weak for contradiction detection, temporal reasoning and machine verification. Introduce a structured claim form such as:
subject / predicate / object-or-value / qualifiers / scope / time / units / modality / uncertainty.

### 5. Truth needs a temporal model
A claim may be true at one time and false later. Add observation time, publication time, retrieval time, valid-from, valid-until, freshness policy and supersession semantics.

### 6. Verification must be policy-driven
The prototype's two-provider rule is deliberately simple. The real engine should select a verification policy by claim class and risk. Some claims need one authoritative primary source; others need independent replications; some should never be automatically verified.

### 7. Contradiction is not merely an edge
A contradiction may be caused by time, scope, definitions, units, measurement error, source revision, or genuine disagreement. TBOHK needs conflict sets and explicit reconciliation attempts while preserving unresolved conflicts.

### 8. Uncertainty needs first-class representation
Statuses alone do not capture uncertainty. Add confidence/evidential strength as structured metadata, while avoiding a misleading single scalar when the uncertainty is multidimensional.

### 9. Negative knowledge needs first-class treatment
"No evidence found" must not silently become "false." Research failures, inaccessible sources, conflicting observations and absence-of-evidence should have distinguishable states.

### 10. Search completeness must be measurable
A research run should record query, search strategy, providers consulted, result counts, filters, failures, cutoff time, and stopping condition. Otherwise a claim of "research completed" is difficult to audit.

### 11. Source quality should be contextual, not a universal score
Source quality depends on claim type. Authority, recency, primary-vs-secondary status, methodological transparency, replication, conflict of interest, and provenance should be represented separately.

### 12. Governance must begin before autonomy
G6 cannot be treated as something added after G9. Authority boundaries should constrain research, reasoning and tool use from the beginning. Capability must never imply permission.

### 13. External actions require a separate action ledger
An eventual autonomous system needs to distinguish observation, analysis, recommendation, approval, execution and post-action verification. Every consequential action should have a principal, authority grant, target, expected effect, actual effect and rollback/compensation path.

### 14. Self-healing needs independent validation
A repair system must not be able to repair the mechanism that decides whether the repair is valid and then certify itself. Repairs should be proposed, evaluated by a separate validation path, authorized within policy, applied, observed and reversible.

### 15. Learning must be evaluation-isolated
If TBOHK changes the policy that evaluates TBOHK, the evaluation can become self-referential. Maintain fixed or independently governed evaluation suites and compare versions across checkpoints.

### 16. Security is a first-class requirement
Untrusted source text must never become trusted instruction. Future research/tool layers need isolation against prompt injection, malicious documents, poisoned data, credential exposure, unauthorized tool use and supply-chain compromise.

### 17. Memory architecture needs lifecycle semantics
Knowledge should have identity, versions, dependencies, invalidation triggers, expiration rules, provenance, and a mechanism for rebuilding derived knowledge when foundational evidence changes.

### 18. The graph needs dependency-aware invalidation
If a source snapshot becomes stale or contradicted, TBOHK should discover every downstream claim, conclusion, decision and plan affected by that change.

### 19. Audit needs severity and blast radius
The current audit returns problems. A mature audit engine should return invariant ID, severity, affected nodes, dependency path, first observed checkpoint, proposed remediation and whether the issue blocks release.

### 20. Checkpoints should become cryptographically identifiable
A release/checkpoint should have a manifest of schema version, code version, invariant registry version, database hash/manifest, test results and dependency versions.

## External research cross-check

W3C PROV is directly relevant. Its model separates entities, activities and agents and explicitly supports derivation, responsibility, roles and plans. That suggests TBOHK's provenance model should grow beyond a generic edge graph toward explicit activity/agent semantics.

NIST AI RMF organizes trustworthy AI risk work into Govern, Map, Measure and Manage, with continuous lifecycle treatment, testing, uncertainty, documentation and independent review. This supports making governance and measurement cross-cutting rather than postponing them until after autonomy.

ISO/IEC 42001 defines an AI management system around establishing, implementing, maintaining and continually improving organizational AI controls, with traceability and transparency among its concerns. That aligns with TBOHK's emphasis on checkpoints, audit and reversible improvement.

## Recommended architecture before G4

1. Introduce first-class Agent, Activity, Source, SourceSnapshot, Observation, EvidenceSpan, VerificationPolicy, ConflictSet, AuthorityGrant, Action, Evaluation, ChangeProposal and Checkpoint entities.
2. Add immutable, content-addressed source snapshots.
3. Add a temporal validity model.
4. Add structured claims beside human-readable claim text.
5. Add an independence graph and shared-origin detection.
6. Add a verification-policy engine instead of hard-coded verification thresholds.
7. Add an invariant registry with severity, dependency scope and release-blocking behavior.
8. Add capability/authority tokens for external actions.
9. Add checkpoint manifests and rollback.
10. Add evaluation isolation before implementing self-improvement.

## Strategic conclusion

The supplied architecture has a coherent core idea: TBOHK should not merely generate answers; it should maintain a continuously challenged, provenance-preserving representation of what it currently knows, what it does not know, why it believes something, what could invalidate it, and what authority it has to act.

The biggest architectural risk is **premature autonomy**. The project should make G2/G3 extremely rigorous, then use that foundation to constrain G4–G9. A system that researches, reasons, learns and repairs itself is only as trustworthy as the mechanisms that keep evidence, provenance, uncertainty, authority and change history distinct.
