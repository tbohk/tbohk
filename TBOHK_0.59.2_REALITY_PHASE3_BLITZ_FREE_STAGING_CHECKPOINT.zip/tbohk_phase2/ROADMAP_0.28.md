# TBOHK 0.28 — Structural Assurance Milestone

## Objective

Make the substrate explicit, inspectable and recoverable before adding the full knowledge workspace.

## Delivered in 0.28

- formal invariant registry
- explicit status transition matrix
- canonical serialization contract
- monotonic schema migration ledger
- signed append-only external checkpoint anchors
- independent database verifier CLI
- corruption/recovery drill harness
- threat model and trust-boundary documentation
- self-care checks for migration and transition integrity
- expanded release evidence and savepoint package

## Still ahead

### 0.29 — Knowledge Workspace
Question workspace, source viewer, claim admission, conflicts, timeline, explanation traces, graph explorer and human review queues.

### 0.30 — Ingestion
Content-addressed artifacts, parsers, extraction provenance, document sandboxing, provider abstraction, deduplication and background jobs.

### 0.31 — Intelligence
Auditable model adapters, structured extraction, claim normalization, contradiction candidates, retrieval acceleration and evaluation isolation.

### 0.32 — Production substrate
Identity/workspaces, PostgreSQL, object storage, queues, secrets/key custody, observability and operational recovery.

## Exit criteria

The system may move into the workspace phase when the 0.28 assurance suite passes, external anchors verify, migration history is contiguous, state-transition audit is clean, and a corruption drill demonstrates detection by both primary and independent paths.
