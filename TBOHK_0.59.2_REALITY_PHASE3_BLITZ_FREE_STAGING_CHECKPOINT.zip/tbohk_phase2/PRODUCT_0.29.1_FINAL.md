# TBOHK 0.29.1 — Product Contract

## Product promise

TBOHK is a question-centered, multi-account knowledge workspace. It helps a person move from a question to an inspectable knowledge state without silently converting generated text, copied sources, or unresolved disagreement into truth.

The primary loop is:

**Ask → inspect → research → challenge → review → monitor → recover**

## Account and billing model

TBOHK now has a real account boundary. Each account has:

- its own user identity and API/session tokens;
- isolated SQLite knowledge storage;
- its own subscription/plan state;
- an atomic calendar-month ask counter;
- an account-level usage view.

Passwords are stored using salted `scrypt` hashes. Browser sessions keep the issued API token in `sessionStorage`.

The billing integration is provider-backed through Stripe-compatible Checkout, Billing Portal and signed webhook flows. Paid plans are not activated merely because a user selects them: the account changes plan only after a verified billing event.

## User experience

The application opens to a focused home workspace with:

- system health and knowledge-state metrics;
- account ask usage;
- a one-click **Ask a question** entry point;
- a question workspace that shows existing claims, evidence, independent evidence, conflicts and next actions;
- bounded research with explicit public URLs and visible provenance;
- a searchable knowledge browser;
- an investigation workspace for competing hypotheses;
- a human review queue for proposed claims and unresolved conflicts;
- an assurance workspace for audit, release, self-care, migrations and invariants;
- a pricing page with live account billing actions.

## Pricing

USD, billed monthly. An **ask** is a question submitted to TBOHK. Ask caps reset automatically each calendar month.

| Plan | Price | Monthly asks | Intended use |
|---|---:|---:|---|
| Free | $0/month | 25 | Core TBOHK knowledge workspace and audit trail |
| Pro | $10/month | 250 | Regular research and decision work, with API access and verified backups |
| Unlimited | $20/month | 1,000 cap | Intensive use with the highest monthly ask allowance |

Only these three plans exist in the product catalog.

## Ask metering

A successful `/workspace` question consumes exactly one ask. Consumption is atomic and account-scoped. Once the current month's allowance is exhausted, TBOHK returns HTTP 429 with the account's used and allowed counts. A new calendar month starts with a zero counter without requiring a background reset job.

## Billing behavior

- Free accounts are immediately active.
- Pro and Unlimited upgrades begin through a hosted billing checkout.
- Stripe webhook signatures are verified before subscription state is changed.
- Subscription/customer identifiers are stored with the account.
- Subscription deletion returns the account to Free.
- Billing failures do not silently grant a higher plan.
- Billing configuration is supplied through deployment secrets; credentials are never embedded in the application bundle.

## Review behavior

- Proposed claims remain proposed until the verification policy succeeds.
- Verification requires the configured evidence/provenance policy.
- Conflicts can be explicitly deferred, accepted, rejected, scope-split or superseded through the governed conflict workflow.
- Every review action records the reviewer and rationale where applicable.
- No UI action bypasses protected state-transition rules.

## Answer presentation

The Ask workflow produces a readable answer view from account-scoped knowledge. Each answer item displays its epistemic status, support level, and cited source links. When ingested public HTML exposes usable media, related images and videos are presented with links back to the originating source. The interface keeps uncertainty, unresolved claims, and the next research/review actions visible instead of presenting unsupported text as fact.

Answer presentation is progressive: question → current answer → evidence/source inspection → uncertainty/conflicts → research → review → re-check. External media URLs are restricted to HTTP(S) presentation targets, and source links open in a separate browser context with `noopener noreferrer`.

## Research boundary

The current release accepts explicit public `http://` and `https://` URLs. It records source identity, origin and retrieval information. It does not silently expand a question into arbitrary web browsing.

## Production data boundary

The deployment keeps the account registry separate from account knowledge databases. Production backups now include the registry and every account knowledge database as one retained snapshot set. The service account is permitted to write only the designated application data paths.
