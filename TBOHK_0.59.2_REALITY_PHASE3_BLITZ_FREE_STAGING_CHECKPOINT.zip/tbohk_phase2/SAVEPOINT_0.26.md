# TBOHK 0.26.0 Savepoint

This savepoint marks the transition from the recovered hardened prototype to the first real operator-facing application surface.

## Added

- Real operator console replacing the minimal proof-of-concept home page.
- Overview dashboard.
- Research workspace.
- Knowledge browser.
- Gaps/conflicts workspace.
- Investigation workspace.
- Assurance workspace.
- Current-state architecture animation.
- Roadmap describing the remaining path from substrate to application.

## Boundaries

This is not the finished TBOHK product. Remaining major gaps include human review workflows, file/document ingestion, broad search providers, auditable model adapters, multi-user identity/workspaces, production persistence, background jobs, production secret custody and external security review.
