# TBOHK Continual Learning & Controlled Self-Improvement — 0.29.1

## Purpose
TBOHK now has a controlled learning plane that turns operational experience into auditable learning signals without allowing generated knowledge or learned changes to self-authorize deployment.

## Components
- `tbohk/learning_core.py` — Experience Store, self-model, learning planner, candidate registry, promotion gate.
- `tbohk/learning.py` — evaluation-suite/evaluation evidence used by candidate promotion.
- API endpoints under `/learning/*` — dashboard, experience recording, learning plan, candidate creation, promotion gate.
- Learning Lab in the web UI.

## Learning loops
1. **Observe:** workspace, research, prediction and prediction-outcome operations record structured experience.
2. **Diagnose:** failures and corrections are grouped into recurring task patterns.
3. **Plan:** recurring failures/corrections become prioritized learning work.
4. **Evaluate:** candidate changes must use the same immutable evaluation suite as the baseline.
5. **Challenge:** adversarial and security evidence are explicit promotion gates.
6. **Optimize:** latency regression has a configurable promotion budget.
7. **Promote:** approval changes candidate state only; it does not deploy code or replace a production model.
8. **Rollback:** production deployment remains a separate release operation, preserving the existing release/recovery controls.

## Safety invariants
- User feedback is a learning signal, not automatic evidence of truth.
- Learning telemetry is fail-open for availability: telemetry failure cannot break a primary user operation.
- Dashboard reads are observational and do not mutate the knowledge graph.
- Candidate and baseline evaluation suites must match.
- Both baseline and candidate evaluations must pass.
- Candidate score cannot regress against baseline.
- Adversarial and security gates must pass.
- Latency regression cannot exceed the promotion budget.
- Approved candidates are still release artifacts; self-approval is not deployment authority.

## Current boundary
This is a production-grade **continual-learning control plane**, not autonomous neural-network weight retraining. Trainable adapters, model selection and offline training workers can be attached behind the candidate interface without weakening the authority boundary.

## Verification
- 622 automated tests passing.
- 7,524 production statements at 100% coverage.
- Python compilation passing.
- UI JavaScript syntax passing.
- Chromium acceptance: 10 views × 6 viewport widths.
- Live HTTP learning smoke passing.


## Executable learning laboratory

The learning control plane now includes two executable, auditable primitives:

- **Replay batches**: recorded experiences can be replayed deterministically with a SHA-256 batch manifest. Replay is observational and does not mutate the graph.
- **Fixed benchmark execution**: the existing deterministic G4.7 reasoning corpus can be run from the Learning Lab and recorded as a `BenchmarkRun`. Benchmark results are evidence for evaluation, not automatic authorization to change production behavior.
- **Promotion remains gated**: candidate changes still require the same evaluation suite, passing baseline/candidate evaluations, adversarial and security checks, and the configured latency budget.

This is the bridge from learning telemetry to executable evaluation. It is intentionally not autonomous neural-weight training or autonomous deployment. Trainable adapters, model/router experiments, or offline training workers can be attached behind the candidate/evaluation boundary without weakening the production authority boundary.

## Isolated adapter experiments

The Learning Lab now includes a deterministic, dependency-light text adapter experiment runner. It consumes only a recorded `LearningDataset`, trains on its training partition, evaluates only on the held-out validation partition, and records a content-addressed `LearningArtifact` plus an `Evaluation` node. It does not execute arbitrary user code, mutate production models, or deploy artifacts. Candidate readiness remains subordinate to the existing promotion gate and release process.

## Controlled canary and rollback

The Learning Lab now supports a deterministic canary evidence layer. A candidate-ready isolated experiment can be evaluated against observed error rate and latency budgets. The canary records a content-addressed `LearningCanary`; if a budget is exceeded it records a `LearningRollback` linked through the existing reversible relation. This is release evidence and rollback simulation only: it does not alter production routing, code, model weights, or deployment state.

Safety boundary:
- candidate must be `candidate_ready`
- observations must be positive
- error rate and latency budgets are explicit
- latency regression is measured against an explicit baseline
- rollback decisions are recorded and auditable
- no canary operation grants deployment authority

## Release control integration

Learning artifacts now flow through an explicit release-control boundary:

1. A candidate-ready experiment plus a continuing canary produces a signed release manifest.
2. Deployment authorization requires a separate Ed25519 authorization signature and named operator.
3. Authorized releases may be staged at an explicit traffic percentage.
4. Health gates evaluate observations, error-rate and latency budgets.
5. Failed health gates create immutable rollback evidence; successful releases can be explicitly completed.
6. The release-control service records state and provenance but does not deploy, alter production routing, or grant learning systems deployment authority.

Release signing and deployment authorization keys are configured separately. Missing authorization material fails closed for authorization.
