# TBOHK Account Security

The commercial foundation now includes:

- 30-day expiring API sessions.
- Explicit single-session logout and all-session revocation.
- Session inventory with creation, last-use, expiry, and revocation state.
- One-time email-verification tokens with 24-hour expiry.
- One-time password-reset tokens with 1-hour expiry.
- Password reset invalidates all existing sessions.
- Login throttling: repeated failures for an email-derived key are blocked for the remainder of the 15-minute window.
- Password-reset requests return the same response whether or not the account exists, preventing basic account enumeration.
- Tokens are stored only as SHA-256 hashes.

## HTTP endpoints

- `POST /account/verify-email`
- `POST /account/password-reset/request`
- `POST /account/password-reset/complete`
- `GET /account/sessions`
- `POST /account/sessions/revoke-all`
- `POST /account/logout`

## Operational note

The token lifecycle is implemented server-side. Actual delivery of verification/reset links requires a configured transactional email provider; no email credential or provider is embedded in the application artifact.
