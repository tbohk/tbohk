from __future__ import annotations
import sqlite3, sys
from pathlib import Path

if len(sys.argv) != 3:
    print('usage: tbohk_restore_verify.py BACKUP_DB RESTORE_DB', file=sys.stderr); raise SystemExit(2)
src, dst = Path(sys.argv[1]).expanduser().resolve(), Path(sys.argv[2]).expanduser().resolve()
if not src.is_file() or src == dst:
    print('invalid source/destination', file=sys.stderr); raise SystemExit(2)
dst.parent.mkdir(parents=True, exist_ok=True); dst.unlink(missing_ok=True)
a = sqlite3.connect(str(src)); b = sqlite3.connect(str(dst))
try:
    a.backup(b); b.commit()
    integrity = b.execute('PRAGMA integrity_check').fetchone()[0]
    fk = b.execute('PRAGMA foreign_key_check').fetchall()
    counts = {t:b.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in ('nodes','edges','events','revisions')}
finally:
    b.close(); a.close()
if integrity != 'ok' or fk:
    print(f'restore verification failed integrity={integrity!r} fk={fk!r}', file=sys.stderr); raise SystemExit(3)
print(f'restored={dst}\nintegrity=ok\nforeign_key_check=clean\ncounts={counts}')
