# TBOHK — The Book of Human Knowledge

## Reality Build 0.28.0

TBOHK is a provenance-preserving, uncertainty-aware, contradiction-preserving knowledge architecture that is now moving from hardened backend prototype to a usable application.

> **Observe → challenge → research → test → authorize → reality → learn**

### Current state

- **325 tests passing** in the recovered regression suite.
- Python compilation passes.
- Clean ReleaseAuditor passes.
- Clean SelfCareEngine passes.
- G0–G30 assurance architecture is implemented in the prototype.
- 0.28 adds the formal invariant registry, state-transition matrix, canonical serialization contract, monotonic schema migrations, signed external checkpoint anchors, an independent verifier path and recovery drills on top of the 0.27 foundation.
- The operator console remains the application shell while the next phase builds the human knowledge workspace.

> **Observe → challenge → research → test → authorize → reality → learn**

### Run

```bash
python -m pip install -e .
python run_tbohk.py
```

Then open `http://127.0.0.1:8000`.

Or:

```bash
tbohk web
```

### CLI

```bash
tbohk version
tbohk stats
tbohk audit
tbohk selfcare
tbohk backup /path/to/tbohk-backup.sqlite
tbohk invariants
tbohk migrations
tbohk drill
tbohk-verify /path/to/tbohk.sqlite
tbohk web
```

The CLI refuses a non-loopback bind unless `TBOHK_API_TOKEN` is configured.

### Architecture boundaries

- Evidence ≠ truth.
- Representation ≠ reality.
- Inference ≠ observation.
- Capability ≠ authority.
- Confidence ≠ probability of truth.
- Absence of evidence ≠ evidence of absence.
- Self-correction ≠ self-authorization.

### 0.28 structural assurance

The foundation now includes SQLite integrity/foreign-key checks, WAL/full synchronous operation for file databases, busy-timeout protection, forensic ledger behavior that never silently reconstructs missing chain entries, fail-closed auditing, structurally guarded checkpoints, verified SQLite backups and a non-destructive self-care engine.

See:

- `ROADMAP_0.28.md` — structural assurance milestone and next phases.
- `READINESS_MATRIX_0.27.md` — recovered subsystem readiness baseline.
- `HARDENING_REVIEW_0.28.md` — structural hardening review.
- `SAVEPOINT_0.28.md` — reproducible savepoint definition.
- `BUILD_REPORT_0.28.txt` — build validation summary.
- `TBOHK_current_0.28.gif` — current architecture narrative.
- `ARCHITECTURE_STATUS_0.28.json` — machine-readable state.
- `RECOVERED_README_0.25.md` — preserved historical README.

### What remains before the envisioned product

1. Human claim/evidence review workflows.
2. File/document ingestion and sandboxing.
3. Search-provider ecosystem.
4. Interactive knowledge graph and temporal visualization.
5. Auditable LLM/model adapters.
6. Multi-user identity and workspaces.
7. Background research/investigation jobs.
8. Production database/migrations and object storage.
9. Production key/secret custody and deployment controls.
10. Disaster-recovery exercises and external security review.

TBOHK is therefore **not finished**. The purpose of this build is to make the foundation harder to break before adding more capability.

## From-zero deployment

For a new Linux/systemd machine, start with `deploy/DEPLOY_FROM_ZERO.md` and run `deploy/install_systemd.sh /opt/tbohk` as root after verifying the release SHA-256. The installer provisions the service account, isolated Python 3.13 runtime, locked dependencies, generated secret, filesystem permissions, systemd units, backup policy, and startup preflight.


## Product contract

The finalized product, account, billing, ask-metering, and pricing contract is documented in `PRODUCT_0.29.1_FINAL.md`.

## Accounts, ask metering, and billing

The product now supports account-scoped knowledge storage, Free/Pro/Unlimited monthly ask metering, account login, and Stripe-backed paid subscriptions. See `BILLING_SETUP.md` for deployment configuration and webhook setup. See `PRODUCT_0.29.1_FINAL.md` for the product contract.

- `ROADMAP_COMMERCIAL_1.0.md` — commercial/store roadmap and release gates.

## Roadmap closure — 2026-09-27
The historical 0.26/0.27/0.28 and Commercial 1.0 roadmaps have been reconciled against the current 0.59.2 implementation. All implementable engineering items are closed and regression-tested; remaining commercial items are external activation gates requiring provider/store credentials, production infrastructure, legal review, or store approval. See `ROADMAP_CLOSURE_0.59.2.md`.
